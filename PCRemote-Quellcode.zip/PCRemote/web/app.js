(function () {
  'use strict';

  // ---------- helpers ----------

  const $ = (s, r) => (r || document).querySelector(s);
  const enc = encodeURIComponent;
  const PC = /[?&]pc=1/.test(location.search);
  // kind of device – each kind has its own tile size (a phone can't show what fits on an iPad); ?dev=… forces one
  const DEV = (/[?&]dev=(phone|tablet|pc)/.exec(location.search) || [])[1] ||
    (PC || !matchMedia('(any-pointer: coarse)').matches ? 'pc' : Math.min(screen.width, screen.height) >= 600 ? 'tablet' : 'phone');

  const LS = {
    get(k, d) { try { const v = localStorage.getItem('pcr.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('pcr.' + k, JSON.stringify(v)); } catch (e) { } },
    del(k) { try { localStorage.removeItem('pcr.' + k); } catch (e) { } }
  };

  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k === 'value') n.value = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(Infinity)) {
      if (c == null || c === false) continue;
      n.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return n;
  }

  const uid = () => Math.random().toString(36).slice(2, 10);
  const clone = o => JSON.parse(JSON.stringify(o));
  const getPath = (o, p) => p.split('.').reduce((x, k) => (x == null ? x : x[k]), o);

  function fmtTime(s) {
    s = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(sec).padStart(2, '0');
  }

  const ICONS = {
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
    next: '<path d="M5 5l10 7-10 7z"/><path d="M19 5v14"/>',
    prev: '<path d="M19 5L9 12l10 7z"/><path d="M5 5v14"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    shuffle: '<path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
    repeat: '<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
    repeat1: '<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/>',
    volume: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>',
    voldown: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>',
    mute: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M22 9l-6 6M16 9l6 6"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/>',
    micoff: '<path d="M2 2l20 20"/><path d="M15 9.3V5a3 3 0 0 0-5.7-1.3"/><path d="M9 9v3a3 3 0 0 0 4.9 2.3"/><path d="M19 10a7 7 0 0 1-1.1 3.8M5 10a7 7 0 0 0 11.4 5.4M12 17v5M8 22h8"/>',
    headphones: '<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3zM3 19a2 2 0 0 0 2 2h1v-6H3z"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    restart: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
    keyboard: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 13h.01M18 13h.01M10 13h4M7 16h10"/>',
    mouse: '<rect x="6" y="2" width="12" height="20" rx="6"/><path d="M12 6v4"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    gamepad: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01"/><path d="M17.3 5H6.7a4 4 0 0 0-4 3.6L2 15a3 3 0 0 0 5.3 2l1.4-1.6a2 2 0 0 1 1.5-.7h3.6a2 2 0 0 1 1.5.7l1.4 1.6A3 3 0 0 0 22 15l-.7-6.4A4 4 0 0 0 17.3 5z"/>',
    more: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    terminal: '<path d="M4 17l6-5-6-5M12 19h8"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
    zap: '<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>',
    type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
    refresh: '<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/>',
    window: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>',
    minimize: '<path d="M5 18h14"/>',
    maximize: '<rect x="4" y="4" width="16" height="16" rx="2"/>',
    left: '<path d="M15 18l-6-6 6-6"/>',
    right: '<path d="M9 18l6-6-6-6"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    down: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
    back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    camera: '<path d="M14.5 4h-5L7.5 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3.5z"/><circle cx="12" cy="13" r="3.5"/>',
    video: '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M22 8l-6 4 6 4z"/>',
    share: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4M12 13V7M9 10l3-3 3 3"/>',
    waves: '<path d="M2 12h2M6 8v8M10 5v14M14 8v8M18 10v4M22 12h0"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.4 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.8 2z"/>',
    phoneoff: '<path d="M10.7 13.3a16 16 0 0 0 3.4 2.6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.7 2v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3 4.2 2 2 0 0 1 5 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.4 2.1L9 9.9"/><path d="M22 2L2 22"/>',
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    star: '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>',
    crown: '<path d="M3 7l4.5 4L12 4l4.5 7L21 7l-2 11H5z"/><path d="M5 21h14"/>',
    bug: '<rect x="7" y="7" width="10" height="13" rx="5"/><path d="M9 7V5a3 3 0 0 1 6 0v2M3 13h4M17 13h4M4 7l3 2M20 7l-3 2M4 19l3-2M20 19l-3-2M12 11v9"/>',
    send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    flask: '<path d="M9 3h6M10 3v6L4.5 18.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7 15h10"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
    home: '<path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
    folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    record: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',
    wifi: '<path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M2 9a15 15 0 0 1 20 0M12 20h.01"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    puzzle: '<path d="M4 7h4a2 2 0 1 1 4 0h4v4a2 2 0 1 1 0 4v4H4v-4a2 2 0 1 0 0-4z"/>',
    qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM21 14v.01M14 21h.01M17 21h4v-4"/>',
    zoomin: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>',
    zoomout: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',
    fullscreen: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    store: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/>',
    code: '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12"/>',
    gauge: '<path d="M12 14l4-4"/><path d="M3.3 19a10 10 0 1 1 17.4 0"/>',
    rocket: '<path d="M4.5 16.5c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2.1-.1-2.9a2.2 2.2 0 0 0-2.9-.1z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.9A12.9 12.9 0 0 1 22 2c0 2.7-.8 7.5-6 11a22.4 22.4 0 0 1-4 2z"/><path d="M9 12H4s.6-3 2-4c1.6-1.1 5 0 5 0M12 15v5s3-.6 4-2c1.1-1.6 0-5 0-5"/>',
    devices: '<rect x="2" y="4" width="14" height="10" rx="2"/><rect x="17" y="8" width="5" height="12" rx="1"/><path d="M6 18h6"/>',
    resize: '<path d="M21 15v6h-6M21 21l-7-7M3 9V3h6M3 3l7 7"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-4"/>'
  };
  const PICK_ICONS = ['zap', 'play', 'next', 'prev', 'volume', 'mute', 'mic', 'micoff', 'headphones', 'music', 'heart', 'gamepad', 'keyboard', 'mouse',
    'monitor', 'window', 'camera', 'video', 'record', 'scissors', 'share', 'message', 'phone', 'phoneoff', 'globe', 'terminal', 'code', 'type', 'copy',
    'clipboard', 'folder', 'save', 'home', 'star', 'bell', 'sun', 'moon', 'lock', 'power', 'restart', 'logout', 'refresh', 'sliders', 'cpu', 'gauge',
    'rocket', 'wifi', 'users', 'store', 'download', 'search', 'x'];
  const COLORS = ['violet', 'cyan', 'pink', 'orange', 'yellow', 'green', 'red', 'slate'];

  const svg = name => '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.zap) + '</svg>';
  function ic(name, cls) {
    const s = document.createElement('span');
    s.className = 'ic' + (cls ? ' ' + cls : '');
    s.innerHTML = svg(name);
    return s;
  }
  function setIc(node, name, cls) { node.innerHTML = ''; node.append(ic(name, cls)); }
  // live values come in every second or two – only touch the page when something really changed (saves layout work)
  function setText(node, s) { s = s == null ? '' : String(s); if (node.textContent !== s) node.textContent = s; }
  const tic = (name, color) => el('span', { class: 't-ic c-' + (color || 'violet') }, ic(name));

  function buzz(ms) {
    if (S.haptics && navigator.vibrate) try { navigator.vibrate(ms || 8); } catch (e) { }
  }

  // action: optional [label, fn] – a button inside the message (e.g. "Ansehen")
  function toast(msg, kind, action) {
    const box = $('#toasts');
    while (box.children.length > 2) box.firstChild.remove();
    const t = el('div', { class: 'toast ' + (kind || '') + (action ? ' has-act' : '') }, msg,
      action ? el('button', { class: 'toast-act', type: 'button', onclick: () => { t.remove(); action[1](); } }, action[0]) : null);
    box.append(t);
    setTimeout(() => t.classList.add('out'), kind === 'err' ? 4200 : 2400);
    setTimeout(() => t.remove(), kind === 'err' ? 4600 : 2800);
  }

  function flash(n) { n.classList.remove('fire'); void n.offsetWidth; n.classList.add('fire'); clickSound(); }

  // A small show on every tap: a soft wave spreads from the finger (only size and transparency move – costs nothing).
  const RIPPLE = '.tile:not(.add), .btn, .abtn, .icon-btn, .pick-item, .chip, .page-chip, .tab, .app-card, .addon-card, .add-card, .dbig, .seg button, .clip-card, .np-btn, .pl-btn, .bg-opt';
  document.addEventListener('pointerdown', e => {
    if (e.button || !e.target.closest) return;
    const t = e.target.closest(RIPPLE);
    if (!t || t.disabled || t.closest('.deck.editing')) return;
    const r = t.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2.4;
    const w = el('span', { class: 'rpl', 'aria-hidden': 'true' },
      el('i', { style: 'width:' + s + 'px;height:' + s + 'px;left:' + (e.clientX - r.left - s / 2) + 'px;top:' + (e.clientY - r.top - s / 2) + 'px' }));
    t.append(w);
    setTimeout(() => w.remove(), 700);
  }, { passive: true });

  // Tap + long-press on one element; cancels when the finger moves (so scrolling never triggers it).
  function press(node, o) {
    let timer = null, fired = false, down = false, sx = 0, sy = 0;
    if (!node.matches('button,a,input')) { node.tabIndex = 0; node.setAttribute('role', 'button'); }
    // o.hold: show a filling bar while the finger stays down (for "hold = close"), o.longMs: how long to hold
    const cancel = () => { down = false; clearTimeout(timer); node.classList.remove('pressed', 'holding'); };
    node.addEventListener('pointerdown', e => {
      if (e.button) return;
      down = true; fired = false; sx = e.clientX; sy = e.clientY;
      node.classList.add('pressed');
      if (o.long) {
        if (o.hold) node.classList.add('holding');
        timer = setTimeout(() => { fired = true; cancel(); buzz(20); o.long(); }, o.longMs || 480);
      }
    });
    node.addEventListener('pointermove', e => { if (down && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
    node.addEventListener('pointerup', () => { if (!down) return; const ok = !fired; cancel(); if (ok && o.tap) o.tap(); });
    node.addEventListener('pointercancel', cancel);
    node.addEventListener('pointerleave', cancel);
    node.addEventListener('contextmenu', e => { e.preventDefault(); if (o.menu && PC) o.menu(); else if (o.long && PC) o.long(); });
    node.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && o.tap) { e.preventDefault(); o.tap(); } });
  }

  // Range input that throttles sends and ignores server updates while the user is touching it.
  function makeRange(o, onSend, onLive) {
    const r = el('input', { type: 'range', class: 'range', min: o.min, max: o.max, step: o.step });
    let dragging = false, lastSend = 0, timer = null, pending = null, touched = 0;
    const paint = () => {
      const min = +r.min, max = +r.max;
      r.style.setProperty('--p', (max > min ? (r.value - min) / (max - min) * 100 : 0) + '%');
    };
    const send = () => { timer = null; if (pending == null) return; const v = pending; pending = null; lastSend = Date.now(); onSend(v); };
    r.addEventListener('input', () => {
      paint();
      pending = +r.value;
      if (onLive) onLive(+r.value);
      const wait = (o.throttle || 70) - (Date.now() - lastSend);
      if (wait <= 0) send(); else if (!timer) timer = setTimeout(send, wait);
    });
    const end = () => { dragging = false; touched = Date.now(); };
    r.addEventListener('pointerdown', () => { dragging = true; });
    r.addEventListener('pointerup', end);
    r.addEventListener('pointercancel', end);
    r.addEventListener('change', end);
    r.busy = () => dragging || Date.now() - touched < 1500;
    r.setValue = v => {
      if (r.busy() || v == null) return;
      r.value = v;
      paint();
    };
    r.setMax = m => { if (+r.max !== m) { r.max = m; paint(); } };
    paint();
    return r;
  }

  // Volume bar like the phone's own control centre: the fill is the level, a tap jumps right there, dragging fine-tunes
  // from where it is (no jump when the finger lands) – also on iPhone, where a normal slider only moves when you hit its
  // small knob. A short vibration every 10 %. Same interface as makeRange (value, setValue, busy, setMax, input/change).
  function makeVol(o, onSend, onLive) {
    const min = +o.min, step = +o.step || 1;
    let max = +o.max, value = min;
    const fill = el('i', { class: 'vb-fill' });
    const bar = el('div', { class: 'vbar', role: 'slider', tabindex: '0', 'aria-valuemin': min, 'aria-valuemax': max }, fill);
    let dragging = false, moved = false, touched = 0, lastSend = 0, timer = null, pending = null, x0 = 0, v0 = 0, rect = null;
    const paint = () => {
      const p = max > min ? Math.max(0, Math.min(100, (value - min) / (max - min) * 100)) : 0;
      fill.style.transform = 'translateX(' + (p - 100) + '%)'; // moving, not resizing: the graphics chip does that alone
      bar.setAttribute('aria-valuenow', value);
    };
    const send = () => { timer = null; if (pending == null) return; const v = pending; pending = null; lastSend = Date.now(); onSend(v); };
    const queue = () => {
      pending = value;
      const wait = (o.throttle || 70) - (Date.now() - lastSend);
      if (wait <= 0) send(); else if (!timer) timer = setTimeout(send, wait);
    };
    const snap = v => Math.max(min, Math.min(max, Math.round((v - min) / step) * step + min));
    const tenth = v => Math.floor((v - min) / (max - min || 1) * 10);
    const userSet = v => {
      v = snap(v);
      if (v === value) return;
      if (tenth(v) !== tenth(value)) buzz(4);
      value = v;
      paint();
      if (onLive) onLive(v);
      queue();
    };
    // a value set from outside (+/− buttons): the same events as a normal slider
    bar.addEventListener('input', () => { paint(); if (onLive) onLive(value); queue(); });
    bar.addEventListener('change', () => { touched = Date.now(); });
    bar.addEventListener('pointerdown', e => {
      if (e.button || bar.disabled) return;
      dragging = true; moved = false; x0 = e.clientX; v0 = value; rect = bar.getBoundingClientRect();
      bar.classList.add('drag');
      try { bar.setPointerCapture(e.pointerId); } catch (x) { }
    });
    bar.addEventListener('pointermove', e => {
      if (!dragging) return;
      const dx = e.clientX - x0;
      if (!moved && Math.abs(dx) < 4) return;
      moved = true;
      userSet(v0 + dx / Math.max(1, rect.width) * (max - min));
    });
    const end = e => {
      if (!dragging) return;
      dragging = false;
      bar.classList.remove('drag');
      if (!moved && e.type === 'pointerup' && rect) userSet(min + (e.clientX - rect.left) / Math.max(1, rect.width) * (max - min));
      touched = Date.now();
    };
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end); // the page scrolls instead (finger went up/down): no jump
    const nudge = d => { userSet(value + d * Math.max(step, (max - min) / 50)); touched = Date.now(); };
    if (PC) bar.addEventListener('wheel', e => { if (bar.disabled) return; e.preventDefault(); nudge(e.deltaY < 0 ? 1 : -1); }, { passive: false });
    bar.addEventListener('keydown', e => {
      const d = e.key === 'ArrowRight' || e.key === 'ArrowUp' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowDown' ? -1 : 0;
      if (d) { e.preventDefault(); nudge(d); }
    });
    bar.busy = () => dragging || Date.now() - touched < 1500;
    bar.setValue = v => { if (bar.busy() || v == null) return; v = +v; if (v !== value) { value = v; paint(); } };
    bar.setMax = m => { if (max !== m) { max = m; bar.setAttribute('aria-valuemax', m); paint(); } };
    Object.defineProperty(bar, 'value', { get: () => value, set: v => { value = snap(+v); paint(); } });
    paint();
    return bar;
  }

  function sw(checked, onChange) {
    const i = el('input', { type: 'checkbox' });
    i.checked = !!checked;
    i.addEventListener('change', () => onChange(i.checked));
    return el('span', { class: 'sw' }, i, el('i'));
  }

  // Segmented tabs; returns the element. items: [[key, label]]
  function segTabs(items, cur, onPick, cls) {
    const seg = el('div', { class: 'seg' + (cls ? ' ' + cls : '') });
    items.forEach(([k, l]) => seg.append(el('button', { class: k === cur ? 'on' : '', 'data-k': k, onclick: () => {
      [...seg.children].forEach(c => c.classList.toggle('on', c.dataset.k === k));
      onPick(k);
    } }, l)));
    return seg;
  }

  const heading = (title, action) => el('div', { class: 'section-title' }, el('span', { class: 'grow' }, title), action || null);

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    const ta = el('textarea', { style: 'position:fixed;opacity:0;top:0' });
    ta.value = text;
    document.body.append(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { }
    ta.remove();
    return ok ? Promise.resolve() : Promise.reject();
  }

  // ---------- state + api ----------

  const S = {
    pin: LS.get('pin', null),
    token: PC ? null : LS.get('token', null), // this device's own key (the PC app itself just uses the PIN)
    name: '',
    local: false,
    layout: null,
    pageIdx: LS.get('deckPage', 0),
    groupPath: [], // ids of the groups opened on the deck (deck in deck)
    sel: null,     // edit mode: id of the tapped tile (shows its size bar)
    apps: [],
    st: {},
    vm: null,
    sp: { connected: false },
    editing: false,
    haptics: LS.get('haptics', true),
    deckCell: deckCellSetting(), // largest tile size in px on this device (0 = automatic: measured from the screen)
    online: true
  };

  // ---------- the same everywhere: settings that live on the PC and are shared by every device ----------
  // (tile size, VIP look, background incl. an own picture). Before the PC answered, the local copy is used.
  const SHARED = ['vipLook', 'bgChoice', 'bgImage']; // (the tile size is per device – see deckCellSetting)
  let uiPatch = {}, uiTimer = null;
  const Shared = {
    get(k, def) {
      const v = S.ui ? S.ui[k] : LS.get(k, undefined);
      return v === undefined || v === null ? def : v;
    },
    set(k, v) {
      if (!S.ui) S.ui = {};
      if (v == null) { delete S.ui[k]; LS.del(k); } else { S.ui[k] = v; LS.set(k, v); }
      uiPatch[k] = v == null ? null : v;
      S.uiPending = true;
      clearTimeout(uiTimer);
      uiTimer = setTimeout(pushShared, 250);
    }
  };
  async function pushShared() {
    const body = uiPatch;
    uiPatch = {};
    try { const r = await api('/api/ui', body); if (r && r.rev) S.rev = r.rev; }
    catch (e) { toast('Nicht gespeichert: ' + e.message, 'err'); }
    S.uiPending = Object.keys(uiPatch).length > 0;
  }

  class ApiError extends Error { constructor(m, s) { super(m); this.status = s; } }

  // for <img>/<video>/WebSocket addresses, which cannot send headers
  const authQ = () => S.token ? 'token=' + enc(S.token) : 'pin=' + enc(S.pin || '');

  // A readable name for this device, e.g. "Android-Handy (Chrome)"; can be renamed later.
  function deviceName() {
    const ua = navigator.userAgent;
    const os = /Android/i.test(ua) ? (/Mobile/i.test(ua) ? 'Android-Handy' : 'Android-Tablet') : /iPhone/i.test(ua) ? 'iPhone' : /iPad/i.test(ua) ? 'iPad'
      : /Windows/i.test(ua) ? 'Windows-PC' : /Mac OS/i.test(ua) ? 'Mac' : /Linux/i.test(ua) ? 'Linux' : 'Gerät';
    const m = /Android [\d.]+; ([^;)]+)\)/.exec(ua);
    const model = m && m[1].trim().length > 2 ? ' ' + m[1].trim() : '';
    const br = /SamsungBrowser/i.test(ua) ? 'Samsung Internet' : /EdgA?\//i.test(ua) ? 'Edge' : /Firefox|FxiOS/i.test(ua) ? 'Firefox' : /OPR\//i.test(ua) ? 'Opera'
      : /Chrome|CriOS/i.test(ua) ? 'Chrome' : /Safari/i.test(ua) ? 'Safari' : 'Browser';
    return os + model + ' (' + br + ')';
  }

  function saveToken(t) {
    S.token = t;
    LS.set('token', t);
    S.pin = null;
    LS.del('pin');
  }

  // Trade the PIN (typed or from the QR code) for this device's own key, once.
  async function pairWithPin(pin) {
    const r = await fetch('/api/pair', { method: 'POST', headers: { 'X-Pin': pin, 'Content-Type': 'application/json' }, body: JSON.stringify({ name: deviceName() }), cache: 'no-store' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.token) throw new ApiError(d.error || 'Fehler ' + r.status, r.status);
    saveToken(d.token);
  }

  async function api(path, body) {
    const opt = { headers: S.token ? { 'X-Token': S.token } : { 'X-Pin': S.pin || '' }, cache: 'no-store' };
    if (body !== undefined) {
      opt.method = 'POST';
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    let res;
    try { res = await fetch(path, opt); }
    catch (e) { setOnline(false); throw new ApiError('PC nicht erreichbar', 0); }
    setOnline(true);
    const xr = res.headers.get('X-Rev');
    if (xr) noteRev(+xr, true);
    noteClip(res.headers.get('X-Clip'));
    let data = null;
    try { data = await res.json(); } catch (e) { }
    if (!res.ok) {
      if (res.status === 401 && (S.pin || S.token)) logout(S.token ? 'Dieses Gerät wurde am PC entfernt – bitte neu verbinden.' : 'Die PIN stimmt nicht mehr – bitte neu eingeben.');
      throw new ApiError((data && data.error) || ('Fehler ' + res.status), res.status);
    }
    return data;
  }

  function prepare(a) {
    a = Object.assign({}, a);
    if (a.t === 'kill' && typeof a.procs === 'string') a.procs = a.procs.split(',').map(s => s.trim()).filter(Boolean);
    if (a.t === 'power') a.delay = +a.delay || 0;
    return a;
  }

  // A clip was saved – by key, voice, the tray or another phone: every device shows it (glow + message).
  let clipSeen = null;
  function noteClip(at) {
    if (at == null) return; // a PC Remote that doesn't tell yet
    if (clipSeen == null || at === clipSeen) { clipSeen = at; return; }
    clipSeen = at;
    const g = el('div', { class: 'clip-glow' });
    document.body.append(g);
    setTimeout(() => g.remove(), 1200);
    if (current === ClipsView) pollSoon();
    if (Date.now() - (S.clipBusy || 0) < 6000) return; // saved from this device – its own message follows
    buzz(30);
    toast('🎬 Clip gespeichert', null, ['Ansehen', () => show('clips')]);
  }

  async function act(a, opts) {
    opts = opts || {};
    if (a.t === 'display' && a.mode) { quickDisplay(a.mode); return { ok: true }; } // handled on the phone itself
    if (a.t === 'clipsave') S.clipBusy = Date.now();
    buzz();
    try {
      const r = await api('/api/action', prepare(a));
      if (r && r.msg && !opts.quiet) toast(r.msg);
      pollSoon();
      return r || { ok: true };
    } catch (e) {
      if (e.status !== 401) toast(e.message, 'err');
      return null;
    }
  }

  function setOnline(v) {
    if (S.online === v) return;
    S.online = v;
    document.body.classList.toggle('offline', !v);
    document.querySelectorAll('.status-text').forEach(s => { s.textContent = v ? 'Verbunden' : 'Getrennt – versuche erneut …'; });
  }

  const isLocal = () => ['localhost', '127.0.0.1', '[::1]', '::1'].includes(location.hostname);

  function appById(id) { return S.apps.find(a => a.id === id); }
  function appByProc(p) { return S.apps.find(a => a.procs.includes(p)); }
  function nameForProc(p) {
    if (p === 'system') return 'Systemklänge';
    const a = appByProc(p);
    return a ? a.name : p.charAt(0).toUpperCase() + p.slice(1);
  }

  function appIcon(o, name) {
    const box = el('span', { class: 'appic' });
    if (o.proc === 'system') { box.classList.add('sys'); box.append(ic('bell')); return box; }
    if (!o.id && !o.proc) { box.classList.add('letter'); box.textContent = (name || '?').trim().charAt(0).toUpperCase(); return box; }
    const src = '/api/icon?' + (o.id ? 'id=' + enc(o.id) : 'proc=' + enc(o.proc)) + '&' + authQ();
    const img = el('img', { src, alt: '', loading: 'lazy', draggable: 'false' });
    img.onerror = () => {
      box.innerHTML = '';
      box.classList.add('letter');
      box.textContent = (name || '?').trim().charAt(0).toUpperCase();
    };
    box.append(img);
    return box;
  }

  function procSet(d) {
    if (!d || !d.procs) return null;
    if (!d._ps) d._ps = new Set(d.procs);
    return d._ps;
  }
  function isRunning(a, d) {
    const ps = procSet(d);
    return !!(a && ps && a.procs.some(p => ps.has(p)));
  }

  // ---------- binds (volume / mute targets) ----------

  const PCT = { min: 0, max: 100, step: 1, toServer: v => v / 100, fromServer: v => Math.round(v * 100), fmt: v => Math.round(v * 100) + ' %' };
  const DB = { min: -60, max: 12, step: 0.5, toServer: v => v, fromServer: v => v, fmt: v => (v > 0 ? '+' : '') + (+v).toFixed(1) + ' dB' };

  function vmParse(p) {
    const m = /^(Strip|Bus)\[(\d)\]\.(\w+)$/.exec(p || '');
    return m ? { kind: m[1], i: +m[2], prop: m[3], base: m[1] + '[' + m[2] + ']' } : null;
  }
  function vmName(m) {
    if (!m) return 'Voicemeeter';
    const vm = S.vm;
    if (m.kind === 'Strip') {
      const s = vm && vm.strips && vm.strips[m.i];
      return s ? s.label : 'Eingang ' + (m.i + 1);
    }
    const b = vm && vm.buses && vm.buses[m.i];
    return 'Bus ' + (b ? b.name : m.i + 1);
  }
  function vmParam(d, p) {
    const vm = d && d.vm;
    if (!vm || !vm.ok || !vm.params || !(p in vm.params)) return null;
    return vm.params[p];
  }

  function bindInfo(bind) {
    bind = bind || 'master';
    if (bind === 'master') return Object.assign({ label: 'Lautstärke', icon: 'volume', offIcon: 'mute', read: d => d && d.master, muteBind: 'master' }, PCT);
    if (bind === 'mic') return Object.assign({ label: 'Mikrofon', icon: 'mic', offIcon: 'micoff', read: d => d && d.mic, muteBind: 'mic' }, PCT);
    if (bind === 'spotify') return Object.assign({
      label: 'Spotify', icon: 'music', offIcon: 'music', proc: 'spotify', muteBind: null, idle: 'Spotify nicht aktiv',
      read: d => d && d.spotify && d.spotify.device && d.spotify.device.volume != null ? { v: d.spotify.device.volume / 100, m: false } : null
    }, PCT);
    if (bind.startsWith('app:')) {
      const p = bind.slice(4);
      return Object.assign({ label: nameForProc(p), proc: p, icon: 'volume', offIcon: 'mute', read: d => d && d.apps && d.apps[p], muteBind: bind, idle: 'Kein Ton aktiv' }, PCT);
    }
    if (bind.startsWith('vm:')) {
      const p = bind.slice(3), m = vmParse(p);
      const label = vmName(m) + (m && m.prop !== 'Gain' && m.prop !== 'Mute' ? ' → ' + m.prop : '');
      const muteP = m ? m.base + '.Mute' : p;
      return Object.assign({
        label, icon: 'sliders', offIcon: 'mute', muteBind: 'vm:' + muteP, idle: 'Voicemeeter nicht verbunden', vm: true,
        read: d => { const v = vmParam(d, p); return v == null ? null : { v, m: vmParam(d, muteP) > 0.5 }; }
      }, DB);
    }
    return Object.assign({ label: bind, icon: 'volume', read: () => null }, PCT);
  }

  // What a toggle shows: "alert" = active means muted, otherwise active means routed/on.
  function toggleInfo(bind) {
    bind = bind || 'mic';
    if (bind === 'master') return { label: 'Ton', on: 'volume', off: 'mute', alert: true, read: d => d && d.master ? d.master.m : null };
    if (bind === 'mic') return { label: 'Mikrofon', on: 'mic', off: 'micoff', alert: true, read: d => d && d.mic ? d.mic.m : null };
    if (bind.startsWith('discord:')) {
      const k = bind.slice(8);
      return {
        label: k === 'deaf' ? 'Discord Ton' : 'Discord Mikro', on: k === 'deaf' ? 'headphones' : 'mic', off: k === 'deaf' ? 'mute' : 'micoff', alert: true,
        read: d => d && d.discord && d.discord.ok && typeof d.discord[k] === 'boolean' ? d.discord[k] : null
      };
    }
    if (bind.startsWith('app:')) {
      const p = bind.slice(4);
      return { label: nameForProc(p), on: 'volume', off: 'mute', alert: true, proc: p, read: d => d && d.apps && d.apps[p] ? d.apps[p].m : null };
    }
    if (bind.startsWith('vm:')) {
      const p = bind.slice(3), m = vmParse(p);
      const mute = m && m.prop === 'Mute';
      return {
        label: vmName(m) + (mute ? '' : ' → ' + (m ? m.prop : p)), on: mute ? 'volume' : 'headphones', off: mute ? 'mute' : 'headphones', alert: mute,
        read: d => { const v = vmParam(d, p); return v == null ? null : v > 0.5; }
      };
    }
    return { label: bind, on: 'zap', off: 'zap', read: () => null };
  }

  // ---------- actions ----------

  const MEDIA_KEYS = [['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['stop', 'Stopp'],
    ['volup', 'Lauter'], ['voldown', 'Leiser'], ['mute', 'Ton aus / an']];
  const MEDIA_SRC = [['', 'Was gerade läuft'], ['spotify', 'Nur Spotify'], ['chrome', 'Nur Chrome'], ['msedge', 'Nur Edge'], ['firefox', 'Nur Firefox']];
  const POWER = [['lock', 'Sperren'], ['monitoroff', 'Monitor aus'], ['sleep', 'Energiesparen'], ['hibernate', 'Ruhezustand'],
    ['restart', 'Neu starten'], ['shutdown', 'Herunterfahren'], ['logoff', 'Abmelden'], ['cancel', 'Herunterfahren abbrechen']];
  const POWER_ICON = { lock: 'lock', monitoroff: 'monitor', sleep: 'moon', hibernate: 'moon', restart: 'restart', shutdown: 'power', logoff: 'logout', cancel: 'x' };
  const SPOTIFY_CMDS = [['toggle', 'Play / Pause'], ['next', 'Nächster Song'], ['prev', 'Vorheriger Song'], ['like', 'Song liken / entliken'],
    ['volup', 'Lauter (in Spotify)'], ['voldown', 'Leiser (in Spotify)'], ['shuffle', 'Shuffle an / aus'], ['repeat', 'Wiederholen umschalten']];
  const SPOTIFY_ICON = { toggle: 'play', next: 'next', prev: 'prev', like: 'heart', volup: 'volume', voldown: 'voldown', shuffle: 'shuffle', repeat: 'repeat' };
  const DISCORD_CMDS = [['mute', 'Mikro stumm'], ['deaf', 'Ton aus (Deafen)'], ['disconnect', 'Auflegen'], ['camera', 'Kamera an / aus'],
    ['screen', 'Bildschirm teilen'], ['noise', 'Rauschunterdrückung'], ['soundboard', 'Soundboard']];
  const DISCORD_ICON = { mute: 'micoff', deaf: 'headphones', disconnect: 'phoneoff', camera: 'video', screen: 'share', noise: 'waves', soundboard: 'music' };
  const MACRO_HELP = 'Eine Zeile pro Schritt:\nkey ctrl+shift+m · text Hallo · wait 500 · launch notepad · url https://… · media next · mute mic · unmute mic · toggle mic · volume 40 · app <app-id> · kill <prozess> · cmd <befehl> · click left · discord mute · spotify next · spotify volume 40 · appkey chrome ctrl+t · riot valorant';
  const optLabel = (list, v, def) => (list.find(x => x[0] === v) || [0, def])[1];

  const ACTS = {
    media: { name: 'Medientaste', icon: 'play', fields: [['k', 'Taste', 'select', MEDIA_KEYS], ['src', 'Für welche App?', 'select', MEDIA_SRC]], label: a => optLabel(MEDIA_KEYS, a.k, 'Medien'), iconFor: a => ({ next: 'next', prev: 'prev', stop: 'stop', volup: 'volume', voldown: 'voldown', mute: 'mute' })[a.k] || 'play' },
    key: { name: 'Tastenkürzel (global)', icon: 'keyboard', fields: [['keys', 'Tasten', 'keys']], label: a => prettyKeys(a.keys) || 'Tastenkürzel' },
    appkey: { name: 'Taste an eine bestimmte App', icon: 'keyboard', fields: [['id', 'App', 'appsel'], ['keys', 'Tasten', 'keys'], ['back', 'Danach zurück zum vorherigen Fenster', 'check']], hint: 'Die App wird kurz nach vorne geholt und bekommt die Tasten – auch wenn gerade ein anderes Fenster aktiv ist.', label: a => prettyKeys(a.keys) || 'Taste' },
    spotify: { name: 'Spotify', icon: 'music', fields: [['cmd', 'Befehl', 'select', SPOTIFY_CMDS]], label: a => optLabel(SPOTIFY_CMDS, a.cmd, 'Spotify').replace(' (in Spotify)', ''), iconFor: a => SPOTIFY_ICON[a.cmd] || 'music' },
    discord: { name: 'Discord', icon: 'message', fields: [['cmd', 'Befehl', 'select', DISCORD_CMDS]], label: a => optLabel(DISCORD_CMDS, a.cmd, 'Discord'), iconFor: a => DISCORD_ICON[a.cmd] || 'message' },
    text: { name: 'Text tippen', icon: 'type', fields: [['text', 'Text', 'area'], ['enter', 'Danach Enter drücken', 'check']], label: a => (a.text || 'Text').slice(0, 24) },
    url: { name: 'Webseite / Link öffnen', icon: 'globe', fields: [['url', 'Adresse', 'text', 'https://… oder steam://…']], label: a => (a.url || 'Webseite').replace(/^https?:\/\/(www\.)?/, '').split('/')[0] },
    launch: { name: 'Programm / Datei öffnen', icon: 'folder', fields: [['target', 'Pfad, Programm oder Link', 'text', 'z. B. notepad oder C:\\Spiele\\spiel.exe'], ['args', 'Argumente (optional)', 'text']], label: a => (a.target || 'Öffnen').split(/[\\/]/).pop().replace(/\.exe$/i, '') },
    riot: { name: 'Riot-Spiel starten', icon: 'gamepad', fields: [['product', 'Spiel', 'select', [['valorant', 'VALORANT'], ['league_of_legends', 'League of Legends']]]], label: a => a.product === 'league_of_legends' ? 'LoL starten' : 'VALORANT starten' },
    cmd: { name: 'Konsolenbefehl', icon: 'terminal', fields: [['cmd', 'Befehl (cmd.exe)', 'text', 'z. B. ipconfig /flushdns']], label: a => a.cmd || 'Befehl' },
    macro: { name: 'Makro (mehrere Schritte)', icon: 'zap', fields: [['script', 'Schritte', 'area', 'discord mute\nkey win+d\nwait 300\nspotify next']], hint: MACRO_HELP, label: () => 'Makro' },
    power: { name: 'Energie', icon: 'power', fields: [['cmd', 'Aktion', 'select', POWER], ['delay', 'Verzögerung in Sekunden (nur Herunterfahren/Neustart)', 'number']], label: a => optLabel(POWER, a.cmd, 'Energie'), iconFor: a => POWER_ICON[a.cmd] || 'power' },
    kill: { name: 'Programm beenden', icon: 'x', fields: [['procs', 'Prozessname(n), mit Komma getrennt', 'text', 'z. B. discord']], label: a => (a.procs || 'Beenden') + ' beenden' },
    procrun: { name: 'Befehl an laufendes Programm', icon: 'terminal', fields: [['procs', 'Prozessname(n), mit Komma getrennt', 'text', 'z. B. wallpaper64'], ['args', 'Argumente', 'text', 'z. B. -control pause']],
      hint: 'Startet das laufende Programm nochmal mit diesen Argumenten – viele Programme verstehen so Befehle (z. B. Wallpaper Engine, VLC).', label: a => a.args || 'Befehl' },
    device: { name: 'Audiogerät wechseln', icon: 'headphones', fields: [['id', 'Gerät', 'device']], label: a => a.devName || 'Audiogerät' },
    clipsave: { name: 'Clip speichern', icon: 'scissors', fields: [], hint: 'Speichert die letzten Sekunden als Video – die Aufnahme läuft ab dem Start von PC Remote im Hintergrund.', label: () => 'Clip speichern' },
    vm: { name: 'Voicemeeter', icon: 'sliders', fields: [['cmd', 'Befehl', 'select', [['show', 'Fenster anzeigen'], ['restart', 'Audio-Engine neu starten']]]], label: a => a.cmd === 'restart' ? 'VM Neustart' : 'Voicemeeter' },
    display: { name: 'Handy als Bildschirm', icon: 'devices', fields: [['mode', 'Was soll passieren?', 'select', [['extend', 'Handy wird zusätzlicher Bildschirm'], ['mirror1', 'Bildschirm 1 aufs Handy spiegeln'], ['mirror2', 'Bildschirm 2 aufs Handy spiegeln'], ['mirror3', 'Bildschirm 3 aufs Handy spiegeln']]]],
      hint: 'Ein Tipp genügt: Das Handy zeigt den Bildschirm im Vollbild, Tippen = Klicken, Ziehen = Fenster ziehen.', label: a => a.mode === 'extend' || !a.mode ? 'Als Bildschirm' : 'Bildschirm ' + a.mode.slice(-1) }
  };
  const HIDDEN_ACTS = { app: 1, mctl: 1, focus: 1, appwin: 1, priority: 1, toggle: 1, set: 1, window: 1, clip: 1, volume: 1, tap: 1, mouse: 1 };

  const KEY_NAMES = { ctrl: 'Strg', control: 'Strg', shift: 'Shift', alt: 'Alt', win: 'Win', enter: 'Enter', esc: 'Esc', space: 'Leertaste', tab: 'Tab',
    backspace: '⌫', delete: 'Entf', del: 'Entf', up: '↑', down: '↓', left: '←', right: '→', printscreen: 'Druck', plus: '+', minus: '−' };
  function prettyKeys(k) {
    return (k || '').split(' ').map(chord => chord.split('+').map(s => s.trim()).filter(Boolean)
      .map(s => KEY_NAMES[s.toLowerCase()] || (s.length === 1 ? s.toUpperCase() : s.charAt(0).toUpperCase() + s.slice(1))).join(' + ')).join(', ');
  }
  const actLabel = a => (ACTS[a.t] && ACTS[a.t].label(a)) || 'Aktion';
  const actIcon = a => { const d = ACTS[a.t]; return d ? (d.iconFor ? d.iconFor(a) : d.icon) : 'zap'; };

  // ---------- sheets ----------

  const sheets = [];
  function sheet(title, body, opts) {
    opts = opts || {};
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      wrap.classList.remove('open');
      setTimeout(() => wrap.remove(), 260);
      const i = sheets.indexOf(close);
      if (i >= 0) sheets.splice(i, 1);
      if (opts.onClose) opts.onClose();
    };
    const head = el('div', { class: 'sheet-head' }, el('h2', null, title),
      el('button', { class: 'icon-btn', 'aria-label': 'Schließen', onclick: close }, ic('x')));
    const panel = el('div', { class: 'sheet' + (opts.wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true' }, el('div', { class: 'sheet-grip' }), head, body);
    const wrap = el('div', { class: 'sheet-wrap' }, el('div', { class: 'sheet-back', onclick: close }), panel);
    $('#sheets').append(wrap);
    requestAnimationFrame(() => requestAnimationFrame(() => wrap.classList.add('open')));
    sheets.push(close);
    return close;
  }
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && sheets.length) sheets[sheets.length - 1](); });

  function confirmSheet(title, text, okLabel, danger) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (done) return; done = true; resolve(v); close(); };
      const body = el('div', null,
        text ? el('p', { class: 'muted', style: 'margin:0 0 18px' }, text) : null,
        el('div', { class: 'sheet-actions' },
          el('button', { class: 'btn', onclick: () => finish(false) }, 'Abbrechen'),
          el('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => finish(true) }, okLabel || 'OK')));
      const close = sheet(title, body, { onClose: () => finish(false) });
    });
  }

  function pickList(items) {
    return el('div', { class: 'pick-list' }, items.map(it =>
      el('button', { class: 'pick-item' + (it.on ? ' on' : ''), onclick: it.onclick }, it.icon, el('div', null, el('b', null, it.title), it.sub ? el('small', null, it.sub) : null), it.trail || null)));
  }

  // ---------- polling ----------

  let current = null, pollTimer = null, pollGen = 0, soonTimer = null;

  function startPoll() {
    clearTimeout(pollTimer);
    const gen = ++pollGen;
    const loop = async () => {
      if (gen !== pollGen) return;
      const v = current;
      const p = v && v.poll && v.poll();
      if (p && !document.hidden) {
        try {
          const d = await api(p.path);
          if (gen === pollGen && v.update) v.update(d);
        } catch (e) { }
      }
      if (gen === pollGen) pollTimer = setTimeout(loop, (p && p.ms) || 2000);
    };
    loop();
  }
  function stopPoll() { pollGen++; clearTimeout(pollTimer); }
  function pollSoon() { clearTimeout(soonTimer); soonTimer = setTimeout(() => { if (current) startPoll(); }, 250); }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && current) startPoll(); });

  // ---------- addon store (settings, on/off, custom buttons; saved on the PC) ----------

  const AD = { settings: {}, disabled: [], buttons: {} };

  async function loadAddons() {
    try {
      const d = await api('/api/addons');
      if (d && typeof d === 'object') {
        AD.settings = d.settings || {};
        AD.disabled = d.disabled || [];
        AD.buttons = d.buttons || {};
      }
    } catch (e) { }
  }

  let adTimer = null;
  function saveAddons() {
    clearTimeout(adTimer);
    S.addonsPending = true;
    adTimer = setTimeout(() => {
      adTimer = null;
      api('/api/addons', { settings: AD.settings, disabled: AD.disabled, buttons: AD.buttons })
        .then(r => { if (r && r.rev) S.rev = r.rev; })
        .catch(e => toast('Addon-Einstellungen nicht gespeichert: ' + e.message, 'err'))
        .then(() => { if (!adTimer) S.addonsPending = false; });
    }, 300);
  }

  const addonOn = id => !AD.disabled.includes(id);
  function setAddonOn(id, on) {
    AD.disabled = AD.disabled.filter(x => x !== id);
    if (!on) AD.disabled.push(id);
    saveAddons();
  }
  function setting(addon, key) {
    const s = AD.settings[addon.id] || {};
    if (s[key] != null && s[key] !== '') return s[key];
    const def = (addon.settings || []).find(x => x.key === key);
    return def && def.def != null ? def.def : '';
  }

  // ---------- addon definitions ----------

  const K = (label, keys, icon) => ({ label, icon, a: { t: 'appkey', keys } });   // keys into this app's window
  const G = (label, keys, icon) => ({ label, icon, a: { t: 'key', keys } });      // global hotkey
  const U = (label, url, icon) => ({ label, icon, a: { t: 'url', url } });
  const KS = (label, key, icon) => ({ label, icon, setting: key });                // hotkey from this addon's settings

  const GAME = {
    type: 'buttons', title: 'Beim Zocken', items: [
      { label: 'Discord Mikro', icon: 'micoff', a: { t: 'discord', cmd: 'mute' }, state: 'discord.mute', deck: { type: 'toggle', bind: 'discord:mute', color: 'violet' } },
      { label: 'Discord Ton', icon: 'headphones', a: { t: 'discord', cmd: 'deaf' }, state: 'discord.deaf', deck: { type: 'toggle', bind: 'discord:deaf', color: 'violet' } },
      { label: 'Clip speichern', icon: 'scissors', a: { t: 'clipsave' } },
      { label: 'Clip (Medal)', icon: 'scissors', ref: ['medal', 'clipKey'] },
      { label: 'Replay (NVIDIA)', icon: 'record', ref: ['nvidia', 'replayKey'] },
      G('Screenshot', 'win+alt+printscreen', 'camera'),
      G('Aufnahme (Game Bar)', 'win+alt+r', 'video'),
      G('Game Bar', 'win+g', 'gamepad'),
      { label: 'Nächster Song', icon: 'next', a: { t: 'media', k: 'next', src: 'spotify' } }
    ]
  };

  function browserAddon(id, name, procs, rx, exe, privKey) {
    return {
      id, name, icon: 'globe', color: 'cyan', match: { procs, name: rx }, parts: ['media'],
      desc: 'Seiten öffnen, Tabs, Navigation, Zoom, Vollbild und YouTube-Steuerung',
      sections: [
        { type: 'player', title: 'Wiedergabe im Browser' },
        { type: 'openurl', exe },
        { type: 'buttons', title: 'Tabs & Navigation', items: [K('Neuer Tab', 'ctrl+t', 'plus'), K('Tab schließen', 'ctrl+w', 'x'), K('Nächster Tab', 'ctrl+tab', 'right'),
          K('Vorheriger Tab', 'ctrl+shift+tab', 'left'), K('Tab zurückholen', 'ctrl+shift+t', 'restart'), K('Neu laden', 'f5', 'refresh'), K('Zurück', 'alt+left', 'back'),
          K('Vor', 'alt+right', 'right'), K('Neues Fenster', 'ctrl+n', 'window'), K('Inkognito', privKey || 'ctrl+shift+n', 'lock'), K('Downloads', 'ctrl+j', 'download'), K('Verlauf', 'ctrl+h', 'list')] },
        { type: 'buttons', title: 'Ansicht', items: [K('Vollbild', 'f11', 'fullscreen'), K('Zoom +', 'ctrl+plus', 'zoomin'), K('Zoom −', 'ctrl+minus', 'zoomout'), K('Zoom 100 %', 'ctrl+0', 'search'),
          K('Ganz nach oben', 'home', 'up'), K('Ganz nach unten', 'end', 'down'), K('Seite hoch', 'pageup', 'up'), K('Seite runter', 'pagedown', 'down')] },
        { type: 'buttons', title: 'YouTube', items: [K('Play / Pause', 'k', 'play'), K('−10 s', 'j', 'prev'), K('+10 s', 'l', 'next'), K('Vollbild', 'f', 'fullscreen'),
          K('Ton aus', 'm', 'mute'), K('Untertitel', 'c', 'type'), K('Kinomodus', 't', 'monitor'), K('Nächstes Video', 'shift+n', 'next'), K('Schneller', 'shift+.', 'up'),
          K('Langsamer', 'shift+,', 'down'), K('Miniplayer', 'i', 'window')] }
      ]
    };
  }

  // music apps: Windows shows what they play (cover, title, buttons) – plus the media keys
  function musicAddon(id, name, procs, rx, color) {
    return {
      id, name, icon: 'music', color, match: { procs, name: rx }, parts: ['media'],
      desc: 'Was gerade läuft mit Cover, Play/Pause, Weiter, Zurück, Lautstärke',
      sections: [
        { type: 'player', title: 'Wiedergabe' },
        { type: 'buttons', title: name, items: [{ label: 'Play / Pause', icon: 'play', a: { t: 'media', k: 'playpause' } }, { label: 'Nächster Titel', icon: 'next', a: { t: 'media', k: 'next' } },
          { label: 'Vorheriger Titel', icon: 'prev', a: { t: 'media', k: 'prev' } }, { label: 'Stopp', icon: 'stop', a: { t: 'media', k: 'stop' } }, K('Suchen', 'ctrl+f', 'search')] }
      ]
    };
  }

  // streaming / recording programs: no fixed shortcuts – you set them once in the program and enter the same here
  function streamAddon(id, name, procs, rx) {
    const hint = 'In ' + name + ' unter Einstellungen → Hotkeys dasselbe Kürzel festlegen. Am besten Kürzel, die kein Spiel benutzt, z. B. ctrl+alt+f9.';
    return {
      id, name, icon: 'record', color: 'slate', match: { procs, name: rx },
      desc: 'Aufnahme, Stream, Replay speichern, Pause, Szenen und Mikro – per Knopfdruck vom Handy',
      settings: [
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: '', hint },
        { key: 'streamKey', label: 'Stream starten / stoppen', type: 'keys', def: '' },
        { key: 'replayKey', label: 'Replay-Puffer speichern', type: 'keys', def: '' },
        { key: 'pauseKey', label: 'Aufnahme pausieren', type: 'keys', def: '' },
        { key: 'micKey', label: 'Mikrofon stumm', type: 'keys', def: '' },
        { key: 'scene1Key', label: 'Szene 1', type: 'keys', def: '' },
        { key: 'scene2Key', label: 'Szene 2', type: 'keys', def: '' },
        { key: 'scene3Key', label: 'Szene 3', type: 'keys', def: '' },
        { key: 'scene4Key', label: 'Szene 4', type: 'keys', def: '' }
      ],
      sections: [
        { type: 'buttons', title: 'Aufnahme & Stream', items: [KS('Aufnahme an / aus', 'recordKey', 'record'), KS('Stream an / aus', 'streamKey', 'video'), KS('Replay speichern', 'replayKey', 'scissors'),
          KS('Pause', 'pauseKey', 'pause'), KS('Mikro stumm', 'micKey', 'micoff')] },
        { type: 'buttons', title: 'Szenen', items: [KS('Szene 1', 'scene1Key', 'monitor'), KS('Szene 2', 'scene2Key', 'monitor'), KS('Szene 3', 'scene3Key', 'monitor'), KS('Szene 4', 'scene4Key', 'monitor')] }
      ]
    };
  }

  // Wallpaper Engine understands commands on its command line ("wallpaper64.exe -control pause")
  const WE = (label, cmd, icon) => ({ label, icon, a: { t: 'procrun', procs: 'wallpaper64,wallpaper32', args: '-control ' + cmd } });

  const ADDONS = [
    {
      id: 'spotify', name: 'Spotify', icon: 'music', color: 'green', match: { procs: ['spotify'], name: /^spotify/i }, parts: ['media', 'spotify'],
      desc: 'Lautstärke direkt in Spotify, Lieblingssongs, Playlists, Suche, Warteschlange, Geräte, Spulen, Shuffle',
      sections: [
        { type: 'player' },
        { type: 'buttons', title: 'Schnellzugriff', items: [
          { label: 'Song liken', icon: 'heart', a: { t: 'spotify', cmd: 'like' }, needs: 'spotify' },
          { label: 'Lauter', icon: 'volume', a: { t: 'spotify', cmd: 'volup' }, needs: 'spotify' },
          { label: 'Leiser', icon: 'voldown', a: { t: 'spotify', cmd: 'voldown' }, needs: 'spotify' },
          { label: 'Shuffle', icon: 'shuffle', a: { t: 'spotify', cmd: 'shuffle' }, needs: 'spotify' },
          { label: 'Wiederholen', icon: 'repeat', a: { t: 'spotify', cmd: 'repeat' }, needs: 'spotify' },
          U('Lieblingssongs', 'spotify:collection:tracks', 'heart'),
          K('Suchen', 'ctrl+l', 'search'),
          K('Zurück', 'alt+left', 'back')] },
        { type: 'spotify' }
      ]
    },
    {
      id: 'discord', name: 'Discord', icon: 'message', color: 'violet', match: { procs: ['discord'], name: /^discord$/i }, parts: ['discord'],
      desc: 'Mikro stumm, Ton aus, Auflegen, Kamera, Bildschirm teilen – direkt in Discord mit Live-Status',
      settings: [
        { key: 'muteKey', label: 'Ersatz-Kürzel: Mikro stumm', type: 'keys', hint: 'Nur nötig, wenn das Discord-Fenster ganz geschlossen ist. In Discord unter Einstellungen → Tastenbelegung dasselbe Kürzel festlegen.' },
        { key: 'deafKey', label: 'Ersatz-Kürzel: Ton aus', type: 'keys' },
        { key: 'disconnectKey', label: 'Ersatz-Kürzel: Auflegen', type: 'keys' }
      ],
      sections: [
        { type: 'discord' },
        { type: 'buttons', title: 'In Discord', items: [K('Schnellwechsler', 'ctrl+k', 'search'), K('Anruf annehmen', 'ctrl+enter', 'phone'), K('Anruf ablehnen', 'esc', 'phoneoff'),
          K('Nächster ungelesener Kanal', 'alt+shift+down', 'down'), K('Kanal gelesen', 'esc', 'check'), K('Server gelesen', 'shift+esc', 'check'),
          K('Einstellungen', 'ctrl+,', 'settings'), K('Nach oben', 'pageup', 'up')] }
      ]
    },
    browserAddon('chrome', 'Google Chrome', ['chrome'], /chrome/i, 'chrome'),
    browserAddon('edge', 'Microsoft Edge', ['msedge'], /microsoft edge/i, 'msedge'),
    {
      id: 'steam', name: 'Steam', icon: 'gamepad', color: 'slate', match: { procs: ['steam'], name: /^steam$/i },
      desc: 'Bibliothek, Shop, Freunde, Downloads, Big Picture, Online-Status und alle Steam-Spiele',
      sections: [
        { type: 'games', source: 'steam', title: 'Steam-Spiele' },
        { type: 'buttons', title: 'Steam öffnen', items: [U('Bibliothek', 'steam://nav/games', 'grid'), U('Shop', 'steam://store', 'store'), U('Freunde', 'steam://open/friends', 'users'),
          U('Downloads', 'steam://open/downloads', 'download'), U('Big Picture', 'steam://open/bigpicture', 'monitor'), U('Screenshots', 'steam://open/screenshots', 'camera'),
          U('Einstellungen', 'steam://open/settings', 'settings'), U('Konsole', 'steam://open/console', 'terminal')] },
        { type: 'buttons', title: 'Online-Status', items: [U('Online', 'steam://friends/status/online', 'check'), U('Abwesend', 'steam://friends/status/away', 'moon'),
          U('Unsichtbar', 'steam://friends/status/invisible', 'lock'), U('Offline', 'steam://friends/status/offline', 'x'),
          Object.assign(U('Steam beenden', 'steam://exit', 'power'), { confirm: true, color: 'red' })] }
      ]
    },
    {
      id: 'epic', name: 'Epic Games', icon: 'gamepad', color: 'slate', match: { procs: ['epicgameslauncher'], name: /epic games launcher/i },
      desc: 'Launcher, Shop und alle Epic-Spiele direkt starten',
      sections: [
        { type: 'games', source: 'epic', title: 'Epic-Spiele' },
        { type: 'buttons', title: 'Epic Games', items: [U('Shop', 'com.epicgames.launcher://store', 'store')] }
      ]
    },
    {
      id: 'riot', name: 'Riot Client', icon: 'gamepad', color: 'red', match: { procs: ['riot client', 'riotclientservices'], name: /^riot client$/i },
      desc: 'VALORANT und League of Legends direkt starten, ohne den Client anzuklicken',
      sections: [{ type: 'buttons', title: 'Spiele starten', items: [
        { label: 'VALORANT', icon: 'play', a: { t: 'riot', product: 'valorant' } },
        { label: 'League of Legends', icon: 'play', a: { t: 'riot', product: 'league_of_legends' } }] }]
    },
    {
      id: 'valorant', name: 'VALORANT', icon: 'gamepad', color: 'red', game: true, match: { procs: ['valorant-win64-shipping', 'valorant'], name: /^valorant$/i },
      launch: { t: 'riot', product: 'valorant' }, desc: 'Direkt über Riot starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'fortnite', name: 'Fortnite', icon: 'gamepad', color: 'violet', game: true, match: { procs: ['fortniteclient-win64-shipping', 'fortnitelauncher'], name: /^fortnite$/i },
      desc: 'Starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'battlefield', name: 'Battlefield', icon: 'gamepad', color: 'orange', game: true, match: { procs: ['bf6'], name: /battlefield/i },
      desc: 'Starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'roblox', name: 'Roblox', icon: 'gamepad', color: 'cyan', game: true, match: { procs: ['robloxplayerbeta'], name: /^roblox player$/i },
      desc: 'Starten, Roblox Studio, Website, Spiel-Shortcuts',
      sections: [GAME, { type: 'buttons', title: 'Roblox', items: [U('Roblox im Browser', 'https://www.roblox.com/home', 'globe'),
        { label: 'Roblox Studio', icon: 'code', a: { t: 'app', id: 'roblox-studio', op: 'smart' } }] }]
    },
    {
      id: 'medal', name: 'Medal', icon: 'scissors', color: 'orange', match: { procs: ['medal'], name: /^medal$/i },
      desc: 'Clips speichern und Aufnahmen starten – per Knopfdruck vom Handy',
      settings: [
        { key: 'clipKey', label: 'Clip speichern', type: 'keys', def: 'f8', hint: 'Standard in Medal ist F8. Hast du es in Medal geändert, hier dasselbe eintragen.' },
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: '' },
        { key: 'screenshotKey', label: 'Screenshot', type: 'keys', def: '' }
      ],
      sections: [{ type: 'buttons', title: 'Medal', items: [KS('Clip speichern', 'clipKey', 'scissors'), KS('Aufnahme an / aus', 'recordKey', 'record'), KS('Screenshot', 'screenshotKey', 'camera')] }]
    },
    {
      id: 'nvidia', name: 'NVIDIA', icon: 'cpu', color: 'green', match: { procs: ['nvidia app', 'nvidia overlay'], name: /^nvidia app$/i }, parts: ['stats'],
      desc: 'Grafikkarte live (Last, Temperatur, Strom, Lüfter, Takt), Instant Replay, Aufnahme, Overlay',
      settings: [
        { key: 'replayKey', label: 'Instant Replay speichern', type: 'keys', def: 'alt+f10' },
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: 'alt+f9' },
        { key: 'replayToggleKey', label: 'Instant Replay an / aus', type: 'keys', def: 'alt+shift+f10' },
        { key: 'screenshotKey', label: 'Screenshot', type: 'keys', def: 'alt+f1' },
        { key: 'overlayKey', label: 'Overlay öffnen', type: 'keys', def: 'alt+z' },
        { key: 'statsKey', label: 'Leistungs-Overlay', type: 'keys', def: 'alt+r' }
      ],
      sections: [{ type: 'gpu' }, { type: 'buttons', title: 'Aufnahme & Overlay', items: [KS('Replay speichern', 'replayKey', 'scissors'), KS('Aufnahme an / aus', 'recordKey', 'record'),
        KS('Instant Replay an / aus', 'replayToggleKey', 'restart'), KS('Screenshot', 'screenshotKey', 'camera'), KS('Overlay', 'overlayKey', 'window'), KS('Leistungs-Overlay', 'statsKey', 'gauge')] }]
    },
    {
      id: 'voicemeeter', name: 'Voicemeeter', icon: 'sliders', color: 'cyan', parts: ['vm'],
      match: { procs: ['voicemeeter', 'voicemeeter_x64', 'voicemeeterpro', 'voicemeeterpro_x64', 'voicemeeter8', 'voicemeeter8x64'], name: /^voicemeeter/i },
      desc: 'Alle Eingänge und Busse: Gain, Stumm, Routing A1–B3, Audio-Engine neu starten',
      sections: [{ type: 'vm' }, { type: 'buttons', title: 'Voicemeeter', items: [{ label: 'Fenster zeigen', icon: 'window', a: { t: 'vm', cmd: 'show' } }, { label: 'Audio-Engine neu starten', icon: 'restart', a: { t: 'vm', cmd: 'restart' } }] }]
    },
    {
      id: 'vscode', name: 'VS Code', icon: 'code', color: 'cyan', match: { procs: ['code'], name: /visual studio code/i },
      desc: 'Speichern, Terminal, Befehlspalette, Debuggen, Formatieren und mehr',
      sections: [
        { type: 'buttons', title: 'Dateien', items: [K('Speichern', 'ctrl+s', 'save'), K('Alle speichern', 'ctrl+k s', 'save'), K('Datei öffnen', 'ctrl+p', 'folder'), K('Rückgängig', 'ctrl+z', 'back')] },
        { type: 'buttons', title: 'Ansicht', items: [K('Befehlspalette', 'ctrl+shift+p', 'search'), K('Terminal', 'ctrl+`', 'terminal'), K('Seitenleiste', 'ctrl+b', 'window'),
          K('In Dateien suchen', 'ctrl+shift+f', 'search'), K('Git', 'ctrl+shift+g', 'code')] },
        { type: 'buttons', title: 'Code', items: [K('Formatieren', 'shift+alt+f', 'type'), K('Kommentar', 'ctrl+#', 'code'), K('Zeile hoch', 'alt+up', 'up'), K('Zeile runter', 'alt+down', 'down'),
          K('Debuggen', 'f5', 'play'), K('Stoppen', 'shift+f5', 'stop')] }]
    },

    // ----- more apps: browsers, streaming, calls, office, music, games -----
    browserAddon('firefox', 'Firefox', ['firefox'], /firefox/i, 'firefox', 'ctrl+shift+p'),
    browserAddon('opera', 'Opera / Opera GX', ['opera'], /^opera/i, 'opera'),
    browserAddon('brave', 'Brave', ['brave'], /^brave/i, 'brave'),
    streamAddon('obs', 'OBS Studio', ['obs64', 'obs32', 'obs'], /^obs studio/i),
    streamAddon('streamlabs', 'Streamlabs', ['streamlabs obs', 'streamlabs desktop'], /^streamlabs/i),
    {
      id: 'wallpaperengine', name: 'Wallpaper Engine', icon: 'image', color: 'cyan', match: { procs: ['wallpaper64', 'wallpaper32'], name: /wallpaper engine/i },
      desc: 'Hintergrund pausieren, weiter, nächstes Wallpaper, Ton und Desktop-Symbole',
      sections: [
        { type: 'buttons', title: 'Wallpaper', items: [WE('Pause', 'pause', 'pause'), WE('Weiter', 'play', 'play'), WE('Stopp', 'stop', 'stop'), WE('Nächstes Wallpaper', 'nextWallpaper', 'next'),
          WE('Ton aus', 'mute', 'mute'), WE('Ton an', 'unmute', 'volume'), WE('Symbole verstecken', 'hideIcons', 'eye'), WE('Symbole zeigen', 'showIcons', 'grid')] }
      ]
    },
    {
      id: 'vlc', name: 'VLC', icon: 'video', color: 'orange', match: { procs: ['vlc'], name: /^vlc/i },
      desc: 'Play/Pause, Spulen, Vollbild, Lautstärke, Untertitel und Tonspur',
      sections: [
        { type: 'buttons', title: 'Wiedergabe', items: [K('Play / Pause', 'space', 'play'), K('Stopp', 's', 'stop'), K('Nächster', 'n', 'next'), K('Vorheriger', 'p', 'prev'),
          K('−10 s', 'alt+left', 'prev'), K('+10 s', 'alt+right', 'next'), K('−1 min', 'ctrl+left', 'prev'), K('+1 min', 'ctrl+right', 'next')] },
        { type: 'buttons', title: 'Bild & Ton', items: [K('Vollbild', 'f', 'fullscreen'), K('Lauter', 'ctrl+up', 'volume'), K('Leiser', 'ctrl+down', 'voldown'), K('Ton aus', 'm', 'mute'),
          K('Untertitel', 'v', 'type'), K('Tonspur', 'b', 'headphones'), K('Schneller', 'plus', 'up'), K('Langsamer', 'minus', 'down')] }
      ]
    },
    {
      id: 'teams', name: 'Microsoft Teams', icon: 'users', color: 'violet', match: { procs: ['ms-teams', 'teams'], name: /microsoft teams|^teams( |$)/i }, // not "TeamSpeak"
      desc: 'Im Anruf: Mikro, Kamera, Hand heben, Bildschirm teilen, Auflegen – und Anrufe annehmen',
      sections: [
        { type: 'buttons', title: 'Im Anruf', items: [K('Mikro an / aus', 'ctrl+shift+m', 'micoff'), K('Kamera an / aus', 'ctrl+shift+o', 'video'), K('Hand heben', 'ctrl+shift+k', 'star'),
          K('Bildschirm teilen', 'ctrl+shift+e', 'share'), Object.assign(K('Auflegen', 'ctrl+shift+h', 'phoneoff'), { color: 'red' })] },
        { type: 'buttons', title: 'Anrufe & Navigation', items: [K('Annehmen (Audio)', 'ctrl+shift+s', 'phone'), K('Annehmen (Video)', 'ctrl+shift+a', 'video'), K('Ablehnen', 'ctrl+shift+d', 'phoneoff'),
          K('Suchen', 'ctrl+e', 'search'), K('Chat', 'ctrl+2', 'message'), K('Kalender', 'ctrl+4', 'list')] }
      ]
    },
    {
      id: 'zoom', name: 'Zoom', icon: 'video', color: 'cyan', match: { procs: ['zoom'], name: /^zoom/i },
      desc: 'Mikro, Video, Teilen, Hand heben, Chat, Aufnahme und Meeting verlassen',
      sections: [
        { type: 'buttons', title: 'Im Meeting', items: [K('Mikro an / aus', 'alt+a', 'micoff'), K('Video an / aus', 'alt+v', 'video'), K('Bildschirm teilen', 'alt+s', 'share'),
          K('Hand heben', 'alt+y', 'star'), K('Chat', 'alt+h', 'message'), K('Teilnehmer', 'alt+u', 'users'), K('Aufnahme', 'alt+r', 'record'), K('Vollbild', 'alt+f', 'fullscreen'),
          Object.assign(K('Verlassen', 'alt+q', 'phoneoff'), { color: 'red' })] }
      ]
    },
    {
      id: 'teamspeak', name: 'TeamSpeak', icon: 'headphones', color: 'cyan', match: { procs: ['ts3client_win64', 'ts3client_win32', 'teamspeak'], name: /teamspeak/i },
      desc: 'Mikro und Lautsprecher stumm, Abwesend – mit deinen TeamSpeak-Kürzeln',
      settings: [
        { key: 'micKey', label: 'Mikro stumm', type: 'keys', def: '', hint: 'In TeamSpeak unter Extras → Optionen → Hotkeys dasselbe Kürzel festlegen.' },
        { key: 'speakerKey', label: 'Lautsprecher stumm', type: 'keys', def: '' },
        { key: 'awayKey', label: 'Abwesend', type: 'keys', def: '' }
      ],
      sections: [{ type: 'buttons', title: 'TeamSpeak', items: [KS('Mikro stumm', 'micKey', 'micoff'), KS('Lautsprecher stumm', 'speakerKey', 'headphones'), KS('Abwesend', 'awayKey', 'moon')] }]
    },
    {
      id: 'whatsapp', name: 'WhatsApp', icon: 'message', color: 'green', match: { procs: ['whatsapp', 'whatsapp.root'], name: /^whatsapp/i },
      desc: 'Neuer Chat, nächster Chat, suchen, stumm, archivieren',
      sections: [
        { type: 'buttons', title: 'Chats', items: [K('Neuer Chat', 'ctrl+n', 'plus'), K('Nächster Chat', 'ctrl+tab', 'down'), K('Vorheriger Chat', 'ctrl+shift+tab', 'up'), K('Suchen', 'ctrl+f', 'search'),
          K('Chat stumm', 'ctrl+shift+m', 'mute'), K('Archivieren', 'ctrl+e', 'download'), K('Als ungelesen', 'ctrl+shift+u', 'bell'), K('Einstellungen', 'ctrl+,', 'settings')] }
      ]
    },
    {
      id: 'powerpoint', name: 'PowerPoint', icon: 'monitor', color: 'orange', match: { procs: ['powerpnt'], name: /powerpoint/i },
      desc: 'Das Handy als Präsentations-Fernbedienung: starten, weiter, zurück, schwarzer Bildschirm, Laserpointer',
      sections: [
        { type: 'buttons', title: 'Präsentieren', items: [K('Von Anfang', 'f5', 'play'), K('Ab dieser Folie', 'shift+f5', 'play'), K('Weiter', 'right', 'next'), K('Zurück', 'left', 'prev'),
          K('Erste Folie', 'home', 'up'), K('Letzte Folie', 'end', 'down'), K('Schwarz', 'b', 'moon'), K('Weiß', 'w', 'sun'), K('Laserpointer', 'ctrl+l', 'star'),
          Object.assign(K('Beenden', 'esc', 'x'), { color: 'red' })] },
        { type: 'buttons', title: 'Bearbeiten', items: [K('Speichern', 'ctrl+s', 'save'), K('Neue Folie', 'ctrl+m', 'plus'), K('Rückgängig', 'ctrl+z', 'back')] }
      ]
    },
    {
      id: 'word', name: 'Word', icon: 'type', color: 'cyan', match: { procs: ['winword'], name: /^word$|microsoft word/i }, // not "WordPad"
      desc: 'Speichern, Rückgängig, Drucken, Suchen, an den Anfang / ans Ende springen',
      sections: [{ type: 'buttons', title: 'Word', items: [K('Speichern', 'ctrl+s', 'save'), K('Rückgängig', 'ctrl+z', 'back'), K('Wiederholen', 'ctrl+y', 'restart'), K('Suchen', 'ctrl+f', 'search'),
        K('Drucken', 'ctrl+p', 'download'), K('Neues Dokument', 'ctrl+n', 'plus'), K('Ganz nach oben', 'ctrl+home', 'up'), K('Ganz nach unten', 'ctrl+end', 'down')] }]
    },
    {
      id: 'excel', name: 'Excel', icon: 'grid', color: 'green', match: { procs: ['excel'], name: /^excel/i },
      desc: 'Speichern, Rückgängig, Blatt wechseln, Suchen, Drucken',
      sections: [{ type: 'buttons', title: 'Excel', items: [K('Speichern', 'ctrl+s', 'save'), K('Rückgängig', 'ctrl+z', 'back'), K('Wiederholen', 'ctrl+y', 'restart'), K('Suchen', 'ctrl+f', 'search'),
        K('Nächstes Blatt', 'ctrl+pagedown', 'right'), K('Vorheriges Blatt', 'ctrl+pageup', 'left'), K('Neu berechnen', 'f9', 'refresh'), K('Drucken', 'ctrl+p', 'download')] }]
    },
    {
      id: 'amd', name: 'AMD Software', icon: 'cpu', color: 'red', match: { procs: ['radeonsoftware', 'amdrsserv'], name: /amd software|radeon/i },
      desc: 'Instant Replay, Aufnahme, Screenshot und Overlays der AMD-Grafiksoftware',
      settings: [
        { key: 'replayKey', label: 'Instant Replay speichern', type: 'keys', def: 'ctrl+shift+s' },
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: 'ctrl+shift+e' },
        { key: 'replayToggleKey', label: 'Instant Replay an / aus', type: 'keys', def: 'ctrl+shift+r' },
        { key: 'screenshotKey', label: 'Screenshot', type: 'keys', def: 'ctrl+shift+i' },
        { key: 'statsKey', label: 'Leistungs-Overlay', type: 'keys', def: 'ctrl+shift+o' },
        { key: 'openKey', label: 'AMD Software öffnen', type: 'keys', def: 'alt+r' }
      ],
      sections: [{ type: 'buttons', title: 'Aufnahme & Overlay', items: [KS('Replay speichern', 'replayKey', 'scissors'), KS('Aufnahme an / aus', 'recordKey', 'record'),
        KS('Instant Replay an / aus', 'replayToggleKey', 'restart'), KS('Screenshot', 'screenshotKey', 'camera'), KS('Leistungs-Overlay', 'statsKey', 'gauge'), KS('Öffnen', 'openKey', 'window')] }]
    },
    {
      id: 'minecraft', name: 'Minecraft', icon: 'gamepad', color: 'green', game: true, match: { procs: ['minecraft.windows'], name: /^minecraft/i },
      desc: 'Starten, Spiel-Shortcuts, Screenshot, Perspektive, HUD',
      sections: [GAME, { type: 'buttons', title: 'Minecraft (im Spiel)', items: [G('Screenshot', 'f2', 'camera'), G('Perspektive', 'f5', 'eye'), G('HUD aus / an', 'f1', 'window'),
        G('Debug-Infos', 'f3', 'list'), G('Vollbild', 'f11', 'fullscreen'), G('Chat', 't', 'message')] }]
    },
    musicAddon('applemusic', 'Apple Music', ['applemusic'], /^apple music/i, 'pink'),
    musicAddon('itunes', 'iTunes', ['itunes'], /^itunes/i, 'pink'),
    musicAddon('amazonmusic', 'Amazon Music', ['amazon music', 'amazonmusic'], /^amazon music/i, 'cyan'),
    musicAddon('deezer', 'Deezer', ['deezer'], /^deezer/i, 'violet'),
    musicAddon('tidal', 'TIDAL', ['tidal'], /^tidal/i, 'slate')
  ];
  const GAME_ADDON = { id: 'game', name: 'Spiel', icon: 'gamepad', color: 'violet', game: true, sections: [GAME], generic: true };

  function matches(ad, app) {
    const m = ad.match || {};
    if (m.name && m.name.test(app.name)) return true;
    return (m.procs || []).some(p => app.procs.includes(p));
  }
  function addonFor(app) {
    const ad = ADDONS.find(x => matches(x, app));
    if (ad) return addonOn(ad.id) ? ad : null;
    return app.kind === 'game' && addonOn('game') ? GAME_ADDON : null;
  }
  const appForAddon = ad => S.apps.find(a => matches(ad, a));
  function addonRunning(ad, d) {
    const ps = procSet(d);
    return !!(ps && ((ad.match && ad.match.procs) || []).some(p => ps.has(p))) || isRunning(appForAddon(ad), d);
  }

  // ---------- deck layout (pages of tiles) ----------

  function defaultLayout() {
    const P = (name, tiles) => ({ id: uid(), name, tiles: tiles.map(t => Object.assign({ id: uid() }, t)) });
    const has = rx => S.apps.some(a => rx.test(a.name));
    const start = [
      { type: 'np' },
      { type: 'slider', bind: 'master' },
      { type: 'toggle', bind: 'mic', w: 2, color: 'violet' },
      { type: 'toggle', bind: 'master', w: 2, color: 'cyan' }
    ];
    if (has(/^discord$/i)) start.push({ type: 'toggle', bind: 'discord:mute', w: 2, color: 'violet' }, { type: 'toggle', bind: 'discord:deaf', w: 2, color: 'violet' });
    start.push({ type: 'stats' });

    const prefer = ['discord', 'spotify', 'valorant', 'fortnite', 'roblox player', 'league of legends', 'minecraft', 'battlefield', 'counter-strike',
      'steam', 'obs studio', 'medal', 'google chrome', 'voicemeeter', 'epic games', 'riot client'];
    const picked = [];
    for (const w of prefer) {
      const a = S.apps.find(x => x.name.toLowerCase().includes(w) && !picked.includes(x));
      if (a) picked.push(a);
      if (picked.length >= 12) break;
    }
    for (const a of S.apps) {
      if (picked.length >= 12) break;
      if (a.kind === 'game' && !picked.includes(a)) picked.push(a);
    }

    const actions = [
      { type: 'action', label: 'Sperren', icon: 'lock', color: 'slate', a: { t: 'power', cmd: 'lock' } },
      { type: 'action', label: 'Monitor aus', icon: 'monitor', color: 'slate', a: { t: 'power', cmd: 'monitoroff' } },
      { type: 'action', label: 'Desktop', icon: 'home', color: 'cyan', a: { t: 'key', keys: 'win+d' } },
      { type: 'action', label: 'Screen\u00adshot', icon: 'camera', color: 'pink', a: { t: 'key', keys: 'win+shift+s' } },
      { type: 'action', label: 'Task-Manager', icon: 'gauge', color: 'slate', a: { t: 'key', keys: 'ctrl+shift+esc' } },
      { type: 'action', label: 'Game Bar', icon: 'gamepad', color: 'violet', a: { t: 'key', keys: 'win+g' } }
    ];
    if (has(/^spotify/i)) actions.push(
      { type: 'action', label: 'Spotify Play/Pause', icon: 'play', color: 'green', a: { t: 'media', k: 'playpause', src: 'spotify' } },
      { type: 'action', label: 'Nächster Song', icon: 'next', color: 'green', a: { t: 'media', k: 'next', src: 'spotify' } });

    const layout = { v: 2, pages: [P('Start', start), P('Apps', picked.map(a => ({ type: 'app', app: a.id, name: a.name }))), P('Aktionen', actions)] };
    layout.pages.forEach(normalize);
    return layout;
  }

  // Older layouts were one flat list of tiles.
  function migrateLayout(l) {
    if (!l || typeof l !== 'object') return null;
    if (Array.isArray(l.pages) && l.pages.length) return l;
    if (Array.isArray(l.tiles)) return { v: 2, custom: l.custom, pages: [{ id: uid(), name: 'Start', tiles: l.tiles }] };
    return null;
  }

  function curPageIdx() {
    const n = S.layout.pages.length;
    S.pageIdx = Math.max(0, Math.min(n - 1, S.pageIdx || 0));
    return S.pageIdx;
  }
  const curPage = () => S.layout.pages[curPageIdx()];

  // Pages and groups both hold tiles ({ cols, tiles }). A group is a tile of type "group" with its own tiles –
  // a deck in the deck. Everything that works on a page (add, move, resize, edit) works the same inside a group.
  function eachBox(fn) {
    const walk = (box, page, path) => {
      fn(box, page, path);
      for (const t of box.tiles) if (t.type === 'group') walk(t, page, path.concat(t));
    };
    S.layout.pages.forEach(p => walk(p, p, []));
  }
  function findTile(id) {
    let res = null;
    eachBox(box => {
      if (res) return;
      const i = box.tiles.findIndex(t => t.id === id);
      if (i >= 0) res = { page: box, i };
    });
    return res;
  }
  const isGroup = t => !!t && t.type === 'group';
  const boxLabel = b => isGroup(b) ? (b.label || 'Gruppe') : b.name;
  // "is box b this group g or somewhere inside it" (a group can't move into itself)
  const within = (b, g) => b === g || g.tiles.some(t => isGroup(t) && within(b, t));
  const boxKey = b => isGroup(b) ? 'g' + b.id : 'p' + S.layout.pages.indexOf(b);
  function boxByKey(k) {
    if (!k) return null;
    if (k[0] === 'p') return S.layout.pages[+k.slice(1)] || null;
    let found = null;
    eachBox(b => { if (!found && isGroup(b) && 'g' + b.id === k) found = b; });
    return found;
  }
  // every place a tile can live: pages and (nested) groups, with a readable name like "Start › Musik"
  function allBoxes() {
    const list = [];
    eachBox((b, page, path) => list.push({ key: boxKey(b), box: b, depth: path.length, name: [page.name].concat(path.map(boxLabel)).join(' › ') }));
    return list;
  }

  // the group(s) opened on the deck right now, outermost first
  function groupTrail() {
    let box = curPage();
    const trail = [];
    for (const id of S.groupPath) {
      const g = box.tiles.find(t => t.id === id && isGroup(t));
      if (!g) break;
      trail.push(g);
      box = g;
    }
    if (trail.length !== S.groupPath.length) S.groupPath = trail.map(g => g.id);
    return trail;
  }
  const viewBox = () => { const tr = groupTrail(); return tr.length ? tr[tr.length - 1] : curPage(); };

  // ---------- grid: every tile has a fixed spot {x, y, w, h} on its page (gaps allowed, same on phone and PC) ----------

  const pageCols = p => Math.max(3, Math.min(8, p.cols || 4));
  const FULL_ROW = { np: 1, slider: 1, stats: 1 };
  const MIN_W = { np: 2, stats: 3 };
  function defSize(t, cols) {
    if (FULL_ROW[t.type]) return { w: cols, h: 1 };
    return { w: Math.min(t.w === 4 ? cols : (t.w || 1), cols), h: 1 };
  }
  const hit = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  const pageRows = p => p.tiles.reduce((m, o) => o.pos ? Math.max(m, o.pos.y + o.pos.h) : m, 0);

  function fits(p, r, skip) {
    if (r.x < 0 || r.y < 0 || r.x + r.w > pageCols(p)) return false;
    return !p.tiles.some(o => o !== skip && o.pos && hit(o.pos, r));
  }

  // Nearest free spot to (x, y): same row first, then below.
  function freeSpot(p, w, h, x, y, skip) {
    const cols = pageCols(p);
    w = Math.min(w, cols);
    let best = null;
    for (let yy = 0; yy <= pageRows(p) + h; yy++)
      for (let xx = 0; xx + w <= cols; xx++) {
        const r = { x: xx, y: yy, w, h };
        if (!fits(p, r, skip)) continue;
        const d = Math.abs(yy - y) * 10 + Math.abs(xx - x) + (yy < y ? 5 : 0);
        if (!best || d < best.d) best = { d, r };
      }
    return best.r;
  }

  // Gives every tile a valid spot. Tiles without one (older layouts) are placed one after another, like before.
  function normalize(p) {
    const cols = p.cols = pageCols(p);
    let cx = 0, cy = 0;
    const done = [];
    for (const t of p.tiles) {
      const s = defSize(t, cols);
      if (t.pos && t.pos.w > 0) {
        const w = Math.max(1, Math.min(cols, Math.round(t.pos.w))), h = Math.max(1, Math.min(4, Math.round(t.pos.h || 1)));
        const r = { x: Math.max(0, Math.min(cols - w, Math.round(t.pos.x) || 0)), y: Math.max(0, Math.round(t.pos.y) || 0), w, h };
        if (!done.some(o => hit(o.pos, r))) { t.pos = r; done.push(t); continue; }
        s.w = w; s.h = h;
      }
      let x = cx, y = cy, r;
      while (true) {
        if (x + s.w > cols) { x = 0; y++; }
        const c = { x, y, w: s.w, h: s.h };
        if (!done.some(o => hit(o.pos, c))) { r = c; break; }
        x++;
      }
      t.pos = r;
      done.push(t);
      cx = r.x + r.w; cy = r.y;
    }
    for (const t of p.tiles) if (isGroup(t)) {
      if (!Array.isArray(t.tiles)) t.tiles = [];
      if (!t.cols) t.cols = cols;
      normalize(t);
    }
  }

  // Put a tile on spot r: a same-sized tile there swaps places, anything else moves to the nearest free spot.
  function placeAt(p, t, r) {
    const old = t.pos;
    t.pos = r;
    const covered = p.tiles.filter(o => o !== t && o.pos && hit(o.pos, r));
    if (covered.length === 1 && old && old.w === r.w && old.h === r.h && covered[0].pos.w === r.w && covered[0].pos.h === r.h) {
      covered[0].pos = { x: old.x, y: old.y, w: old.w, h: old.h };
      return;
    }
    for (const o of covered) {
      const from = o.pos;
      o.pos = null;
      o.pos = freeSpot(p, from.w, from.h, from.x, from.y, o);
    }
  }

  // Tidy up: close all gaps, keeping the reading order.
  function packPage(p) {
    p.tiles.sort((a, b) => a.pos.y - b.pos.y || a.pos.x - b.pos.x);
    const sizes = p.tiles.map(t => ({ w: t.pos.w, h: t.pos.h }));
    p.tiles.forEach(t => { t.pos = null; });
    p.tiles.forEach((t, i) => { t.pos = freeSpot(p, sizes[i].w, sizes[i].h, 0, 0, t); });
  }

  // move a tile to another page or into/out of a group
  function moveTo(t, dest) {
    const loc = findTile(t.id);
    if (!loc || !dest || loc.page === dest) return false;
    if (isGroup(t) && within(dest, t)) { toast('Eine Gruppe kann nicht in sich selbst', 'err'); return false; }
    loc.page.tiles.splice(loc.i, 1);
    const w = Math.min(t.pos.w, pageCols(dest)), h = t.pos.h;
    t.pos = null;
    t.pos = freeSpot(dest, w, h, 0, Math.max(0, pageRows(dest) - 1), t);
    dest.tiles.push(t);
    toast('„' + (t.label || t.name || (TILES[t.type] || {}).name || 'Kachel') + '“ liegt jetzt in „' + boxLabel(dest) + '“');
    return true;
  }

  // Undo for layout changes while editing.
  const undoStack = [];
  function remember() {
    undoStack.push(JSON.stringify(S.layout.pages));
    if (undoStack.length > 40) undoStack.shift();
    paintUndo();
  }
  function undoLast() {
    const s = undoStack.pop();
    if (!s) return;
    S.layout.pages = JSON.parse(s);
    saveLayout();
    Deck.draw();
    paintUndo();
    toast('Rückgängig gemacht');
  }
  function paintUndo() {
    document.querySelectorAll('.undo-btn').forEach(b => {
      b.style.display = S.editing && current === Deck ? '' : 'none';
      b.disabled = !undoStack.length;
    });
  }

  let saveTimer = null;
  function saveLayout() {
    S.layout.custom = true;
    LS.set('layout', S.layout);
    clearTimeout(saveTimer);
    S.layoutPending = true; // until the PC has it, changes from other devices wait – ours must not be overwritten
    saveTimer = setTimeout(() => {
      saveTimer = null;
      api('/api/layout', S.layout)
        .then(r => { if (r && r.rev) S.rev = r.rev; })
        .catch(e => toast('Layout nicht gespeichert: ' + e.message, 'err'))
        .then(() => { if (!saveTimer) S.layoutPending = false; });
    }, 400);
  }

  // shared settings from the PC (see Shared)
  async function loadShared() {
    let ui;
    try { ui = await api('/api/ui'); } catch (e) { return; }
    if (!ui || typeof ui !== 'object' || Array.isArray(ui)) ui = {};
    if (!Object.keys(ui).length) {
      // the first device with this version brings its own settings along, so nothing set before is lost
      const seed = {};
      SHARED.forEach(k => { const v = LS.get(k, null); if (v != null) seed[k] = v; });
      if (Object.keys(seed).length) { Object.assign(ui, seed); api('/api/ui', seed).then(r => { if (r && r.rev) S.rev = r.rev; }).catch(() => { }); }
    }
    applyShared(ui);
  }
  function applyShared(ui) {
    S.ui = ui;
    SHARED.forEach(k => { if (ui[k] == null) LS.del(k); else LS.set(k, ui[k]); });
    applyBackground();
    if (Deck.wrap && Deck.wrap.isConnected) sizeDeck(Deck.wrap, Deck.cols);
  }

  // Another device changed something (rev went up): fetch it and show it right away.
  async function pullShared(rev) {
    if (S.layoutPending || S.addonsPending || S.uiPending) return; // our own change is still on its way – next round
    const [layout, addons, ui] = await Promise.all(['/api/layout', '/api/addons', '/api/ui'].map(p => api(p).catch(() => undefined)));
    if (S.layoutPending || S.addonsPending || S.uiPending) return;
    S.rev = rev;
    let redraw = false;
    const l = migrateLayout(layout);
    if (l) {
      l.pages.forEach(normalize);
      if (JSON.stringify(l.pages) !== JSON.stringify(S.layout.pages)) { S.layout = l; LS.set('layout', l); redraw = true; }
    }
    if (addons && typeof addons === 'object') {
      const before = JSON.stringify(AD);
      AD.settings = addons.settings || {}; AD.disabled = addons.disabled || []; AD.buttons = addons.buttons || {};
      if (JSON.stringify(AD) !== before) redraw = true;
    }
    if (ui && typeof ui === 'object' && JSON.stringify(ui) !== JSON.stringify(S.ui)) applyShared(ui);
    if (redraw && current === Deck) Deck.draw();
  }

  async function loadLayout(pending) {
    try { S.layout = migrateLayout(await (pending || api('/api/layout'))); }
    catch (e) { S.layout = migrateLayout(LS.get('layout', null)); }
    if (!S.layout) S.layout = defaultLayout();
    S.layout.pages.forEach(normalize);
  }

  async function loadApps() {
    try { S.apps = await api('/api/apps') || []; } catch (e) { }
  }

  let addAt = null; // set when an empty grid cell was tapped: the new tile goes exactly there
  function addTile(t, box) {
    remember();
    t.id = uid();
    const p = box || viewBox();
    if (isGroup(t)) { t.tiles = t.tiles || []; t.cols = t.cols || pageCols(p); }
    const s = defSize(t, pageCols(p));
    const want = addAt || { x: 0, y: Math.max(0, pageRows(p) - 1) };
    addAt = null;
    const r = { x: Math.min(want.x, pageCols(p) - s.w), y: want.y, w: s.w, h: s.h };
    t.pos = fits(p, r) ? r : freeSpot(p, s.w, s.h, want.x, want.y);
    p.tiles.push(t);
    saveLayout();
    if (current === Deck) Deck.draw();
  }

  // Put something on the deck; asks where when there are several pages or groups.
  function toDeck(t, label) {
    const boxes = allBoxes();
    const put = b => { addTile(t, b.box); toast('„' + label + '“ liegt jetzt in „' + b.name + '“'); };
    if (boxes.length === 1) return put(boxes[0]);
    const close = sheet('Wohin aufs Deck?', pickList(boxes.map(b => ({
      icon: tic(b.depth ? 'folder' : 'grid', b.depth ? 'orange' : 'violet'), title: b.name, sub: b.box.tiles.length + ' Kacheln' + (b.depth ? ' · Gruppe' : ''),
      onclick: () => { close(); put(b); }
    }))));
  }

  // ---------- tiles ----------

  function artUrl(s) {
    if (!s) return null;
    if (s.image) return s.image;
    return s.art ? '/api/art?id=' + enc(s.id) + '&k=' + s.art + '&' + authQ() : null;
  }

  const TILES = {
    np: {
      name: 'Wiedergabe', w: 4,
      build(n, t, live) {
        const title = el('div', { class: 'np-title' }, 'Nichts läuft');
        const sub = el('div', { class: 'np-sub' }, '');
        const img = el('img', { alt: '' });
        const art = el('div', { class: 'np-art' }, ic('music'), img);
        const pp = el('button', { class: 'np-btn big', 'aria-label': 'Play/Pause' }, ic('play', 'fill'));
        const prev = el('button', { class: 'np-btn', 'aria-label': 'Zurück' }, ic('prev', 'fill'));
        const next = el('button', { class: 'np-btn', 'aria-label': 'Weiter' }, ic('next', 'fill'));
        let np = null, spIdle = null;
        const ctl = cmd => np && np.id ? act({ t: 'mctl', id: np.id, cmd }, { quiet: 1 })
          : spIdle ? act({ t: 'spotify', cmd: cmd === 'toggle' ? 'play' : cmd }, { quiet: 1 })
          : act({ t: 'media', k: cmd === 'toggle' ? 'playpause' : cmd }, { quiet: 1 });
        if (live) {
          prev.onclick = () => ctl('prev');
          pp.onclick = () => ctl('toggle');
          next.onclick = () => ctl('next');
          press(art, { tap: () => show('media') });
        }
        n.append(art, el('div', { class: 'np-meta' }, title, sub), el('div', { class: 'np-ctl' }, prev, pp, next));
        let playing = null, lastArt = null;
        img.onerror = () => { img.style.display = 'none'; };
        img.onload = () => { img.style.display = ''; };
        return d => {
          np = d && d.np;
          // nothing playing in Windows, but Spotify is there (paused/closed/on another device): show the last song, Play resumes
          spIdle = !np && spotifyIdle(d && d.spotify) ? d.spotify : null;
          const view = np || (spIdle ? { title: spIdle.lastTrack ? spIdle.lastTrack.name : 'Spotify', artist: spIdle.lastTrack ? spIdle.lastTrack.artists : 'Bereit', app: 'Spotify', image: spIdle.lastTrack ? spIdle.lastTrack.image : null, playing: false } : null);
          setText(title, view ? (view.title || view.app) : 'Nichts läuft');
          setText(sub, !view ? 'Spotify oder YouTube starten' : view.title ? [view.artist, view.app].filter(Boolean).join(' · ') : view.playing === false ? 'Pausiert' : view.app);
          const p = !!(view && view.playing === true);
          if (p !== playing) { playing = p; setIc(pp, p ? 'pause' : 'play', 'fill'); }
          const u = artUrl(view);
          if (u !== lastArt) { lastArt = u; if (u) img.src = u; else img.style.display = 'none'; }
        };
      }
    },

    slider: {
      name: 'Lautstärkeregler', w: 4,
      build(n, t, live) {
        const b = bindInfo(t.bind);
        // narrow or upright tiles become a fader: swipe up/down on the tile, like a mixer channel
        if (!t.pos || t.pos.w < 2 * t.pos.h) return faderTile(n, t, live, b);
        const mute = el('button', { class: 'sl-mute', 'aria-label': 'Stumm' }, b.proc ? appIcon({ proc: b.proc }, b.label) : ic(b.icon));
        const val = el('div', { class: 'sl-val' }, '–');
        const range = makeVol(b, v => act(t.bind === 'spotify' ? { t: 'spotify', cmd: 'volume', value: v } : { t: 'set', bind: t.bind, value: b.toServer(v) }, { quiet: 1 }),
          v => { val.textContent = b.fmt(b.toServer(v)); });
        if (!live) range.disabled = true;
        if (live && b.muteBind) mute.onclick = () => act({ t: 'toggle', bind: b.muteBind }, { quiet: 1 });
        n.append(el('div', { class: 'sl-head' }, mute, el('div', { class: 'sl-name', title: t.label || b.label }, t.label || b.label), val), range);
        let wasMuted = null;
        return d => {
          const s = b.read(d);
          n.classList.toggle('idle', !s);
          if (!s) { setText(val, (t.pos && t.pos.w >= 3 && b.idle) || '–'); return; } // short tiles: the name needs the room
          const v = b.fromServer(s.v);
          if (+range.value !== v) range.setValue(v);
          if (!range.busy()) setText(val, b.fmt(s.v));
          n.classList.toggle('muted-state', !!s.m);
          if (!b.proc && wasMuted !== !!s.m) { wasMuted = !!s.m; setIc(mute, s.m ? b.offIcon : b.icon); }
        };
      }
    },

    toggle: {
      name: 'Stummschalter', w: 1, sq: true,
      build(n, t, live) {
        const info = toggleInfo(t.bind);
        const icBox = el('div', { class: 't-ic' }, ic(info.on));
        const state = el('div', { class: 't-sub' }, '…');
        n.append(icBox, el('div', { class: 't-text' }, tileLabel(t.label || info.label), state));
        let last, hold = 0;
        // feels instant: the tile flips right away, the PC's answer confirms it a moment later (or flips it back)
        if (live) press(n, {
          tap: () => {
            flash(n);
            if (!n.classList.contains('idle')) { hold = Date.now(); show(!n.classList.contains(info.alert ? 'alert' : 'on')); }
            act({ t: 'toggle', bind: t.bind }, { quiet: 1 });
          }
        });
        const show = v => {
          n.classList.toggle('idle', v == null);
          n.classList.toggle('alert', !!(info.alert && v));
          n.classList.toggle('on', !!(!info.alert && v));
          setText(state, v == null ? (t.bind && t.bind.startsWith('app:') ? 'Kein Ton aktiv' : t.bind && t.bind.startsWith('discord:') ? 'Discord zu' : '–') : info.alert ? (v ? 'Stumm' : 'An') : (v ? 'An' : 'Aus'));
          const tip = (t.label || info.label) + ': ' + state.textContent; // small tiles hide the state text – the colour and this tooltip say it
          if (n.title !== tip) n.title = tip;
          const iconName = info.alert ? (v ? info.off : info.on) : info.on;
          if (iconName !== last) { last = iconName; setIc(icBox, iconName); }
        };
        return d => { if (Date.now() - hold > 1200) show(info.read(d)); };
      }
    },

    app: {
      name: 'App / Spiel', w: 1, sq: true,
      build(n, t, live) {
        const a = appById(t.app);
        const name = t.label || (a && a.name) || t.name || t.app;
        n.append(el('span', { class: 'run-dot' }), appIcon({ id: t.app }, name), tileLabel(name));
        n.title = name + ' – antippen öffnet, gedrückt halten schließt';
        // tap = open (or bring to the front), hold = close it (a red bar fills up while holding, so it never happens by accident)
        if (live) press(n, {
          tap: () => {
            const app = appById(t.app);
            if (!app) return toast('App nicht gefunden – unter „Apps“ neu scannen', 'err');
            const ad = addonFor(app);
            act(t.op === 'smart' || !t.op ? (ad && ad.launch && !isRunning(app, S.st) ? ad.launch : { t: 'app', id: t.app, op: 'smart' }) : { t: 'app', id: t.app, op: t.op });
          },
          hold: true, longMs: 700,
          long: () => {
            if (!appById(t.app)) return toast('App nicht gefunden – unter „Apps“ neu scannen', 'err');
            act({ t: 'app', id: t.app, op: 'kill' });
          },
          menu: () => { const app = appById(t.app); if (app) openApp({ app }); } // right click on the PC: the app's page
        });
        return d => n.classList.toggle('running', isRunning(appById(t.app), d));
      }
    },

    action: {
      name: 'Aktion', w: 1, sq: true,
      build(n, t, live) {
        const emo = tileEmoji(t); // VIP: an emoji instead of the symbol
        n.append(el('div', { class: 't-ic' + (emo ? ' emoji' : '') }, emo ? el('span', { class: 't-emoji' }, emo) : ic(t.icon || actIcon(t.a || {}))), tileLabel(t.label || actLabel(t.a || {})));
        if (live) press(n, {
          tap: async () => {
            if (t.confirm && !await confirmSheet((t.label || actLabel(t.a)) + '?', 'Wirklich ausführen?', 'Ausführen', true)) return;
            flash(n);
            act(t.a);
          }
        });
        return null;
      }
    },

    stats: {
      name: 'Systemwerte', w: 4,
      build(n) {
        const mk = label => {
          const b = el('b', null, '–'), bar = el('i'), sm = el('small', null, '');
          const box = el('div', { class: 'bar' }, bar);
          n.append(el('div', { class: 'meter' }, el('div', { class: 'meter-top' }, label, b), box, sm));
          return (pct, extra) => {
            setText(b, pct == null ? '–' : Math.round(pct) + '%');
            const w = Math.round(pct || 0) + '%';
            if (bar.style.width !== w) bar.style.width = w;
            box.classList.toggle('hot', pct > 85);
            setText(sm, extra || '');
          };
        };
        const cpu = mk('CPU'), ram = mk('RAM'), gpu = mk('GPU');
        return d => {
          const s = d && d.stats;
          if (!s) return;
          cpu(s.cpu, 'Laufzeit ' + uptime(s.uptime));
          ram(s.ram && s.ram.pct, s.ram ? s.ram.used + ' / ' + s.ram.total + ' GB' : '');
          if (s.gpu) gpu(s.gpu.util, s.gpu.temp + ' °C · ' + Math.round(s.gpu.memUsed / 1024 * 10) / 10 + ' GB');
          else gpu(null, 'nur NVIDIA');
        };
      }
    },

    // A Spotify playlist with its cover: one tap starts it from the very first song.
    playlist: {
      name: 'Spotify-Playlist', w: 1,
      build(n, t, live) {
        const cover = t.image ? el('img', { class: 'plt-cover', src: t.image, alt: '', loading: 'lazy' })
          : el('div', { class: 'plt-cover none' }, ic(t.liked ? 'heart' : 'music'));
        n.append(cover, el('div', { class: 'plt-shade' }), el('span', { class: 'plt-badge' }, ic('play', 'fill')),
          tileLabel(t.label || t.name || 'Playlist'));
        if (live) press(n, { tap: () => { flash(n); act({ t: 'spotify', cmd: 'playlist', uri: t.uri, noShuffle: t.noShuffle !== false }); } });
        return null;
      }
    },

    // A group: a deck in the deck. Shows a preview of what's inside; tapping opens it – a new group is empty.
    group: {
      name: 'Gruppe', w: 1,
      build(n, t, live) {
        const kids = t.tiles || [], emo = tileEmoji(t);
        const sym = () => emo ? el('span', { class: 't-emoji' }, emo) : ic(t.icon || 'folder');
        const prev = el('div', { class: 'grp-prev' + (kids.length ? '' : ' empty') });
        if (kids.length) kids.slice(0, 4).forEach(k => prev.append(miniTile(k)));
        else prev.append(sym());
        n.append(prev, el('div', { class: 'grp-foot' }, el('span', { class: 'grp-ic' }, sym()),
          tileLabel(t.label || 'Gruppe'), kids.length ? el('span', { class: 'grp-count' }, String(kids.length)) : null));
        if (live) press(n, { tap: () => { flash(n); Deck.openGroup(t); } });
        return null;
      }
    }
  };

  // ---------- tile names ----------
  // Soft hyphens for long (mostly German) words: a name breaks as "Lieblings-songs" / "Bild-schirm" only when it has to,
  // instead of being cut mid-word or ending in "…". Rule of thumb: split before the last consonant between two vowels,
  // keep sch/spr/str/ch/ck/ph/th/sh/st/sp and kr/tr/pr/… together.
  const VOWELS = 'aeiouyäöü';
  const UNITS = ['schr', 'sch', 'spr', 'str', 'ch', 'ck', 'ph', 'th', 'sh', 'st', 'sp'];
  const ONSET = /^[cdfgkpt]r$/;
  function hyphWord(w) {
    const s = w.toLowerCase(), n = s.length, isV = i => VOWELS.includes(s[i]);
    const cuts = [];
    for (let i = 0; i < n;) {
      if (!isV(i)) { i++; continue; }
      let j = i;
      while (j < n && isV(j)) j++;
      let k = j;
      while (k < n && !isV(k)) k++;
      if (k >= n || j === k) break;
      let split = k - 1;
      const unit = UNITS.find(u => u.length <= k - j && s.slice(k - u.length, k) === u);
      if (unit) split = k - unit.length;
      else if (k - j >= 2 && ONSET.test(s.slice(k - 2, k))) split = k - 2;
      // compounds after "-en" ("Zwischen-ablage", "Seiten-ansicht"): split after the n, not before it
      else if (cuts.length && k - j === 1 && s[j] === 'n' && s[j - 1] === 'e' && j - i === 1 && !isV(i - 1) && n - k >= 4) split = k;
      cuts.push(split);
      i = k;
    }
    let out = '', last = 0;
    for (const c of cuts) {
      if (c < 3 || c - last < 2 || n - c < 3) continue;
      out += w.slice(last, c) + '­';
      last = c;
    }
    return out + w.slice(last);
  }
  const LONG_WORD = /[A-Za-zÄÖÜäöüß]{8,}/g;
  // the name as plain text; fitLabels() adds hyphens only to words that are wider than the tile
  const tileLabel = (text, cls) => el('div', { class: cls || 't-label', title: text, 'data-raw': text }, text);
  let measureCtx = null;
  function hyphToFit(n) {
    const raw = n.dataset.raw;
    if (raw == null) return;
    const cs = getComputedStyle(n), width = n.clientWidth;
    measureCtx = measureCtx || document.createElement('canvas').getContext('2d');
    measureCtx.font = cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
    n.textContent = raw.replace(LONG_WORD, w => measureCtx.measureText(w).width > width - 1 ? hyphWord(w) : w);
  }

  const tileIcon = k => k.type === 'action' ? (k.icon || actIcon(k.a || {})) : k.type === 'toggle' ? toggleInfo(k.bind).on : k.type === 'slider' ? 'sliders'
    : k.type === 'np' ? 'music' : k.type === 'stats' ? 'cpu' : k.type === 'playlist' ? (k.liked ? 'heart' : 'music') : isGroup(k) ? (k.icon || 'folder') : 'zap';
  // tiny version of a tile for the group preview
  function miniTile(k) {
    const color = k.color || (k.type === 'playlist' || k.type === 'np' ? 'green' : k.type === 'app' ? 'slate' : k.type === 'slider' ? 'cyan' : isGroup(k) ? 'orange' : 'violet');
    const box = el('span', { class: 'grp-mini c-' + color });
    if (k.type === 'app') box.append(appIcon({ id: k.app }, k.name || ''));
    else if (tileEmoji(k)) box.append(el('span', { class: 't-emoji' }, tileEmoji(k)));
    else if (k.type === 'playlist' && k.image) box.append(el('img', { src: k.image, alt: '', loading: 'lazy' }));
    else box.append(ic(tileIcon(k)));
    return box;
  }

  // Pick one of your Spotify playlists (incl. Lieblingssongs) and put it on the deck.
  async function playlistPicker(box) {
    const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade deine Playlists …'));
    const q = el('input', { class: 'in', type: 'search', placeholder: 'Playlist suchen …' });
    const close = sheet('Spotify-Playlist aufs Deck', el('div', null, el('div', { class: 'search', style: 'margin-bottom:12px' }, ic('search'), q), list));
    let all = [];
    const draw = () => {
      list.innerHTML = '';
      const s = q.value.trim().toLowerCase();
      const items = all.filter(p => !s || p.name.toLowerCase().includes(s));
      if (!items.length) return list.append(el('div', { class: 'empty' }, all.length ? 'Nichts gefunden.' : 'Keine Playlists gefunden.'));
      items.forEach(p => list.append(el('button', { class: 'pick-item', onclick: () => {
        close();
        addTile({ type: 'playlist', uri: p.uri, name: p.name, image: p.image || null, liked: p.kind === 'liked', noShuffle: true }, box);
        toast('„' + p.name + '“ liegt auf dem Deck – Tippen startet sie von vorne');
      } },
        el('span', { class: 'sp-img' }, p.image ? el('img', { src: p.image, alt: '', loading: 'lazy' }) : tic(p.kind === 'liked' ? 'heart' : 'music', p.kind === 'liked' ? 'violet' : 'green')),
        el('div', null, el('b', null, p.name), el('small', null, p.kind === 'liked' ? 'Deine Lieblingssongs' : (p.count ? p.count + ' Songs' : '') + (p.owner ? ' · ' + p.owner : ''))))));
    };
    q.addEventListener('input', draw);
    try {
      const st = await api('/api/spotify?what=status');
      if (!st.connected) {
        list.innerHTML = '';
        list.append(el('div', { class: 'empty' }, 'Dafür muss Spotify einmal verbunden werden.'),
          el('button', { class: 'btn primary block', onclick: () => { close(); spotifySetup(); } }, ic('music'), 'Spotify einrichten'));
        return;
      }
      all = await api('/api/spotify?what=playlists');
      draw();
    } catch (e) { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); }
  }

  // Volume as a fader that fits into one cell or stands upright: the fill shows the level,
  // dragging up/down anywhere on the tile changes it (relative, so a tap never jumps), the symbol mutes.
  function faderTile(n, t, live, b) {
    const fill = el('div', { class: 'fd-fill' });
    const val = el('div', { class: 'fd-val' }, '–');
    const mute = el('button', { class: 'fd-mute', 'aria-label': 'Stumm' }, b.proc ? appIcon({ proc: b.proc }, b.label) : ic(b.icon));
    n.classList.add('fader');
    n.append(fill, el('div', { class: 'fd-top' }, mute, val), tileLabel(t.label || b.label, 'fd-name'));
    const span = b.max - b.min;
    let cur = null, held = 0, pending = null, timer = null, last = 0, wasMuted = null;
    const paint = v => {
      fill.style.height = Math.max(0, Math.min(100, (v - b.min) / span * 100)) + '%';
      val.textContent = b.fmt(b.toServer(v));
    };
    const send = () => {
      timer = null;
      if (pending == null) return;
      const v = pending;
      pending = null;
      last = Date.now();
      act(t.bind === 'spotify' ? { t: 'spotify', cmd: 'volume', value: v } : { t: 'set', bind: t.bind, value: b.toServer(v) }, { quiet: 1 });
    };
    const setVal = v => {
      v = Math.max(b.min, Math.min(b.max, Math.round(v / b.step) * b.step));
      if (v === cur) return;
      if (cur != null && Math.floor((v - b.min) / span * 10) !== Math.floor((cur - b.min) / span * 10)) buzz(4); // a tick every 10 %
      cur = v;
      held = Date.now();
      paint(v);
      pending = v;
      const wait = (t.bind === 'spotify' ? 300 : 70) - (Date.now() - last);
      if (wait <= 0) send(); else if (!timer) timer = setTimeout(send, wait);
    };
    if (live) {
      if (b.muteBind) mute.onclick = e => { e.stopPropagation(); act({ t: 'toggle', bind: b.muteBind }, { quiet: 1 }); };
      let lastTap = 0;
      n.addEventListener('pointerdown', e => {
        if (e.button || cur == null || e.target.closest('.fd-mute')) return;
        const y0 = e.clientY, v0 = cur, scale = Math.max(n.clientHeight, 170); // whole range ≈ one tile height (at least 170 px)
        let moved = false;
        n.classList.add('dragging');
        try { n.setPointerCapture(e.pointerId); } catch (x) { }
        const move = ev => { if (Math.abs(y0 - ev.clientY) > 3) moved = true; setVal(v0 + (y0 - ev.clientY) / scale * span); };
        const end = () => {
          n.classList.remove('dragging');
          n.removeEventListener('pointermove', move);
          n.removeEventListener('pointerup', end);
          n.removeEventListener('pointercancel', end);
          held = Date.now();
          // double tap without dragging = mute / unmute
          if (!moved && b.muteBind) {
            if (Date.now() - lastTap < 350) { lastTap = 0; flash(n); act({ t: 'toggle', bind: b.muteBind }, { quiet: 1 }); }
            else lastTap = Date.now();
          }
        };
        n.addEventListener('pointermove', move);
        n.addEventListener('pointerup', end);
        n.addEventListener('pointercancel', end);
      });
      n.addEventListener('wheel', e => { if (cur == null) return; e.preventDefault(); setVal(cur + (e.deltaY < 0 ? 1 : -1) * span / 25); }, { passive: false });
    }
    return d => {
      const s = b.read(d);
      n.classList.toggle('idle', !s);
      if (!s) { setText(val, '–'); cur = null; return; }
      n.classList.toggle('muted-state', !!s.m);
      if (!b.proc && wasMuted !== !!s.m) { wasMuted = !!s.m; setIc(mute, s.m ? b.offIcon : b.icon); }
      if (n.classList.contains('dragging') || Date.now() - held < 1500) return; // don't jump back while the finger is (or just was) on it
      const v = b.fromServer(s.v);
      if (v !== cur) { cur = v; paint(cur); }
    };
  }

  function uptime(s) {
    if (s == null) return '';
    const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
    return (d ? d + ' T ' : '') + (d || h ? h + ' h ' : '') + m + ' min';
  }

  const gridArea = r => 'grid-column:' + (r.x + 1) + ' / span ' + r.w + ';grid-row:' + (r.y + 1) + ' / span ' + r.h;

  const tileClass = (t, r) => 'tile t-' + t.type + ' w' + (r.w >= 3 ? 4 : r.w) + (r.h >= 2 ? ' tall' : '') + (r.w >= 2 && r.h >= 2 ? ' big' : '') +
    ' c-' + (t.color || (isGroup(t) ? 'orange' : 'violet')) + (t.hideLabel ? ' no-label' : '');

  // the tile as it will look, without any function (for the editor's live preview)
  function tilePreview(t) {
    const w = Math.min(t.pos.w, 4), h = Math.min(t.pos.h, 3), cell = Math.round(Math.max(70, Math.min(116, Deck.cell || 96)));
    const r = { x: 0, y: 0, w, h };
    const grid = el('div', { class: 'deck preview-deck' + (cell < 84 ? ' compact' : ''),
      style: '--cell:' + cell + 'px;grid-template-columns:repeat(' + w + ',' + cell + 'px);grid-auto-rows:' + cell + 'px;width:' + (w * cell + (w - 1) * DECK_GAP) + 'px' });
    const p = Object.assign(clone(t), { pos: r });
    const n = el('div', { class: tileClass(p, r), style: gridArea(r) });
    try { TILES[p.type].build(n, p, false); } catch (e) { }
    grid.append(n);
    fitLabels(grid);
    return grid;
  }

  function renderTile(t, ups, page) {
    const kind = TILES[t.type];
    if (!kind) return null;
    const r = t.pos;
    const sel = S.editing && S.sel === t.id;
    const n = el('div', { class: tileClass(t, r) + (sel ? ' selected' : ''), style: gridArea(r) });
    if (S.editing && isGroup(t)) n.dataset.drop = 'g' + t.id; // drag other tiles onto it = into the group
    const upd = kind.build(n, t, !S.editing);
    if (upd) ups.push(upd);
    if (S.editing) {
      if (sel) n.append(el('span', { class: 'rs-handle', title: 'Ziehen = Größe ändern' }, ic('resize')));
      dragTile(n, t, page);
    }
    return n;
  }

  // Edit mode: tap = select (size bar), tap again = edit (a group opens), drag = move (phones: hold briefly first),
  // drag the corner of the selected tile = resize, drop on a page name / group / way back = move it there.
  function dragTile(n, t, page) {
    const cols = pageCols(page);
    let active = false;
    n.addEventListener('touchmove', e => { if (active) e.preventDefault(); }, { passive: false });
    n.addEventListener('contextmenu', e => e.preventDefault());
    n.addEventListener('pointerdown', e => {
      if (e.button) return;
      const resize = !!e.target.closest('.rs-handle');
      const touch = e.pointerType === 'touch';
      const grid = n.parentNode, marker = grid.querySelector('.drop-marker');
      const gr = grid.getBoundingClientRect(), gap = parseFloat(getComputedStyle(grid).columnGap) || 10;
      const pitch = (gr.width - gap * (cols - 1)) / cols + gap;
      const rect = n.getBoundingClientRect(), sx = e.clientX, sy = e.clientY, scroll0 = window.scrollY;
      let moving = false, armed = !touch || resize, target = null, ghost = null, chip = null, scrollT = null, lastY = sy;
      active = false;
      // a quick swipe on a phone still scrolls the page; holding still for a moment picks the tile up
      const armT = armed ? null : setTimeout(() => { armed = true; active = true; buzz(15); n.classList.add('lifted'); }, 260);
      try { n.setPointerCapture(e.pointerId); } catch (x) { }

      const mark = r => {
        const busy = page.tiles.some(o => o !== t && o.pos && hit(o.pos, r));
        marker.setAttribute('style', gridArea(r));
        marker.className = 'drop-marker on' + (busy ? ' push' : '');
      };
      const scrollLoop = () => {
        clearInterval(scrollT);
        scrollT = setInterval(() => {
          if (lastY < 90) window.scrollBy(0, -12);
          else if (lastY > window.innerHeight - 110) window.scrollBy(0, 12);
        }, 16);
      };
      const move = ev => {
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        lastY = ev.clientY;
        if (!armed) { if (Math.hypot(dx, dy) > 8) { clearTimeout(armT); finish(null, true); } return; }
        if (!moving) {
          if (Math.hypot(dx, dy) < 6) return;
          moving = true;
          active = true;
          n.classList.add('drag-src');
          if (!resize) {
            ghost = n.cloneNode(true);
            ghost.className += ' drag-ghost';
            ghost.setAttribute('style', 'left:' + rect.left + 'px;top:' + rect.top + 'px;width:' + rect.width + 'px;height:' + rect.height + 'px');
            document.body.append(ghost);
            scrollLoop();
          }
        }
        const gridTop = gr.top - (window.scrollY - scroll0);
        if (resize) {
          const w = Math.max(MIN_W[t.type] || 1, Math.min(cols - t.pos.x, Math.round((rect.width + dx + gap) / pitch)));
          const h = Math.max(1, Math.min(4, Math.round((rect.height + dy + gap) / pitch)));
          target = { x: t.pos.x, y: t.pos.y, w, h };
          n.setAttribute('style', gridArea(target));
          mark(target);
          return;
        }
        ghost.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(1.04)';
        const under = document.elementFromPoint(ev.clientX, ev.clientY);
        let c = under && under.closest('[data-drop]');
        if (c && (c === n || c.dataset.drop === boxKey(page))) c = null;
        if (c && c.classList.contains('tile')) {
          // a group tile: only its middle means "into the group" – near the edges the tile is placed next to it
          const gr2 = c.getBoundingClientRect(), fx = (ev.clientX - gr2.left) / gr2.width, fy = (ev.clientY - gr2.top) / gr2.height;
          if (fx < .18 || fx > .82 || fy < .18 || fy > .82) c = null;
        }
        if (chip && chip !== c) chip.classList.remove('drop');
        chip = c;
        if (chip) { chip.classList.add('drop'); marker.className = 'drop-marker'; target = null; return; }
        const gx = Math.round((rect.left + dx - gr.left) / pitch), gy = Math.round((rect.top + dy - gridTop) / pitch);
        target = { x: Math.max(0, Math.min(cols - t.pos.w, gx)), y: Math.max(0, gy), w: t.pos.w, h: t.pos.h };
        mark(target);
      };
      const finish = (ev, cancelled) => {
        n.removeEventListener('pointermove', move);
        n.removeEventListener('pointerup', up);
        n.removeEventListener('pointercancel', cancel);
        clearTimeout(armT);
        clearInterval(scrollT);
        active = false;
        n.classList.remove('lifted', 'drag-src');
        if (ghost) ghost.remove();
        if (chip) chip.classList.remove('drop');
        if (marker) marker.className = 'drop-marker';
        if (cancelled) { if (resize) n.setAttribute('style', gridArea(t.pos)); return; }
        if (!moving) {
          if (resize) return;
          if (S.sel !== t.id) { S.sel = t.id; Deck.draw(); } // first tap: select – shows the size bar
          else if (isGroup(t)) Deck.openGroup(t);        // tap again: open the group to fill it
          else editTile(t);                               // … or edit the tile
          return;
        }
        if (!chip && !target) return;
        remember();
        if (chip) { if (!moveTo(t, boxByKey(chip.dataset.drop))) { undoStack.pop(); paintUndo(); } }
        else placeAt(page, t, target);
        S.sel = t.id;
        saveLayout();
        Deck.draw();
      };
      const up = ev => finish(ev, false);
      const cancel = ev => finish(ev, true);
      n.addEventListener('pointermove', move);
      n.addEventListener('pointerup', up);
      n.addEventListener('pointercancel', cancel);
    });
  }

  // ---------- deck ----------

  const Deck = {
    title: 'Deck',
    pushed: 0, // history entries added for opened groups (so the phone's back gesture closes a group)
    poll() {
      const tiles = viewBox().tiles;
      const q = ['stats=' + (tiles.some(t => t.type === 'stats') ? 1 : 0)];
      if (tiles.some(t => (t.bind || '').startsWith('vm:'))) q.push('vm=1');
      if (tiles.some(t => (t.bind || '').startsWith('discord:'))) q.push('discord=1');
      if (tiles.some(t => t.bind === 'spotify' || t.type === 'np')) q.push('spotify=1');
      // only buttons on this page (nothing shows a live value): ask rarely, that saves battery
      const live = tiles.some(t => ['np', 'slider', 'toggle', 'app', 'stats'].includes(t.type));
      return { path: '/api/state?' + q.join('&'), ms: live ? 1000 : 5000 };
    },
    render(root) { this.root = root; this.intro = true; this.draw(); },
    draw() {
      const root = this.root;
      if (!root) return;
      // a new page or group: the tiles fly in one after another (not on every small change while editing)
      const intro = this.intro && !S.editing;
      this.intro = false;
      root.innerHTML = '';
      this.ups = [];
      const ps = S.layout.pages, idx = curPageIdx(), page = ps[idx];
      const trail = groupTrail(), box = trail.length ? trail[trail.length - 1] : page;
      if (S.sel && !box.tiles.some(t => t.id === S.sel)) S.sel = null;

      if (trail.length) root.append(this.crumbs(page, idx, trail));
      else if (ps.length > 1 || S.editing) {
        const bar = el('div', { class: 'page-bar' });
        ps.forEach((p, i) => bar.append(el('button', {
          class: 'page-chip' + (i === idx ? ' on' : ''), 'data-page': i, 'data-drop': 'p' + i,
          onclick: () => (S.editing && i === idx ? pageSheet(i) : setDeckPage(i))
        }, p.name, S.editing && i === idx ? ic('edit') : null)));
        if (S.editing) bar.append(el('button', { class: 'page-chip add', onclick: () => pageSheet(-1) }, ic('plus'), 'Seite'));
        root.append(bar);
        requestAnimationFrame(() => { const on = bar.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest', inline: 'center' }); });
      }

      const cols = pageCols(box);
      this.rows = Math.max(1, pageRows(box));
      if (S.editing) root.append(deckTools(box, cols));
      const grid = el('div', { class: 'deck' + (S.editing ? ' editing' : '') + (intro ? ' intro' : '') });
      const wrap = el('div', { class: 'deck-wrap', style: '--cols:' + cols }, grid);
      this.wrap = wrap;
      this.cols = cols;
      // top left first, then row by row
      const order = box.tiles.slice().sort((a, b) => (a.pos ? a.pos.y * 10 + a.pos.x : 0) - (b.pos ? b.pos.y * 10 + b.pos.x : 0));
      for (const t of box.tiles) {
        const n = renderTile(t, this.ups, box);
        if (!n) continue;
        if (intro) n.style.setProperty('--i', Math.min(order.indexOf(t), 24));
        grid.append(n);
      }
      if (intro) setTimeout(() => grid.classList.remove('intro'), 1400); // afterwards the tap effects take over again
      if (S.editing) {
        // every free cell (plus one extra row) is a "+": a new tile goes exactly there
        const rows = pageRows(box) + 1;
        for (let y = 0; y < rows; y++)
          for (let x = 0; x < cols; x++) {
            if (!fits(box, { x, y, w: 1, h: 1 })) continue;
            const slot = el('div', { class: 'slot', style: gridArea({ x, y, w: 1, h: 1 }), 'aria-label': 'Neue Kachel hier' }, ic('plus'));
            press(slot, { tap: () => { addAt = { x, y }; addTileSheet(); } });
            grid.append(slot);
          }
        grid.append(el('div', { class: 'drop-marker' }));
      }
      if (!trail.length) swipePages(grid);
      root.append(wrap);
      sizeDeck(wrap, cols);
      const selT = S.editing && S.sel ? box.tiles.find(t => t.id === S.sel) : null;
      if (selT) root.append(tileBar(box, selT));
      if (!box.tiles.length && !S.editing)
        root.append(el('div', { class: 'empty' }, trail.length ? 'Diese Gruppe ist noch leer. ' : 'Diese Seite ist noch leer. ',
          el('a', { href: '#', onclick: e => { e.preventDefault(); setEditing(true); } }, 'Kacheln hinzufügen')));
      if (S.editing)
        root.append(el('div', { class: 'edit-help' },
          el('div', null, ic('check'), el('span', null, el('b', null, 'Antippen: '), 'Kachel auswählen – unten erscheinen Größen, Bearbeiten und Löschen')),
          el('div', null, ic('edit'), el('span', null, el('b', null, 'Nochmal antippen: '), 'bearbeiten · eine Gruppe öffnet sich')),
          el('div', null, ic('mouse'), el('span', null, el('b', null, 'Verschieben: '), PC ? 'Kachel mit der Maus ziehen' : 'Kachel kurz festhalten, dann ziehen')),
          el('div', null, ic('folder'), el('span', null, el('b', null, 'In eine Gruppe: '), 'Kachel auf die Mitte einer Gruppe ziehen · raus: auf „Zurück“ ziehen')),
          el('div', null, ic('plus'), el('span', null, el('b', null, 'Neu: '), 'ein freies Feld antippen')),
          trail.length ? null : el('div', null, ic('grid'), el('span', null, el('b', null, 'Andere Seite: '), 'Kachel auf den Seitennamen oben ziehen · aktive Seite antippen = Name, Spalten, Aufräumen'))));
      else if (!trail.length && ps.length > 1)
        root.append(el('div', { class: 'page-dots' }, ps.map((p, i) => el('i', { class: i === idx ? 'on' : '' }))));
      this.update(S.st);
    },

    // inside a group: "Zurück" and where you are (page › group › …); you can drop tiles on them to move them out
    crumbs(page, idx, trail) {
      const up = trail.length > 1 ? trail[trail.length - 2] : page;
      const bar = el('div', { class: 'page-bar crumbs' },
        el('button', { class: 'page-chip back', 'data-drop': boxKey(up), onclick: () => this.closeGroup(1) }, ic('back'), 'Zurück'),
        el('button', { class: 'page-chip crumb', 'data-drop': 'p' + idx, onclick: () => this.closeGroup(trail.length) }, page.name));
      trail.forEach((g, i) => {
        const last = i === trail.length - 1;
        bar.append(el('span', { class: 'crumb-sep' }, ic('right')),
          el('button', { class: 'page-chip crumb' + (last ? ' on' : ''), 'data-drop': last ? null : boxKey(g), onclick: () => { if (!last) this.closeGroup(trail.length - 1 - i); else if (S.editing) editTile(g); } },
            ic(g.icon || 'folder'), g.label || 'Gruppe', last && S.editing ? ic('edit') : null));
      });
      requestAnimationFrame(() => { bar.scrollLeft = bar.scrollWidth; });
      return bar;
    },
    openGroup(g) {
      S.groupPath = groupTrail().map(x => x.id).concat(g.id);
      S.sel = null;
      history.pushState({ deckGroup: S.groupPath.length }, '');
      this.pushed = S.groupPath.length;
      this.intro = true;
      this.draw();
      window.scrollTo(0, 0);
      if (current === Deck) startPoll();
    },
    // back out of n groups – through the browser history, so the phone's back gesture does exactly the same
    closeGroup(n) {
      if (n <= 0) return;
      if (this.pushed >= S.groupPath.length) history.go(-n);
      else this.setDepth(Math.max(0, S.groupPath.length - n));
    },
    setDepth(d) {
      const tr = groupTrail();
      if (d >= tr.length) return;
      S.groupPath = tr.slice(0, d).map(x => x.id);
      this.pushed = Math.min(this.pushed, d);
      S.sel = S.editing ? tr[d].id : null; // in edit mode the group you came from stays selected
      this.intro = true;
      this.draw();
      if (current === Deck) startPoll();
    },
    update(d) {
      if (!d) return;
      S.st = d;
      if (d.vm && d.vm.ok) {
        const first = !S.vm;
        S.vm = d.vm;
        if (first) return this.draw(); // labels of Voicemeeter tiles come from this data
      }
      for (const u of this.ups) try { u(d); } catch (e) { }
    }
  };

  // ---------- deck size (per device) ----------

  const DECK_GAP = 10;
  const sizeName = v => !v ? 'Automatisch' : v <= 60 ? 'Sehr klein' : v <= 80 ? 'Klein' : v <= 108 ? 'Mittel' : v <= 148 ? 'Groß' : v < 200 ? 'Sehr groß' : 'Maximal';

  // Tile size of this one device: every new device measures its own screen ("Auto", 0) – a phone and an iPad can't
  // share one size. You can still pick a fixed size per device; the tiles themselves stay the same everywhere.
  function deckCellSetting() {
    const v = LS.get('tileSize', null);
    if (v != null) return v;
    return DEV === 'pc' ? LS.get('deckCell', 100) : 0; // the PC app keeps the size it had
  }
  function setDeckSize(v) { LS.set('tileSize', v); }

  // the screen height without the browser's address bar sliding in and out
  const viewH = () => document.documentElement.clientHeight || innerHeight;

  // "Automatisch": as big as the screen allows – a whole page should fit without scrolling where possible,
  // but the tiles shrink only a little for that and always stay big enough for a finger.
  function autoCell(wrap, cols) {
    const w = (wrap.parentNode && wrap.parentNode.clientWidth) || innerWidth;
    const byWidth = (w - (cols - 1) * DECK_GAP) / cols;
    let cell = Math.min(byWidth, DEV === 'tablet' ? 172 : DEV === 'phone' ? 150 : 132);
    const top = $('.top'), tabs = $('.tabs'), rows = Deck.rows || 1;
    const free = viewH() - (top ? top.offsetHeight : 70) - 64 - (tabs && tabs.offsetHeight ? tabs.offsetHeight + 12 : 0);
    const byHeight = (free - (rows - 1) * DECK_GAP) / rows;
    if (byHeight < cell) cell = Math.max(byHeight, cell * .72, Math.min(64, byWidth));
    return Math.floor(cell);
  }

  // The deck is never wider than "columns × tile size"; small tiles get a compact look (tiny ones: symbol only).
  function sizeDeck(wrap, cols) {
    const auto = !S.deckCell, want = S.deckCell || autoCell(wrap, cols);
    wrap.style.maxWidth = (cols * want + (cols - 1) * DECK_GAP) + 'px';
    const w = wrap.clientWidth, grid = wrap.firstChild;
    if (!w || !grid) return;
    const col = (w - (cols - 1) * DECK_GAP) / cols;
    Deck.cell = col;
    grid.style.setProperty('--cell', Math.round(col) + 'px'); // symbols and names grow with the tile (style.css)
    if (auto && !LS.get('screenSeen', false)) {
      // the very first start on this device: say that the screen was measured
      LS.set('screenSeen', true);
      toast('Bildschirm erkannt (' + screen.width + ' × ' + screen.height + ') – Kacheln und Symbole passen sich an');
    }
    grid.classList.toggle('compact', col < 84);
    grid.classList.toggle('tiny', col < 62);
    grid.classList.toggle('snug', col < 106); // one-cell tiles: no room for a state line under a two-line name
    fitLabels(grid);
    // tell the size control how big the tiles really are – a phone screen may be the limit, not the setting
    const real = Math.round(col), capped = !auto && S.deckCell > col + 6;
    document.querySelectorAll('.dt-info').forEach(n => {
      n.textContent = auto ? 'Automatisch: jede Kachel ist gerade ' + real + ' px breit – passend für diesen Bildschirm.'
        : 'Jede Kachel ist gerade ' + real + ' px breit' + (capped ? ' – größer geht hier nur mit weniger Spalten, der Bildschirm ist voll.' : '.');
      n.classList.toggle('warn', capped);
    });
  }
  let lastVW = innerWidth, lastVH = innerHeight;
  window.addEventListener('resize', () => {
    // phones: the address bar slides in and out while scrolling – that's no reason for new tile sizes
    if (Math.abs(innerWidth - lastVW) < 2 && Math.abs(innerHeight - lastVH) < 150) return;
    lastVW = innerWidth;
    lastVH = innerHeight;
    if (current === Deck && Deck.wrap && Deck.wrap.isConnected) sizeDeck(Deck.wrap, Deck.cols);
  });

  // Names first break at the soft hyphens, then shrink a little (never below a readable size) until they fit.
  function fitLabels(root) {
    requestAnimationFrame(() => root.querySelectorAll('.tile .t-label, .tile .fd-name').forEach(n => {
      n.style.fontSize = '';
      n.style.overflowWrap = 'normal';
      if (!n.clientHeight) return;
      hyphToFit(n);
      const start = parseFloat(getComputedStyle(n).fontSize), min = Math.max(10.5, start * .78);
      let size = start, guard = 0;
      const over = () => n.scrollHeight > n.clientHeight + 1 || n.scrollWidth > n.clientWidth + 1;
      while (over() && size > min && guard++ < 12) { size -= .5; n.style.fontSize = size + 'px'; }
      if (over()) n.style.overflowWrap = ''; // still too long: break the word after all (the full name is in the tooltip)
    }));
  }

  const SIZE_PRESETS = [[0, 'Auto'], [64, 'Klein'], [88, 'Mittel'], [120, 'Groß'], [200, 'Maximal']];
  function deckSizeControl() {
    const val = el('b', { class: 'dt-val' }, sizeName(S.deckCell));
    let seg = null;
    const mark = v => { if (seg) [...seg.children].forEach(b => b.classList.toggle('on', +b.dataset.k === v)); };
    const apply = v => {
      S.deckCell = v;
      val.textContent = sizeName(v);
      mark(v);
      if (Deck.wrap && Deck.wrap.isConnected) sizeDeck(Deck.wrap, Deck.cols);
    };
    const range = makeRange({ min: 48, max: 200, step: 4, throttle: 250 }, setDeckSize, apply);
    range.setValue(S.deckCell || Math.round(Deck.cell || 88)); // automatic: the slider starts at today's real size
    const set = v => {
      range.value = Math.max(48, Math.min(200, v));
      range.dispatchEvent(new Event('input'));
      range.dispatchEvent(new Event('change'));
    };
    const auto = () => { apply(0); setDeckSize(0); range.value = Math.round(Deck.cell || 88); range.dispatchEvent(new Event('change')); };
    seg = segTabs(SIZE_PRESETS.map(([v, l]) => [String(v), l]), String(S.deckCell), k => +k ? set(+k) : auto(), 'dt-presets');
    return el('div', { class: 'dt-sizebox' }, seg,
      el('div', { class: 'dt-size' },
        el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Kleiner', onclick: () => set(+range.value - 8) }, ic('zoomout')),
        el('div', { class: 'grow' }, range),
        el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Größer', onclick: () => set(+range.value + 8) }, ic('zoomin')),
        val),
      el('small', { class: 'dt-info' }, ''));
  }

  // Edit mode: size (this device) and columns (this page or group) right above the grid.
  function deckTools(page, cols) {
    return el('div', { class: 'card deck-tools' },
      el('div', { class: 'dt-block' }, el('span', { class: 'field-label' }, 'Kachelgröße', el('small', null, ' · nur dieses Gerät')), deckSizeControl()),
      el('div', { class: 'dt-block' }, el('span', { class: 'field-label' }, 'Spalten', el('small', null, isGroup(page) ? ' · diese Gruppe' : ' · diese Seite, alle Geräte')),
        segTabs([3, 4, 5, 6, 7, 8].map(c => [String(c), String(c)]), String(cols), k => {
          remember();
          page.cols = +k;
          normalize(page);
          saveLayout();
          Deck.draw();
        }),
        el('small', { class: 'field-hint' }, 'Weniger Spalten = größere Kacheln.')));
  }

  // ---------- size of one tile ----------

  const tileName = t => t.label || (t.type === 'action' ? actLabel(t.a || {}) : t.type === 'app' ? ((appById(t.app) || {}).name || t.name || 'App')
    : t.type === 'slider' ? bindInfo(t.bind).label : t.type === 'toggle' ? toggleInfo(t.bind).label : t.type === 'playlist' ? (t.name || 'Playlist')
    : isGroup(t) ? 'Gruppe' : (TILES[t.type] || {}).name || 'Kachel');

  // the sizes you need most, as one tap each
  function sizePresets(cols, minW) {
    const list = [[1, 1], [2, 1], [1, 2], [2, 2], [3, 1], [3, 2], [cols, 1]];
    return list.filter(([w, h], i) => w <= cols && w >= minW && list.findIndex(x => x[0] === w && x[1] === h) === i);
  }
  const sizeLabel = (w, h, cols) => w === cols && cols > 3 && h === 1 ? 'Zeile' : w + '×' + h;
  const sizeShape = (w, h) => el('span', { class: 'sz-shape', style: '--w:' + Math.min(w, 5) + ';--h:' + Math.min(h, 3) });
  function sizeButtons(cols, minW, cur, onPick) {
    return sizePresets(cols, minW).map(([w, h]) => el('button', {
      class: 'tb-size' + (cur.w === w && cur.h === h ? ' on' : ''), type: 'button', 'aria-label': w + ' × ' + h, onclick: () => onPick(w, h)
    }, sizeShape(w, h), el('span', null, sizeLabel(w, h, cols))));
  }

  // exact size: tap the field where the tile should end, like choosing a table size
  function sizeGrid(cols, minW, cur, onPick) {
    const g = el('div', { class: 'sz-grid', style: '--cols:' + cols });
    const label = el('div', { class: 'sz-label' });
    const cells = [];
    const paint = (w, h) => {
      cells.forEach(c => c.classList.toggle('on', +c.dataset.x < w && +c.dataset.y < h));
      label.textContent = w + ' × ' + h + (w === cols ? ' · ganze Zeile' : '') + (h > 1 ? ' · ' + h + ' Reihen hoch' : '');
    };
    for (let y = 0; y < 4; y++)
      for (let x = 0; x < cols; x++) {
        const w = Math.max(minW, x + 1), h = y + 1;
        const c = el('button', { type: 'button', class: 'sz-cell', 'data-x': x, 'data-y': y, 'aria-label': w + ' × ' + h });
        c.addEventListener('pointerenter', () => paint(w, h));
        c.addEventListener('click', () => { onPick(w, h); paint(cur.w, cur.h); });
        cells.push(c);
        g.append(c);
      }
    g.addEventListener('pointerleave', () => paint(cur.w, cur.h));
    paint(cur.w, cur.h);
    return el('div', { class: 'sz-pick' }, g, label);
  }

  function resizeTile(box, t, w, h) {
    const cols = pageCols(box);
    w = Math.max(MIN_W[t.type] || 1, Math.min(cols, w));
    h = Math.max(1, Math.min(4, h));
    if (t.pos.w === w && t.pos.h === h) return;
    remember();
    placeAt(box, t, { x: Math.min(t.pos.x, cols - w), y: t.pos.y, w, h });
    saveLayout();
    Deck.draw();
  }

  const countTiles = g => g.tiles.reduce((n, k) => n + 1 + (isGroup(k) ? countTiles(k) : 0), 0);
  async function deleteTile(t) {
    const n = isGroup(t) ? countTiles(t) : 0;
    if (!await confirmSheet((isGroup(t) ? 'Gruppe „' + tileName(t) + '“' : 'Kachel') + ' löschen?', n ? 'Die ' + n + (n === 1 ? ' Kachel darin wird' : ' Kacheln darin werden') + ' mitgelöscht.' : null, 'Löschen', true)) return false;
    remember();
    const cur = findTile(t.id);
    if (cur) cur.page.tiles.splice(cur.i, 1);
    if (S.sel === t.id) S.sel = null;
    saveLayout();
    if (current === Deck) Deck.draw();
    toast('Gelöscht – oben mit ↶ rückgängig machen');
    return true;
  }

  function duplicateTile(box, t) {
    remember();
    const c = clone(t);
    const renew = x => { x.id = uid(); if (isGroup(x)) x.tiles.forEach(renew); };
    renew(c);
    c.pos = null;
    c.pos = freeSpot(box, t.pos.w, t.pos.h, t.pos.x + t.pos.w, t.pos.y, c);
    box.tiles.push(c);
    S.sel = c.id;
    saveLayout();
    Deck.draw();
    toast('Kopie angelegt');
  }

  // Edit mode: bar for the tapped tile – change its size with one tap, edit, open (group), copy, delete.
  function tileBar(box, t) {
    const cols = pageCols(box), minW = MIN_W[t.type] || 1;
    const more = () => {
      const close = sheet('Größe: ' + tileName(t), el('div', null,
        el('p', { class: 'hint', style: 'margin:0 0 12px' }, 'Tippe auf das Feld, bis zu dem die Kachel reichen soll.'),
        sizeGrid(cols, minW, t.pos, (w, h) => { close(); resizeTile(box, t, w, h); })));
    };
    return el('div', { class: 'tile-bar' },
      el('div', { class: 'tb-head' },
        el('div', { class: 'grow' }, el('b', null, tileName(t)), el('small', null, 'Größe ' + t.pos.w + ' × ' + t.pos.h + (isGroup(t) ? ' · ' + t.tiles.length + ' Kacheln drin' : ''))),
        el('button', { class: 'icon-btn', 'aria-label': 'Auswahl aufheben', onclick: () => { S.sel = null; Deck.draw(); } }, ic('x'))),
      el('div', { class: 'tb-sizes' }, sizeButtons(cols, minW, t.pos, (w, h) => resizeTile(box, t, w, h)),
        el('button', { class: 'tb-size more', type: 'button', onclick: more }, ic('resize'), el('span', null, 'Genau'))),
      el('div', { class: 'tb-acts' },
        isGroup(t) ? el('button', { class: 'btn small primary', onclick: () => Deck.openGroup(t) }, ic('folder'), 'Öffnen') : null,
        el('button', { class: 'btn small' + (isGroup(t) ? '' : ' primary'), onclick: () => editTile(t) }, ic('edit'), 'Bearbeiten'),
        el('button', { class: 'btn small', onclick: () => duplicateTile(box, t) }, ic('copy'), 'Kopieren'),
        el('button', { class: 'btn small danger', 'aria-label': 'Löschen', onclick: () => deleteTile(t) }, ic('trash'), el('span', { class: 'tb-del' }, 'Löschen'))));
  }

  function setDeckPage(i) {
    S.pageIdx = i;
    S.groupPath = [];
    S.sel = null;
    Deck.pushed = 0;
    LS.set('deckPage', i);
    Deck.intro = true;
    Deck.draw();
    if (current === Deck) startPoll();
  }

  function swipePages(node) {
    let sx = null, sy = 0;
    node.addEventListener('touchstart', e => {
      sx = e.touches.length === 1 && !e.target.closest('input') ? e.touches[0].clientX : null;
      if (sx != null) sy = e.touches[0].clientY;
    }, { passive: true });
    node.addEventListener('touchend', e => {
      if (sx == null || S.editing) return;
      const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      sx = null;
      if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
      const i = curPageIdx() + (dx < 0 ? 1 : -1);
      if (i >= 0 && i < S.layout.pages.length) setDeckPage(i);
    }, { passive: true });
  }

  function pageSheet(i) {
    const isNew = i < 0;
    const ps = S.layout.pages;
    const p = isNew ? { id: uid(), name: '', tiles: [] } : ps[i];
    const name = el('input', { class: 'in', placeholder: 'z. B. Gaming, Musik, Stream', value: p.name, autocomplete: 'off' });
    const move = dir => {
      const j = i + dir;
      if (j < 0 || j >= ps.length) return;
      [ps[i], ps[j]] = [ps[j], ps[i]];
      saveLayout();
      close();
      setDeckPage(j);
    };
    let cols = pageCols(p);
    const save = () => {
      remember();
      p.name = name.value.trim() || 'Seite ' + (isNew ? ps.length + 1 : i + 1);
      if (cols !== pageCols(p)) { p.cols = cols; normalize(p); }
      if (isNew) ps.push(p);
      saveLayout();
      close();
      setDeckPage(isNew ? ps.length - 1 : i);
    };
    name.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
    const body = el('div', { class: 'form' },
      field('Name der Seite', name),
      field('Spalten', segTabs([3, 4, 5, 6, 7, 8].map(c => [String(c), String(c)]), String(cols), k => { cols = +k; }),
        'Mehr Spalten = mehr Kacheln pro Zeile. Gilt auf Handy und PC gleich – wie groß die Kacheln sind, stellst du pro Gerät im Bearbeiten-Modus ein.'),
      isNew || !p.tiles.length ? null : field('Lücken', el('button', { class: 'btn small', onclick: () => {
        remember();
        packPage(p);
        saveLayout();
        close();
        Deck.draw();
        toast('Aufgeräumt – alle Lücken geschlossen');
      } }, ic('grid'), 'Aufräumen: Kacheln nach oben rücken')),
      isNew || ps.length < 2 ? null : field('Reihenfolge', el('div', { class: 'row' },
        el('button', { class: 'btn small grow', onclick: () => move(-1) }, ic('left'), 'Nach links'),
        el('button', { class: 'btn small grow', onclick: () => move(1) }, 'Nach rechts', ic('right')))),
      el('div', { class: 'sheet-actions' },
        isNew || ps.length < 2 ? null : el('button', { class: 'btn danger', onclick: async () => {
          if (!await confirmSheet('Seite „' + p.name + '“ löschen?', p.tiles.length ? 'Die ' + p.tiles.length + ' Kacheln darauf werden mitgelöscht.' : null, 'Löschen', true)) return;
          ps.splice(i, 1);
          saveLayout();
          close();
          setDeckPage(Math.max(0, i - 1));
        } }, ic('trash')),
        el('button', { class: 'btn primary', onclick: save }, ic('check'), isNew ? 'Seite anlegen' : 'Speichern')));
    const close = sheet(isNew ? 'Neue Deck-Seite' : 'Seite bearbeiten', body);
    if (isNew) setTimeout(() => name.focus(), 300);
  }

  function setEditing(v) {
    S.editing = v;
    S.sel = null;
    document.querySelectorAll('.edit-btn').forEach(b => {
      b.classList.toggle('on', v);
      b.innerHTML = '';
      b.append(ic(v ? 'check' : 'edit'), el('span', null, v ? 'Fertig' : 'Bearbeiten'));
    });
    if (current === Deck) Deck.draw();
    paintUndo();
  }

  // ---------- media player (Windows sessions + Spotify) ----------

  function spotifySession(sp) {
    if (!sp || !sp.connected || !sp.active || !sp.track) return null;
    const t = sp.track;
    return {
      id: 'spotify-api', proc: 'spotify', app: 'Spotify' + (sp.device ? ' · ' + sp.device.name : ''), title: t.name, artist: t.artists, album: t.album,
      status: sp.playing ? 'playing' : 'paused', pos: sp.progress, dur: t.dur, shuffle: sp.shuffle,
      repeat: sp.repeat === 'context' ? 'list' : sp.repeat === 'track' ? 'track' : 'none', image: t.image,
      canPlay: true, canPause: true, canNext: true, canPrev: true, canSeek: true, canShuffle: true, canRepeat: true
    };
  }

  // Spotify is connected but nothing is active (paused, closed, or last on another device) – show the last song and let Play resume.
  const spotifyIdle = sp => sp && sp.connected && !sp.active && (sp.lastTrack || sp.spotifyRunning || (sp.devices && sp.devices.length));
  function spotifyIdleSession(sp) {
    if (!spotifyIdle(sp)) return null;
    const t = sp.lastTrack;
    return {
      id: 'spotify-api', proc: 'spotify', app: 'Spotify', title: t ? t.name : 'Spotify', artist: t ? t.artists : 'Bereit – auf Play tippen', album: t ? t.album : '',
      status: 'paused', pos: 0, dur: t ? t.dur : 0, image: t ? t.image : null, idle: true,
      canPlay: true, canPause: true, canNext: !!t, canPrev: !!t, canSeek: false, canShuffle: false, canRepeat: false
    };
  }

  function makePlayer() {
    const img = el('img', { alt: '' });
    const art = el('div', { class: 'pl-art' }, ic('music'), img);
    const bg = el('div', { class: 'pl-bg' });
    img.onerror = () => { img.style.display = 'none'; bg.classList.remove('on'); };
    img.onload = () => { img.style.display = ''; bg.style.backgroundImage = 'url("' + img.src.replace(/"/g, '%22') + '")'; bg.classList.add('on'); };
    const app = el('div', { class: 'pl-app' }, '');
    const title = el('div', { class: 'pl-title' }, 'Nichts läuft');
    const sub = el('div', { class: 'pl-sub' }, '');
    const tPos = el('span', null, '0:00'), tDur = el('span', null, '0:00');
    let cur = null, sp = null, base = 0, baseAt = 0, playing = false, lastArt = null;
    const useSp = () => !!(sp && sp.connected && cur && cur.proc === 'spotify');
    const control = (cmd, value) => {
      // nothing playing: prev/play/next still work as the keyboard's media keys (e.g. to resume Spotify)
      if (!cur) return act({ t: 'media', k: cmd === 'toggle' ? 'playpause' : cmd }, { quiet: 1 });
      if (useSp()) {
        const a = { t: 'spotify', cmd };
        if (cmd === 'seek') a.value = value;
        if (cmd === 'shuffle') a.value = !cur.shuffle;
        act(a, { quiet: 1 });
      } else act({ t: 'mctl', id: cur.id, cmd, value }, { quiet: 1 });
    };
    const seek = makeRange({ min: 0, max: 100, step: 1, throttle: 400 }, v => { base = v; baseAt = Date.now(); control('seek', v); }, v => { tPos.textContent = fmtTime(v); });
    const btn = (icon, label, fn, cls) => el('button', { class: 'pl-btn ' + (cls || ''), 'aria-label': label, onclick: fn }, ic(icon, cls === 'big' ? 'fill' : ''));
    const bShuf = btn('shuffle', 'Shuffle', () => control('shuffle', cur && cur.shuffle ? 0 : 1), 'pl-side');
    const bPrev = btn('prev', 'Zurück', () => control('prev'));
    const bPlay = btn('play', 'Play/Pause', () => { if (cur) { playing = !playing; setIc(bPlay, playing ? 'pause' : 'play', 'fill'); } control('toggle'); }, 'big');
    const bNext = btn('next', 'Weiter', () => control('next'));
    const bRep = btn('repeat', 'Wiederholen', () => {
      if (useSp()) return control('repeat');
      const r = cur && cur.repeat;
      control('repeat', r === 'none' ? 2 : r === 'list' ? 1 : 0);
    }, 'pl-side');
    setIc(bPrev, 'prev', 'fill'); setIc(bNext, 'next', 'fill');
    const like = el('button', { class: 'icon-btn like', 'aria-label': 'Liken', onclick: () => { like.classList.toggle('on'); act({ t: 'spotify', cmd: 'like', value: like.classList.contains('on') }); } }, ic('heart'));
    const volLabel = el('span', { class: 'v' }, '');
    const vol = makeVol({ min: 0, max: 100, step: 1, throttle: 250 }, v => {
      if (useSp()) act({ t: 'spotify', cmd: 'volume', value: v }, { quiet: 1 });
      else if (cur) act({ t: 'set', bind: 'app:' + cur.proc, value: v / 100 }, { quiet: 1 });
    }, v => { volLabel.textContent = v + ' %'; });
    const volName = el('span', null, 'Lautstärke');
    const volStep = d => () => {
      vol.value = Math.max(0, Math.min(100, +vol.value + d));
      vol.dispatchEvent(new Event('input'));
      vol.dispatchEvent(new Event('change'));
    };
    const volRow = el('div', { class: 'pl-vol' },
      el('button', { class: 'icon-btn', 'aria-label': 'Leiser', onclick: volStep(-5) }, ic('voldown')),
      el('div', { class: 'grow' }, el('div', { class: 'mix-name' }, volName, volLabel), vol),
      el('button', { class: 'icon-btn', 'aria-label': 'Lauter', onclick: volStep(5) }, ic('volume')));
    const devBtn = el('button', { class: 'chip pl-dev', onclick: () => spotifyDevices() }, ic('devices'), el('span', { class: 't' }, ''));
    const openBtn = el('button', { class: 'chip', onclick: () => cur && cur.proc && act({ t: 'focus', procs: cur.proc }, { quiet: 1 }) }, ic('window'), el('span', { class: 't' }, 'Am PC zeigen'));
    const note = el('div', { class: 'pl-note', style: 'display:none' });
    const node = el('div', { class: 'player card' },
      bg, art,
      el('div', { class: 'pl-main' },
        el('div', { class: 'pl-head' }, el('div', { class: 'grow' }, app, title, sub), like),
        el('div', { class: 'pl-seek' }, seek, el('div', { class: 'pl-times' }, tPos, tDur)),
        el('div', { class: 'pl-ctl' }, bShuf, bPrev, bPlay, bNext, bRep),
        volRow, el('div', { class: 'pl-foot' }, devBtn, openBtn), note));
    const timer = setInterval(() => {
      if (!cur || !playing || seek.busy()) return;
      const p = Math.min(cur.dur || 0, base + (Date.now() - baseAt) / 1000);
      seek.setValue(p);
      tPos.textContent = fmtTime(p);
    }, 500);

    return {
      node,
      set(s, spState, volumes) {
        sp = spState;
        const lim = s && s.proc === 'spotify' && sp && sp.limited;
        note.style.display = lim ? '' : 'none';
        if (lim) note.textContent = 'Spotify pausiert die Extras (Lautstärke in Spotify, Liken, Playlists) bis ' + lim + ' Uhr – Play, Pause, Weiter, Zufall gehen trotzdem.';
        if (s && s.proc === 'spotify' && sp && sp.connected && sp.active && sp.track) {
          const o = spotifySession(sp);
          s = Object.assign({}, s, { title: o.title, artist: o.artist, album: o.album, status: o.status, pos: o.pos, dur: o.dur, shuffle: o.shuffle, repeat: o.repeat, image: o.image });
        }
        cur = s;
        node.classList.toggle('empty-pl', !s);
        if (!s) {
          title.textContent = 'Gerade läuft nichts';
          sub.textContent = 'Play drückt die Medientaste am PC – oder starte Musik in Spotify, YouTube …';
          app.textContent = '';
          playing = false;
          setIc(bPlay, 'play', 'fill');
          img.style.display = 'none';
          bg.classList.remove('on');
          lastArt = null;
          volRow.style.display = 'none';
          devBtn.style.display = 'none';
          openBtn.style.display = 'none';
          like.style.display = 'none';
          tPos.textContent = tDur.textContent = '0:00';
          seek.setValue(0);
          return;
        }
        openBtn.style.display = s.proc && s.id !== 'spotify-api' ? '' : 'none';
        app.textContent = s.app || '';
        title.textContent = s.title || s.app || '';
        sub.textContent = [s.artist, s.album].filter(Boolean).join(' · ');
        const p = s.status === 'playing';
        if (p !== playing) { playing = p; setIc(bPlay, p ? 'pause' : 'play', 'fill'); }
        base = s.pos || 0;
        baseAt = Date.now();
        seek.setMax(Math.max(1, Math.round(s.dur || 0)));
        seek.setValue(base);
        seek.disabled = !s.canSeek;
        if (!seek.busy()) tPos.textContent = fmtTime(base);
        tDur.textContent = fmtTime(s.dur);
        bShuf.style.visibility = s.canShuffle || useSp() ? '' : 'hidden';
        bRep.style.visibility = s.canRepeat || useSp() ? '' : 'hidden';
        bShuf.classList.toggle('on', !!s.shuffle);
        bRep.classList.toggle('on', s.repeat === 'list' || s.repeat === 'track');
        setIc(bRep, s.repeat === 'track' ? 'repeat1' : 'repeat');
        bNext.disabled = !s.canNext;
        bPrev.disabled = !s.canPrev;
        const u = artUrl(s);
        if (u !== lastArt) { lastArt = u; if (u) img.src = u; else { img.style.display = 'none'; bg.classList.remove('on'); } }

        // volume: inside Spotify when connected, otherwise the app's Windows volume
        let v = null;
        if (useSp() && sp.device && sp.device.canVolume !== false) { v = sp.device.volume; volName.textContent = 'Spotify-Lautstärke'; }
        else if (volumes && volumes[s.proc]) { v = Math.round(volumes[s.proc].v * 100); volName.textContent = 'Windows-Lautstärke'; }
        volRow.style.display = v == null ? 'none' : '';
        if (v != null) { vol.setValue(v); if (!vol.busy()) volLabel.textContent = v + ' %'; }
        const showLike = useSp() && typeof sp.liked === 'boolean';
        like.style.display = showLike ? '' : 'none';
        if (showLike) like.classList.toggle('on', sp.liked);
        devBtn.style.display = useSp() && sp.device ? '' : 'none';
        if (useSp() && sp.device) devBtn.lastChild.textContent = sp.device.name;
      },
      destroy() { clearInterval(timer); }
    };
  }

  // ---------- spotify ----------

  async function spotifyDevices() {
    const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade Geräte …'));
    const close = sheet('Wiedergabe auf …', list);
    try {
      const devs = await api('/api/spotify?what=devices');
      list.innerHTML = '';
      if (!devs.length) list.append(el('div', { class: 'empty' }, 'Keine Spotify-Geräte gefunden. Öffne Spotify auf dem Gerät.'));
      devs.forEach(d => list.append(el('button', { class: 'pick-item' + (d.active ? ' on' : ''), onclick: () => { close(); act({ t: 'spotify', cmd: 'transfer', device: d.id }); } },
        tic(d.type === 'Smartphone' ? 'phone' : d.type === 'Speaker' ? 'volume' : 'monitor', d.active ? 'green' : 'slate'),
        el('div', null, el('b', null, d.name), el('small', null, d.type + (d.active ? ' · spielt gerade' : ''))))));
    } catch (e) { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); }
  }

  function spotifySetup(after) {
    const body = el('div', { class: 'form' }, el('div', { class: 'hint' }, 'Lade …'));
    let watch = null;
    const close = sheet('Spotify verbinden', body, { onClose: () => { clearInterval(watch); if (after) after(); } });
    api('/api/spotify?what=status').then(st => {
      body.innerHTML = '';
      if (st.connected) {
        body.append(
          el('div', { class: 'connected-box' }, tic('check', 'green'), el('div', null, el('b', null, 'Verbunden'), el('small', null, 'Angemeldet als ' + (st.user || '?')))),
          el('p', { class: 'hint' }, 'Spotify-Lautstärke, Lieblingssongs, Playlists, Suche, Warteschlange und Geräte sind aktiv.'),
          el('button', { class: 'btn danger', onclick: async () => { await act({ t: 'spotify', cmd: 'logout' }); S.sp = { connected: false }; close(); } }, ic('logout'), 'Spotify trennen'));
        return;
      }
      const cid = el('input', { class: 'in', placeholder: 'Client ID (32 Zeichen)', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', value: st.clientId || '' });
      const redirect = st.redirect;
      const copyBtn = el('button', { class: 'btn small', type: 'button', onclick: () => copyText(redirect).then(() => toast('Kopiert'), () => toast('Bitte von Hand markieren', 'err')) }, ic('copy'), 'Kopieren');
      const dash = 'https://developer.spotify.com/dashboard';
      body.append(
        el('p', { class: 'muted', style: 'margin:0' }, 'Einmalig, dauert etwa 2 Minuten. Danach steuerst du Spotify von innen: Lautstärke in Spotify, Liken, Playlists, Suche, Warteschlange, Geräte wechseln.'),
        el('ol', { class: 'steps small' },
          el('li', null, el('span', null, 'Öffne das Spotify-Dashboard und melde dich an: ',
            el('a', { href: dash, target: '_blank', rel: 'noopener' }, 'developer.spotify.com/dashboard'),
            S.local ? null : el('button', { class: 'btn small', type: 'button', style: 'margin-left:6px', onclick: () => act({ t: 'url', url: dash }) }, ic('external'), 'Am PC öffnen'))),
          el('li', null, el('span', null, 'Auf „Create app“ tippen. Name z. B. „PC Remote“, Beschreibung egal. Bei „Which API/SDKs“ ', el('b', null, 'Web API'), ' anhaken.')),
          el('li', null, el('span', null, 'Bei „Redirect URIs“ genau diese Adresse eintragen und „Add“ drücken:',
            el('div', { class: 'copy-row' }, el('code', null, redirect), copyBtn))),
          el('li', null, el('span', null, 'Speichern, dann in den App-Einstellungen die ', el('b', null, 'Client ID'), ' kopieren und hier einfügen:'))),
        cid,
        el('button', { class: 'btn primary', onclick: async () => {
          const v = cid.value.trim();
          if (v.length < 20) return toast('Bitte die Client ID einfügen', 'err');
          const r = await act({ t: 'spotify', cmd: 'login', clientId: v });
          if (!r) return;
          body.append(el('p', { class: 'hint', style: 'text-align:center' }, 'Warte auf die Bestätigung im Browser am PC …'));
          clearInterval(watch);
          let n = 0;
          watch = setInterval(async () => {
            if (++n > 90) return clearInterval(watch);
            try {
              const s = await api('/api/spotify?what=status');
              if (s.connected) { clearInterval(watch); S.sp = { connected: true }; toast('Spotify verbunden ✓'); close(); }
            } catch (e) { }
          }, 2000);
        } }, ic('music'), 'Mit Spotify verbinden'),
        el('p', { class: 'hint' }, 'Die Anmeldung öffnet sich im Browser am PC (Spotify erlaubt die Rückleitung nur dorthin). Es wird nur ein Anmelde-Schlüssel auf deinem PC gespeichert – kein Passwort.'));
    }).catch(e => { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); });
  }

  function spotifyPromo() {
    return el('div', { class: 'card promo' }, tic('music', 'green'),
      el('div', { class: 'grow' }, el('b', null, 'Spotify richtig steuern'),
        el('small', null, 'Lautstärke in Spotify, Liken, Playlists, Suche, Warteschlange, Geräte wechseln')),
      el('button', { class: 'btn small primary', onclick: () => spotifySetup() }, 'Einrichten'));
  }

  // Lists: queue, playlists, search, recently played
  function spotifyBrowser() {
    const tabs = [['playlists', 'Playlists'], ['search', 'Suche'], ['queue', 'Warteschlange'], ['recent', 'Zuletzt']];
    let cur = LS.get('spTab', 'playlists');
    const body = el('div', { class: 'sp-body' });
    const seg = segTabs(tabs, cur, k => { cur = k; LS.set('spTab', k); load(); });
    const row = (it, opts) => {
      const img = it.image ? el('img', { src: it.image, alt: '', loading: 'lazy' }) : tic(it.kind === 'liked' ? 'heart' : it.kind === 'artist' ? 'users' : 'music', it.kind === 'liked' ? 'violet' : 'green');
      const n = el('div', { class: 'sp-row' }, el('span', { class: 'sp-img' + (it.kind === 'artist' ? ' round' : '') }, img),
        el('div', { class: 'grow' }, el('b', null, it.name), el('small', null, opts.sub || '')),
        opts.queue ? el('button', { class: 'icon-btn', 'aria-label': 'Zur Warteschlange', onclick: e => { e.stopPropagation(); act({ t: 'spotify', cmd: 'queue', uri: it.uri }); } }, ic('list')) : null,
        opts.deck ? el('button', { class: 'icon-btn', 'aria-label': 'Aufs Deck legen', title: 'Aufs Deck legen', onclick: e => {
          e.stopPropagation();
          toDeck({ type: 'playlist', uri: it.uri, name: it.name, image: it.image || null, liked: it.kind === 'liked', noShuffle: true }, it.name);
        } }, ic('grid')) : null);
      if (opts.play) press(n, { tap: opts.play, long: opts.queue ? () => act({ t: 'spotify', cmd: 'queue', uri: it.uri }) : null });
      return n;
    };
    const play = (uri, context) => () => act({ t: 'spotify', cmd: 'playUri', uri, context }, { quiet: 1 });
    let searchInput = null, searchTimer = null, lastQ = '';
    async function load() {
      body.innerHTML = '';
      if (cur === 'search') {
        searchInput = el('input', { class: 'in', type: 'search', placeholder: 'Songs, Künstler, Alben, Playlists …', value: lastQ });
        const res = el('div');
        searchInput.addEventListener('input', () => {
          clearTimeout(searchTimer);
          lastQ = searchInput.value;
          searchTimer = setTimeout(() => doSearch(res), 350);
        });
        body.append(el('div', { class: 'search', style: 'margin-bottom:10px' }, ic('search'), searchInput), res);
        if (lastQ) doSearch(res);
        setTimeout(() => searchInput.focus(), 50);
        return;
      }
      body.append(el('div', { class: 'hint', style: 'padding:10px 0' }, 'Lade …'));
      try {
        const d = await api('/api/spotify?what=' + cur);
        body.innerHTML = '';
        if (cur === 'queue') {
          if (d.current) body.append(heading('Läuft gerade'), row(d.current, { sub: d.current.artists }));
          body.append(heading('Als Nächstes'));
          if (!d.queue.length) body.append(el('div', { class: 'empty' }, 'Die Warteschlange ist leer.'));
          d.queue.forEach(t => body.append(row(t, { sub: t.artists })));
        } else if (cur === 'playlists') {
          if (!d.length) body.append(el('div', { class: 'empty' }, 'Keine Playlists gefunden.'));
          d.forEach(p => body.append(row(p, { sub: p.kind === 'liked' ? 'Deine Lieblingssongs' : (p.count ? p.count + ' Songs' : '') + (p.owner ? ' · ' + p.owner : ''), play: play(p.uri), deck: true })));
        } else if (cur === 'recent') {
          if (!d.length) body.append(el('div', { class: 'empty' }, 'Noch nichts gehört.'));
          d.forEach(t => body.append(row(t, { sub: t.artists, play: play(t.uri), queue: true })));
        }
      } catch (e) { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); }
    }
    async function doSearch(res) {
      const q = (searchInput && searchInput.value || '').trim();
      if (!q) { res.innerHTML = ''; return; }
      try {
        const d = await api('/api/spotify?what=search&q=' + enc(q));
        if (q !== (searchInput.value || '').trim()) return;
        res.innerHTML = '';
        const group = (title, items, map) => { if (!items || !items.length) return; res.append(heading(title)); items.forEach(x => res.append(map(x))); };
        group('Songs', d.tracks, t => row(t, { sub: t.artists + (t.album ? ' · ' + t.album : ''), play: play(t.uri), queue: true }));
        group('Künstler', d.artists, a => row(a, { sub: 'Künstler', play: play(a.uri) }));
        group('Alben', d.albums, a => row(a, { sub: a.artists, play: play(a.uri), deck: true }));
        group('Playlists', d.playlists, p => row(p, { sub: p.owner, play: play(p.uri), deck: true }));
        if (!res.children.length) res.append(el('div', { class: 'empty' }, 'Nichts gefunden.'));
      } catch (e) { res.innerHTML = ''; res.append(el('div', { class: 'empty' }, e.message)); }
    }
    load();
    return el('div', { class: 'card sp-browser' }, el('div', { class: 'card-h' }, el('h3', null, 'Deine Musik'),
      el('div', { class: 'row' }, el('button', { class: 'icon-btn', 'aria-label': 'Geräte', onclick: spotifyDevices }, ic('devices')),
        el('button', { class: 'icon-btn', 'aria-label': 'Neu laden', onclick: load }, ic('refresh')))), seg, body);
  }

  // ---------- media view ----------

  const MediaView = {
    title: 'Medien',
    poll: () => ({ path: '/api/media?spotify=1', ms: 1000 }),
    render(root) {
      this.sel = LS.get('mediaSel', null);
      this.chips = el('div', { class: 'chips src-chips' });
      this.player = makePlayer();
      this.extra = el('div');
      this.chipKey = null;
      this.spMode = null;
      root.append(this.chips, el('div', { class: 'media-wrap' }, el('div', { class: 'media-grid' }, el('div', { class: 'pl-holder' }, this.player.node), this.extra)));
    },
    update(d) {
      const sp = d.spotify || { connected: false };
      S.sp = sp;
      let list = (d.sessions || []).slice();
      if (sp.connected && sp.active && !list.some(s => s.proc === 'spotify')) list.unshift(spotifySession(sp));
      // nothing active but Spotify is there: offer it so Play can resume
      else if (!list.some(s => s.proc === 'spotify') && spotifyIdle(sp)) list.push(spotifyIdleSession(sp));
      list = list.filter(Boolean);
      const key = list.map(s => s.id + s.app).join('|');
      if (key !== this.chipKey) {
        this.chipKey = key;
        this.chips.innerHTML = '';
        if (list.length > 1) list.forEach(s => this.chips.append(el('button', { class: 'chip', 'data-id': s.id, onclick: () => { this.sel = s.id; LS.set('mediaSel', s.id); this.update(this.last); } },
          s.proc && s.id !== 'spotify-api' ? appIcon({ proc: s.proc }, s.app) : ic('music'), el('span', { class: 't' }, s.app))));
      }
      const s = list.find(x => x.id === this.sel) || list[0] || null;
      [...this.chips.children].forEach(c => c.classList.toggle('on', !!s && c.dataset.id === s.id));
      this.last = d;
      this.player.set(s, sp, d.volumes);
      const mode = sp.connected ? 'browser' : 'promo';
      if (mode !== this.spMode) {
        this.spMode = mode;
        this.extra.innerHTML = '';
        this.extra.append(mode === 'browser' ? spotifyBrowser() : spotifyPromo());
      }
    },
    destroy() { if (this.player) this.player.destroy(); }
  };

  // ---------- clips (instant replay) ----------

  const CLIP_LEN = [[15, '15 s'], [30, '30 s'], [60, '1 Min.'], [120, '2 Min.']];
  const CLIP_QUALITY = [['mid', 'Gut'], ['high', 'Hoch'], ['max', 'Sehr hoch']];
  const CLIP_RES = [['native', 'Original'], ['1080', '1080p'], ['720', '720p']];
  const fmtSize = b => b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB';
  const clipUrl = (name, extra) => '/api/clipfile?name=' + enc(name) + '&' + authQ() + (extra || '');
  const clipTitle = n => n.replace(/\.mp4$/i, '');

  async function saveClip() {
    buzz();
    S.clipBusy = Date.now();
    try {
      const r = await api('/api/clips', { cmd: 'save' });
      toast(r.msg || 'Clip gespeichert');
      if (current === ClipsView) pollSoon();
    } catch (e) { toast(e.message, 'err'); }
  }

  const ClipsView = {
    title: 'Clips',
    poll: () => ({ path: '/api/clips', ms: 2000 }),
    render(root) {
      this.key = this.listKey = null;
      // clips newer than the last visit are marked "Neu" while this page is open
      this.seen = LS.get('clipsSeen', 0);
      LS.set('clipsSeen', Date.now());
      this.head = el('div', null, el('div', { class: 'empty' }, 'Lade …'));
      this.count = el('small', { class: 'muted' }, '');
      this.list = el('div', { class: 'clip-list' });
      root.append(this.head, el('div', { class: 'clip-list-head' }, el('h3', null, 'Gespeicherte Clips'), this.count), this.list);
    },
    update(d) {
      this.d = d;
      const s = d.settings, st = d.status;
      const key = JSON.stringify([s, st.state, st.error, st.encoder, st.capture, st.w, st.h, st.audio, st.hotkeyOk, d.folder, d.monitors]);
      if (key !== this.key) { this.key = key; this.drawHead(d); }
      if (this.bufEl) this.bufEl.textContent = st.state === 'on' ? 'Aufnahme läuft · ' + Math.min(st.buffered, s.seconds) + ' von ' + s.seconds + ' s im Puffer' : st.state === 'error' ? 'Aufnahme gestört' : 'Startet …';
      const lk = JSON.stringify(d.clips.map(c => [c.name, c.size, c.thumb]));
      if (lk !== this.listKey) { this.listKey = lk; this.drawList(d); }
    },
    set(patch) {
      api('/api/clips', Object.assign({ cmd: 'settings' }, patch))
        .then(d => { this.key = null; this.update(d); })
        .catch(e => toast(e.message, 'err'));
    },
    drawHead(d) {
      const s = d.settings, st = d.status, box = this.head;
      box.innerHTML = '';
      this.bufEl = null;
      const hk = s.hotkey ? prettyKeys(s.hotkey) : '';
      if (!s.enabled) {
        box.append(el('div', { class: 'card clip-hero off' },
          el('div', { class: 'clip-hero-ic' }, ic('video')),
          el('h2', null, 'Clip-Aufnahme pausiert'),
          el('p', { class: 'muted' }, 'Normalerweise merkt sich PC Remote ab dem Start ständig die letzten ' + s.seconds + ' Sekunden deines Bildschirms – mit Ton. Gerade ist das ausgeschaltet.'),
          el('button', { class: 'btn primary block', onclick: () => this.set({ enabled: true }) }, ic('record'), 'Wieder aufnehmen'),
          el('p', { class: 'hint' }, 'Gespeichert wird nur auf deinem PC (Videos → PC Remote Clips).')));
      } else {
        const ok = st.state === 'on';
        this.bufEl = el('b', null, '');
        const tech = [st.encoder ? (/nvidia/i.test(st.encoder) ? 'NVIDIA NVENC' : /intel/i.test(st.encoder) ? 'Intel Quick Sync' : /amd|amf/i.test(st.encoder) ? 'AMD AMF' : /software/i.test(st.encoder) ? 'Software-Encoder' : st.encoder) : null,
          st.w ? st.w + '×' + st.h : null, s.fps + ' FPS', st.audio ? 'mit Ton' : 'ohne Ton'].filter(Boolean).join(' · ');
        box.append(el('div', { class: 'card clip-hero' + (ok ? ' live' : '') },
          el('div', { class: 'clip-status' }, el('i', { class: 'rec-dot' }), el('div', { class: 'grow' }, this.bufEl, el('small', null, st.state === 'error' ? st.error : tech))),
          el('button', { class: 'btn primary block clip-save', disabled: !ok, onclick: saveClip }, ic('scissors'), 'Clip speichern'),
          el('p', { class: 'hint', style: 'text-align:center;margin:10px 0 0' }, hk
            ? (st.hotkeyOk ? 'Am PC – auch mitten im Spiel: ' : 'Das Kürzel ' + hk + ' benutzt schon ein anderes Programm – bitte unten ein anderes wählen. ')
            : 'Kein Tastenkürzel am PC eingestellt.', st.hotkeyOk && hk ? el('kbd', null, hk) : null)));
      }

      // settings
      const sel = el('select', { class: 'in' }, el('option', { value: '' }, 'Hauptbildschirm'), d.monitors.map(m => el('option', { value: m.dev }, m.name)));
      sel.value = s.monitor || '';
      sel.onchange = () => this.set({ monitor: sel.value });
      const hkIn = el('input', { class: 'in', value: s.hotkey || '', placeholder: 'z. B. alt+shift+c', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const seg = (key, items) => segTabs(items.map(([v, l]) => [String(v), l]), String(s[key]), k => this.set({ [key]: isNaN(+k) ? k : +k }));
      box.append(el('div', { class: 'card form clip-settings' },
        el('div', { class: 'card-h' }, el('h3', null, 'Aufnahme'), el('small', null, 'Änderungen starten den Puffer neu')),
        el('label', { class: 'check' }, el('span', null, 'Ab dem Start im Hintergrund aufnehmen (empfohlen)'), sw(s.enabled, v => this.set({ enabled: v }))),
        field('Länge eines Clips', seg('seconds', CLIP_LEN)),
        el('div', { class: 'size-row' }, field('Bildrate', seg('fps', [[30, '30 FPS'], [60, '60 FPS']])), field('Qualität', seg('quality', CLIP_QUALITY))),
        el('div', { class: 'size-row' }, field('Auflösung', seg('res', CLIP_RES)), field('Bildschirm', sel)),
        el('label', { class: 'check' }, el('span', null, 'Ton aufnehmen (was du hörst)'), sw(s.audio, v => this.set({ audio: v }))),
        el('label', { class: 'check' }, el('span', null, 'Ton am PC beim Speichern'), sw(s.sound, v => this.set({ sound: v }))),
        el('p', { class: 'hint', style: 'margin:0' }, 'Clippen mit deiner Stimme: Einstellungen → „Clips per Stimme“.'),
        field('Tastenkürzel am PC', el('div', { class: 'row' }, el('div', { class: 'grow' }, hkIn),
          el('button', { class: 'btn small', onclick: () => this.set({ hotkey: hkIn.value.trim().toLowerCase() }) }, ic('check'), 'Übernehmen')),
          'Funktioniert überall, auch im Spiel. Tasten mit + verbinden, z. B. alt+shift+c, ctrl+f9 oder f8. Leer lassen = aus.'),
        field('Speicherort', el('div', null, el('div', { class: 'mono clip-folder' }, d.folder),
          el('div', { class: 'row wrap', style: 'margin-top:8px' },
            el('button', { class: 'btn small', onclick: () => api('/api/clips', { cmd: 'folder' }).then(r => toast(r.msg)).catch(e => toast(e.message, 'err')) }, ic('folder'), 'Ordner am PC öffnen'),
            S.local ? el('button', { class: 'btn small', onclick: () => api('/api/clips', { cmd: 'choosefolder' }).then(r => { this.key = null; this.update(r); }).catch(e => toast(e.message, 'err')) }, ic('edit'), 'Ändern') : null)))));
    },
    drawList(d) {
      const list = this.list;
      list.innerHTML = '';
      this.count.textContent = d.clips.length ? d.clips.length + (d.clips.length === 1 ? ' Clip · ' : ' Clips · ') + fmtSize(d.total) : '';
      if (!d.clips.length) {
        list.append(el('div', { class: 'empty clip-empty' }, ic('scissors'), el('div', null, 'Noch keine Clips.'),
          el('small', null, d.settings.enabled ? 'Tippe auf „Clip speichern“' + (d.settings.hotkey ? ' oder drücke am PC ' + prettyKeys(d.settings.hotkey) : '') + '.' : 'Die Aufnahme ist pausiert – oben fortsetzen.')));
        return;
      }
      // filter by game (chips), then grouped by day – newest first; clips since the last visit get a "Neu"
      const games = new Map();
      d.clips.forEach(c => games.set(clipGame(c.name), (games.get(clipGame(c.name)) || 0) + 1));
      let pick = LS.get('clipGame', '');
      if (pick && !games.has(pick)) pick = '';
      if (games.size > 1) {
        const chip = (k, label, n) => el('button', { class: 'chip' + (pick === k ? ' on' : ''), onclick: () => { LS.set('clipGame', k); this.drawList(d); } },
          el('span', { class: 't' }, label), el('span', { class: 'chip-n' }, n));
        list.append(el('div', { class: 'chips clip-filter' }, chip('', 'Alle', d.clips.length), [...games].sort((a, b) => b[1] - a[1]).map(([g, n]) => chip(g, g, n))));
      }
      let day = null, grid = null;
      for (const c of d.clips) {
        if (pick && clipGame(c.name) !== pick) continue;
        const dl = clipDay(c.time);
        if (dl !== day) { day = dl; list.append(el('div', { class: 'clip-day' }, dl)); grid = el('div', { class: 'clip-grid' }); list.append(grid); }
        const img = c.thumb ? el('img', { src: '/api/clipthumb?name=' + enc(c.name) + '&' + authQ(), alt: '', loading: 'lazy' }) : null;
        const fresh = c.time > (this.seen || 0);
        grid.append(el('button', { class: 'clip-card' + (fresh ? ' fresh' : ''), onclick: () => openClip(c, () => { this.listKey = null; pollSoon(); }) },
          el('div', { class: 'clip-thumb' }, img || ic('video'), fresh ? el('span', { class: 'clip-new' }, 'Neu') : null,
            c.dur ? el('span', { class: 'clip-dur' }, fmtTime(c.dur)) : null, el('span', { class: 'clip-play' }, ic('play', 'fill'))),
          el('div', { class: 'clip-meta' }, el('b', null, clipName(c.name)),
            el('small', null, new Date(c.time).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }) + ' · ' + fmtSize(c.size) + (c.h ? ' · ' + c.h + 'p' : '')))));
      }
    }
  };
  // "Fortnite 2026-10-26 17-42-11" → game "Fortnite"; renamed clips keep their own name
  const CLIP_STAMP = /\s*\d{4}-\d{2}-\d{2} \d{2}-\d{2}-\d{2}( \(\d+\))?$/;
  const clipGame = n => { const t = clipTitle(n); return CLIP_STAMP.test(t) ? (t.replace(CLIP_STAMP, '') || 'Desktop') : 'Eigene Namen'; };
  const clipName = n => { const t = clipTitle(n); return CLIP_STAMP.test(t) ? (t.replace(CLIP_STAMP, '') || 'Desktop') : t; };
  function clipDay(ms) {
    const d = new Date(ms), today = new Date();
    const days = Math.round((new Date(today.getFullYear(), today.getMonth(), today.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);
    return days === 0 ? 'Heute' : days === 1 ? 'Gestern' : d.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
  }

  // Player with download, rename, delete.
  function openClip(c, changed) {
    const video = el('video', { class: 'clip-video', src: clipUrl(c.name), controls: true, playsinline: true, preload: 'metadata', autoplay: true });
    const title = el('div', { class: 'clip-sheet-title' }, clipTitle(c.name));
    const run = (body, ok) => api('/api/clips', body).then(r => { if (r && r.msg) toast(r.msg); if (ok) ok(r); }).catch(e => toast(e.message, 'err'));
    const body = el('div', { class: 'clip-sheet' }, video, title,
      el('small', { class: 'muted' }, ago(c.time) + ' · ' + fmtSize(c.size) + (c.w ? ' · ' + c.w + '×' + c.h : '') + (c.dur ? ' · ' + fmtTime(c.dur) : '')),
      el('div', { class: 'clip-actions' },
        el('a', { class: 'btn primary', href: clipUrl(c.name, '&dl=1'), download: c.name }, ic('download'), PC ? 'Speichern unter …' : 'Aufs Handy laden'),
        el('button', { class: 'btn', onclick: () => run({ cmd: 'play', name: c.name }) }, ic('monitor'), 'Am PC abspielen'),
        el('button', { class: 'btn', onclick: () => run({ cmd: 'folder', name: c.name }) }, ic('folder'), 'Im Ordner zeigen'),
        el('button', { class: 'btn', onclick: () => renameClip(c, n => { c.name = n; title.textContent = clipTitle(n); changed(); }) }, ic('edit'), 'Umbenennen'),
        el('button', { class: 'btn danger', onclick: async () => {
          if (!await confirmSheet('Clip löschen?', '„' + clipTitle(c.name) + '“ wird endgültig vom PC gelöscht.', 'Löschen', true)) return;
          run({ cmd: 'delete', name: c.name }, () => { toast('Gelöscht'); close(); changed(); });
        } }, ic('trash'), 'Löschen')));
    const close = sheet('Clip', body, { wide: true, onClose: () => { video.pause(); video.removeAttribute('src'); video.load(); } });
  }

  function renameClip(c, done) {
    const inp = el('input', { class: 'in', value: clipTitle(c.name), autocomplete: 'off' });
    const go = () => api('/api/clips', { cmd: 'rename', name: c.name, to: inp.value.trim() })
      .then(r => { close(); toast('Umbenannt'); done(r.name); }).catch(e => toast(e.message, 'err'));
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    const close = sheet('Clip umbenennen', el('div', { class: 'form' }, inp,
      el('div', { class: 'sheet-actions' }, el('button', { class: 'btn', onclick: () => close() }, 'Abbrechen'), el('button', { class: 'btn primary', onclick: go }, ic('check'), 'Umbenennen'))));
    setTimeout(() => { inp.focus(); inp.select(); }, 300);
  }

  // ---------- mixer + voicemeeter ----------

  function mixRow(o) {
    const iconBox = o.proc ? appIcon({ proc: o.proc }, o.name) : el('span', { class: 'appic sys' }, ic(o.icon));
    const v = el('span', { class: 'v' }, '–');
    const sc = o.scale || PCT;
    const range = makeVol(sc, x => act({ t: 'set', bind: o.bind, value: sc.toServer(x) }, { quiet: 1 }), x => { v.textContent = sc.fmt(sc.toServer(x)); });
    const mute = el('button', { class: 'icon-btn', 'aria-label': 'Stumm', onclick: () => act({ t: 'toggle', bind: o.muteBind || o.bind }, { quiet: 1 }) }, ic(o.icon === 'mic' ? 'mic' : 'volume'));
    const peak = el('i');
    const mid = el('div', { class: 'mix-mid' }, el('div', { class: 'mix-name' }, el('span', null, o.name), v), range, o.peak ? el('div', { class: 'peak' }, peak) : null);
    const row = el('div', { class: 'mix-row' }, iconBox, mid, mute);
    let lastM = null;
    row.set = s => {
      if (!s) { v.textContent = '–'; return; }
      range.setValue(sc.fromServer(s.v));
      if (!range.busy()) v.textContent = sc.fmt(s.v);
      if (lastM !== !!s.m) {
        lastM = !!s.m;
        row.classList.toggle('muted-state', lastM);
        mute.classList.toggle('alert', lastM);
        setIc(mute, lastM ? (o.icon === 'mic' ? 'micoff' : 'mute') : (o.icon === 'mic' ? 'mic' : 'volume'));
      }
      if (o.peak) peak.style.width = Math.min(100, (s.peak || 0) * 100) + '%';
    };
    return row;
  }

  function vmPanel() {
    const box = el('div');
    let key = null, ups = [];
    const strip = (base, label, buses) => {
      const v = el('span', { class: 'v' }, '');
      const range = makeVol(DB, x => act({ t: 'set', bind: 'vm:' + base + '.Gain', value: x }, { quiet: 1 }), x => { v.textContent = DB.fmt(x); });
      const mute = el('button', { class: 'vm-bus mute', onclick: () => act({ t: 'toggle', bind: 'vm:' + base + '.Mute' }, { quiet: 1 }) }, 'Mute');
      const chips = buses.map(name => {
        const c = el('button', { class: 'vm-bus', onclick: () => act({ t: 'toggle', bind: 'vm:' + base + '.' + name }, { quiet: 1 }) }, name);
        c.param = base + '.' + name;
        return c;
      });
      const n = el('div', { class: 'vm-strip' }, el('div', { class: 'mix-name' }, el('span', null, label), v), range, el('div', { class: 'vm-buses' }, mute, chips));
      ups.push(p => {
        const g = p[base + '.Gain'];
        range.setValue(g);
        if (!range.busy()) v.textContent = DB.fmt(g);
        const m = p[base + '.Mute'] > 0.5;
        mute.classList.toggle('on', m);
        n.classList.toggle('muted-state', m);
        chips.forEach(c => c.classList.toggle('on', p[c.param] > 0.5));
      });
      return n;
    };
    return {
      node: box,
      update(vm) {
        if (!vm || !vm.ok) {
          if (key !== 'off') {
            key = 'off';
            box.innerHTML = '';
            box.append(el('div', { class: 'empty' }, 'Voicemeeter ist nicht verbunden (nicht installiert oder nicht gestartet).'));
          }
          return;
        }
        S.vm = vm;
        const k = vm.type + JSON.stringify(vm.strips.map(s => s.label));
        if (k !== key) {
          key = k;
          box.innerHTML = '';
          ups = [];
          const strips = el('div', { class: 'card' });
          for (const s of vm.strips) strips.append(strip('Strip[' + s.i + ']', s.label, vm.buses.map(x => x.name)));
          const buses = el('div', { class: 'card' });
          for (const b of vm.buses) buses.append(strip('Bus[' + b.i + ']', 'Bus ' + b.name, []));
          box.append(
            heading('Eingänge', el('div', { class: 'row' },
              el('button', { class: 'btn small', onclick: () => act({ t: 'vm', cmd: 'show' }) }, ic('window'), 'Öffnen'),
              el('button', { class: 'btn small', onclick: () => act({ t: 'vm', cmd: 'restart' }) }, ic('restart'), 'Engine'))),
            strips, heading('Ausgänge (Busse)'), buses);
        }
        for (const u of ups) u(vm.params);
      }
    };
  }

  const Mixer = {
    title: 'Mixer',
    poll: () => ({ path: '/api/mixer?vm=1', ms: 900 }),
    render(root) {
      this.master = mixRow({ name: 'Lautsprecher', icon: 'volume', bind: 'master' });
      this.mic = mixRow({ name: 'Mikrofon', icon: 'mic', bind: 'mic' });
      this.sessBox = el('div');
      this.outBox = el('div', { class: 'dev-list' });
      this.inBox = el('div', { class: 'dev-list' });
      this.vm = vmPanel();
      this.sessKey = this.outKey = this.inKey = null;
      const tab = LS.get('mixTab', 'vol');
      this.panes = {
        vol: el('div', null, el('div', { class: 'card' }, this.master, this.mic), heading('Apps'), el('div', { class: 'card' }, this.sessBox)),
        dev: el('div', null, heading('Ausgabe (Lautsprecher / Headset)'), el('div', { class: 'card' }, this.outBox), heading('Eingabe (Mikrofon)'), el('div', { class: 'card' }, this.inBox)),
        vm: this.vm.node
      };
      const pick = k => { LS.set('mixTab', k); Object.keys(this.panes).forEach(p => { this.panes[p].style.display = p === k ? '' : 'none'; }); };
      this.seg = segTabs([['vol', 'Lautstärke'], ['dev', 'Geräte'], ['vm', 'Voicemeeter']], tab, pick, 'top-seg');
      this.seg.lastChild.style.display = 'none';
      root.append(this.seg, this.panes.vol, this.panes.dev, this.panes.vm);
      pick(tab === 'vm' ? 'vol' : tab);
      this.wantVm = tab === 'vm';
    },
    update(d) {
      this.master.set(d.master);
      this.mic.set(d.mic);
      const sess = d.sessions || [];
      const key = sess.map(s => s.key).join('|');
      if (key !== this.sessKey) {
        this.sessKey = key;
        this.rows = {};
        this.sessBox.innerHTML = '';
        if (!sess.length) this.sessBox.append(el('div', { class: 'empty' }, 'Gerade spielt keine App Ton ab.'));
        for (const s of sess) {
          const r = mixRow({ name: s.name, proc: s.key, bind: 'app:' + s.key, peak: true });
          this.rows[s.key] = r;
          this.sessBox.append(r);
        }
      }
      for (const s of sess) this.rows[s.key].set(s);
      this.devices(d.outputs, 'outBox', 'outKey', 'headphones');
      this.devices(d.inputs, 'inBox', 'inKey', 'mic');
      const vmOk = !!(d.vm && d.vm.ok);
      this.seg.lastChild.style.display = vmOk ? '' : 'none';
      if (vmOk && this.wantVm) { this.wantVm = false; this.seg.lastChild.click(); }
      this.vm.update(d.vm);
    },
    devices(list, box, keyName, icon) {
      list = list || [];
      const key = JSON.stringify(list);
      if (key === this[keyName]) return;
      this[keyName] = key;
      const b = this[box];
      b.innerHTML = '';
      if (!list.length) b.append(el('div', { class: 'hint' }, 'Keine Geräte gefunden'));
      for (const dev of list)
        b.append(el('button', { class: 'dev-row' + (dev.def ? ' on' : ''), onclick: () => !dev.def && act({ t: 'device', id: dev.id }) },
          ic(icon), el('span', { class: 'grow' }, dev.name), dev.def ? el('span', { class: 'dev-badge' }, ic('check'), 'Aktiv') : null));
    }
  };

  // ---------- apps & addons ----------

  function resolveAction(item, ctx) {
    if (item.setting) {
      const keys = setting(ctx.addon, item.setting);
      return keys ? { t: 'key', keys } : null;
    }
    if (item.ref) {
      const ad = ADDONS.find(x => x.id === item.ref[0]);
      const keys = ad && setting(ad, item.ref[1]);
      return keys ? { t: 'key', keys } : null;
    }
    const a = clone(item.a);
    if (a.t === 'appkey' && !a.id && !a.procs) {
      if (ctx.app) a.id = ctx.app.id;
      else a.procs = ctx.procs.join(',');
    }
    return a;
  }

  function deckTileFor(item, ctx) {
    if (item.deck) return Object.assign({}, item.deck);
    const a = resolveAction(item, ctx);
    if (!a) return null;
    return { type: 'action', label: item.label, icon: item.icon || actIcon(a), color: item.color || (ctx.addon && ctx.addon.color) || 'violet', a, confirm: item.confirm };
  }

  function buttonMenu(item, ctx, extra) {
    const items = [{ icon: tic('grid', 'violet'), title: 'Aufs Deck legen', sub: 'Als Kachel auf der Startseite', onclick: () => {
      close();
      const t = deckTileFor(item, ctx);
      if (!t) return toast('Erst das Kürzel in den Einstellungen eintragen', 'err');
      toDeck(t, item.label);
    } }];
    (extra || []).forEach(x => items.push(Object.assign({}, x, { onclick: () => { close(); x.onclick(); } })));
    const close = sheet(item.label, pickList(items));
  }

  // An addon button whose shortcut is still missing (OBS, TeamSpeak …): enter it right here instead of hunting for the settings.
  function askKey(item, ctx, then) {
    const ad = item.ref ? ADDONS.find(x => x.id === item.ref[0]) : ctx.addon;
    const key = item.ref ? item.ref[1] : item.setting;
    if (!ad || !key) return toast('Dafür fehlt noch das Tastenkürzel', 'err');
    const def = (ad.settings || []).find(s => s.key === key) || {};
    const inp = el('input', { class: 'in', value: setting(ad, key) || '', placeholder: 'z. B. ctrl+alt+f9', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
    const save = () => {
      const v = inp.value.trim().toLowerCase().replace(/\s*\+\s*/g, '+');
      if (!v) return inp.focus();
      AD.settings[ad.id] = Object.assign({}, AD.settings[ad.id] || {}, { [key]: v });
      saveAddons();
      close();
      toast('„' + item.label + '“ = ' + prettyKeys(v));
      if (then) then();
    };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') save(); });
    const close = sheet(item.label, el('div', { class: 'form' },
      el('p', { class: 'hint', style: 'margin:0' }, (def.hint || 'Trag dasselbe Tastenkürzel ein, das du in ' + ad.name + ' eingestellt hast.') + ' Tasten mit + verbinden.'),
      field(def.label || 'Tastenkürzel', inp),
      el('div', { class: 'chips' }, ['ctrl+alt+f9', 'ctrl+alt+f10', 'ctrl+alt+f11', 'ctrl+alt+f12', 'ctrl+shift+f9'].map(k =>
        el('button', { class: 'chip', type: 'button', onclick: () => { inp.value = k; } }, prettyKeys(k)))),
      el('div', { class: 'sheet-actions' }, el('button', { class: 'btn', type: 'button', onclick: () => close() }, 'Abbrechen'),
        el('button', { class: 'btn primary', type: 'button', onclick: save }, ic('check'), 'Speichern'))));
    setTimeout(() => inp.focus(), 300);
  }

  function addonButton(item, ctx, extra) {
    const missing = (item.setting || item.ref) && !resolveAction(item, ctx);
    const b = el('button', { class: 'abtn c-' + (item.color || (ctx.addon && ctx.addon.color) || 'violet') + (missing ? ' missing' : '') },
      el('span', { class: 't-ic' }, ic(item.icon || (item.a ? actIcon(item.a) : 'zap'))), el('span', { class: 'abtn-l' }, item.label, missing ? el('small', null, 'Kürzel eintragen') : null));
    press(b, {
      tap: async () => {
        const a = resolveAction(item, ctx);
        if (!a) return askKey(item, ctx, () => { b.classList.remove('missing'); const s = b.querySelector('.abtn-l small'); if (s) s.remove(); });
        if (item.confirm && !await confirmSheet(item.label + '?', null, 'Ausführen', true)) return;
        flash(b);
        act(a);
      },
      long: () => buttonMenu(item, ctx, extra)
    });
    if (item.state) ctx.ups.push(d => b.classList.toggle('alert', getPath(d, item.state) === true));
    return b;
  }

  const SECTIONS = {
    buttons(ctx, sec) {
      const items = sec.items.filter(i => i.needs !== 'spotify' || S.sp.connected);
      if (!items.length) return null;
      return [heading(sec.title || 'Funktionen'), el('div', { class: 'abtn-grid' }, items.map(i => addonButton(i, ctx)))];
    },

    player(ctx, sec) {
      const p = makePlayer();
      ctx.destroy.push(() => p.destroy());
      ctx.ups.push(d => {
        if (d.spotify) S.sp = d.spotify;
        const list = (d.media || []).filter(s => ctx.procs.includes(s.proc));
        let s = list.find(x => x.status === 'playing') || list[0] || null;
        if (!s && ctx.procs.includes('spotify')) s = spotifySession(d.spotify);
        p.set(s, d.spotify, d.app && d.app.audio && s ? { [s.proc]: d.app.audio } : null);
      });
      return [heading(sec.title || 'Wiedergabe'), p.node];
    },

    spotify(ctx) {
      const box = el('div');
      let mode = null;
      ctx.ups.push(d => {
        const sp = d.spotify || { connected: false };
        const m = sp.connected ? 'on' : 'off';
        if (m === mode) return;
        mode = m;
        box.innerHTML = '';
        box.append(sp.connected ? spotifyBrowser() : spotifyPromo());
      });
      return [heading('Bibliothek'), box];
    },

    discord(ctx) {
      const big = (key, label, icon, offIcon) => {
        const state = el('small', null, '…');
        const icBox = el('span', { class: 't-ic' }, ic(icon));
        const b = el('button', { class: 'dbig' }, icBox, el('span', null, el('b', null, label), state));
        press(b, {
          tap: () => { flash(b); act({ t: 'discord', cmd: key }, { quiet: 1 }); },
          long: () => buttonMenu({ label: 'Discord ' + label, deck: { type: 'toggle', bind: 'discord:' + key, color: 'violet' } }, ctx)
        });
        let last = null;
        ctx.ups.push(d => {
          const v = d.discord && d.discord[key];
          b.classList.toggle('alert', v === true);
          state.textContent = v === true ? 'Stumm' : v === false ? 'An' : '–';
          const want = v ? offIcon : icon;
          if (want !== last) { last = want; setIc(icBox, want); }
        });
        return b;
      };
      const extras = [['disconnect', 'Auflegen', 'phoneoff', 'red'], ['camera', 'Kamera', 'video', 'cyan'], ['screen', 'Bildschirm', 'share', 'cyan'],
        ['noise', 'Rauschunterdr.', 'waves', 'violet'], ['soundboard', 'Soundboard', 'music', 'pink'], ['activity', 'Aktivität', 'rocket', 'orange']]
        .map(([k, l, i, c]) => { const b = addonButton({ label: l, icon: i, color: c, a: { t: 'discord', cmd: k } }, ctx); b.dataset.key = k; return b; });
      const grid = el('div', { class: 'abtn-grid', style: 'margin-top:10px' }, extras);
      const hint = el('p', { class: 'hint' }, '');
      ctx.ups.push(d => {
        const dc = d.discord || {};
        const has = dc.controls || [];
        extras.forEach(b => { b.style.display = has.includes(b.dataset.key) ? '' : 'none'; });
        grid.style.display = extras.some(b => b.style.display === '') ? '' : 'none';
        hint.textContent = !dc.running ? 'Discord läuft nicht.' : !dc.ok ? 'Discord-Fenster nicht erreichbar – öffne Discord einmal (minimiert reicht). Bis dahin werden die Ersatz-Kürzel aus den Einstellungen benutzt.'
          : dc.voice ? 'Du bist in einem Sprachkanal.' : 'Nicht im Sprachkanal – Auflegen, Kamera und Bildschirm erscheinen, sobald du drin bist.';
      });
      return [heading('Sprache'), el('div', { class: 'dbig-row' }, big('mute', 'Mikrofon', 'mic', 'micoff'), big('deaf', 'Ton', 'headphones', 'mute')), grid, hint];
    },

    volume(ctx) {
      const v = el('span', { class: 'v' }, '');
      let proc = null;
      const range = makeVol(PCT, x => proc && act({ t: 'set', bind: 'app:' + proc, value: x / 100 }, { quiet: 1 }), x => { v.textContent = x + ' %'; });
      const mute = el('button', { class: 'icon-btn', 'aria-label': 'Stumm', onclick: () => proc && act({ t: 'toggle', bind: 'app:' + proc }, { quiet: 1 }) }, ic('volume'));
      const row = el('div', { class: 'mix-row' }, el('span', { class: 'appic sys' }, ic('volume')), el('div', { class: 'mix-mid' }, el('div', { class: 'mix-name' }, el('span', null, 'Lautstärke in Windows'), v), range), mute);
      const none = el('div', { class: 'hint' }, 'Spielt gerade keinen Ton.');
      const card = el('div', { class: 'card' }, row, none);
      ctx.ups.push(d => {
        const a = d.app && d.app.audio;
        proc = d.app && d.app.audioProc;
        row.style.display = a ? '' : 'none';
        none.style.display = a ? 'none' : '';
        if (!a) return;
        range.setValue(Math.round(a.v * 100));
        if (!range.busy()) v.textContent = Math.round(a.v * 100) + ' %';
        row.classList.toggle('muted-state', a.m);
        mute.classList.toggle('alert', a.m);
      });
      return [heading('Ton'), card];
    },

    vm(ctx) {
      const p = vmPanel();
      ctx.ups.push(d => p.update(d.vm));
      return [p.node];
    },

    gpu(ctx) {
      const cells = {};
      const cell = (k, label) => { cells[k] = el('div', { class: 'big-num' }, '–'); return el('div', { class: 'card' }, el('div', { class: 'hint' }, label), cells[k]); };
      const grid = el('div', { class: 'stat-grid three' }, cell('util', 'Auslastung'), cell('temp', 'Temperatur'), cell('mem', 'Grafikspeicher'), cell('power', 'Strom'), cell('fan', 'Lüfter'), cell('clock', 'Takt'));
      const name = el('div', { class: 'hint', style: 'margin:-4px 2px 10px' }, '');
      ctx.ups.push(d => {
        const g = d.stats && d.stats.gpu;
        if (!g) { name.textContent = 'Keine NVIDIA-Grafikkarte gefunden (nvidia-smi fehlt).'; return; }
        name.textContent = g.name + (g.driver ? ' · Treiber ' + g.driver : '');
        cells.util.textContent = Math.round(g.util) + ' %';
        cells.temp.textContent = Math.round(g.temp) + ' °C';
        cells.mem.textContent = (g.memUsed / 1024).toFixed(1) + ' / ' + (g.memTotal / 1024).toFixed(0) + ' GB';
        cells.power.textContent = g.power ? Math.round(g.power) + ' W' : '–';
        cells.fan.textContent = g.fan != null ? Math.round(g.fan) + ' %' : '–';
        cells.clock.textContent = g.clock ? Math.round(g.clock) + ' MHz' : '–';
      });
      return [heading('Grafikkarte live'), name, grid];
    },

    games(ctx, sec) {
      const games = S.apps.filter(a => a.source === sec.source);
      if (!games.length) return null;
      const grid = el('div', { class: 'app-grid' }, games.map(a => {
        const c = el('div', { class: 'app-card' }, el('span', { class: 'run-dot' }), appIcon({ id: a.id }, a.name), el('div', { class: 'n' }, a.name));
        press(c, { tap: () => act({ t: 'app', id: a.id, op: 'smart' }), long: () => openApp({ app: a }) });
        ctx.ups.push(() => c.classList.toggle('running', isRunning(a, S.st)));
        return c;
      }));
      return [heading(sec.title || 'Spiele'), grid, el('p', { class: 'hint' }, 'Antippen startet das Spiel, lange drücken öffnet seine Seite.')];
    },

    openurl(ctx, sec) {
      const inp = el('input', { class: 'in', type: 'url', placeholder: 'Adresse oder Suchbegriff', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const go = url => {
        url = (url || inp.value).trim();
        if (!url) return;
        if (!/^[a-z]+:\/\//i.test(url)) url = /^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(url) ? 'https://' + url : 'https://www.google.com/search?q=' + enc(url);
        act({ t: 'launch', target: sec.exe, args: url });
        inp.value = '';
      };
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      const sites = [['YouTube', 'https://www.youtube.com'], ['Twitch', 'https://www.twitch.tv'], ['Google', 'https://www.google.com'], ['Netflix', 'https://www.netflix.com'], ['ChatGPT', 'https://chatgpt.com'], ['Gmail', 'https://mail.google.com']];
      return [heading('Seite öffnen'),
        el('div', { class: 'card' }, el('div', { class: 'row' }, el('div', { class: 'grow' }, inp), el('button', { class: 'btn primary', onclick: () => go() }, 'Öffnen')),
          el('div', { class: 'chips', style: 'margin-top:10px' }, sites.map(([l, u]) => el('button', { class: 'chip', onclick: () => go(u) }, l))))];
    },

    custom(ctx) {
      const grid = el('div', { class: 'abtn-grid' });
      const draw = () => {
        grid.innerHTML = '';
        const list = AD.buttons[ctx.key] || [];
        list.forEach(t => grid.append(addonButton({ label: t.label || actLabel(t.a), icon: t.icon || actIcon(t.a), color: t.color, a: t.a, confirm: t.confirm }, ctx, [
          { icon: tic('edit', 'cyan'), title: 'Bearbeiten', onclick: () => editTile(t, false, customTarget(ctx, draw)) },
          { icon: tic('trash', 'red'), title: 'Löschen', onclick: async () => {
            if (!await confirmSheet('Button löschen?', null, 'Löschen', true)) return;
            AD.buttons[ctx.key] = (AD.buttons[ctx.key] || []).filter(x => x.id !== t.id);
            saveAddons();
            draw();
          } }])));
        const add = el('button', { class: 'abtn add' }, el('span', { class: 't-ic' }, ic('plus')), el('span', { class: 'abtn-l' }, 'Neuer Button'));
        press(add, { tap: () => {
          const a = { t: 'appkey', keys: '' };
          if (ctx.app) a.id = ctx.app.id; else a.procs = ctx.procs.join(',');
          editTile({ id: uid(), type: 'action', color: (ctx.addon && ctx.addon.color) || 'violet', a }, true, customTarget(ctx, draw));
        } });
        grid.append(add);
      };
      draw();
      return [el('p', { class: 'hint', style: 'margin:0 2px 12px' }, 'Deine eigenen Tastenkürzel, Texte, Makros oder Links für ' + ctx.name + '. Lange drücken = bearbeiten oder aufs Deck legen.'), grid];
    },

    process(ctx) {
      const prio = [['below', 'Niedrig'], ['normal', 'Normal'], ['above', 'Höher'], ['high', 'Hoch']];
      const seg = segTabs(prio, null, k => act({ t: 'priority', procs: ctx.procs, level: k }));
      const winBox = el('div');
      const info = el('dl', { class: 'kv' });
      let winKey = null;
      ctx.ups.push(d => {
        const a = d.app;
        if (!a) return;
        [...seg.children].forEach(b => b.classList.toggle('on', b.dataset.k === a.priority));
        info.innerHTML = '';
        const row = (k, v) => [el('dt', null, k), el('dd', null, v)];
        if (a.running) info.append(...[row('Prozesse', a.count), row('Arbeitsspeicher', a.ram + ' MB'), row('CPU', a.cpu == null ? '…' : a.cpu + ' %'),
          row('Läuft seit', a.since == null ? '–' : uptime(a.since))].flat());
        else info.append(...row('Status', 'Läuft gerade nicht'));
        const key = JSON.stringify(a.windows);
        if (key === winKey) return;
        winKey = key;
        winBox.innerHTML = '';
        (a.windows || []).forEach(w => {
          const op = o => e => { e.stopPropagation(); act({ t: 'window', h: w.h, op: o }, { quiet: 1 }); };
          const r = el('div', { class: 'win-row' + (w.fg ? ' fg' : '') }, el('span', { class: 'appic sys' }, ic('window')),
            el('div', { class: 'win-main' }, el('b', null, w.title), el('small', null, w.min ? 'minimiert' : w.fg ? 'im Vordergrund' : 'antippen = nach vorne')),
            el('div', { class: 'win-acts' },
              el('button', { class: 'icon-btn', 'aria-label': 'Minimieren', onclick: op('min') }, ic('minimize')),
              el('button', { class: 'icon-btn', 'aria-label': 'Maximieren', onclick: op('max') }, ic('maximize')),
              el('button', { class: 'icon-btn alert', 'aria-label': 'Schließen', onclick: op('close') }, ic('x'))));
          press(r.querySelector('.win-main'), { tap: () => act({ t: 'window', h: w.h, op: 'focus' }, { quiet: 1 }) });
          winBox.append(r);
        });
        if (!(a.windows || []).length) winBox.append(el('div', { class: 'hint' }, a.running ? 'Kein sichtbares Fenster.' : 'Läuft nicht.'));
      });
      const appOp = op => ctx.app ? act({ t: 'app', id: ctx.app.id, op }) : act({ t: 'kill', procs: ctx.procs, force: op === 'forcekill' });
      return [
        heading('Leistung'),
        el('div', { class: 'card' }, info,
          el('div', { class: 'field', style: 'margin-top:14px' }, el('span', { class: 'field-label' }, 'Priorität – „Hoch“ gibt dem Programm mehr CPU-Leistung'), seg)),
        heading('Fenster'),
        el('div', { class: 'card' },
          el('div', { class: 'row wrap' },
            el('button', { class: 'btn small', onclick: () => act({ t: 'appwin', procs: ctx.procs, op: 'min' }) }, ic('minimize'), 'Alle minimieren'),
            el('button', { class: 'btn small', onclick: () => act({ t: 'appwin', procs: ctx.procs, op: 'max' }) }, ic('maximize'), 'Maximieren')),
          el('div', { style: 'margin-top:8px' }, winBox)),
        heading('Neu starten & Beenden'),
        el('div', { class: 'card row wrap' },
          ctx.app ? el('button', { class: 'btn small', onclick: () => act({ t: 'app', id: ctx.app.id, op: 'restart' }) }, ic('restart'), 'Neu starten') : null,
          el('button', { class: 'btn small danger', onclick: async () => { if (await confirmSheet('Sofort beenden?', 'Das Programm wird hart beendet – nicht gespeicherte Daten gehen verloren.', 'Sofort beenden', true)) appOp('forcekill'); } }, ic('x'), 'Sofort beenden'))];
    },

    settings(ctx) {
      const ad = ctx.addon;
      if (!ad || ad.generic) return null;
      const box = el('div', { class: 'card form' },
        el('label', { class: 'check' }, el('span', null, el('b', null, ad.name + '-Addon aktiv'), el('small', { class: 'hint', style: 'display:block' }, ad.desc)),
          sw(addonOn(ad.id), v => { setAddonOn(ad.id, v); toast(v ? 'Addon aktiviert' : 'Addon ausgeschaltet'); ctx.reload(); })));
      for (const f of ad.settings || []) {
        const cur = (AD.settings[ad.id] || {})[f.key];
        const inp = el('input', { class: 'in', placeholder: f.def ? 'Standard: ' + prettyKeys(f.def) : 'nicht belegt', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', value: cur || '' });
        inp.addEventListener('change', () => {
          AD.settings[ad.id] = Object.assign({}, AD.settings[ad.id], { [f.key]: inp.value.trim() });
          saveAddons();
          toast('Gespeichert');
        });
        box.append(field(f.label, inp, f.hint || (f.type === 'keys' ? 'z. B. alt+f10 oder ctrl+shift+m' : null)));
      }
      if (ad.id === 'spotify') box.append(el('button', { class: 'btn small', onclick: () => spotifySetup(() => ctx.reload()) }, ic('music'), S.sp.connected ? 'Spotify-Verbindung' : 'Spotify verbinden'));
      return [box];
    }
  };

  function customTarget(ctx, redraw) {
    return {
      title: 'Eigener Button',
      save(t) {
        const list = AD.buttons[ctx.key] = AD.buttons[ctx.key] || [];
        const i = list.findIndex(x => x.id === t.id);
        if (i >= 0) list[i] = t; else list.push(t);
        saveAddons();
        redraw();
      }
    };
  }

  function buildPage(target, reload) {
    const app = target.app || (target.addon ? appForAddon(target.addon) : null);
    let addon = target.addon || (app ? addonFor(app) : null);
    if (addon && !addon.generic && !addonOn(addon.id)) addon = app ? addonFor(app) : null;
    const procs = [...new Set([...(app ? app.procs : []), ...((addon && addon.match && addon.match.procs) || [])].map(p => p.toLowerCase()))];
    const name = app ? app.name : addon ? addon.name : 'App';
    const ctx = { app, addon, procs, name, key: addon && !addon.generic ? addon.id : 'app:' + (app ? app.id : name), ups: [], destroy: [], reload };
    const parts = new Set((addon && addon.parts) || []);
    if (addon && addon.sections.includes(GAME)) parts.add('discord');
    if (procs.includes('spotify')) parts.add('spotify');

    const root = el('div', { class: 'app-page' });

    // hero: icon, status, start/front/stop
    const status = el('div', { class: 'hero-status' }, '…');
    const start = el('button', { class: 'btn primary', onclick: () => {
      if (addon && addon.launch) act(addon.launch);
      else if (app) act({ t: 'app', id: app.id, op: 'launch' });
      else toast('Für diese App ist kein Start bekannt', 'err');
    } }, ic('play', 'fill'), 'Starten');
    const front = el('button', { class: 'btn', onclick: () => app ? act({ t: 'app', id: app.id, op: 'focus' }) : act({ t: 'focus', procs }) }, ic('window'), 'Nach vorne');
    const stop = el('button', { class: 'btn danger', onclick: async () => {
      if (!await confirmSheet(name + ' beenden?', 'Nicht gespeicherte Daten können verloren gehen.', 'Beenden', true)) return;
      app ? act({ t: 'app', id: app.id, op: 'kill' }) : act({ t: 'kill', procs });
    } }, ic('x'), 'Beenden');
    const icon = app ? appIcon({ id: app.id }, name) : procs[0] ? appIcon({ proc: procs[0] }, name) : tic(addon.icon, addon.color);
    const about = addon && !addon.generic ? addon.desc : addon ? 'Spiel – mit Discord-, Clip- und Screenshot-Knöpfen' : 'App – Start, Fenster, Ton und eigene Buttons';
    root.append(el('div', { class: 'app-hero card' + (addon ? ' c-' + addon.color : '') },
      el('div', { class: 'row' }, icon, el('div', { class: 'grow' }, status, el('small', { class: 'hero-about' }, about))),
      el('div', { class: 'hero-btns' }, start, front, stop)));
    ctx.ups.push(d => {
      const a = d.app;
      if (!a) return;
      status.textContent = a.running ? 'Läuft' + (a.cpu != null ? ' · ' + a.cpu + ' % CPU' : '') + ' · ' + a.ram + ' MB' : 'Läuft gerade nicht';
      status.classList.toggle('running-text', a.running);
      stop.style.display = a.running ? '' : 'none';
      front.style.display = a.running ? '' : 'none';
      start.style.display = a.running ? 'none' : '';
    });

    // panes behind tabs, so a page never turns into one endless list
    const flat = x => [].concat(x || []).filter(Boolean);
    const control = [];
    if (addon) for (const sec of addon.sections) control.push(...flat(SECTIONS[sec.type](ctx, sec)));
    if (!addon && app) {
      const off = ADDONS.find(x => matches(x, app));
      if (off) control.push(el('div', { class: 'card promo' }, tic(off.icon, off.color), el('div', { class: 'grow' }, el('b', null, off.name + '-Addon ist aus'), el('small', null, off.desc)),
        el('button', { class: 'btn small primary', onclick: () => { setAddonOn(off.id, true); reload(); } }, 'Einschalten')));
    }
    const program = [];
    if (!(addon && addon.sections.some(s => s.type === 'vm'))) program.push(...flat(SECTIONS.volume(ctx)));
    if (procs.length) program.push(...flat(SECTIONS.process(ctx)));
    const settings = flat(SECTIONS.settings(ctx));

    const panes = [];
    if (control.length) panes.push(['control', 'Steuerung', control]);
    panes.push(['mine', 'Buttons', flat(SECTIONS.custom(ctx))]);
    panes.push(['program', 'Programm', program]);
    if (settings.length) panes.push(['settings', 'Optionen', settings]);

    const paneEls = {};
    const saved = LS.get('pane.' + ctx.key, panes[0][0]);
    const first = panes.some(p => p[0] === saved) ? saved : panes[0][0];
    const pick = k => { LS.set('pane.' + ctx.key, k); Object.keys(paneEls).forEach(p => { paneEls[p].style.display = p === k ? '' : 'none'; }); };
    root.append(segTabs(panes.map(p => [p[0], p[1]]), first, pick, 'page-tabs'));
    for (const [k, , nodes] of panes) {
      paneEls[k] = el('div', { class: 'pane' }, nodes);
      root.append(paneEls[k]);
    }
    pick(first);

    const q = 'procs=' + enc(procs.join(',')) + '&parts=' + [...parts].join(',');
    return {
      node: root, name,
      poll: () => ({ path: '/api/appinfo?' + q, ms: 1500 }),
      update(d) {
        if (d.spotify) S.sp = d.spotify;
        for (const u of ctx.ups) try { u(d); } catch (e) { console.error(e); }
      },
      destroy() { ctx.destroy.forEach(f => f()); }
    };
  }

  function appPage(target) {
    const view = { title: '' };
    view.render = root => {
      view.page = buildPage(target, () => view.reload());
      view.title = view.page.name;
      root.append(view.page.node);
    };
    view.poll = () => view.page.poll();
    view.update = d => view.page.update(d);
    view.destroy = () => { if (view.page) view.page.destroy(); };
    view.reload = () => {
      view.destroy();
      view.el.innerHTML = '';
      view.render(view.el);
      if (current === view) mount();
    };
    return view;
  }

  function openApp(target) {
    if (NAV.tab !== 'apps') show('apps');
    push(appPage(target));
  }

  const KIND_GROUPS = [['game', 'Spiele'], ['app', 'Apps'], ['launcher', 'Launcher']];

  const AppsView = {
    title: 'Apps',
    filter: 'all', q: '',
    poll() { return { path: '/api/state' + (addonOn('discord') ? '?discord=1' : ''), ms: 2500 }; },
    render(root) {
      this.root = root;
      const search = el('input', { class: 'in', type: 'search', placeholder: 'App oder Spiel suchen …', value: this.q });
      search.addEventListener('input', () => { this.q = search.value; this.drawApps(); });
      const rescan = el('button', { class: 'icon-btn', 'aria-label': 'Apps neu suchen', title: 'Apps neu suchen', onclick: async () => {
        rescan.disabled = true;
        toast('Suche Apps & Spiele …');
        try { S.apps = await api('/api/rescan') || []; toast(S.apps.length + ' Apps gefunden'); this.drawApps(); }
        catch (e) { toast(e.message, 'err'); }
        rescan.disabled = false;
      } }, ic('refresh'));
      const manage = el('button', { class: 'icon-btn', 'aria-label': 'Addons verwalten', title: 'Addons verwalten', onclick: addonManager }, ic('puzzle'));
      const seg = segTabs([['all', 'Alle'], ['game', 'Spiele'], ['app', 'Apps'], ['running', 'Läuft']], this.filter, k => { this.filter = k; this.drawApps(); });
      this.stripBox = el('div', { class: 'run-box' });
      this.list = el('div');
      root.append(
        el('div', { class: 'app-tools' }, el('div', { class: 'row' }, el('div', { class: 'search grow' }, ic('search'), search), manage, rescan), seg),
        this.stripBox, this.list,
        el('p', { class: 'hint', style: 'text-align:center;margin-top:18px' }, 'Antippen öffnet alle Funktionen der App · lange drücken startet sie direkt · ', ic('puzzle', 'inline'), ' = Addon mit Extra-Funktionen'));
      this.stripKey = null;
      this.drawApps();
      this.drawStrip(S.st);
    },
    card(a) {
      const ad = addonFor(a);
      const c = el('div', { class: 'app-card' + (ad && !ad.generic ? ' has-addon c-' + ad.color : '') }, el('span', { class: 'run-dot' }), appIcon({ id: a.id }, a.name), el('div', { class: 'n' }, a.name),
        ad && !ad.generic ? el('span', { class: 'addon-badge', title: 'Addon' }, ic('puzzle')) : null);
      press(c, { tap: () => openApp({ app: a }), long: () => act(ad && ad.launch ? ad.launch : { t: 'app', id: a.id, op: 'smart' }) });
      c.app = a;
      this.appCards.push(c);
      return c;
    },
    drawApps() {
      const q = this.q.trim().toLowerCase();
      const list = S.apps.filter(a => (this.filter === 'all' || (this.filter === 'running' ? isRunning(a, S.st) : this.filter === 'app' ? a.kind !== 'game' : a.kind === this.filter)) &&
        (!q || a.name.toLowerCase().includes(q)));
      this.list.innerHTML = '';
      this.appCards = [];
      if (!list.length) {
        this.list.append(el('div', { class: 'empty' }, S.apps.length ? (this.filter === 'running' ? 'Gerade läuft keine der Apps.' : 'Nichts gefunden.') : 'Apps werden noch gesucht … tippe gleich auf ↻.'));
        return;
      }
      if (this.filter === 'all' && !q) {
        for (const [k, l] of KIND_GROUPS) {
          const items = list.filter(a => a.kind === k);
          if (!items.length) continue;
          this.list.append(heading(l, el('span', { class: 'count' }, items.length)), el('div', { class: 'app-grid' }, items.map(a => this.card(a))));
        }
      } else this.list.append(el('div', { class: 'app-grid', style: 'margin-top:14px' }, list.map(a => this.card(a))));
      this.update(S.st, true);
    },
    // "running now" strip with live status for Spotify/Discord
    drawStrip(d) {
      const run = S.apps.filter(a => isRunning(a, d));
      const key = run.map(a => a.id).join('|');
      if (key !== this.stripKey) {
        this.stripKey = key;
        this.stripBox.innerHTML = '';
        this.stripItems = [];
        if (run.length && this.filter !== 'running') {
          const strip = el('div', { class: 'run-strip' });
          for (const a of run) {
            const sub = el('small', null, 'Läuft');
            const c = el('div', { class: 'run-item' }, appIcon({ id: a.id }, a.name), el('div', { class: 'grow' }, el('b', null, a.name), sub));
            press(c, { tap: () => openApp({ app: a }) });
            c.upd = dd => {
              let txt = 'Läuft';
              if (/^spotify/i.test(a.name) && dd.np && dd.np.proc === 'spotify' && dd.np.title) txt = (dd.np.playing ? '▶ ' : '❚❚ ') + dd.np.title;
              if (/^discord$/i.test(a.name) && dd.discord && dd.discord.ok) txt = dd.discord.deaf ? 'Ton aus' : dd.discord.mute ? 'Mikro stumm' : 'Mikro an';
              sub.textContent = txt;
            };
            this.stripItems.push(c);
            strip.append(c);
          }
          this.stripBox.append(heading('Läuft gerade', el('span', { class: 'count' }, run.length)), strip);
        }
      }
      (this.stripItems || []).forEach(c => c.upd(d || {}));
    },
    update(d, quiet) {
      if (!d) return;
      if (!quiet) S.st = d;
      for (const c of this.appCards || []) c.classList.toggle('running', isRunning(c.app, d));
      if (this.stripBox) this.drawStrip(d);
    }
  };

  function addonManager() {
    const list = el('div', { class: 'pick-list' });
    const all = ADDONS.concat([Object.assign({}, GAME_ADDON, { name: 'Spiele (allgemein)', desc: 'Für alle anderen Spiele: Discord stumm, Clips, Screenshots, Priorität, Lautstärke', match: {} })]);
    const installed = [], missing = [];
    for (const ad of all) {
      const app = ad.match && ad.match.name ? appForAddon(ad) : null;
      const found = ad.id === 'game' ? S.apps.some(a => a.kind === 'game') : !!app || addonRunning(ad, S.st);
      const row = el('div', { class: 'pick-item manager-row' + (found ? '' : ' dim') },
        app ? appIcon({ id: app.id }, ad.name) : tic(ad.icon, ad.color),
        el('div', null, el('b', null, ad.name), el('small', null, ad.desc)),
        sw(addonOn(ad.id), v => { setAddonOn(ad.id, v); if (current === AppsView) AppsView.drawApps(); }));
      if (found && ad.id !== 'game') press(row.children[1], { tap: () => { close(); openApp(app ? { app, addon: ad } : { addon: ad }); } });
      (found ? installed : missing).push(row);
    }
    list.append(heading('Auf diesem PC', el('span', { class: 'count' }, installed.length)), ...installed);
    if (missing.length) list.append(heading('Nicht installiert', el('span', { class: 'count' }, missing.length)), ...missing);
    const close = sheet('Addons verwalten', el('div', null,
      el('p', { class: 'muted', style: 'margin:0 0 4px' }, 'Addons geben einer App Extra-Funktionen. Schalter = an/aus, Antippen = App-Seite mit Einstellungen und eigenen Buttons.'), list), { wide: true });
  }

  // ---------- mouse & keyboard ----------

  const MouseView = {
    title: 'Maus & Tastatur',
    render(root) {
      const sens = LS.get('sens', 1.6);
      const M = { dx: 0, dy: 0, sx: 0, sy: 0, busy: false, extra: [], sens };
      this.release = Live.use();
      const nextAction = () => {
        const dx = Math.trunc(M.dx), dy = Math.trunc(M.dy), sx = Math.trunc(M.sx), sy = Math.trunc(M.sy);
        const extra = M.extra.shift();
        if (!dx && !dy && !sx && !sy && !extra) return null;
        M.dx -= dx; M.dy -= dy; M.sx -= sx; M.sy -= sy;
        return Object.assign({ t: 'mouse' }, dx ? { dx } : null, dy ? { dy } : null, sx ? { sx } : null, sy ? { sy } : null, extra);
      };
      const flush = () => {
        if (M.busy) return;
        // open line: send right away; otherwise one request at a time
        if (Live.ok) { let a; while ((a = nextAction())) Live.send(a); return; }
        const a = nextAction();
        if (!a) return;
        M.busy = true;
        api('/api/action', a).catch(() => { }).then(() => { M.busy = false; flush(); });
      };
      const queue = extra => { M.extra.push(extra); flush(); };

      const pad = el('div', { class: 'pad' }, el('div', { class: 'pad-hint' }, '1 Finger: bewegen · Tippen: Klick · 2 Finger: scrollen · 2-Finger-Tipp: Rechtsklick'));
      const pts = new Map();
      let maxPts = 0, startT = 0, moved = 0;
      pad.addEventListener('pointerdown', e => {
        e.preventDefault();
        try { pad.setPointerCapture(e.pointerId); } catch (x) { }
        if (!pts.size) { startT = performance.now(); moved = 0; maxPts = 0; }
        pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
        maxPts = Math.max(maxPts, pts.size);
        pad.classList.add('active');
      });
      pad.addEventListener('pointermove', e => {
        const p = pts.get(e.pointerId);
        if (!p) return;
        const dx = e.clientX - p.x, dy = e.clientY - p.y;
        p.x = e.clientX; p.y = e.clientY;
        moved += Math.abs(dx) + Math.abs(dy);
        if (pts.size === 1 && maxPts === 1) {
          const acc = 1 + Math.min(2.2, Math.hypot(dx, dy) / 14);
          M.dx += dx * M.sens * acc;
          M.dy += dy * M.sens * acc;
        } else if (pts.size >= 2) {
          M.sy += dy / pts.size * 4;
          M.sx -= dx / pts.size * 4;
        }
        flush();
      });
      const up = e => {
        if (!pts.has(e.pointerId)) return;
        pts.delete(e.pointerId);
        if (pts.size) return;
        pad.classList.remove('active');
        if (performance.now() - startT < 260 && moved < 14 * maxPts) { buzz(); queue({ click: maxPts >= 2 ? 'right' : 'left' }); }
      };
      pad.addEventListener('pointerup', up);
      pad.addEventListener('pointercancel', up);
      pad.addEventListener('contextmenu', e => e.preventDefault());

      // Hold a button while moving on the pad to drag, just like a laptop touchpad.
      const mbtn = (b, label) => {
        const n = el('button', null, label);
        n.addEventListener('pointerdown', e => { e.preventDefault(); buzz(); n.classList.add('down'); queue({ down: b }); });
        const rel = () => { if (!n.classList.contains('down')) return; n.classList.remove('down'); queue({ up: b }); };
        n.addEventListener('pointerup', rel);
        n.addEventListener('pointercancel', rel);
        n.addEventListener('pointerleave', rel);
        n.addEventListener('contextmenu', e => e.preventDefault());
        return n;
      };

      const sensR = makeRange({ min: 0.6, max: 4, step: 0.1 }, v => { M.sens = v; LS.set('sens', v); });
      sensR.value = sens;
      sensR.dispatchEvent(new Event('input'));

      let chain = Promise.resolve();
      const kq = a => { chain = chain.then(() => api('/api/action', a).catch(e => toast(e.message, 'err'))); };
      const live = el('input', { class: 'in', placeholder: 'Hier tippen – geht sofort an den PC', autocomplete: 'off', autocorrect: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'send' });
      let last = '', composing = false;
      live.addEventListener('compositionstart', () => { composing = true; });
      live.addEventListener('compositionend', () => { composing = false; });
      live.addEventListener('input', () => {
        const v = live.value;
        let i = 0;
        while (i < last.length && i < v.length && last[i] === v[i]) i++;
        const del = last.length - i, ins = v.slice(i);
        last = v;
        for (let k = 0; k < del; k++) kq({ t: 'key', keys: 'backspace' });
        if (ins) kq({ t: 'text', text: ins });
        if (!composing && v.length > 80) { live.value = ''; last = ''; }
      });
      live.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); kq({ t: 'key', keys: 'enter' }); live.value = ''; last = ''; }
      });
      live.addEventListener('blur', () => { live.value = ''; last = ''; });

      const KEYS = [['Esc', 'esc'], ['Tab', 'tab'], ['⌫', 'backspace'], ['Enter', 'enter'],
        ['Entf', 'delete'], ['↑', 'up'], ['Leer', 'space'], ['Win', 'win'],
        ['←', 'left'], ['↓', 'down'], ['→', 'right'], ['Alt+Tab', 'alt+tab'],
        ['Strg+C', 'ctrl+c'], ['Strg+V', 'ctrl+v'], ['Strg+Z', 'ctrl+z'], ['Strg+A', 'ctrl+a'],
        ['Desktop', 'win+d'], ['Snip', 'win+shift+s'], ['Alt+F4', 'alt+f4'], ['Task-Mgr', 'ctrl+shift+esc'],
        ['F5', 'f5'], ['F11', 'f11'], ['Pos1', 'home'], ['Ende', 'end']];
      const keys = el('div', { class: 'keys' }, KEYS.map(([l, k]) => el('button', { onclick: () => { buzz(); kq({ t: 'key', keys: k }); } }, l)));
      const combo = el('input', { class: 'in', placeholder: 'Eigene Kombination, z. B. ctrl+shift+m', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const sendCombo = () => { if (combo.value.trim()) { buzz(); kq({ t: 'key', keys: combo.value.trim() }); } };
      combo.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); sendCombo(); } });

      const mousePane = el('div', null, pad, el('div', { class: 'pad-btns' }, mbtn('left', 'Links'), mbtn('middle', 'Mitte'), mbtn('right', 'Rechts')),
        el('div', { class: 'sens' }, el('span', null, 'Tempo'), sensR));
      const keyPane = el('div', null, el('div', { class: 'card' }, live, el('div', { style: 'height:12px' }), keys, el('div', { style: 'height:12px' }),
        el('div', { class: 'row' }, el('div', { class: 'grow' }, combo), el('button', { class: 'btn', onclick: sendCombo }, 'Senden'))));
      const pick = k => { LS.set('mouseTab', k); mousePane.style.display = k === 'mouse' ? '' : 'none'; keyPane.style.display = k === 'keys' ? '' : 'none'; };
      const tab = LS.get('mouseTab', 'mouse');
      root.append(segTabs([['mouse', 'Touchpad'], ['keys', 'Tastatur']], tab, pick, 'top-seg'), mousePane, keyPane);
      pick(tab);
    },
    destroy() { if (this.release) { this.release(); this.release = null; } }
  };

  // ---------- system, power, screen, windows, tools ----------

  const SysSub = {
    title: 'System & Leistung',
    poll: () => ({ path: '/api/state?stats=1', ms: 2000 }),
    render(root) {
      const grid = el('div', { class: 'stat-grid' });
      root.append(grid);
      const stat = label => {
        const num = el('div', { class: 'big-num' }, '–'), bar = el('i'), sm = el('small', { class: 'hint' }, '');
        const box = el('div', { class: 'bar' }, bar);
        grid.append(el('div', { class: 'card' }, el('div', { class: 'hint' }, label), num, box, sm));
        return (pct, txt, sub) => {
          num.innerHTML = '';
          num.style.fontSize = txt != null && txt.length > 4 ? '20px' : '';
          num.append(txt != null ? txt : pct == null ? '–' : Math.round(pct) + '', pct != null && txt == null ? el('small', null, ' %') : '');
          bar.style.width = (pct || 0) + '%';
          box.classList.toggle('hot', pct > 85);
          sm.textContent = sub || '';
        };
      };
      this.cpu = stat('CPU'); this.ram = stat('Arbeitsspeicher'); this.gpu = stat('Grafikkarte'); this.up = stat('Laufzeit');

      this.info = el('dl', { class: 'kv' });
      this.drives = el('div');
      root.append(heading('Dieser PC'), el('div', { class: 'card' }, this.info, this.drives));
      api('/api/info').then(i => {
        const row = (k, v) => [el('dt', null, k), el('dd', null, v)];
        this.info.append(...[row('Name', i.name), row('Benutzer', i.user), row('System', i.os), row('PC Remote', 'Version ' + i.version), row('Adresse', i.urls.join('\n'))].flat());
        for (const d of i.drives) {
          const used = d.total - d.free, pct = d.total ? used / d.total * 100 : 0;
          this.drives.append(el('div', { style: 'margin-top:14px' },
            el('div', { class: 'meter-top' }, 'Laufwerk ' + d.name, el('span', null, d.free + ' GB frei von ' + d.total + ' GB')),
            el('div', { class: 'bar' + (pct > 90 ? ' hot' : '') }, el('i', { style: 'width:' + pct + '%' }))));
        }
      }).catch(() => { });
    },
    update(d) {
      const s = d && d.stats;
      if (!s) return;
      this.cpu(s.cpu);
      this.ram(s.ram && s.ram.pct, null, s.ram ? s.ram.used + ' von ' + s.ram.total + ' GB' : '');
      if (s.gpu) this.gpu(s.gpu.util, null, s.gpu.name + ' · ' + s.gpu.temp + ' °C' + (s.gpu.power ? ' · ' + Math.round(s.gpu.power) + ' W' : ''));
      else this.gpu(null, '–', 'Nur NVIDIA-Grafikkarten');
      this.up(null, uptime(s.uptime), 'seit dem letzten Start');
    }
  };

  const PowerSub = {
    title: 'Energie',
    render(root) {
      const pw = (cmd, label, sub, icon, color, opts) => {
        const b = el('button', { class: 'pick-item power-item', onclick: () => power(cmd, label, opts) }, tic(icon, color), el('div', null, el('b', null, label), el('small', null, sub)));
        return b;
      };
      root.append(
        heading('Sofort'),
        el('div', { class: 'pick-list' },
          pw('lock', 'Sperren', 'Sperrbildschirm, alles läuft weiter', 'lock', 'slate'),
          pw('monitoroff', 'Monitor aus', 'Bildschirm aus, PC läuft weiter', 'monitor', 'slate')),
        heading('Schlafen'),
        el('div', { class: 'pick-list' },
          pw('sleep', 'Energiesparen', 'Schnell wieder da, braucht etwas Strom', 'moon', 'violet', { confirm: 1 }),
          pw('hibernate', 'Ruhezustand', 'Speichert alles und schaltet ab', 'moon', 'violet', { confirm: 1 })),
        heading('Aus & Neustart'),
        el('div', { class: 'pick-list' },
          pw('restart', 'Neu starten', 'Jetzt oder mit Timer', 'restart', 'red', { delay: 1 }),
          pw('shutdown', 'Herunterfahren', 'Jetzt oder mit Timer', 'power', 'red', { delay: 1 }),
          pw('logoff', 'Abmelden', 'Windows-Benutzer abmelden', 'logout', 'orange', { confirm: 1 }),
          pw('cancel', 'Timer abbrechen', 'Geplantes Herunterfahren / Neustarten stoppen', 'x', 'green')));
    }
  };

  async function power(cmd, label, opts) {
    opts = opts || {};
    if (opts.delay) {
      const choices = [[0, 'Jetzt'], [60, 'In 1 Minute'], [300, 'In 5 Minuten'], [900, 'In 15 Minuten'], [1800, 'In 30 Minuten'], [3600, 'In 1 Stunde'], [7200, 'In 2 Stunden']];
      const close = sheet(label, el('div', null,
        el('p', { class: 'muted', style: 'margin:0 0 14px' }, 'Wann? Ein geplanter Vorgang lässt sich mit „Timer abbrechen“ stoppen.'),
        pickList(choices.map(([s, l]) => ({ icon: tic(cmd === 'restart' ? 'restart' : 'power', s ? 'slate' : 'red'), title: l, onclick: () => { close(); act({ t: 'power', cmd, delay: s }); } })))));
      return;
    }
    if (opts.confirm && !await confirmSheet(label + '?', null, label, true)) return;
    act({ t: 'power', cmd });
  }

  const ScreenSub = {
    title: 'Bildschirm',
    render(root) {
      this.mon = LS.get('mon', 0);
      this.mode = 'left';
      this.live = false;
      this.alive = true;
      const monBox = el('div', { class: 'chips', style: 'margin-bottom:12px' });
      this.img = el('img', { alt: 'Bildschirm' });
      this.loading = el('div', { class: 'loading' }, 'Lade Bildschirm …');
      this.wrap = el('div', { class: 'screen-wrap' }, this.img, this.loading);
      const liveBtn = el('button', { class: 'btn small', onclick: () => { this.live = !this.live; liveBtn.classList.toggle('primary', this.live); liveBtn.lastChild.textContent = this.live ? 'Live an' : 'Live'; if (this.live) this.load(); } }, ic('record'), 'Live');
      const modes = [['left', 'Klick'], ['right', 'Rechts'], ['double', 'Doppel'], ['move', 'Nur zeigen']];
      root.append(monBox, this.wrap,
        el('div', { class: 'row', style: 'margin:12px 0' }, el('button', { class: 'btn small', onclick: () => this.load() }, ic('refresh'), 'Neu laden'), liveBtn),
        el('div', { class: 'hint', style: 'margin-bottom:8px' }, 'Tippe ins Bild, um dort zu klicken:'), segTabs(modes, this.mode, m => { this.mode = m; }));

      this.img.addEventListener('load', () => {
        this.loading.style.display = 'none';
        if (this.live && this.alive) this.timer = setTimeout(() => this.load(), 350);
      });
      this.img.addEventListener('error', () => { this.loading.textContent = 'Bildschirm konnte nicht geladen werden'; this.loading.style.display = ''; });
      this.img.addEventListener('click', e => {
        const r = this.img.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        const mark = el('span', { class: 'tap-mark', style: 'left:' + (x * 100) + '%;top:' + (y * 100) + '%' });
        this.wrap.append(mark);
        setTimeout(() => mark.remove(), 520);
        act({ t: 'tap', x, y, mon: this.mon, button: this.mode }, { quiet: 1 }).then(() => { if (!this.live) setTimeout(() => this.load(), 450); });
      });

      api('/api/windows').then(d => {
        const mons = d.monitors || [];
        if (mons.length < 2) return;
        mons.forEach(m => monBox.append(el('button', {
          class: 'chip' + (m.i === this.mon ? ' on' : ''),
          onclick: e => { this.mon = m.i; LS.set('mon', m.i); [...monBox.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); this.load(); }
        }, ic('monitor'), 'Monitor ' + (m.i + 1) + (m.primary ? ' (Haupt)' : ''))));
      }).catch(() => { });
      this.load();
    },
    load() {
      clearTimeout(this.timer);
      if (!this.alive) return;
      const w = Math.min(1920, Math.round((this.wrap.clientWidth || 400) * (window.devicePixelRatio || 1)));
      this.img.src = '/api/screen?' + authQ() + '&mon=' + this.mon + '&w=' + w + '&q=' + (this.live ? 50 : 70) + '&t=' + Date.now();
    },
    destroy() { this.alive = false; this.live = false; clearTimeout(this.timer); }
  };

  const WinSub = {
    title: 'Fenster',
    poll: () => ({ path: '/api/windows', ms: 3000 }),
    render(root) {
      this.box = el('div', { class: 'card' }, el('div', { class: 'empty' }, 'Lade Fenster …'));
      this.key = null;
      root.append(el('p', { class: 'hint', style: 'margin:0 2px 12px' }, 'Antippen holt das Fenster nach vorne.'), this.box);
    },
    update(d) {
      const wins = d.windows || [];
      const key = JSON.stringify(wins);
      if (key === this.key) return;
      this.key = key;
      this.box.innerHTML = '';
      if (!wins.length) this.box.append(el('div', { class: 'empty' }, 'Keine offenen Fenster.'));
      for (const w of wins) {
        const op = o => e => { e.stopPropagation(); act({ t: 'window', h: w.h, op: o }, { quiet: 1 }); };
        const row = el('div', { class: 'win-row' + (w.fg ? ' fg' : '') }, appIcon({ proc: w.proc }, w.app),
          el('div', { class: 'win-main' }, el('b', null, w.title), el('small', null, w.app + (w.min ? ' · minimiert' : w.fg ? ' · im Vordergrund' : ''))),
          el('div', { class: 'win-acts' },
            el('button', { class: 'icon-btn', 'aria-label': 'Minimieren', onclick: op('min') }, ic('minimize')),
            el('button', { class: 'icon-btn', 'aria-label': 'Maximieren', onclick: op('max') }, ic('maximize')),
            el('button', { class: 'icon-btn alert', 'aria-label': 'Schließen', onclick: op('close') }, ic('x'))));
        press(row.querySelector('.win-main'), { tap: () => act({ t: 'window', h: w.h, op: 'focus' }, { quiet: 1 }) });
        this.box.append(row);
      }
    }
  };

  const ToolsSub = {
    title: 'Zwischenablage & Befehle',
    render(root) {
      const clipIn = el('textarea', { class: 'in', placeholder: 'Text, der in die Zwischenablage des PCs soll …', style: 'min-height:80px;font-family:inherit;font-size:15px' });
      const clipOut = el('pre', { class: 'out', style: 'display:none' });
      const fromPc = el('button', { class: 'btn small', onclick: async () => {
        try {
          const r = await api('/api/clipboard');
          clipOut.style.display = '';
          clipOut.textContent = r.text || '(leer oder kein Text)';
          if (r.text) copyText(r.text).then(() => toast('Auch aufs Handy kopiert'), () => { });
        } catch (e) { toast(e.message, 'err'); }
      } }, ic('clipboard'), 'Vom PC holen');
      root.append(heading('Zwischenablage'),
        el('div', { class: 'card' }, clipIn,
          el('div', { class: 'row wrap', style: 'margin-top:10px' },
            el('button', { class: 'btn small primary', onclick: () => { if (clipIn.value) act({ t: 'clip', text: clipIn.value }); } }, ic('copy'), 'An PC senden'),
            el('button', { class: 'btn small', onclick: () => { if (clipIn.value) act({ t: 'text', text: clipIn.value }, { quiet: 1 }); } }, ic('type'), 'Am PC tippen'),
            fromPc),
          clipOut));

      const cmdIn = el('input', { class: 'in', placeholder: 'z. B. ipconfig', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const out = el('pre', { class: 'out', style: 'display:none' });
      const run = async () => {
        if (!cmdIn.value.trim()) return;
        out.style.display = '';
        out.textContent = '…';
        const r = await act({ t: 'cmd', cmd: cmdIn.value }, { quiet: 1 });
        out.textContent = r ? r.msg : 'Fehlgeschlagen';
      };
      cmdIn.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); run(); } });
      root.append(heading('Befehl ausführen'),
        el('div', { class: 'card' }, el('div', { class: 'row' }, el('div', { class: 'grow' }, cmdIn), el('button', { class: 'btn', onclick: run }, ic('terminal'))), out));
    }
  };

  // Update card: shows the current version and, when GitHub has a newer one, a button to update the PC.
  function updateCard() {
    const box = el('div', { class: 'card update-card' }, el('div', { class: 'hint' }, 'Suche nach Updates …'));
    const draw = u => {
      box.innerHTML = '';
      box.classList.toggle('has-update', !!u.available);
      if (u.state === 'downloading') {
        box.append(el('div', { class: 'row' }, el('span', { class: 'spinner' }), el('b', null, 'Update wird geladen …')),
          el('p', { class: 'hint' }, 'Gleich öffnet sich am PC das Setup und aktualisiert PC Remote.'));
        return;
      }
      if (u.available) {
        box.append(
          el('div', { class: 'row' }, tic('download', 'green'), el('div', { class: 'grow' }, el('b', null, 'Update verfügbar: Version ' + u.latest), el('small', null, 'Du hast ' + u.current))),
          u.notes ? el('details', { class: 'up-notes' }, el('summary', null, 'Was ist neu?'), el('pre', null, u.notes.slice(0, 1200))) : null,
          el('div', { class: 'row wrap', style: 'margin-top:12px' },
            el('button', { class: 'btn primary', onclick: async () => {
              if (!await confirmSheet('Jetzt auf Version ' + u.latest + ' aktualisieren?', 'Am PC öffnet sich das Setup, aktualisiert PC Remote und startet es neu. Deine Einstellungen bleiben.', 'Aktualisieren')) return;
              api('/api/update', { cmd: 'install' }).then(draw).catch(e => toast(e.message, 'err'));
              toast('Update wird geladen …');
            } }, ic('download'), 'Jetzt aktualisieren'),
            el('a', { class: 'btn', href: u.url, target: '_blank', rel: 'noopener' }, ic('external'), 'Auf GitHub ansehen')));
      } else {
        box.append(el('div', { class: 'row' }, tic('check', 'green'), el('div', { class: 'grow' }, el('b', null, 'PC Remote ist aktuell'), el('small', null, 'Version ' + u.current + (u.error ? ' · Prüfung fehlgeschlagen' : '')))),
          el('button', { class: 'btn small', style: 'margin-top:10px', onclick: () => { box.querySelector('b').textContent = 'Prüfe …'; api('/api/update', { cmd: 'check' }).then(draw).catch(() => { }); } }, ic('refresh'), 'Nach Update suchen'));
      }
    };
    api('/api/update').then(draw).catch(() => { box.innerHTML = ''; box.append(el('div', { class: 'hint' }, 'Update-Prüfung nicht möglich.')); });
    return box;
  }

  function logSheet() {
    const list = el('div', { class: 'log-list' }, el('div', { class: 'hint' }, 'Lade …'));
    let problems = false;
    const load = () => {
      api('/api/logs?problems=' + (problems ? 1 : 0)).then(d => {
        list.innerHTML = '';
        if (!d.logs.length) { list.append(el('div', { class: 'empty' }, problems ? 'Keine Warnungen oder Fehler.' : 'Noch nichts protokolliert.')); return; }
        d.logs.forEach(e => list.append(el('div', { class: 'log-row log-' + e.level },
          el('span', { class: 'log-time' }, new Date(e.t).toLocaleTimeString()),
          el('span', { class: 'log-msg' }, e.msg))));
      }).catch(e => { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); });
    };
    const seg = segTabs([['all', 'Alles'], ['problems', 'Nur Probleme']], 'all', k => { problems = k === 'problems'; load(); });
    load();
    sheet('Protokoll', el('div', null, el('div', { class: 'row', style: 'margin-bottom:12px' }, el('div', { class: 'grow' }, seg), el('button', { class: 'icon-btn', 'aria-label': 'Neu laden', onclick: load }, ic('refresh'))), list));
  }

  // Opt-in: let PC Remote send names of found apps anonymously so the author can add support. Default off.
  function consentCard() {
    const box = el('div', { class: 'card form' }, el('div', { class: 'hint' }, 'Lade …'));
    api('/api/consent').then(c => {
      box.innerHTML = '';
      box.append(
        el('label', { class: 'check' }, el('span', null, 'Unbekannte App-Namen anonym senden'),
          sw(c.reportApps, v => api('/api/consent', { reportApps: v }).then(() => toast(v ? 'Danke fürs Mithelfen!' : 'Aus')).catch(e => toast(e.message, 'err')))),
        el('p', { class: 'hint' }, 'Hilft, PC Remote für mehr Spiele und Programme passend zu machen. Gesendet wird nur der Name einer App (z. B. „Fortnite“) – kein Konto, keine PIN, nichts Persönliches. Jederzeit abschaltbar.'));
    }).catch(() => { box.innerHTML = ''; box.append(el('div', { class: 'hint' }, 'Nicht verfügbar.')); });
    return box;
  }

  // Admin link from the server console (http://…/admin?key=…): unlocks reported apps and account management.
  // Stored only on this device.
  function adminConnect(onDone, label) {
    const inp = el('input', { class: 'in', placeholder: 'http://…/admin?key=… einfügen', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
    const go = () => {
      try {
        const u = new URL(inp.value.trim());
        const k = u.searchParams.get('key');
        if (!k) return toast('Im Link fehlt der Schlüssel', 'err');
        LS.set('adminBase', u.origin); LS.set('adminKey', k); onDone();
      } catch (e) { toast('Das ist kein gültiger Link', 'err'); }
    };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
    return el('div', null, field(label || 'Admin-Link (aus der Server-Konsole)', inp),
      el('button', { class: 'btn small primary', style: 'margin-top:10px', onclick: go }, ic('check'), 'Verbinden'));
  }

  // Admin tool (for the author): review the apps users reported and confirm or ignore them.
  function adminAppsCard() {
    const box = el('div', { class: 'card' });
    const draw = () => {
      box.innerHTML = '';
      const base = LS.get('adminBase', ''), key = LS.get('adminKey', '');
      if (!base || !key) { box.append(adminConnect(draw, 'Bestätigen-Link (aus der Server-Konsole oder der Benachrichtigung)')); return; }
      const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
      const load = () => fetch(base + '/api/admin/pending?key=' + enc(key)).then(r => r.json()).then(d => {
        list.innerHTML = '';
        if (d.error) return list.append(el('div', { class: 'empty' }, d.error));
        if (!d.pending.length) return list.append(el('div', { class: 'empty' }, 'Keine offenen Apps. ' + d.known + ' bestätigt.'));
        d.pending.forEach(a => {
          const resolve = action => fetch(base + '/api/admin/resolve?key=' + enc(key), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ app: a.name, action }) }).then(load);
          list.append(el('div', { class: 'pick-item', style: 'cursor:default' }, tic('gamepad', 'violet'),
            el('div', { class: 'grow' }, el('b', null, a.name), el('small', null, a.count + '× gemeldet')),
            el('button', { class: 'btn small primary', onclick: () => resolve('confirm') }, 'Bestätigen'),
            el('button', { class: 'btn small', onclick: () => resolve('ignore') }, 'Ignorieren')));
        });
      }).catch(e => { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, 'Server nicht erreichbar.')); });
      box.append(list, el('div', { class: 'row', style: 'margin-top:8px' },
        el('button', { class: 'btn small', onclick: load }, ic('refresh'), 'Neu laden'),
        el('button', { class: 'btn small', onclick: () => { LS.del('adminBase'); LS.del('adminKey'); draw(); } }, ic('x'), 'Trennen')));
      load();
    };
    draw();
    return box;
  }

  // ---------- accounts (on the central server, MySQL) ----------
  // Every device can sign in with an account; each sign-in is one row in the database, so the admin sees
  // how many devices are signed in and which are online. The admin creates the accounts on the "Konten" page.

  async function centralBase() {
    if (!S.central) {
      try { const d = await fetch('/api/ping', { cache: 'no-store' }).then(r => r.json()); if (d.central) S.central = d.central; } catch (e) { }
    }
    return S.central || LS.get('adminBase', '');
  }

  async function central(path, body, base, headers) {
    const b = base || await centralBase();
    if (!b) throw new Error('Kein Konten-Server bekannt');
    let r;
    try {
      r = await fetch(b + path, body ? { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers), body: JSON.stringify(body) }
        : { cache: 'no-store', headers: headers || {} });
    } catch (e) { const x = new Error('Server nicht erreichbar – hat das Gerät Internet?'); x.offline = true; throw x; }
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.error) { const e = new Error(d.error || ('Fehler ' + r.status)); e.status = r.status; e.signedOut = !!d.signedOut; throw e; }
    return d;
  }

  // The signed-in account: in localStorage with "Angemeldet bleiben", otherwise only for this session
  // (closing the browser / PC Remote signs out). Roles: owner > admin > vip > user.
  const Acct = {
    get() {
      try { const v = sessionStorage.getItem('pcr.account'); if (v) return JSON.parse(v); } catch (e) { }
      return LS.get('account', null);
    },
    set(a, keep) {
      if (keep) { LS.set('account', a); try { sessionStorage.removeItem('pcr.account'); } catch (e) { } }
      else { LS.del('account'); try { sessionStorage.setItem('pcr.account', JSON.stringify(a)); } catch (e) { } }
    },
    update(patch) { const a = this.get(); if (a) this.set(Object.assign(a, patch), !!LS.get('account', null)); },
    del() { LS.del('account'); try { sessionStorage.removeItem('pcr.account'); } catch (e) { } }
  };
  const realRole = () => (Acct.get() || {}).role || 'user';
  // owner test area: "Ansicht als VIP / Nutzer" shows the app with another role (only on this screen, nothing changes on the server)
  const myRole = () => S.viewAs || realRole();
  const isRealStaff = () => ['owner', 'admin'].includes(realRole());
  const isStaff = () => ['owner', 'admin'].includes(myRole());
  const isVip = () => ['vip', 'owner', 'admin'].includes(myRole());
  const ROLE_NAMES = { owner: 'Owner', admin: 'Admin', vip: 'VIP', user: 'Nutzer' };
  // requests as the signed-in account
  const asMe = (path, body) => { const a = Acct.get(); if (!a) return Promise.reject(new Error('Bitte anmelden')); return central(path, Object.assign({ token: a.token }, body), a.base); };

  function deviceGuess() {
    if (PC) return 'PC ' + (S.name || '');
    const ua = navigator.userAgent;
    return /iPad|Tablet/i.test(ua) || (/Android/.test(ua) && !/Mobile/.test(ua)) ? 'Tablet' : /iPhone/.test(ua) ? 'iPhone' : /Android/.test(ua) ? 'Android-Handy' : 'Browser';
  }
  function platformGuess() {
    const ua = navigator.userAgent;
    const b = PC ? 'PC-App' : /Edg\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung Internet' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
    const os = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Mac OS X/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '';
    return b + (os ? ' · ' + os : '');
  }
  const acctIcon = s => /ipad|tablet/i.test(s) ? 'devices' : /android|iphone|ios|handy/i.test(s) ? 'phone' : 'monitor';
  const devCount = n => n === 0 ? 'kein Gerät angemeldet' : n === 1 ? '1 Gerät angemeldet' : n + ' Geräte angemeldet';

  const ACC = { redrawMe: null, reload: null };
  const accountsChanged = () => { if (ACC.redrawMe) ACC.redrawMe(); if (ACC.reload) ACC.reload(true); };

  // A signed-in device reports in regularly while the app is open: the database knows it is online, the app learns
  // a new role right away (VIP given by the owner) and how many chat answers are waiting.
  function accountHeartbeat() {
    if (accountHeartbeat.on) return;
    accountHeartbeat.on = true;
    const beat = async () => {
      const me = Acct.get();
      if (!me || document.hidden) return;
      try {
        const d = await central('/api/session/ping', { token: me.token }, me.base);
        const roleChanged = d.role && d.role !== me.role;
        if (roleChanged) Acct.update({ role: d.role });
        setUnread(d.unread || 0);
        if (roleChanged) roleUpdated(me.role, d.role);
      } catch (e) {
        const now = Acct.get();
        if (e.signedOut && now && now.token === me.token) signedOut(e.message);
      }
    };
    beat();
    setInterval(beat, 40000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) beat(); });
  }

  // answers waiting: a dot on VIP / Bug-Fix (users) or on Nachrichten (owner) – and for the owner a Windows notification
  function setUnread(n) {
    const before = S.unread || 0;
    S.unread = n;
    document.querySelectorAll('.tab[data-tab="inbox"], .tab[data-tab="support"], .tab[data-tab="vip"], .menu-row[data-tab]').forEach(b => {
      const k = b.dataset.tab, show = n > 0 && (isStaff() ? k === 'inbox' : k === 'support' || k === 'vip');
      let dot = b.querySelector('.tab-badge');
      if (show && !dot) b.append(dot = el('span', { class: 'tab-badge' }));
      if (dot) { dot.textContent = show ? String(n) : ''; dot.style.display = show ? '' : 'none'; }
    });
    if (n > before && before >= 0 && S.unreadSeen) {
      const text = isStaff() ? (n === 1 ? 'Eine neue Nachricht wartet auf dich' : n + ' Nachrichten warten auf dich') : 'Du hast eine neue Antwort';
      toast(text);
      if (PC && isStaff()) api('/api/pc', { cmd: 'notify', title: 'PC Remote – Nachrichten', text }).catch(() => { });
    }
    S.unreadSeen = true;
  }

  function roleUpdated(was, now) {
    toast(now === 'vip' ? 'Du bist jetzt VIP – viel Spaß!' : 'Deine Rolle ist jetzt: ' + (ROLE_NAMES[now] || now));
    applyBackground();
    if (current && NAV.tab && ['vip', 'support', 'accounts', 'inbox'].includes(NAV.tab)) show(NAV.tab);
    if (isStaff() !== ['owner', 'admin'].includes(was)) startApp(); // owner tabs appear / disappear
  }

  function signedOut(msg) {
    Acct.del();
    applyBackground();
    renderAccountGate(msg || 'Du wurdest abgemeldet – bitte neu anmelden.');
  }

  // "Dieses Gerät": sign in / out with an account
  function myAccountCard() {
    const box = el('div', { class: 'card form acct-me' });
    const draw = () => {
      if (!box.isConnected && box.dataset.drawn) { ACC.redrawMe = null; return; }
      box.dataset.drawn = '1';
      box.innerHTML = '';
      const me = Acct.get();
      if (me) {
        box.append(el('div', { class: 'row' },
          el('div', { class: 'acct-avatar' }, me.username.slice(0, 1).toUpperCase()),
          el('div', { class: 'grow acct-who' }, el('b', null, me.username, roleBadge(me.role)),
            el('small', null, 'Angemeldet auf „' + me.device + '“ · seit ' + new Date(me.since).toLocaleDateString('de-DE') + (LS.get('account', null) ? ' · bleibt angemeldet' : ''))),
          el('button', { class: 'btn small', onclick: async () => {
            if (!await confirmSheet('Abmelden?', 'Ohne Konto kommst du nicht mehr in PC Remote – du kannst dich jederzeit wieder anmelden.', 'Abmelden')) return;
            await central('/api/session/logout', { token: me.token }, me.base).catch(() => { });
            signedOut('Du bist abgemeldet.');
          } }, ic('logout'), 'Abmelden')));
        return;
      }
      const u = el('input', { class: 'in', placeholder: 'Benutzername', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false' });
      const pw = el('input', { class: 'in', type: 'password', placeholder: 'Passwort', autocomplete: 'current-password' });
      const dev = el('input', { class: 'in', value: deviceGuess(), maxlength: '60', autocomplete: 'off' });
      const btn = el('button', { class: 'btn primary' }, ic('check'), 'Anmelden');
      const go = async () => {
        if (!u.value.trim() || !pw.value) return toast('Benutzername und Passwort eingeben', 'err');
        btn.disabled = true;
        try {
          const base = await centralBase();
          const d = await central('/api/login', { username: u.value, password: pw.value, device: dev.value, platform: platformGuess() }, base);
          Acct.set({ base, token: d.token, session: d.session, username: d.username, role: d.role, device: dev.value.trim() || deviceGuess(), since: Date.now() }, true);
          toast('Angemeldet als ' + d.username);
          accountsChanged();
        } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
      };
      [u, pw].forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } }));
      btn.onclick = go;
      box.append(el('p', { class: 'hint', style: 'margin:0' }, 'Melde dieses Gerät mit einem PC-Remote-Konto an. Dann zählt es in der Datenbank zu den angemeldeten Geräten.'),
        el('div', { class: 'size-row' }, field('Benutzername', u), field('Passwort', pw)),
        field('Name dieses Geräts', dev), btn);
    };
    ACC.redrawMe = draw;
    draw();
    return box;
  }

  // one account: its signed-in devices, sign out, new password, delete
  function accountSheet(acc, adm) {
    const me = Acct.get();
    const devs = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
    const loadDevs = () => adm('/api/admin/sessions?user=' + enc(acc.username)).then(d => {
      devs.innerHTML = '';
      if (!d.sessions.length) return devs.append(el('div', { class: 'empty' }, 'Auf keinem Gerät angemeldet.'));
      d.sessions.forEach(s => {
        const mine = !!(me && me.session === s.id);
        devs.append(el('div', { class: 'pick-item', style: 'cursor:default' }, tic(acctIcon(s.device + ' ' + s.platform), s.online ? 'green' : 'slate'),
          el('div', { class: 'grow' }, el('b', null, s.device || 'Gerät', mine ? el('span', { class: 'me-badge' }, 'dieses Gerät') : null),
            el('small', null, (s.online ? 'Gerade online' : 'Zuletzt aktiv ' + ago(s.last_seen)) + (s.platform ? ' · ' + s.platform : '') + ' · angemeldet ' + ago(s.created))),
          el('button', { class: 'btn small', 'aria-label': 'Abmelden', title: 'Abmelden', onclick: async () => {
            if (!await confirmSheet('„' + (s.device || 'Gerät') + '“ abmelden?', 'Das Gerät muss sich danach neu anmelden.', 'Abmelden', true)) return;
            try {
              await adm('/api/admin/sessions', { op: 'revoke', id: s.id });
              if (mine) return signedOut('Du hast dieses Gerät abgemeldet.');
              toast('Gerät abgemeldet'); loadDevs(); accountsChanged();
            } catch (e) { toast(e.message, 'err'); }
          } }, ic('logout'))));
      });
    }).catch(e => { devs.innerHTML = ''; devs.append(el('div', { class: 'empty' }, e.message)); });

    const pw = el('input', { class: 'in', type: 'password', placeholder: 'Neues Passwort (min. 6)', autocomplete: 'new-password' });
    const isMe = !!(me && me.username === acc.username);
    // the owner hands out roles: VIP unlocks the VIP area for this account
    const roles = [['user', 'Nutzer'], ['vip', 'VIP'], ['admin', 'Admin']].concat(myRole() === 'owner' ? [['owner', 'Owner']] : []);
    const roleSeg = segTabs(roles, acc.role, async k => {
      if (k === acc.role) return;
      if (isMe && !await confirmSheet('Deine eigene Rolle ändern?', 'Als ' + ROLE_NAMES[k] + ' verlierst du eventuell den Zugriff auf diese Verwaltung.', 'Ändern', true)) { roleSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.k === acc.role)); return; }
      try {
        await adm('/api/admin/accounts', { op: 'role', username: acc.username, role: k });
        acc.role = k;
        toast('„' + acc.username + '“ ist jetzt ' + ROLE_NAMES[k] + (k === 'vip' ? ' – der VIP-Bereich ist freigeschaltet' : ''));
        accountsChanged();
      } catch (e) { toast(e.message, 'err'); }
    });
    const close = sheet(acc.username, el('div', { class: 'form' },
      el('p', { class: 'hint', style: 'margin:0' }, (ROLE_NAMES[acc.role] || 'Nutzer') + ' · angelegt am ' + (acc.created ? new Date(acc.created).toLocaleDateString('de-DE') : '?') +
        (acc.last_login ? ' · zuletzt angemeldet ' + ago(acc.last_login) : ' · noch nie angemeldet')),
      field('Rolle', roleSeg, 'VIP: Zugang zum VIP-Bereich (z. B. eigene Hintergründe). Admin: darf Konten verwalten. Owner: alles, auch Nachrichten und Texte.'),
      heading('Angemeldete Geräte'), devs,
      el('div', { class: 'row wrap' },
        el('button', { class: 'btn small', onclick: loadDevs }, ic('refresh'), 'Neu laden'),
        el('button', { class: 'btn small', onclick: async () => {
          if (!await confirmSheet('Alle Geräte von „' + acc.username + '“ abmelden?', 'Jedes Gerät muss sich danach neu anmelden.', 'Alle abmelden', true)) return;
          try {
            const r = await adm('/api/admin/sessions', { op: 'revokeAll', username: acc.username });
            if (isMe) return signedOut('Du hast alle deine Geräte abgemeldet.');
            toast(r.n === 1 ? '1 Gerät abgemeldet' : r.n + ' Geräte abgemeldet'); loadDevs(); accountsChanged();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('logout'), 'Alle abmelden')),
      heading('Passwort ändern'),
      el('div', { class: 'row' }, el('div', { class: 'grow' }, pw),
        el('button', { class: 'btn primary', onclick: async () => {
          try {
            const r = await adm('/api/admin/accounts', { op: 'password', username: acc.username, password: pw.value });
            if (isMe) return signedOut('Passwort geändert – bitte mit dem neuen Passwort anmelden.');
            pw.value = '';
            toast('Passwort geändert' + (r.signedOut ? ' · ' + r.signedOut + ' Gerät' + (r.signedOut === 1 ? '' : 'e') + ' abgemeldet' : ''));
            loadDevs(); accountsChanged();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('check'), 'Speichern')),
      el('p', { class: 'hint', style: 'margin:0' }, 'Ein neues Passwort meldet das Konto auf allen Geräten ab.'),
      el('div', { class: 'sheet-actions' },
        el('button', { class: 'btn danger', onclick: async () => {
          if (!await confirmSheet('Konto „' + acc.username + '“ löschen?', 'Das Konto und alle Anmeldungen werden aus der Datenbank gelöscht.', 'Löschen', true)) return;
          try {
            await adm('/api/admin/accounts', { op: 'delete', username: acc.username });
            close();
            if (isMe) return signedOut('Dein Konto wurde gelöscht.');
            toast('Konto gelöscht'); accountsChanged();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('trash'), 'Konto löschen'))));
    loadDevs();
  }

  // Management (admin link needed): numbers from the database, all accounts with their devices, new account
  function accountAdmin() {
    const box = el('div');
    let timer = null;
    const draw = () => {
      clearInterval(timer);
      box.innerHTML = '';
      const base = LS.get('adminBase', ''), key = LS.get('adminKey', ''), me = Acct.get();
      // the owner / an admin manages everything with their own sign-in; the admin link is only a fallback
      const viaAccount = !!(me && isStaff());
      if (!viaAccount && (!base || !key)) {
        ACC.reload = null;
        return; // normal accounts don't manage anything here
      }
      const adm = viaAccount
        ? (path, body) => central(path, body || null, me.base, { Authorization: 'Bearer ' + me.token })
        : (path, body) => central(path + (path.indexOf('?') >= 0 ? '&' : '?') + 'key=' + enc(key), body, base);

      const stats = el('div', { class: 'stat-grid three acct-stats' });
      const cell = (label, cls) => { const n = el('div', { class: 'big-num' }, '–'); stats.append(el('div', { class: 'card ' + (cls || '') }, el('div', { class: 'hint' }, label), n)); return n; };
      const nAcc = cell('Konten'), nDev = cell('Geräte angemeldet'), nOn = cell('Gerade online', 'acct-online');
      const dbLine = el('p', { class: 'hint acct-db' }, 'Verbinde …');
      const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
      let lastKey = '';
      const load = async force => {
        if (!box.isConnected && lastKey) { clearInterval(timer); return; }
        if (force) lastKey = '';
        try {
          const [s, a] = await Promise.all([adm('/api/admin/stats'), adm('/api/admin/accounts')]);
          nAcc.textContent = s.db ? s.accounts : '–';
          nDev.textContent = s.db ? s.devices : '–';
          nOn.textContent = s.db ? s.online : '–';
          dbLine.textContent = s.db
            ? 'Datenbank verbunden · ' + s.signedInAccounts + ' von ' + s.accounts + (s.accounts === 1 ? ' Konto' : ' Konten') + ' auf mindestens einem Gerät angemeldet · online = in den letzten 3 Minuten aktiv'
            : 'Datenbank nicht verbunden' + (s.dbError ? ' (' + s.dbError + ')' : '');
          const k = JSON.stringify(a.accounts);
          if (k === lastKey) return;
          lastKey = k;
          list.innerHTML = '';
          if (!a.accounts.length) return list.append(el('div', { class: 'empty' }, 'Noch keine Konten – unten das erste anlegen.'));
          a.accounts.forEach(x => list.append(el('button', { class: 'pick-item menu-row', onclick: () => accountSheet(x, adm) },
            tic(x.role === 'owner' || x.role === 'vip' ? 'crown' : x.role === 'admin' ? 'lock' : 'users', x.online ? 'green' : x.role === 'vip' || x.role === 'owner' ? 'yellow' : x.role === 'admin' ? 'violet' : 'cyan'),
            el('div', null, el('b', null, x.username, roleBadge(x.role)),
              el('small', null, devCount(x.devices) + (x.online ? ' · ' + x.online + ' online' : '') + ' · ' +
                (x.last_seen ? 'aktiv ' + ago(x.last_seen) : x.last_login ? 'zuletzt angemeldet ' + ago(x.last_login) : 'noch nie angemeldet'))),
            el('span', { class: 'acct-count' + (x.online ? ' on' : '') }, ic('devices'), String(x.devices)),
            ic('right', 'chev'))));
        } catch (e) {
          nAcc.textContent = nDev.textContent = nOn.textContent = '–';
          dbLine.textContent = e.status === 401 ? 'Der Admin-Link stimmt nicht (mehr) – unten trennen und neu verbinden.' : e.message;
          if (!lastKey) { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); }
        }
      };

      const u = el('input', { class: 'in', placeholder: 'z. B. max', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', maxlength: '32' });
      const pw = el('input', { class: 'in', type: 'password', placeholder: 'mindestens 6 Zeichen', autocomplete: 'new-password' });
      const role = { v: 'user' };
      const create = async () => {
        try {
          const r = await adm('/api/admin/accounts', { op: 'create', username: u.value, password: pw.value, role: role.v });
          toast('Konto „' + r.account.username + '“ angelegt');
          u.value = ''; pw.value = '';
          load(true);
        } catch (e) { toast(e.message, 'err'); }
      };
      pw.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); create(); } });

      box.append(heading('Übersicht'), stats, dbLine,
        heading('Alle Konten'), list,
        heading('Neues Konto'), el('div', { class: 'card form' },
          el('div', { class: 'size-row' }, field('Benutzername', u, '3–32 Zeichen: a–z, 0–9, . _ -'), field('Passwort', pw)),
          field('Rolle', segTabs([['user', 'Nutzer'], ['vip', 'VIP'], ['admin', 'Admin']], 'user', k => role.v = k)),
          el('button', { class: 'btn primary', onclick: create }, ic('plus'), 'Konto anlegen')),
        el('div', { class: 'row wrap', style: 'margin-top:14px' },
          el('button', { class: 'btn small', onclick: () => load(true) }, ic('refresh'), 'Neu laden'),
          viaAccount ? null : el('button', { class: 'btn small', onclick: async () => {
            if (!await confirmSheet('Admin-Link auf diesem Gerät vergessen?', 'Die Konten bleiben erhalten. Zum Verwalten musst du den Link danach neu einfügen.', 'Trennen')) return;
            LS.del('adminBase'); LS.del('adminKey'); draw();
          } }, ic('x'), 'Admin-Link trennen')));
      ACC.reload = load;
      load();
      timer = setInterval(() => { if (!box.isConnected) { clearInterval(timer); return; } if (!document.hidden) load(); }, 15000);
    };
    draw();
    return box;
  }

  const roleBadge = r => r && r !== 'user' ? el('span', { class: 'role-badge r-' + r }, ROLE_NAMES[r] || r) : null;

  const AccountsView = {
    title: 'Konto',
    render(root) {
      root.append(heading('Dein Konto'), myAccountCard(), accountAdmin());
    },
    destroy() { ACC.redrawMe = null; ACC.reload = null; }
  };

  // ---------- sign-in gate: without an account there is no way into PC Remote ----------

  function renderAccountGate(msg) {
    stopPoll();
    NAV.stack.forEach(v => { if (v.destroy) v.destroy(); });
    NAV.stack = [];
    current = null;
    sheets.slice().forEach(c => c());
    const app = $('#app');
    app.innerHTML = '';
    let mode = 'login';
    const err = el('div', { class: 'err-text' }, msg || '');
    const u = el('input', { class: 'in', placeholder: 'Benutzername', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false', maxlength: '32' });
    const pw = el('input', { class: 'in', type: 'password', placeholder: 'Passwort', autocomplete: 'current-password' });
    const pw2 = el('input', { class: 'in', type: 'password', placeholder: 'Passwort wiederholen', autocomplete: 'new-password' });
    const keep = el('input', { type: 'checkbox', checked: true });
    keep.checked = LS.get('keepSignedIn', true);
    const btn = el('button', { class: 'btn primary block', type: 'submit' }, 'Anmelden');
    const regRow = el('div', { class: 'gate-extra', style: 'display:none' }, pw2, el('small', { class: 'hint' }, 'Benutzername: 3–32 Zeichen (a–z, 0–9, . _ -). Passwort: mindestens 6 Zeichen.'));
    const setMode = m => {
      mode = m;
      regRow.style.display = m === 'register' ? '' : 'none';
      btn.textContent = m === 'register' ? 'Konto erstellen' : 'Anmelden';
      pw.autocomplete = m === 'register' ? 'new-password' : 'current-password';
      err.textContent = '';
    };
    const form = el('form', { class: 'login gate', onsubmit: async e => {
      e.preventDefault();
      if (!u.value.trim() || !pw.value) { err.textContent = 'Bitte Benutzername und Passwort eingeben.'; return; }
      btn.disabled = true;
      err.textContent = '';
      try {
        const base = await centralBase();
        const body = { username: u.value, password: pw.value, device: deviceGuess(), platform: platformGuess() };
        if (mode === 'register') body.password2 = pw2.value;
        const d = await central(mode === 'register' ? '/api/register' : '/api/login', body, base);
        LS.set('keepSignedIn', keep.checked);
        Acct.set({ base, token: d.token, session: d.session, username: d.username, role: d.role, device: deviceGuess(), since: Date.now() }, keep.checked);
        S.unreadSeen = false;
        toast(mode === 'register' ? (d.role === 'owner' ? 'Willkommen, Owner! Dein Konto ist das erste und verwaltet alles.' : 'Konto erstellt – willkommen!') : 'Willkommen zurück, ' + d.username + '!');
        applyBackground();
        startApp();
      } catch (x) { err.textContent = x.message; btn.disabled = false; }
    } },
      el('img', { class: 'logo', src: '/logo-192.png', alt: '' }),
      el('h1', null, 'PC Remote'),
      el('p', null, 'Melde dich mit deinem Konto an'),
      segTabs([['login', 'Anmelden'], ['register', 'Konto erstellen']], 'login', setMode, 'gate-seg'),
      el('div', { class: 'gate-fields' }, u, pw, regRow),
      el('label', { class: 'gate-keep' }, keep, el('span', null, 'Angemeldet bleiben')),
      err, btn,
      el('p', { class: 'hint' }, 'Ohne „Angemeldet bleiben“ wirst du abgemeldet, sobald du ' + (PC ? 'PC Remote schließt.' : 'den Browser schließt.')));
    app.append(el('div', { class: 'center' }, form));
    setTimeout(() => u.focus(), 50);
  }

  // ---------- VIP backgrounds ----------

  const BG_PRESETS = [
    ['aurora', 'Aurora', 'radial-gradient(1100px 680px at 8% -5%, rgba(124,92,255,.62), transparent 60%), radial-gradient(900px 620px at 95% 5%, rgba(34,211,238,.4), transparent 62%), radial-gradient(900px 600px at 50% 110%, rgba(236,72,153,.32), transparent 60%), #08080f'],
    ['sunset', 'Sonnenuntergang', 'linear-gradient(165deg, #1d0b3d 0%, #5b1d8f 32%, #c2366f 64%, #f8875b 100%)'],
    ['ocean', 'Ozean', 'radial-gradient(1000px 640px at 15% 0%, rgba(56,189,248,.5), transparent 60%), radial-gradient(800px 600px at 100% 100%, rgba(45,212,191,.28), transparent 60%), linear-gradient(180deg, #02101f, #052849 60%, #083b63)'],
    ['forest', 'Wald', 'radial-gradient(900px 620px at 85% -5%, rgba(74,222,128,.42), transparent 60%), radial-gradient(800px 600px at 0% 100%, rgba(16,185,129,.3), transparent 60%), linear-gradient(180deg, #03130d, #0a271c)'],
    ['nebula', 'Nebel', 'radial-gradient(700px 520px at 28% 28%, rgba(217,70,239,.5), transparent 62%), radial-gradient(820px 620px at 75% 72%, rgba(59,130,246,.45), transparent 62%), radial-gradient(500px 400px at 80% 15%, rgba(255,255,255,.08), transparent 60%), #06050e'],
    ['ember', 'Glut', 'radial-gradient(950px 620px at 50% 115%, rgba(251,146,60,.6), transparent 62%), radial-gradient(700px 520px at 0% 0%, rgba(239,68,68,.38), transparent 60%), #110705'],
    ['synth', 'Synthwave', 'linear-gradient(180deg, rgba(8,4,24,0) 50%, rgba(236,72,153,.4) 100%), repeating-linear-gradient(90deg, rgba(168,85,247,.2) 0 1px, transparent 1px 64px), repeating-linear-gradient(0deg, rgba(168,85,247,.2) 0 1px, transparent 1px 64px), linear-gradient(180deg, #090418, #1c0b3d)'],
    ['carbon', 'Carbon', 'radial-gradient(900px 600px at 50% -10%, rgba(255,255,255,.07), transparent 60%), repeating-linear-gradient(45deg, rgba(255,255,255,.028) 0 2px, transparent 2px 9px), linear-gradient(180deg, #15161c, #0a0b0f)']
  ];

  // ---------- VIP look: accent colour, tile style, font, animated background, click sound (per device) ----------

  const VIP_ACCENTS = [['violet', '#7c5cff'], ['blue', '#3b82f6'], ['cyan', '#06b6d4'], ['green', '#10b981'], ['pink', '#ec4899'], ['orange', '#f97316'], ['red', '#ef4444'], ['gold', '#f59e0b']];
  const VIP_FONTS = ['Manrope', 'Inter', 'Space Grotesk', 'Nunito', 'Outfit'];
  const VIP_TILES = [['', 'Standard'], ['glass', 'Glas'], ['neon', 'Neon'], ['flat', 'Flach']];
  const VIP_PERKS = [['image', 'Eigene Hintergründe – auch mit deinem Bild'], ['star', 'Akzentfarbe für die ganze App'], ['grid', 'Kachel-Stile: Glas, Neon, Flach'],
    ['type', 'Eigene Schriftarten'], ['zap', 'Animierter Hintergrund'], ['heart', 'Emojis als Kachel-Symbol'], ['music', 'Klick-Sound beim Antippen']];
  const vipLook = () => Shared.get('vipLook', null) || {};
  const tileEmoji = t => t && t.emoji && Acct.get() && isVip() ? t.emoji : null;

  function loadFont(name) {
    if (!name || name === 'Manrope' || document.querySelector('link[data-font="' + name + '"]')) return;
    document.head.append(el('link', { rel: 'stylesheet', 'data-font': name, href: 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@500;600;700;800&display=swap' }));
  }

  function applyVipLook() {
    const L = Acct.get() && isVip() ? vipLook() : {};
    const st = document.documentElement.style;
    const acc = (VIP_ACCENTS.find(a => a[0] === L.accent) || [])[1];
    if (acc && L.accent !== 'violet') {
      st.setProperty('--accent', acc);
      st.setProperty('--accent-hi', 'color-mix(in srgb, ' + acc + ' 62%, #fff)');
      st.setProperty('--accent-soft', 'color-mix(in srgb, ' + acc + ' 16%, transparent)');
      st.setProperty('--grad', 'linear-gradient(135deg, ' + acc + ', color-mix(in srgb, ' + acc + ' 62%, #fff))');
    } else ['--accent', '--accent-hi', '--accent-soft', '--grad'].forEach(p => st.removeProperty(p));
    ['glass', 'neon', 'flat'].forEach(s => document.body.classList.toggle('tiles-' + s, L.tiles === s));
    document.body.classList.toggle('bg-anim', !!L.anim);
    if (L.font && L.font !== 'Manrope') { loadFont(L.font); st.setProperty('--font', '"' + L.font + '"'); } else st.removeProperty('--font');
    S.clickSound = !!L.sound;
  }

  let audioCtx = null;
  function clickSound() {
    if (!S.clickSound) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain(), t = audioCtx.currentTime;
      o.type = 'triangle';
      o.frequency.setValueAtTime(1150, t);
      o.frequency.exponentialRampToValueAtTime(620, t + .05);
      g.gain.setValueAtTime(.12, t);
      g.gain.exponentialRampToValueAtTime(.001, t + .07);
      o.connect(g).connect(audioCtx.destination);
      o.start(t);
      o.stop(t + .08);
    } catch (e) { }
  }

  function vipLookCard() {
    const card = el('div', { class: 'card form vip-look' });
    VIP_FONTS.forEach(loadFont);
    const draw = () => {
      card.innerHTML = '';
      const L = vipLook();
      const set = patch => { const n = Object.assign({}, vipLook(), patch); Object.keys(n).forEach(k => { if (n[k] === '' || n[k] === false) delete n[k]; }); Shared.set('vipLook', n); applyVipLook(); draw(); };
      const fonts = segTabs(VIP_FONTS.map(f => [f, f]), L.font || 'Manrope', k => set({ font: k === 'Manrope' ? '' : k }));
      [...fonts.children].forEach(b => { b.style.fontFamily = '"' + b.dataset.k + '", sans-serif'; });
      card.append(
        field('Akzentfarbe', el('div', { class: 'swatches' }, VIP_ACCENTS.map(([id, hex]) => el('button', { type: 'button', class: (L.accent || 'violet') === id ? 'on' : '', style: '--c:' + hex, 'aria-label': id, onclick: () => set({ accent: id === 'violet' ? '' : id }) })))),
        field('Kachel-Stil', segTabs(VIP_TILES, L.tiles || '', k => set({ tiles: k }))),
        field('Schriftart', fonts),
        el('label', { class: 'check' }, el('span', null, 'Animierter Hintergrund', el('small', { class: 'hint', style: 'display:block' }, 'Die Farben wandern langsam – am schönsten mit einem Hintergrund von oben')), sw(L.anim, v => set({ anim: v }))),
        el('label', { class: 'check' }, el('span', null, 'Klick-Sound beim Antippen', el('small', { class: 'hint', style: 'display:block' }, 'Ein kurzes „Tick“, wenn du eine Kachel drückst')), sw(L.sound, v => { set({ sound: v }); clickSound(); })),
        el('p', { class: 'hint', style: 'margin:0' }, 'Emoji als Kachel-Symbol: im Deck auf „Bearbeiten“, Kachel antippen → „Bearbeiten“ → „Emoji“.'),
        el('div', null, el('button', { class: 'btn small', type: 'button', onclick: () => { Shared.set('vipLook', null); applyVipLook(); draw(); } }, ic('restart'), 'Aussehen zurücksetzen')));
    };
    draw();
    return card;
  }

  // VIP only: a preset or an own picture behind the whole app (stored on this device), darkened so text stays readable
  function applyBackground() {
    applyVipLook();
    const bg = document.querySelector('.bg');
    if (!bg) return;
    const c = Shared.get('bgChoice', null);
    let css = null;
    if (c && Acct.get() && isVip()) {
      if (c.type === 'preset') { const p = BG_PRESETS.find(x => x[0] === c.id); css = p ? p[2] : null; }
      else if (c.type === 'image') { const img = Shared.get('bgImage', null); css = img ? 'url("' + img + '") center / cover no-repeat, #000' : null; }
    }
    bg.style.background = css || '';
    bg.classList.toggle('custom', !!css);
    document.body.classList.toggle('custom-bg', !!css);
    document.body.style.setProperty('--bg-dim', String(c && c.dim != null ? c.dim : .3));
  }

  function backgroundPicker() {
    const box = el('div', { class: 'bg-picker' });
    const draw = () => {
      box.innerHTML = '';
      const c = Shared.get('bgChoice', null) || {};
      const pick = choice => { Shared.set('bgChoice', Object.assign({ dim: c.dim != null ? c.dim : .3 }, choice)); applyBackground(); draw(); };
      const tiles = el('div', { class: 'bg-grid' },
        el('button', { class: 'bg-opt none' + (!c.type ? ' on' : ''), type: 'button', onclick: () => { Shared.set('bgChoice', null); applyBackground(); draw(); } }, ic('x'), el('span', null, 'Standard')),
        // the preview draws the whole screen-sized background and shrinks it, so you see the real picture
        BG_PRESETS.map(([id, name, css]) => el('button', { class: 'bg-opt' + (c.type === 'preset' && c.id === id ? ' on' : ''), type: 'button', onclick: () => pick({ type: 'preset', id }) },
          el('i', { class: 'bg-mini', style: 'background:' + css }), el('span', null, name))));
      const img = Shared.get('bgImage', null);
      if (img) tiles.append(el('button', { class: 'bg-opt' + (c.type === 'image' ? ' on' : ''), type: 'button', style: 'background:url("' + img + '") center / cover', onclick: () => pick({ type: 'image' }) }, el('span', null, 'Dein Bild')));
      const file = el('input', { type: 'file', accept: 'image/*', style: 'display:none' });
      file.addEventListener('change', () => {
        const f = file.files && file.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
          const im = new Image();
          im.onload = () => {
            // shrink to at most 1920 px and store as JPEG – fits into the browser storage
            const scale = Math.min(1, 1920 / Math.max(im.width, im.height));
            const cv = document.createElement('canvas');
            cv.width = Math.round(im.width * scale); cv.height = Math.round(im.height * scale);
            cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
            let data = cv.toDataURL('image/jpeg', .82);
            if (data.length > 2400000) data = cv.toDataURL('image/jpeg', .6);
            if (data.length > 4000000) return toast('Das Bild ist zu groß – bitte ein kleineres wählen', 'err');
            Shared.set('bgImage', data); // goes to the PC – so every device shows it
            pick({ type: 'image' });
            toast('Dein Bild ist jetzt der Hintergrund');
          };
          im.onerror = () => toast('Das ist kein Bild, das der Browser lesen kann', 'err');
          im.src = reader.result;
        };
        reader.readAsDataURL(f);
      });
      const dim = makeRange({ min: 0, max: 80, step: 5, throttle: 100 }, v => { Shared.set('bgChoice', Object.assign({}, Shared.get('bgChoice', {}), { dim: v / 100 })); applyBackground(); },
        v => document.body.style.setProperty('--bg-dim', String(v / 100)));
      dim.setValue(Math.round((c.dim != null ? c.dim : .3) * 100));
      box.append(...[tiles,
        el('div', { class: 'row wrap', style: 'margin:12px 0' },
          el('button', { class: 'btn small primary', type: 'button', onclick: () => file.click() }, ic('image'), 'Eigenes Bild einfügen'),
          img ? el('button', { class: 'btn small', type: 'button', onclick: () => { Shared.set('bgImage', null); if (c.type === 'image') Shared.set('bgChoice', null); applyBackground(); draw(); } }, ic('trash'), 'Bild entfernen') : null),
        c.type ? field('Abdunkeln (damit Text gut lesbar bleibt)', dim) : null, file,
        el('p', { class: 'hint', style: 'margin:10px 0 0' }, 'Gilt sofort auf allen Geräten, die mit diesem PC verbunden sind.')].filter(Boolean));
    };
    draw();
    return box;
  }

  // ---------- support chats: VIP requests and Bug/Fix – the AI answers first, the owner gets what really needs him ----------

  let infoCache = null;
  async function centralInfo(fresh) {
    if (!fresh && infoCache && Date.now() - infoCache.at < 60000) return infoCache.d;
    const d = await central('/api/info', null, (Acct.get() || {}).base).catch(() => ({}));
    infoCache = { at: Date.now(), d };
    return d;
  }

  const CHAT_KIND = { vip: { name: 'VIP-Anfrage', icon: 'crown', color: 'yellow' }, bug: { name: 'Bug/Fix', icon: 'bug', color: 'red' } };
  const chatStatus = (st, owner) => st === 'owner' ? (owner ? 'Wartet auf dich' : 'Beim Owner') : st === 'closed' ? 'Erledigt' : 'KI antwortet';

  function chatBubbles(list, msgs, ownerView) {
    list.innerHTML = '';
    msgs.forEach(m => {
      const mine = ownerView ? m.from === 'owner' : m.from === 'user';
      const who = m.from === 'ai' ? 'KI-Assistent' : m.from === 'owner' ? 'Owner' : m.from === 'system' ? 'PC Remote' : ownerView ? 'Nutzer' : 'Du';
      list.append(el('div', { class: 'msg ' + (mine ? 'me' : 'them') + ' from-' + m.from },
        mine ? null : el('div', { class: 'msg-who' }, m.from === 'ai' ? ic('zap') : m.from === 'owner' ? ic('crown') : null, who),
        el('div', { class: 'msg-text' }, m.text), el('div', { class: 'msg-time' }, new Date(m.t).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }))));
    });
    requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
  }

  // chat sheet for users: start a new chat (id null) or continue one
  function chatSheet(kind, id, onChange) {
    const k = CHAT_KIND[kind];
    const list = el('div', { class: 'msg-list' });
    const banner = el('div', { class: 'chat-banner' });
    const input = el('textarea', { class: 'in chat-in', rows: '2', maxlength: '2000', placeholder: id ? 'Nachricht schreiben …' : kind === 'vip' ? 'Was möchtest du zu VIP wissen?' : 'Was ist passiert? Je genauer, desto schneller die Hilfe.' });
    const send = el('button', { class: 'btn primary chat-send', type: 'button', 'aria-label': 'Senden' }, ic('send'));
    const compose = el('div', { class: 'chat-compose' }, input, send);
    // a finished chat can't be continued – it disappears once you close it; a new message starts a new chat
    const ended = el('div', { class: 'chat-ended', style: 'display:none' }, el('span', null, 'Dieser Chat ist beendet.'),
      el('button', { class: 'btn small primary', type: 'button', onclick: () => { close(); chatSheet(kind, null, onChange); } }, ic('plus'), 'Neue Nachricht'));
    let chat = null, timer = null;
    const paint = () => {
      const isClosed = !!(chat && chat.status === 'closed');
      compose.style.display = isClosed ? 'none' : '';
      ended.style.display = isClosed ? '' : 'none';
      if (!chat) {
        list.innerHTML = '';
        list.append(el('div', { class: 'empty chat-empty' }, tic(k.icon, k.color), el('b', null, kind === 'vip' ? 'Schreib, was du zu VIP wissen möchtest' : 'Beschreib dein Problem'),
          el('small', null, kind === 'vip' ? 'Ein KI-Assistent antwortet sofort. Wenn es wirklich den Owner braucht, gibt er deine Nachricht weiter – die Antwort kommt dann hier.'
            : 'Deine Meldung geht direkt an den Owner – er antwortet dir hier im Chat. Je genauer (was, wann, welches Gerät), desto schneller die Hilfe.')));
      } else chatBubbles(list, chat.msgs, false);
      const st = chat ? chat.status : (kind === 'bug' ? 'owner' : 'ai');
      banner.className = 'chat-banner st-' + st;
      banner.textContent = st === 'owner' ? (kind === 'bug' ? 'Geht direkt an den Owner – er antwortet dir hier im Chat.' : 'An den Owner weitergeleitet – er antwortet dir hier im Chat.')
        : st === 'closed' ? 'Beendet – sobald du den Chat schließt, ist er weg.' : 'Die erste Antwort kommt von einem KI-Assistenten.';
    };
    const load = () => asMe('/api/chat', { op: 'get', id: chat.id }).then(d => { const changed = JSON.stringify(d.chat.msgs) !== JSON.stringify(chat.msgs) || d.chat.status !== chat.status; chat = d.chat; if (changed) paint(); }).catch(() => { });
    const go = async () => {
      const text = input.value.trim();
      if (!text) return input.focus();
      send.disabled = true; input.disabled = true;
      const typing = el('div', { class: 'msg them typing' }, el('i'), el('i'), el('i'));
      list.append(el('div', { class: 'msg me pending' }, el('div', { class: 'msg-text' }, text)), typing);
      list.scrollTop = list.scrollHeight;
      try {
        const d = await asMe('/api/chat', chat ? { op: 'send', id: chat.id, text } : { op: 'start', kind, text });
        chat = d.chat;
        input.value = '';
        paint();
        if (onChange) onChange();
      } catch (e) {
        if (e.status === 410 && chat) chat.status = 'closed'; // closed meanwhile
        toast(e.message, 'err');
        paint();
      }
      send.disabled = false; input.disabled = false; input.focus();
    };
    send.onclick = go;
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
    const close = sheet(k.name, el('div', { class: 'chat' }, banner, list, compose, ended),
      { wide: true, onClose: () => { clearInterval(timer); if (onChange) onChange(); } });
    if (id) asMe('/api/chat', { op: 'get', id }).then(d => { chat = d.chat; paint(); if (onChange) onChange(); }).catch(e => { toast(e.message, 'err'); close(); });
    else paint();
    timer = setInterval(() => { if (chat && !document.hidden) load(); }, 5000);
    setTimeout(() => input.focus(), 300);
  }

  // a user's OPEN chats of one kind – nothing is shown until there is one, and a closed chat disappears
  function myChats(kind, title) {
    const box = el('div', { class: 'my-chats', style: 'display:none' });
    const list = el('div', { class: 'pick-list' });
    box.append(heading(title), list);
    const load = () => asMe('/api/chat', { op: 'list', kind }).then(d => {
      list.innerHTML = '';
      box.style.display = d.chats.length ? '' : 'none';
      d.chats.forEach(ch => list.append(el('button', { class: 'pick-item menu-row chat-row' + (ch.unread && ch.lastFrom !== 'user' ? ' unread' : ''), onclick: () => chatSheet(kind, ch.id, load) },
        tic(CHAT_KIND[kind].icon, CHAT_KIND[kind].color),
        el('div', null, el('b', null, ch.title || CHAT_KIND[kind].name), el('small', null, chatStatus(ch.status) + ' · ' + ago(ch.updated) + (ch.last ? ' · ' + ch.last.slice(0, 60) : ''))),
        ic('right', 'chev'))));
    }).catch(() => { box.style.display = 'none'; });
    load();
    box.reload = load;
    return box;
  }

  // owner: edit the texts users see (VIP page, Bug/Fix page)
  function ownerTextCard(fields, title) {
    const card = el('div', { class: 'card form owner-card' }, el('div', { class: 'owner-tag' }, ic('crown'), title));
    const vals = {};
    centralInfo(true).then(info => {
      fields.forEach(([key, label, from, ph, area]) => {
        vals[key] = info[from] || '';
        const i = el(area ? 'textarea' : 'input', { class: 'in', placeholder: ph, maxlength: area ? '1500' : '40' });
        if (area) i.style.minHeight = '96px', i.style.fontFamily = 'inherit', i.style.fontSize = '14px';
        i.value = vals[key];
        i.addEventListener('input', () => { vals[key] = i.value; });
        card.append(field(label, i));
      });
      card.append(el('button', { class: 'btn primary', onclick: () => asMe('/api/owner', Object.assign({ op: 'settings' }, vals)).then(() => { infoCache = null; toast('Gespeichert – alle sehen den neuen Text'); }).catch(e => toast(e.message, 'err')) }, ic('check'), 'Speichern'));
    });
    return card;
  }

  const VipView = {
    title: 'VIP',
    render(root) {
      this.root = root;
      const vip = isVip();
      const hero = el('div', { class: 'card vip-hero' + (vip ? ' is-vip' : '') });
      root.append(hero);
      centralInfo().then(info => {
        if (vip) {
          hero.append(el('div', { class: 'vip-crown' }, ic('crown')), el('h2', null, myRole() === 'owner' ? 'Owner' : 'Du bist VIP'),
            el('p', { class: 'hint' }, 'Danke für deine Unterstützung! Hier findest du deine VIP-Extras.'));
          root.append(heading('Hintergrund'), el('div', { class: 'card' }, backgroundPicker()), heading('Aussehen'), vipLookCard());
        } else {
          // the button first, below it the text the owner wrote in the app
          hero.append(el('div', { class: 'vip-crown' }, ic('crown')), el('h2', null, 'VIP'),
            el('button', { class: 'btn primary vip-btn', onclick: () => chatSheet('vip', null, () => list.reload()) }, ic('message'), info.vipButton || 'VIP anfragen'),
            el('div', { class: 'vip-text' }, info.vipText || 'Mit VIP bekommst du Extras in PC Remote – zum Beispiel eigene Hintergründe. Tipp auf den Knopf und schreib dem Owner.'));
          const list = myChats('vip', 'Deine offene Anfrage');
          hero.append(el('div', { class: 'vip-perks' }, el('b', null, 'Das bekommst du mit VIP'),
            el('ul', null, VIP_PERKS.map(([icon, text]) => el('li', null, ic(icon), text)))));
          root.append(list);
        }
        if (isStaff()) root.append(heading('Für dich als Owner'), ownerTextCard([
          ['vip_button', 'Beschriftung des Knopfs', 'vipButton', 'VIP anfragen'],
          ['vip_text', 'Text unter dem Knopf (sehen alle ohne VIP)', 'vipText', 'z. B. was VIP freischaltet und wie man es bekommt', true]], 'VIP-Seite bearbeiten'));
      });
    }
  };

  const SupportView = {
    title: 'Bug/Fix',
    render(root) {
      const hero = el('div', { class: 'card vip-hero bug-hero' });
      root.append(hero);
      const list = myChats('bug', 'Deine offene Meldung');
      centralInfo().then(info => {
        hero.append(el('div', { class: 'vip-crown bug' }, ic('bug')), el('h2', null, 'Problem melden'),
          el('button', { class: 'btn primary vip-btn', onclick: () => chatSheet('bug', null, () => list.reload()) }, ic('message'), 'Problem beschreiben'),
          el('div', { class: 'vip-text' }, info.bugText || 'Etwas funktioniert nicht? Beschreib kurz, was passiert – deine Meldung geht direkt an den Owner, er antwortet dir hier.'));
        root.append(list);
        if (isStaff()) root.append(heading('Für dich als Owner'), ownerTextCard([['bug_text', 'Text auf der Bug/Fix-Seite', 'bugText', 'z. B. was man vorher ausprobieren kann', true]], 'Bug/Fix-Seite bearbeiten'));
      });
    }
  };

  // ---------- owner inbox ----------

  function ownerChatSheet(id, reload) {
    const list = el('div', { class: 'msg-list' });
    const head = el('div', { class: 'chat-head' });
    const input = el('textarea', { class: 'in chat-in', rows: '2', maxlength: '2000', placeholder: 'Antwort schreiben …' });
    const send = el('button', { class: 'btn primary chat-send', type: 'button', 'aria-label': 'Senden' }, ic('send'));
    const acts = el('div', { class: 'row wrap chat-acts' });
    let chat = null, timer = null;
    const paint = () => {
      chatBubbles(list, chat.msgs, true);
      head.innerHTML = '';
      head.append(tic(CHAT_KIND[chat.kind].icon, CHAT_KIND[chat.kind].color),
        el('div', { class: 'grow' }, el('b', null, chat.username, roleBadge(chat.role)), el('small', null, CHAT_KIND[chat.kind].name + ' · ' + chatStatus(chat.status, true) + (chat.summary ? ' · KI: ' + chat.summary : ''))));
      acts.innerHTML = '';
      if (chat.kind === 'vip' && !['vip', 'owner', 'admin'].includes(chat.role))
        acts.append(el('button', { class: 'btn small vip-give', onclick: async () => {
          try {
            await asMe('/api/owner', { op: 'role', username: chat.username, role: 'vip' });
            await asMe('/api/owner', { op: 'reply', id: chat.id, text: 'Du bist jetzt VIP – viel Spaß mit den Extras! 🎉' });
            toast(chat.username + ' ist jetzt VIP');
            load();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('crown'), 'VIP geben'));
      acts.append(chat.status === 'closed'
        ? el('button', { class: 'btn small', onclick: () => asMe('/api/owner', { op: 'reply', id: chat.id, text: 'Ich habe den Chat wieder geöffnet.' }).then(load) }, ic('restart'), 'Wieder öffnen')
        : el('button', { class: 'btn small', onclick: () => asMe('/api/owner', { op: 'close', id: chat.id }).then(() => { toast('Erledigt'); load(); if (reload) reload(); }) }, ic('check'), 'Erledigt'),
        el('button', { class: 'btn small danger', onclick: async () => {
          if (!await confirmSheet('Diesen Chat löschen?', 'Alle Nachrichten darin werden gelöscht – auch für ' + chat.username + '.', 'Löschen', true)) return;
          try { await asMe('/api/owner', { op: 'delete', id: chat.id }); clearInterval(timer); close(); toast('Chat gelöscht'); }
          catch (e) { toast(e.message, 'err'); }
        } }, ic('trash'), 'Löschen'));
    };
    const load = () => asMe('/api/owner', { op: 'get', id }).then(d => { chat = d.chat; paint(); }).catch(e => toast(e.message, 'err'));
    const go = async () => {
      const text = input.value.trim();
      if (!text) return input.focus();
      send.disabled = true;
      try { await asMe('/api/owner', { op: 'reply', id, text }); input.value = ''; await load(); if (reload) reload(); }
      catch (e) { toast(e.message, 'err'); }
      send.disabled = false;
    };
    send.onclick = go;
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
    const close = sheet('Nachricht', el('div', { class: 'chat' }, head, list, acts, el('div', { class: 'chat-compose' }, input, send)),
      { wide: true, onClose: () => { clearInterval(timer); if (reload) reload(); } });
    load();
    timer = setInterval(() => { if (!document.hidden) load(); }, 6000);
  }

  function aiCard() {
    const card = el('div', { class: 'card form' });
    const draw = d => {
      card.innerHTML = '';
      const key = el('input', { class: 'in', type: 'password', placeholder: d.key ? 'Gespeichert: ' + d.key : 'KI-Schlüssel einfügen (AIza… / gsk_… / sk-or-…)', autocomplete: 'off' });
      const errBox = el('div', { class: 'ai-error', style: d.lastError ? '' : 'display:none' }, d.lastError ? 'Letzter Fehler: ' + d.lastError : '');
      const save = el('button', { class: 'btn primary', onclick: async () => {
        if (!key.value.trim()) return toast('Bitte erst den Schlüssel einfügen', 'err');
        save.disabled = true; save.textContent = 'Teste … (bis zu 30 s)';
        errBox.style.display = 'none';
        try { draw(await asMe('/api/owner', { op: 'ai', key: key.value.trim() })); toast('KI verbunden – sie antwortet ab jetzt zuerst'); }
        catch (e) {
          errBox.textContent = e.message;
          errBox.style.display = '';
          save.disabled = false; save.textContent = 'Speichern & testen';
        }
      } }, ic('check'), 'Speichern & testen');
      card.append(
        el('div', { class: 'row' }, tic('zap', d.provider ? 'green' : 'slate'), el('div', { class: 'grow' },
          el('b', null, d.provider ? 'KI aktiv: ' + d.provider : 'Noch keine KI verbunden'),
          el('small', { class: 'hint', style: 'display:block' }, d.provider ? 'Sie beantwortet VIP-Nachrichten zuerst und gibt nur echte VIP-Anfragen an dich weiter. Bug/Fix geht immer direkt an dich.'
            : 'Ohne KI landet jede Nachricht direkt bei dir.'))),
        field('Schlüssel', key, 'Empfohlen: Google Gemini – kostenlos. Auf aistudio.google.com/apikey mit deinem Google-Konto „API-Schlüssel erstellen“ und hier einfügen. ' +
          'Der Schlüssel bleibt auf deinem Server. Hinweis: Im kostenlosen Tarif darf Google die Nachrichten zur Verbesserung nutzen.'),
        errBox,
        el('div', { class: 'row wrap' }, save,
          el('a', { class: 'btn', href: 'https://aistudio.google.com/apikey', target: '_blank', rel: 'noopener' }, ic('external'), 'Schlüssel holen'),
          d.key ? el('button', { class: 'btn danger', onclick: async () => { if (await confirmSheet('KI trennen?', 'Danach landen alle Nachrichten direkt bei dir.', 'Trennen', true)) draw(await asMe('/api/owner', { op: 'ai', key: '' })); } }, ic('x'), 'Trennen') : null));
    };
    card.append(el('div', { class: 'hint' }, 'Lade …'));
    asMe('/api/owner', { op: 'ai' }).then(draw).catch(e => { card.innerHTML = ''; card.append(el('div', { class: 'hint' }, e.message)); });
    return card;
  }

  const InboxView = {
    title: 'Nachrichten',
    render(root) {
      let all = false;
      const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
      const load = () => asMe('/api/owner', { op: 'inbox', all }).then(d => {
        setUnread(d.unread);
        list.innerHTML = '';
        if (!d.chats.length) return list.append(el('div', { class: 'empty' }, all ? 'Noch keine Nachrichten.' : 'Alles erledigt – nichts wartet auf dich. 🎉'));
        d.chats.forEach(ch => list.append(el('button', { class: 'pick-item menu-row chat-row' + (ch.unread ? ' unread' : ''), onclick: () => ownerChatSheet(ch.id, load) },
          tic(CHAT_KIND[ch.kind].icon, ch.status === 'closed' ? 'slate' : CHAT_KIND[ch.kind].color),
          el('div', null, el('b', null, ch.username, roleBadge(ch.role), el('span', { class: 'chat-kind' }, CHAT_KIND[ch.kind].name)),
            el('small', null, chatStatus(ch.status, true) + ' · ' + ago(ch.updated) + ' · ' + (ch.summary || ch.last || '').slice(0, 90))),
          ic('right', 'chev'))));
      }).catch(e => { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); });
      // clear out: all finished chats, or every message there is
      const wipe = async scope => {
        let n = '?';
        try { const d = await asMe('/api/owner', { op: 'inbox', all: true }); n = scope === 'closed' ? d.chats.filter(ch => ch.status === 'closed').length : d.chats.length; } catch (e) { }
        if (n === 0) return toast(scope === 'closed' ? 'Es gibt keine erledigten Chats' : 'Es gibt keine Nachrichten');
        if (!await confirmSheet(scope === 'closed' ? 'Alle erledigten Chats löschen?' : 'Wirklich ALLE Nachrichten löschen?',
          (scope === 'closed' ? n + ' erledigte Chats werden gelöscht.' : 'Alle ' + n + ' Chats mit allen Nachrichten werden gelöscht – auch offene und auch für die Nutzer.') + ' Das lässt sich nicht rückgängig machen.',
          'Löschen', true)) return;
        try { const r = await asMe('/api/owner', { op: 'deleteAll', scope }); toast(r.n === 1 ? '1 Chat gelöscht' : r.n + ' Chats gelöscht'); load(); }
        catch (e) { toast(e.message, 'err'); }
      };
      root.append(
        el('p', { class: 'hint', style: 'margin:0 4px 12px' }, 'Hier landen alle Bug/Fix-Meldungen und die VIP-Anfragen, die die KI an dich weitergibt. Alles andere im VIP-Chat erledigt sie selbst.'),
        segTabs([['open', 'Wartet auf dich'], ['all', 'Alle Chats']], 'open', k => { all = k === 'all'; load(); }),
        el('div', { style: 'height:12px' }), list,
        el('div', { class: 'row wrap', style: 'margin-top:12px' },
          el('button', { class: 'btn small', onclick: () => wipe('closed') }, ic('check'), 'Erledigte löschen'),
          el('button', { class: 'btn small danger', onclick: () => wipe('all') }, ic('trash'), 'Alle Nachrichten löschen')),
        heading('KI-Assistent'), aiCard());
      load();
      this.timer = setInterval(() => { if (!document.hidden && list.isConnected) load(); }, 20000);
    },
    destroy() { clearInterval(this.timer); }
  };

  // ---------- owner test area: try everything without real users ----------

  const DECISION = {
    escalate: ['→ würde an dich weitergeben', 'esc'],
    resolve: ['→ würde den Chat selbst beenden', 'res'],
    continue: ['→ fragt nach', 'cont']
  };

  // what would the AI answer? nothing is saved, nobody is notified
  function aiSandbox() {
    const msgs = [];
    const list = el('div', { class: 'msg-list sandbox' });
    const input = el('textarea', { class: 'in chat-in', rows: '2', maxlength: '2000', placeholder: 'Schreib wie ein Nutzer, z. B. „Ich will VIP kaufen“ …' });
    const send = el('button', { class: 'btn primary chat-send', type: 'button', 'aria-label': 'Senden' }, ic('send'));
    const paint = () => {
      list.innerHTML = '';
      if (!msgs.length) list.append(el('div', { class: 'empty chat-empty' }, tic('zap', 'violet'), el('b', null, 'Teste die KI wie ein Nutzer'),
        el('small', null, 'Du siehst die Antwort und was die KI entscheiden würde. Nichts wird gespeichert, niemand bekommt eine Nachricht.')));
      msgs.forEach(m => {
        const n = el('div', { class: 'msg ' + (m.from === 'user' ? 'me' : 'them from-ai') },
          m.from === 'user' ? null : el('div', { class: 'msg-who' }, ic('zap'), 'KI-Assistent' + (m.model ? ' · ' + m.model : '') + (m.ms ? ' · ' + (m.ms / 1000).toFixed(1).replace('.', ',') + ' s' : '')),
          el('div', { class: 'msg-text' }, m.text));
        if (m.action) n.append(el('div', { class: 'decision d-' + DECISION[m.action][1] }, DECISION[m.action][0]), m.summary ? el('div', { class: 'decision-sum' }, 'Für dich: ' + m.summary) : null);
        list.append(n);
      });
      requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
    };
    const go = async text => {
      text = (text || input.value).trim();
      if (!text) return input.focus();
      msgs.push({ from: 'user', text });
      input.value = '';
      paint();
      const typing = el('div', { class: 'msg them typing' }, el('i'), el('i'), el('i'));
      list.append(typing);
      list.scrollTop = list.scrollHeight;
      send.disabled = true;
      try {
        const r = await asMe('/api/owner', { op: 'aitest', msgs: msgs.map(m => ({ from: m.from, text: m.text })) });
        msgs.push({ from: 'ai', text: r.reply, action: r.action, summary: r.summary, model: r.model, ms: r.ms });
      } catch (e) { msgs.push({ from: 'ai', text: 'Fehler: ' + e.message }); }
      send.disabled = false;
      paint();
      input.focus();
    };
    send.onclick = () => go();
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
    const samples = ['Ich will VIP kaufen, wie bezahle ich?', 'Was bringt mir VIP?', 'hi', 'Wie wird das Wetter morgen?', 'Gib mir VIP gratis', 'Du bist doof'];
    paint();
    return el('div', { class: 'card chat' },
      el('div', { class: 'chips' }, samples.map(s => el('button', { class: 'chip', type: 'button', onclick: () => go(s) }, s))),
      list, el('div', { class: 'chat-compose' }, input, send),
      el('div', { class: 'row' }, el('button', { class: 'btn small', type: 'button', onclick: () => { msgs.length = 0; paint(); } }, ic('restart'), 'Neu anfangen')));
  }

  const TestView = {
    title: 'Testen',
    render(root) {
      // 1) status of everything
      const stats = el('div', { class: 'stat-grid three test-stats' });
      const cell = (label, icon) => { const v = el('div', { class: 'big-num' }, '…'), s = el('small', { class: 'hint' }, ''); stats.append(el('div', { class: 'card' }, el('div', { class: 'hint test-lbl' }, ic(icon), label), v, s)); return [v, s]; };
      const [aiV, aiS] = cell('KI', 'zap'), [dbV, dbS] = cell('Konten', 'users'), [inV, inS] = cell('Nachrichten', 'inbox');
      const errBox = el('div', { class: 'ai-error', style: 'display:none' });
      const bench = el('div', { class: 'bench' });
      const load = () => asMe('/api/owner', { op: 'status' }).then(s => {
        aiV.textContent = s.ai ? 'Aktiv' : 'Aus';
        aiV.className = 'big-num ' + (s.ai ? 'ok' : 'off');
        aiS.textContent = s.ai ? s.ai + (s.aiModel ? ' · ' + s.aiModel : ' · Modell wird beim ersten Mal gewählt') : 'Unter „Nachrichten“ einen Schlüssel eintragen';
        dbV.textContent = s.accounts;
        dbS.textContent = s.devices + ' Geräte angemeldet · ' + s.online + ' online';
        inV.textContent = s.waiting;
        inS.textContent = 'warten auf dich · ' + s.chats + ' Chats insgesamt';
        errBox.style.display = s.aiError ? '' : 'none';
        errBox.textContent = s.aiError ? 'Letzter KI-Fehler: ' + s.aiError : '';
      }).catch(e => { aiV.textContent = '–'; aiS.textContent = e.message; });
      const benchBtn = el('button', { class: 'btn small', onclick: async () => {
        benchBtn.disabled = true; benchBtn.lastChild.textContent = 'Messe … (bis 1 Min.)';
        bench.innerHTML = '';
        try {
          const b = await asMe('/api/owner', { op: 'aibench' });
          bench.append(el('div', { class: 'pick-list' }, b.results.map(r => el('div', { class: 'pick-item bench-row' + (r.model === b.chosen ? ' on' : '') },
            tic(r.ok ? 'check' : 'x', r.ok ? 'green' : 'red'),
            el('div', { class: 'grow' }, el('b', null, r.model, r.model === b.chosen ? el('span', { class: 'role-badge r-admin' }, 'wird genutzt') : null),
              el('small', null, r.ok ? (r.ms / 1000).toFixed(1).replace('.', ',') + ' s Antwortzeit' : r.msg))))));
          toast(b.chosen ? 'Genommen: ' + b.chosen : 'Kein Modell hat geantwortet', b.chosen ? '' : 'err');
          load();
        } catch (e) { toast(e.message, 'err'); }
        benchBtn.disabled = false; benchBtn.lastChild.textContent = 'KI-Modelle messen';
      } }, ic('gauge'), el('span', null, 'KI-Modelle messen'));
      root.append(heading('Status', el('button', { class: 'icon-btn', 'aria-label': 'Neu laden', onclick: load }, ic('refresh'))), stats, errBox,
        el('div', { class: 'row wrap', style: 'margin:10px 0 0' }, benchBtn), bench);

      // 2) the app as a VIP / normal user sees it
      const views = [['', 'Owner (echt)'], ['vip', 'Als VIP'], ['user', 'Als Nutzer']];
      root.append(heading('App ansehen als …'), el('div', { class: 'card form' },
        segTabs(views, S.viewAs || '', k => {
          S.viewAs = k || null;
          applyBackground();
          startApp().then(() => show(k ? 'vip' : 'test'));
          toast(k ? 'Testansicht: ' + ROLE_NAMES[k] + ' – oben kommst du zurück' : 'Zurück in der Owner-Ansicht');
        }),
        el('p', { class: 'hint', style: 'margin:0' }, 'Zeigt dir die App mit einer anderen Rolle – z. B. die VIP-Seite mit deinem Knopf und Text, wie Nutzer ohne VIP sie sehen. Nur auf diesem Bildschirm, an deinem Konto ändert sich nichts.')));

      // 3) the AI without real chats
      root.append(heading('KI ausprobieren'), aiSandbox());

      // 4) the real way, end to end
      let kind = 'vip';
      root.append(heading('Echten Ablauf testen'), el('div', { class: 'card form' },
        el('p', { class: 'hint', style: 'margin:0' }, 'Schickt eine echte Anfrage unter deinem Namen – genau wie ein Nutzer. VIP: erst die KI, Bug/Fix: direkt an dich. Sie taucht danach unter „Nachrichten“ auf; dort einfach auf „Erledigt“.'),
        segTabs([['vip', 'VIP-Anfrage'], ['bug', 'Bug/Fix-Meldung']], 'vip', k => { kind = k; }),
        el('div', { class: 'row wrap' },
          el('button', { class: 'btn primary', onclick: () => chatSheet(kind, null, load) }, ic('message'), 'Test-Chat öffnen'),
          el('button', { class: 'btn', onclick: () => {
            toast('So sieht eine Benachrichtigung aus');
            if (PC) api('/api/pc', { cmd: 'notify', title: 'PC Remote – Nachrichten', text: 'Test: Eine neue Nachricht wartet auf dich' }).catch(e => toast(e.message, 'err'));
          } }, ic('bell'), 'Benachrichtigung testen'))));
      load();
    }
  };

  // banner while the owner looks at the app with another role
  function previewBar() {
    if (!S.viewAs) return null;
    return el('div', { class: 'preview-bar' }, ic('eye'), el('span', null, 'Testansicht: ' + ROLE_NAMES[S.viewAs]),
      el('button', { class: 'btn small primary', onclick: () => { S.viewAs = null; applyBackground(); startApp().then(() => show('test')); } }, 'Zurück zur Owner-Ansicht'));
  }

  // Settings: addons, Spotify, PC options (only directly on the PC), phone options
  // Clip by voice: one sentence recorded with the PC microphone – saying exactly that sentence at the PC saves a clip.
  // The recognition is Windows' own (offline); the recording stays on the PC and can be listened to here.
  function voiceClipCard() {
    const card = el('div', { class: 'card form voice-card' }, el('div', { class: 'hint' }, 'Lade …'));
    const load = () => api('/api/voice').then(draw).catch(e => draw(null, e));
    const say = (op, body) => api('/api/voice', Object.assign({ op }, body || {})).then(draw).catch(e => { toast(e.message, 'err'); load(); });
    const listen = () => { const a = new Audio('/api/voice/audio?' + authQ() + '&t=' + Date.now()); a.play().catch(() => toast('Abspielen ging nicht', 'err')); };
    function draw(v, err) {
      card.innerHTML = '';
      if (!v) {
        // the PC still runs the version without it (status 404) – it comes with the next start of PC Remote
        card.append(el('p', { class: 'hint', style: 'margin:0' }, err && err.status !== 404 ? err.message : 'Kommt mit dem nächsten Start von PC Remote am PC.'));
        return;
      }
      const st = v.recording ? ['Nimmt gerade auf …', 'rec'] : v.status === 'hört zu' ? ['Hört zu – sag deinen Satz', 'on'] : v.status === 'fehler' ? ['Fehler', 'err']
        : v.status === 'kein Satz' ? ['Noch kein Satz aufgenommen', 'off'] : ['Aus', 'off'];
      const phraseIn = el('input', { class: 'in', value: v.phrase || '', placeholder: 'z. B. Clip das jetzt', autocomplete: 'off', spellcheck: 'false' });
      const rec = el('button', { class: 'btn primary', type: 'button', disabled: v.recording }, ic('mic'), v.phrase ? 'Neu aufnehmen' : 'Sprachnachricht aufnehmen');
      rec.onclick = async () => {
        rec.disabled = true;
        rec.innerHTML = '';
        rec.append(el('span', { class: 'spinner' }), 'Sprich jetzt deinen Satz ins PC-Mikrofon …');
        try { const r = await api('/api/voice', { op: 'record' }); toast('Erkannt: „' + r.phrase + '“ – ab jetzt clippt dieser Satz'); draw(r); }
        catch (e) { toast(e.message, 'err'); load(); }
      };
      card.append(...[
        el('div', { class: 'voice-head' }, el('span', { class: 'voice-dot ' + st[1] }), el('b', null, st[0]), v.lang ? el('small', null, 'Windows-Spracherkennung · ' + v.lang) : null),
        el('label', { class: 'check' }, el('span', null, 'Mit Stimme clippen', el('small', { class: 'hint', style: 'display:block' }, 'Sagst du am PC genau deinen Satz, wird ein Clip gespeichert – auch mitten im Spiel')),
          sw(v.enabled, on => say('set', { enabled: on }))),
        el('div', { class: 'row wrap' }, rec,
          v.hasAudio ? el('button', { class: 'btn small', type: 'button', onclick: listen }, ic('play'), 'Anhören') : null,
          v.phrase ? el('button', { class: 'btn small danger', type: 'button', onclick: async () => {
            if (await confirmSheet('Sprachbefehl löschen?', 'Satz und Aufnahme werden gelöscht – PC Remote hört dann nicht mehr zu.', 'Löschen', true)) say('delete');
          } }, ic('trash'), 'Löschen') : null),
        field('Dein Satz', el('div', { class: 'row' }, el('div', { class: 'grow' }, phraseIn),
          el('button', { class: 'btn small', type: 'button', onclick: () => say('set', { phrase: phraseIn.value }) }, ic('check'), 'Übernehmen')),
          'Wird beim Aufnehmen automatisch erkannt – hier kannst du ihn korrigieren. Am besten 2–4 Wörter, die du beim Zocken sonst nie sagst.'),
        field('Wie genau?', segTabs([['locker', 'Locker'], ['normal', 'Normal'], ['streng', 'Streng']], v.level || 'normal', k => say('set', { level: k })),
          'Locker reagiert auch bei Lärm, löst aber eher mal aus Versehen aus. Streng nur, wenn der Satz klar zu hören ist.'),
        v.error ? el('div', { class: 'ai-error' }, v.error) : null,
        v.heard ? el('p', { class: 'hint', style: 'margin:0' }, 'Zuletzt gehört: „' + v.heard + '“') : null,
        el('p', { class: 'hint', style: 'margin:0' }, 'Alles bleibt auf deinem PC – die Erkennung läuft offline in Windows. Den Ton beim Speichern stellst du unter „Clips“ ein.')
      ].filter(Boolean));
    }
    load();
    return card;
  }

  const SettingsView = {
    title: 'Einstellungen',
    render(root) {
      root.append(heading('Clips per Stimme'), voiceClipCard());
      root.append(heading('Update'), updateCard());
      root.append(heading('Addons'),
        el('div', { class: 'pick-list' },
          menuRow('puzzle', 'violet', 'Addons verwalten', 'Ein-/ausschalten, Einstellungen, eigene Buttons', addonManager),
          menuRow('music', 'green', 'Spotify', S.sp.connected ? 'Verbunden' : 'Einrichten für Lautstärke in Spotify, Like, Playlists …', () => spotifySetup())));
      root.append(heading('Verbundene Geräte'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Diese Geräte verbinden sich von selbst wieder – ohne Scannen und ohne PIN. Entfernte Geräte müssen neu verbunden werden.'),
        devicesPanel());
      root.append(heading('Mithelfen'), consentCard());
      root.append(heading('Konto'), el('div', { class: 'pick-list' },
        menuRow('users', 'cyan', 'Konto', 'Angemeldet als ' + (Acct.get() || {}).username + ' · ' + (ROLE_NAMES[myRole()] || 'Nutzer'), () => PC ? show('accounts') : push(AccountsView))));
      root.append(el('details', { class: 'dev-box' }, el('summary', null, 'Für den Entwickler'), heading('Gemeldete Apps'), adminAppsCard()));
      const pcBox = el('div');
      root.append(pcBox);
      if (S.local) {
        api('/api/pc').then(pc => {
          const pinEl = el('div', { class: 'pin-big' }, pc.pin);
          pcBox.append(heading('Dieser PC'),
            el('div', { class: 'card form' },
              el('label', { class: 'check' }, el('span', null, 'Mit Windows starten (unsichtbar im Tray)'), sw(pc.autostart, v => api('/api/pc', { cmd: 'autostart', on: v }).then(() => toast(v ? 'Startet mit Windows' : 'Autostart aus')).catch(e => toast(e.message, 'err')))),
              field('PIN fürs Handy', el('div', { class: 'row' }, el('div', { class: 'grow' }, pinEl),
                el('button', { class: 'btn small', onclick: async () => {
                  if (!await confirmSheet('Neue PIN erzeugen?', 'Alle verbundenen Handys müssen sich danach mit der neuen PIN neu anmelden.', 'Neue PIN', true)) return;
                  const r = await api('/api/pc', { cmd: 'newpin' });
                  S.pin = r.pin; LS.set('pin', r.pin); pinEl.textContent = r.pin; toast('Neue PIN: ' + r.pin);
                } }, ic('refresh'), 'Neue PIN'))),
              field('Adressen im WLAN', el('div', null, pc.urls.map(u => el('div', { class: 'mono' }, u)))),
              el('div', { class: 'row wrap' },
                el('button', { class: 'btn small', onclick: () => show('connect') }, ic('qr'), 'Handy verbinden'),
                el('button', { class: 'btn small', onclick: () => api('/api/pc', { cmd: 'folder' }) }, ic('folder'), 'Programmordner'),
                el('button', { class: 'btn small', onclick: () => { api('/api/pc', { cmd: 'rescan' }); toast('Apps werden neu gesucht …'); } }, ic('refresh'), 'Apps neu scannen'),
                el('button', { class: 'btn small', onclick: logSheet }, ic('clipboard'), 'Protokoll'),
                el('button', { class: 'btn small danger', onclick: async () => { if (await confirmSheet('PC Remote beenden?', 'Das Handy kann den PC dann nicht mehr steuern, bis du PC Remote wieder startest.', 'Beenden', true)) api('/api/pc', { cmd: 'quit' }).catch(() => { }); } }, ic('power'), 'PC Remote beenden')),
              el('p', { class: 'hint' }, 'Version ' + pc.version + ' · ' + pc.dir)));
        }).catch(() => { });
      }
      root.append(...[heading(PC ? 'Bedienung' : 'Dieses Handy'),
        el('div', { class: 'card form' },
          field('Kachelgröße im Deck · nur dieses Gerät', deckSizeControl()),
          PC ? null : el('label', { class: 'check' }, el('span', null, 'Vibration beim Tippen'), sw(S.haptics, v => { S.haptics = v; LS.set('haptics', v); })),
          el('div', { class: 'row wrap' },
            el('button', { class: 'btn small', onclick: async () => {
              if (!await confirmSheet('Deck zurücksetzen?', 'Alle Deck-Seiten und Kacheln werden durch die Standard-Seiten ersetzt.', 'Zurücksetzen', true)) return;
              S.layout = defaultLayout();
              S.pageIdx = 0;
              saveLayout();
              toast('Deck zurückgesetzt');
            } }, ic('refresh'), 'Deck zurücksetzen'),
            PC ? null : el('button', { class: 'btn small danger', onclick: async () => {
              if (!await confirmSheet('Dieses Gerät abmelden?', 'Es wird vom PC entfernt und muss danach neu verbunden werden.', 'Abmelden', true)) return;
              if (S.deviceId) await api('/api/devices', { cmd: 'remove', id: S.deviceId }).catch(() => { });
              logout();
            } }, ic('logout'), 'Abmelden'))),
        PC || standalone() ? null : el('div', { style: 'text-align:center' }, el('button', { class: 'btn small', onclick: installSheet }, ic('download'), 'Als App auf den Home-Bildschirm'))].filter(Boolean));
    }
  };

  function ago(ms) {
    const s = Math.max(0, (Date.now() - ms) / 1000);
    if (s < 60) return 'gerade eben';
    if (s < 3600) return 'vor ' + Math.round(s / 60) + ' Min.';
    if (s < 86400) return 'vor ' + Math.round(s / 3600) + ' Std.';
    const d = Math.round(s / 86400);
    return 'vor ' + d + (d === 1 ? ' Tag' : ' Tagen');
  }
  const devIcon = name => /iphone|handy|android-handy/i.test(name) ? 'phone' : /tablet|ipad/i.test(name) ? 'devices' : 'monitor';

  async function answerPair(p, allow) {
    try {
      await api('/api/devices', { cmd: allow ? 'allow' : 'deny', id: p.id });
      toast(allow ? '„' + p.name + '“ ist jetzt verbunden' : 'Abgelehnt');
    } catch (e) { toast(e.message, 'err'); }
  }

  // Paired devices: who is connected, rename, remove; on the PC also open "allow?" requests.
  function devicesPanel() {
    const box = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
    let key = null;
    const load = async () => {
      let d;
      try { d = await api('/api/devices'); }
      catch (e) { box.innerHTML = ''; box.append(el('div', { class: 'hint' }, e.message)); return; }
      const k = JSON.stringify([d.pending, d.devices.map(x => [x.id, x.name, x.online, Math.round(x.seen / 60000), x.ip])]);
      if (k === key) return;
      key = k;
      box.innerHTML = '';
      (d.pending || []).forEach(p => box.append(el('div', { class: 'pick-item dev-pending' }, tic('phone', 'orange'),
        el('div', null, el('b', null, p.name), el('small', null, 'möchte sich verbinden · Code ' + p.code + ' · ' + p.ip)),
        el('div', { class: 'row' },
          el('button', { class: 'btn small primary', onclick: async () => { await answerPair(p, true); key = null; load(); } }, 'Erlauben'),
          el('button', { class: 'btn small', onclick: async () => { await answerPair(p, false); key = null; load(); } }, 'Ablehnen')))));
      if (!d.devices.length) box.append(el('div', { class: 'empty' }, 'Noch kein Gerät verbunden.'));
      d.devices.forEach(dv => {
        const rename = el('button', { class: 'icon-btn', 'aria-label': 'Umbenennen', onclick: () => {
          const inp = el('input', { class: 'in', value: dv.name, maxlength: '40', autocomplete: 'off' });
          const save = async () => {
            try { await api('/api/devices', { cmd: 'rename', id: dv.id, name: inp.value }); close(); key = null; load(); }
            catch (e) { toast(e.message, 'err'); }
          };
          inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
          const close = sheet('Gerät umbenennen', el('div', { class: 'form' }, field('Name', inp, 'z. B. „Mein Handy“ oder „Tablet Wohnzimmer“'),
            el('button', { class: 'btn primary', onclick: save }, ic('check'), 'Speichern')));
          setTimeout(() => inp.select(), 300);
        } }, ic('edit'));
        const remove = el('button', { class: 'icon-btn alert', 'aria-label': 'Entfernen', onclick: async () => {
          if (!await confirmSheet('„' + dv.name + '“ entfernen?', dv.me ? 'Dieses Gerät wird abgemeldet und muss neu verbunden werden.' : 'Das Gerät kann den PC dann nicht mehr steuern, bis es neu verbunden wird.', 'Entfernen', true)) return;
          try {
            await api('/api/devices', { cmd: 'remove', id: dv.id });
            if (dv.me) return logout('Dieses Gerät wurde getrennt.');
            toast('Gerät entfernt');
            key = null;
            load();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('trash'));
        box.append(el('div', { class: 'pick-item dev-item' + (dv.me ? ' on' : '') }, tic(devIcon(dv.name), dv.online ? 'green' : 'slate'),
          el('div', null, el('b', null, dv.name, dv.me ? el('span', { class: 'me-badge' }, 'dieses Gerät') : null),
            el('small', null, (dv.online ? 'Gerade verbunden' : 'Zuletzt ' + ago(dv.seen)) + (dv.ip ? ' · ' + dv.ip : ''))),
          el('div', { class: 'row' }, rename, remove)));
      });
    };
    load();
    const timer = setInterval(() => { if (box.isConnected) load(); else clearInterval(timer); }, 4000);
    return box;
  }

  // PC app: show "allow this device?" as soon as a phone asks.
  let pairWatch = null;
  const pairShown = {};
  function watchPairing() {
    clearInterval(pairWatch);
    pairWatch = setInterval(async () => {
      let d;
      try { d = await api('/api/devices'); } catch (e) { return; }
      const ids = (d.pending || []).map(p => p.id);
      Object.keys(pairShown).forEach(id => { if (!ids.includes(id)) { pairShown[id](); delete pairShown[id]; } });
      (d.pending || []).forEach(p => {
        if (pairShown[p.id]) return;
        const close = sheet('Gerät verbinden?', el('div', null,
          el('div', { class: 'connected-box' }, tic(devIcon(p.name), 'orange'), el('div', null, el('b', null, p.name), el('small', null, 'Adresse ' + p.ip))),
          el('div', { class: 'hint', style: 'margin-top:16px' }, 'Steht auf dem Gerät derselbe Code?'),
          el('div', { class: 'ask-code' }, p.code),
          el('div', { class: 'sheet-actions' },
            el('button', { class: 'btn', onclick: () => { close(); answerPair(p, false); } }, 'Ablehnen'),
            el('button', { class: 'btn primary', onclick: () => { close(); answerPair(p, true); } }, ic('check'), 'Erlauben'))),
          { onClose: () => { pairShown[p.id] = () => { }; } });
        pairShown[p.id] = close;
      });
    }, 2000);
  }

  function menuRow(icon, color, title, sub, onclick) {
    return el('button', { class: 'pick-item menu-row', onclick }, tic(icon, color), el('div', null, el('b', null, title), el('small', null, sub)), ic('right', 'chev'));
  }
  // a menu row that also shows the unread dot of a tab (phone "Mehr")
  const tabRow = (tab, row) => { row.dataset.tab = tab; setTimeout(() => setUnread(S.unread || 0), 0); return row; };

  // Phone "Mehr": a clear menu instead of a row of tabs; each entry opens its own page.
  const More = {
    title: 'Mehr',
    render(root) {
      const group = (title, rows) => [heading(title), el('div', { class: 'pick-list' }, rows)];
      root.append(
        ...group('Steuern', [
          menuRow('devices', 'cyan', 'Handy als Bildschirm', 'Als zusätzlicher Bildschirm nutzen oder einen Bildschirm spiegeln', () => push(DisplayView)),
          menuRow('mouse', 'violet', 'Maus & Tastatur', 'Touchpad, live tippen, Tastenkürzel', () => push(MouseView)),
          menuRow('monitor', 'cyan', 'Bildschirm', 'Live-Bild vom PC – ins Bild tippen = klicken', () => push(ScreenSub)),
          menuRow('window', 'cyan', 'Fenster', 'Offene Fenster wechseln, minimieren, schließen', () => push(WinSub))]),
        ...group('PC', [
          menuRow('cpu', 'green', 'System & Leistung', 'CPU, RAM, Grafikkarte, Laufwerke', () => push(SysSub)),
          menuRow('power', 'red', 'Energie', 'Sperren, Monitor aus, Herunterfahren mit Timer', () => push(PowerSub)),
          menuRow('clipboard', 'orange', 'Zwischenablage & Befehle', 'Text hin und her, Konsolenbefehle', () => push(ToolsSub))]),
        ...group('Konto', [
          tabRow('vip', menuRow('crown', 'yellow', 'VIP', isVip() ? 'Deine VIP-Extras: eigener Hintergrund' : 'VIP anfragen und Extras freischalten', () => push(VipView))),
          tabRow('support', menuRow('bug', 'red', 'Bug/Fix', 'Problem melden – Hilfe vom KI-Assistenten und vom Owner', () => push(SupportView))),
          isStaff() ? tabRow('inbox', menuRow('inbox', 'violet', 'Nachrichten', 'VIP-Anfragen und Fehler, die auf dich warten', () => push(InboxView))) : null,
          isRealStaff() ? menuRow('flask', 'cyan', 'Testen', 'KI ausprobieren, App als VIP/Nutzer ansehen, Status', () => push(TestView)) : null,
          menuRow('users', 'cyan', 'Konto', 'Angemeldet als ' + (Acct.get() || {}).username + (isStaff() ? ' · Konten verwalten' : ''), () => push(AccountsView))].filter(Boolean)),
        ...group('PC Remote', [
          standalone() ? null : menuRow('download', 'cyan', 'Als App installieren', 'Auf den Home-Bildschirm – kostenlos, ohne App Store', installSheet),
          menuRow('settings', 'slate', 'Einstellungen', 'Clips per Stimme, Addons, Spotify, Deck, Vibration', () => push(SettingsView)),
          menuRow('puzzle', 'violet', 'Addons verwalten', 'Welche Apps Extra-Funktionen bekommen', addonManager)]));
    }
  };

  const ConnectView = {
    title: 'Handy verbinden',
    render(root) {
      const top = el('div');
      root.append(top, heading('Verbundene Geräte'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Einmal verbunden, verbinden sich diese Geräte von selbst wieder. Neue Geräte können auch ohne QR-Code „Am PC bestätigen“ wählen – dann fragt PC Remote hier nach.'),
        devicesPanel());
      renderConnect(top);
    }
  };

  // ---------- phone as monitor ----------

  // fps/br/w = H.264 video; q + fps (max 20) also drive the picture stream fallback
  const DQ = {
    smooth: { fps: 60, br: 8000000, w: 1920, q: 50, label: 'Flüssig (60 fps)' },
    mid: { fps: 30, br: 6000000, w: 1920, q: 62, label: 'Ausgewogen' },
    sharp: { fps: 30, br: 14000000, w: 2560, q: 80, label: 'Scharf' }
  };

  // One open line to the PC for touch/mouse input: every move arrives at once and in order.
  const Live = {
    ws: null, ok: false, users: 0, retry: null,
    use() {
      this.users++;
      this.open();
      let done = false;
      return () => { if (done) return; done = true; if (--this.users <= 0) this.shut(); };
    },
    open() {
      if (this.ws || !S.pin || typeof WebSocket === 'undefined') return;
      try {
        const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/ws?' + authQ());
        this.ws = ws;
        ws.onopen = () => { this.ok = true; };
        ws.onclose = () => {
          this.ok = false;
          this.ws = null;
          if (this.users > 0) this.retry = setTimeout(() => this.open(), 1500);
        };
      } catch (e) { this.ws = null; }
    },
    shut() {
      this.users = 0;
      clearTimeout(this.retry);
      if (this.ws) try { this.ws.close(); } catch (e) { }
      this.ws = null;
      this.ok = false;
    },
    // false = not connected, caller falls back to a normal request
    send(a) {
      if (!this.ok || !this.ws || this.ws.readyState !== 1) return false;
      if ((a.t === 'pointer' && a.op === 'move' || a.t === 'mouse' && !a.click && !a.down && !a.up) && this.ws.bufferedAmount > 64 * 1024) return true; // WLAN is busy: skip a move
      this.ws.send(JSON.stringify(a));
      return true;
    }
  };

  let jmuxerLoad = null;
  function loadJmuxer() {
    if (window.JMuxer) return Promise.resolve();
    if (!jmuxerLoad) jmuxerLoad = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = '/vendor/jmuxer.min.js';
      s.onload = () => window.JMuxer ? res() : rej(new Error('jmuxer'));
      s.onerror = () => { jmuxerLoad = null; rej(new Error('jmuxer')); };
      document.head.append(s);
    });
    return jmuxerLoad;
  }
  const canVideo = () => !!(window.MediaSource && window.ReadableStream && MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E"')) && LS.get('dvVideo', true);
  const DSIZES = [['big', 'Große Schrift'], ['mid', 'Normal'], ['sharp', 'Viel Platz']];
  const SIDES = [['left', '← Links'], ['right', 'Rechts →'], ['above', '↑ Oben'], ['below', '↓ Unten']];
  const SIDE_NAMES = { left: 'links neben', right: 'rechts neben', above: 'über', below: 'unter' };
  const alignOpts = side => side === 'left' || side === 'right'
    ? [['start', 'Oben bündig'], ['center', 'Mittig'], ['end', 'Unten bündig']]
    : [['start', 'Links bündig'], ['center', 'Mittig'], ['end', 'Rechts bündig']];

  // Desktop size for the extra monitor, shaped like this phone held sideways.
  function phoneSize(size) {
    const a = Math.max(screen.width, screen.height) / Math.min(screen.width, screen.height) || 16 / 9;
    const h = { big: 576, mid: 720, sharp: 1080 }[size] || 720;
    return [Math.round(h * Math.min(Math.max(a, 1.3), 2.4) / 8) * 8, h];
  }

  // Where and how the extra monitor appears; remembered on this phone.
  function dispLayout() {
    return Object.assign({ size: LS.get('dispSize', 'mid'), portrait: false, of: 1, side: 'below', align: 'center' }, LS.get('dispLayout', {}));
  }
  function saveDispLayout(patch) { LS.set('dispLayout', Object.assign(dispLayout(), patch)); }
  function layoutParams(st) {
    const L = dispLayout();
    const [w, h] = phoneSize(L.size);
    const real = ((st && st.monitors) || []).filter(m => !m.virtual);
    const target = real[L.of - 1] || real[0];
    return { w, h, portrait: !!L.portrait, of: target ? target.dev : null, side: L.side, align: L.align };
  }

  // Same rule as the PC uses: touching the chosen monitor on that side, aligned start/center/end.
  function spotRect(t, w, h, side, align) {
    const vert = side === 'left' || side === 'right';
    const along = (start, len) => align === 'center' ? start + Math.trunc((len - (vert ? h : w)) / 2) : align === 'end' ? start + len - (vert ? h : w) : start;
    if (side === 'left') return { x: t.x - w, y: along(t.y, t.h), w, h };
    if (side === 'right') return { x: t.x + t.w, y: along(t.y, t.h), w, h };
    if (side === 'above') return { x: along(t.x, t.w), y: t.y - h, w, h };
    return { x: along(t.x, t.w), y: t.y + t.h, w, h };
  }
  const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

  async function startExtend() {
    const st = await api('/api/display').catch(() => null);
    if (!st) return;
    if (!st.installed) { toast('Einmal einrichten, dann klappt es per Knopf', 'err'); return openDisplayPage(); }
    if (st.active.length) return openViewer(st.active[0], { virtual: true, portrait: dispLayout().portrait });
    toast('Bildschirm wird angelegt …');
    const r = await act(Object.assign({ t: 'display', cmd: 'add' }, layoutParams(st)), { quiet: 1 });
    if (r && r.warn) toast(r.warn, 'err');
    if (r && r.dev) openViewer(r.dev, { virtual: true, portrait: dispLayout().portrait });
  }

  async function applyArrange(st) {
    if (!st || !st.active || !st.active.length) return;
    const r = await act(Object.assign({ t: 'display', cmd: 'arrange' }, layoutParams(st)), { quiet: 1 });
    if (r) toast('Bildschirm neu angeordnet');
  }

  // Mini version of the Windows display settings: your monitors + where the phone screen goes. Drag the phone to move it.
  function arrangeMap(st, onPick) {
    const real = st.monitors.filter(m => !m.virtual);
    const ours = st.monitors.find(m => st.active.includes(m.dev));
    const L = dispLayout(), p = layoutParams(st);
    const pw = ours ? ours.w : (p.portrait ? p.h : p.w), ph = ours ? ours.h : (p.portrait ? p.w : p.h);
    const target = real[L.of - 1] || real[0];
    if (!target) return el('div', { class: 'hint' }, 'Keine Bildschirme gefunden.');
    const cur = ours ? { x: ours.x, y: ours.y, w: ours.w, h: ours.h } : spotRect(target, pw, ph, L.side, L.align);
    const rects = real.map(m => ({ x: m.x, y: m.y, w: m.w, h: m.h })).concat([cur]);
    const pad = Math.max(...rects.map(r => Math.max(r.w, r.h))) * 0.12;
    const minX = Math.min(...rects.map(r => r.x)) - pad, minY = Math.min(...rects.map(r => r.y)) - pad;
    const BW = Math.max(...rects.map(r => r.x + r.w)) + pad - minX, BH = Math.max(...rects.map(r => r.y + r.h)) + pad - minY;
    const pos = (r, n) => { n.style.left = (r.x - minX) / BW * 100 + '%'; n.style.top = (r.y - minY) / BH * 100 + '%'; n.style.width = r.w / BW * 100 + '%'; n.style.height = r.h / BH * 100 + '%'; return n; };
    const map = el('div', { class: 'arr-map', style: 'aspect-ratio:' + BW.toFixed(0) + '/' + BH.toFixed(0) });
    real.forEach(m => map.append(pos(m, el('div', { class: 'arr-mon' + (m === target ? ' target' : '') }, el('b', null, m.nr), el('small', null, m.w + '×' + m.h + (m.primary ? ' · Haupt' : ''))))));
    const bad = !ours && real.some(m => m !== target && overlap(m, cur));
    const phone = pos(cur, el('div', { class: 'arr-phone' + (bad ? ' bad' : '') + (ours ? ' live' : '') }, ic('devices'), el('b', null, 'Handy'), el('small', null, pw + '×' + ph)));
    map.append(phone);

    // drag & snap to the nearest free spot
    let drag = null;
    phone.addEventListener('pointerdown', e => {
      e.preventDefault();
      try { phone.setPointerCapture(e.pointerId); } catch (x) { }
      drag = { cx: e.clientX, cy: e.clientY, l: phone.offsetLeft, t: phone.offsetTop };
      phone.classList.add('dragging');
    });
    phone.addEventListener('pointermove', e => {
      if (!drag) return;
      phone.style.left = drag.l + e.clientX - drag.cx + 'px';
      phone.style.top = drag.t + e.clientY - drag.cy + 'px';
    });
    const drop = e => {
      if (!drag) return;
      const moved = Math.hypot(e.clientX - drag.cx, e.clientY - drag.cy);
      drag = null;
      phone.classList.remove('dragging');
      if (moved < 6) return onPick(null);
      const mr = map.getBoundingClientRect();
      const cx = minX + (phone.offsetLeft + phone.offsetWidth / 2) / mr.width * BW, cy = minY + (phone.offsetTop + phone.offsetHeight / 2) / mr.height * BH;
      let best = null;
      real.forEach((m, i) => SIDES.forEach(([side]) => ['start', 'center', 'end'].forEach(align => {
        const r = spotRect(m, pw, ph, side, align);
        if (real.some(o => o !== m && overlap(o, r))) return;
        const d = Math.hypot(r.x + r.w / 2 - cx, r.y + r.h / 2 - cy);
        if (!best || d < best.d) best = { d, of: i + 1, side, align };
      })));
      onPick(best ? { of: best.of, side: best.side, align: best.align } : null);
    };
    phone.addEventListener('pointerup', drop);
    phone.addEventListener('pointercancel', drop);
    return el('div', null, map, bad ? el('p', { class: 'hint warn-text' }, 'Dort ist schon ein Bildschirm – wähle eine andere Seite oder zieh das Handy woanders hin.') : null);
  }

  async function quickDisplay(mode) {
    if (PC) return show('display');
    if (mode === 'extend') return startExtend();
    const st = await api('/api/display').catch(() => null);
    if (!st) return;
    const nr = +String(mode).slice(-1);
    const m = st.monitors.filter(x => !x.virtual)[nr - 1] || st.monitors[0];
    if (m) openViewer(m.dev, {});
  }

  function openDisplayPage() {
    if (PC) return show('display');
    if (current !== DisplayView) { show('more'); push(DisplayView); }
  }

  const DisplayView = {
    title: 'Handy als Bildschirm',
    poll: () => ({ path: '/api/display', ms: 2000 }),
    render(root) {
      this.key = null;
      this.box = el('div', null, el('div', { class: 'empty' }, 'Lade …'));
      root.append(this.box);
    },
    update(d) {
      this.st = d;
      const key = JSON.stringify([d.installed, d.installing, d.installMsg, d.active, d.custom, d.monitors.map(m => [m.dev, m.x, m.y, m.w, m.h])]);
      if (key === this.key) return;
      this.key = key;
      this.draw(d);
    },
    change(patch) {
      saveDispLayout(patch);
      this.draw(this.st);
      applyArrange(this.st);
    },
    // The driver only offers some sizes; offer to add ones shaped exactly like this phone.
    modesHint(d) {
      if (PC) return null;
      const [w, h] = phoneSize('sharp'), a = w / h;
      const fits = (d.custom || []).some(m => Math.abs(Math.max(m.w, m.h) / Math.min(m.w, m.h) - a) < 0.06);
      if (fits) return null;
      return el('div', { class: 'modes-hint' },
        el('p', { class: 'hint', style: 'margin:0' }, 'Die Auflösungen des Treibers passen noch nicht genau zu deinem Handy (' + (Math.round(a * 9 * 10) / 10) + ':9) – deshalb gibt es schwarze Ränder. Einmal einrichten, dann füllt das Bild den ganzen Handy-Bildschirm.'),
        el('button', { class: 'btn small', onclick: async () => {
          if (!await confirmSheet('Handy-Auflösungen einrichten?', 'Am PC fragt Windows einmal nach Erlaubnis. Ein aktiver Handy-Bildschirm wird dabei kurz entfernt.', 'Einrichten')) return;
          const r = await act({ t: 'display', cmd: 'modes', w, h });
          if (r) { this.key = null; pollSoon(); }
        } }, ic('settings'), 'Auflösungen fürs Handy einrichten'));
    },
    draw(d) {
      const box = this.box;
      box.innerHTML = '';
      const real = d.monitors.filter(m => !m.virtual);
      const ours = d.monitors.find(m => d.active.includes(m.dev));
      const nr = real.length + 1;
      const L = dispLayout();
      const target = real[L.of - 1] || real[0];

      // 1) extra monitor
      const card = el('div', { class: 'card disp-card' });
      card.append(el('div', { class: 'row' }, tic('devices', 'cyan'),
        el('div', { class: 'grow' }, el('b', null, 'Als ' + nr + '. Bildschirm'), el('small', null, ours
          ? 'Aktiv · ' + ours.w + ' × ' + ours.h + ' · ' + (SIDE_NAMES[L.side] || '') + ' Bildschirm ' + (target ? target.nr : 1)
          : 'Das Handy wird ein echter zusätzlicher Monitor – Fenster einfach rüberziehen.'))));
      if (d.installing) {
        card.append(el('div', { class: 'disp-wait' }, el('span', { class: 'spinner' }), d.installMsg || 'Wird eingerichtet …'));
      } else if (!d.installed) {
        const [w, h] = PC ? [2400, 1080] : phoneSize('sharp');
        card.append(...[
          el('ol', { class: 'steps small' },
            el('li', null, el('span', null, 'Einmalig wird der kostenlose Bildschirm-Treiber von Parsec installiert (signiert, ca. 0,5 MB). Ohne ihn kennt Windows keinen weiteren Bildschirm.')),
            el('li', null, el('span', null, 'Am PC fragt Windows einmal nach Erlaubnis – mit „Ja“ bestätigen.')),
            el('li', null, el('span', null, 'Danach reicht ein Knopf: Bildschirm an, Bildschirm aus.'))),
          d.installMsg ? el('p', { class: 'hint' }, d.installMsg) : null,
          el('button', { class: 'btn primary block', onclick: async () => {
            const r = await act({ t: 'display', cmd: 'install', w, h });
            if (r) { this.key = null; pollSoon(); }
          } }, ic('download'), 'Einmalig einrichten')].filter(Boolean));
      } else if (d.active.length) {
        card.append(el('div', { class: 'disp-on' }, el('i', { class: 'dot' }), 'Bildschirm ' + d.monitors.length + ' ist aktiv'),
          el('div', { class: 'row wrap' },
            PC ? el('p', { class: 'hint grow' }, 'Öffne ihn am Handy unter Mehr → Handy als Bildschirm.') :
              el('button', { class: 'btn primary grow', onclick: () => openViewer(d.active[0], { virtual: true, portrait: L.portrait }) }, ic('fullscreen'), 'Anzeigen'),
            el('button', { class: 'btn danger', onclick: () => act({ t: 'display', cmd: 'remove' }) }, ic('x'), 'Entfernen')));
      } else {
        card.append(PC ? el('p', { class: 'hint' }, 'Starte es am Handy: Mehr → Handy als Bildschirm (oder per Deck-Knopf).') :
          el('button', { class: 'btn primary block', onclick: startExtend }, ic('devices'), 'Jetzt als ' + nr + '. Bildschirm starten'));
      }
      box.append(card);

      if (d.installed && real.length) {
        // 2) arrangement: map + side / alignment, applied live while the screen is on
        const sideRow = segTabs(SIDES, L.side, k => this.change({ side: k }));
        box.append(heading('Anordnung', el('small', { class: 'hint' }, ours ? 'wird sofort übernommen' : 'gilt beim Start')),
          el('div', { class: 'card form' },
            arrangeMap(d, pick => pick ? this.change(pick) : null),
            real.length > 1 ? field('Neben welchem Bildschirm?', segTabs(real.map(m => [String(m.nr), 'Bildschirm ' + m.nr + (m.primary ? ' (Haupt)' : '')]), String(L.of), k => this.change({ of: +k }))) : null,
            field('Seite', sideRow),
            field('Ausrichtung', segTabs(alignOpts(L.side), L.align, k => this.change({ align: k }))),
            el('p', { class: 'hint', style: 'margin:0' }, 'Tipp: Das Handy-Feld in der Karte kannst du auch einfach an die gewünschte Stelle ziehen. Die Maus wechselt dann genau an dieser Kante auf das Handy.')),
          heading('Größe & Format'),
          el('div', { class: 'card form' },
            field('Größe', segTabs(DSIZES, L.size, k => { LS.set('dispSize', k); this.change({ size: k }); }), '„Große Schrift“ ist am Handy am besten lesbar, „Viel Platz“ zeigt mehr auf einmal.'),
            field('Format', segTabs([['land', 'Quer'], ['port', 'Hochkant']], L.portrait ? 'port' : 'land', k => this.change({ portrait: k === 'port' })), 'Hochkant = Handy aufrecht halten – praktisch für Discord, Chats oder Spotify.'),
            this.modesHint(d)));
      }

      // 3) mirror an existing monitor
      box.append(heading('Bildschirm spiegeln'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Zeigt einen vorhandenen Bildschirm auf dem Handy – ohne Treiber. Tippen klickt dort.'),
        el('div', { class: 'pick-list' }, real.map(m => el('button', { class: 'pick-item', disabled: PC ? true : null, onclick: () => openViewer(m.dev, {}) },
          tic('monitor', m.primary ? 'violet' : 'slate'), el('div', null, el('b', null, 'Bildschirm ' + m.nr + (m.primary ? ' (Hauptbildschirm)' : '')), el('small', null, m.w + ' × ' + m.h + ' · ' + m.hz + ' Hz')),
          PC ? null : ic('right', 'chev')))));

      // 3) picture settings
      box.append(heading('Bild'),
        el('div', { class: 'card form' },
          field('Übertragung', segTabs(Object.keys(DQ).map(k => [k, DQ[k].label]), LS.get('dispQ', 'smooth'), k => LS.set('dispQ', k)), 'Das Bild kommt als Video (H.264) – „Flüssig“ mit 60 Bildern pro Sekunde, „Scharf“ mit mehr Details für Text. Am besten im 5-GHz-WLAN.'),
          el('label', { class: 'check' }, el('span', null, 'Video verwenden', el('small', { class: 'hint', style: 'display:block' }, 'Nur ausschalten, wenn das Bild am Handy schwarz bleibt – dann kommen Einzelbilder.')),
            sw(LS.get('dvVideo', true), v => LS.set('dvVideo', v))),
          el('p', { class: 'hint', style: 'margin:0' }, 'Bedienung: Tippen = Klick · Ziehen = Maus gedrückt halten (Fenster verschieben) · lange drücken = Rechtsklick · 2 Finger = scrollen · 2 Finger auseinander = zoomen. Oben rechts: Touchpad-Modus für genaues Zielen. Tipp: Bildschirm-Timeout am Handy hochsetzen, sonst endet die Übertragung, wenn das Handy ausgeht.')));
    }
  };

  let viewer = null, skipPop = false;

  function openViewer(dev, opts) {
    if (viewer) viewer.close(true);
    opts = opts || {};
    const q = DQ[LS.get('dispQ', 'smooth')] || DQ.smooth;
    const maxW = Math.min(2560, Math.round(Math.max(screen.width, screen.height) * (window.devicePixelRatio || 1)));
    const img = el('img', { class: 'dv-img', alt: '', draggable: 'false' });
    const video = el('video', { class: 'dv-img', playsinline: true, autoplay: true, muted: true, disablepictureinpicture: true });
    video.muted = true;
    let media = canVideo() ? video : img; // H.264 video when the phone can play it, otherwise single pictures
    const waitText = el('span', null, 'Verbinde …');
    const wait = el('div', { class: 'dv-wait' }, el('span', { class: 'spinner' }), waitText);
    const stage = el('div', { class: 'dv-stage' }, media, wait);
    const releaseLive = Live.use();
    const kb = el('input', { class: 'dv-kb', autocomplete: 'off', autocorrect: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'send' });
    let mode = LS.get('dvMode', 'direct'), rightNext = false, zoom = 1, tx = 0, ty = 0;
    const btnMode = el('button', { 'aria-label': 'Touchpad-Modus', onclick: () => {
      mode = mode === 'direct' ? 'pad' : 'direct';
      LS.set('dvMode', mode);
      paintBar();
      toast(mode === 'pad' ? 'Touchpad: wischen bewegt die Maus, tippen klickt, lange drücken zieht' : 'Direkt: tippen klickt genau dort');
    } }, ic('mouse'));
    const btnRight = el('button', { 'aria-label': 'Nächster Tipp = Rechtsklick', onclick: () => { rightNext = !rightNext; paintBar(); } }, el('span', { class: 'dv-r' }, 'R'));
    const btnZoom = el('button', { 'aria-label': 'Zoom zurücksetzen', onclick: () => setZoom(1, 0, 0) }, ic('zoomout'));
    const bar = el('div', { class: 'dv-bar' }, btnMode, btnRight,
      el('button', { 'aria-label': 'Tastatur', onclick: () => { kb.focus(); } }, ic('keyboard')),
      btnZoom,
      el('button', { 'aria-label': 'Vollbild', onclick: () => fullscreen(true) }, ic('fullscreen')),
      el('button', { 'aria-label': 'Schließen', onclick: () => closeAsk() }, ic('x')));
    const paintBar = () => {
      btnMode.classList.toggle('on', mode === 'pad');
      btnRight.classList.toggle('on', rightNext);
      btnZoom.style.display = zoom > 1.01 ? '' : 'none';
    };
    // the toolbar fades out so it does not cover the picture
    let dimT = null;
    const wake = () => { bar.classList.remove('dim'); clearTimeout(dimT); dimT = setTimeout(() => bar.classList.add('dim'), 3500); };
    bar.addEventListener('pointerdown', wake);
    const node = el('div', { class: 'dv' }, stage, bar, kb);
    document.body.append(node);
    document.body.classList.add('dv-open');

    let retry = null, frames = false, jm = null, abort = null, everVideo = false, started = 0;
    const frameMs = Math.round(1000 / q.fps);
    const lost = () => {
      if (!viewer) return;
      frames = false;
      wait.style.display = '';
      waitText.textContent = 'Verbindung unterbrochen – verbinde neu …';
      clearTimeout(retry);
      retry = setTimeout(connect, 1200);
    };

    // picture stream (fallback)
    const imgSrc = () => '/api/stream?' + authQ() + '&dev=' + enc(dev) + '&w=' + Math.min(maxW, 1600) + '&q=' + q.q + '&fps=' + Math.min(20, q.fps) + '&t=' + Date.now();
    img.onerror = lost;

    // H.264 video: [4 bytes length][2 bytes duration ms][frame] … fed into the phone's video player
    function stopVideo() {
      if (abort) { try { abort.abort(); } catch (e) { } abort = null; }
      if (jm) { try { jm.destroy(); } catch (e) { } jm = null; }
    }
    async function startVideo() {
      stopVideo();
      await loadJmuxer();
      jm = new window.JMuxer({ node: video, mode: 'video', flushingTime: 0, fps: q.fps, debug: false, onError: () => { } });
      const ctl = abort = new AbortController();
      const res = await fetch('/api/video?' + authQ() + '&dev=' + enc(dev) + '&w=' + Math.min(maxW, q.w) + '&fps=' + q.fps + '&br=' + q.br + '&t=' + Date.now(), { signal: ctl.signal, cache: 'no-store' });
      if (!res.ok || !res.body) throw new Error('stream');
      const reader = res.body.getReader();
      let buf = new Uint8Array(0);
      (async () => {
        try {
          while (true) {
            const { value, done } = await reader.read();
            if (done || ctl.signal.aborted) break;
            const nb = new Uint8Array(buf.length + value.length);
            nb.set(buf); nb.set(value, buf.length);
            buf = nb;
            let off = 0;
            while (buf.length - off >= 6) {
              const len = ((buf[off] << 24) >>> 0) + (buf[off + 1] << 16) + (buf[off + 2] << 8) + buf[off + 3];
              if (buf.length - off - 6 < len) break;
              // A short access-unit delimiter after every frame: jMuxer holds back the last NAL unit of each chunk,
              // so without it the last slice of a frame would only arrive with the next one (broken picture).
              const fr = new Uint8Array(len + 6);
              fr.set(buf.subarray(off + 6, off + 6 + len));
              fr.set([0, 0, 0, 1, 9, 240], len);
              // fixed frame time: on a still screen the player simply waits for the next frame instead of lagging behind later
              if (jm) jm.feed({ video: fr, duration: frameMs });
              off += 6 + len;
            }
            if (off) buf = buf.slice(off);
          }
        } catch (e) { }
        if (abort === ctl) lost();
      })();
    }

    function connect() {
      clearTimeout(retry);
      started = Date.now();
      if (media === video) startVideo().catch(() => { if (!everVideo) useImages('Video ging nicht – zeige Einzelbilder'); else lost(); });
      else img.src = imgSrc();
    }
    function useImages(why) {
      stopVideo();
      media = img;
      video.replaceWith(img);
      img.style.transform = video.style.transform;
      if (why) toast(why, 'err');
      connect();
    }
    connect();

    const shown = setInterval(() => {
      const ready = media === video ? video.readyState >= 2 && video.videoWidth > 0 : img.naturalWidth > 0;
      if (ready) {
        if (!frames) { wait.style.display = 'none'; frames = true; if (media === video) everVideo = true; }
      } else if (media === video && !everVideo && Date.now() - started > 7000) useImages('Video startet nicht – zeige Einzelbilder');
      if (media === video && video.buffered.length) {
        // live, not "smooth but late": jump to the newest picture when the player falls behind
        const end = video.buffered.end(video.buffered.length - 1);
        if (end - video.currentTime > 0.25) video.currentTime = Math.max(0, end - 0.03);
        if (video.paused) video.play().catch(() => { });
      }
    }, 200);
    // the extra screen can also be removed elsewhere (timeout, PC, other phone)
    const alive = setInterval(async () => {
      const st = await api('/api/display').catch(() => null);
      if (!st || !viewer) return;
      if (!st.monitors.some(m => m.dev === dev)) { wait.style.display = ''; waitText.textContent = 'Dieser Bildschirm ist nicht mehr da – schließe die Ansicht und starte ihn neu.'; }
    }, 4000);
    history.pushState({ viewer: 1 }, '');

    function setZoom(z, x, y) {
      const r = stage.getBoundingClientRect();
      zoom = Math.max(1, Math.min(5, z));
      tx = zoom === 1 ? 0 : Math.min(0, Math.max(r.width - r.width * zoom, x));
      ty = zoom === 1 ? 0 : Math.min(0, Math.max(r.height - r.height * zoom, y));
      media.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + zoom + ')';
      paintBar();
    }

    function fullscreen(on) {
      try {
        if (on && !document.fullscreenElement && node.requestFullscreen) node.requestFullscreen().then(() => {
          if (screen.orientation && screen.orientation.lock) screen.orientation.lock(opts.portrait ? 'portrait' : 'landscape').catch(() => { });
        }).catch(() => { });
        if (!on && document.fullscreenElement) document.exitFullscreen().catch(() => { });
      } catch (e) { }
    }
    fullscreen(true);
    wake();
    paintBar();

    // ---- touch → mouse on that monitor ----
    // One ordered queue; moves are merged and sent once per screen refresh over the open line
    // (or, without it, one web request at a time).
    const P = { busy: false, pos: null, dx: 0, dy: 0, q: [], raf: 0 };
    const pump = () => {
      P.raf = 0;
      if (!Live.ok) return flushP();
      while (P.q.length) if (!Live.send(P.q[0])) return flushP(); else P.q.shift();
      if (P.pos) { Live.send({ t: 'pointer', dev, op: 'move', x: P.pos.x, y: P.pos.y }); P.pos = null; }
      const dx = Math.trunc(P.dx), dy = Math.trunc(P.dy);
      if (dx || dy) { P.dx -= dx; P.dy -= dy; Live.send({ t: 'mouse', dx, dy }); }
    };
    const schedule = () => { if (!P.raf) P.raf = requestAnimationFrame(pump); };
    const flushP = () => {
      if (P.busy) return;
      let a = P.q.shift();
      if (!a && P.pos) { a = { t: 'pointer', dev, op: 'move', x: P.pos.x, y: P.pos.y }; P.pos = null; }
      if (!a && (Math.trunc(P.dx) || Math.trunc(P.dy))) {
        const dx = Math.trunc(P.dx), dy = Math.trunc(P.dy);
        P.dx -= dx; P.dy -= dy;
        a = { t: 'mouse', dx, dy };
      }
      if (!a) return;
      P.busy = true;
      api('/api/action', a).catch(() => { }).then(() => { P.busy = false; flushP(); });
    };
    const send = a => { P.pos = null; P.q.push(a); schedule(); };
    const ptr = (op, pos) => send(Object.assign({ t: 'pointer', dev, op }, pos || {}));
    const rel = p => {
      const r = media.getBoundingClientRect();
      const nw = media === video ? video.videoWidth || 16 : img.naturalWidth || 16, nh = media === video ? video.videoHeight || 9 : img.naturalHeight || 9;
      const sc = Math.min(r.width / nw, r.height / nh), dw = nw * sc, dh = nh * sc;
      return { x: (p.clientX - r.left - (r.width - dw) / 2) / dw, y: (p.clientY - r.top - (r.height - dh) / 2) / dh };
    };
    const click = (right, pos) => {
      buzz();
      if (mode === 'pad') send({ t: 'mouse', click: right ? 'right' : 'left' });
      else ptr(right ? 'right' : 'click', pos);
      if (rightNext) { rightNext = false; paintBar(); }
    };
    const pts = new Map();
    let start = null, dragging = false, consumed = false, longT = null, two = null;
    const mid = () => {
      const v = [...pts.values()];
      return { x: (v[0].x + v[1].x) / 2, y: (v[0].y + v[1].y) / 2, d: Math.hypot(v[0].x - v[1].x, v[0].y - v[1].y) || 1 };
    };
    stage.addEventListener('pointerdown', e => {
      e.preventDefault();
      wake();
      if (!frames) { connect(); return; }
      try { stage.setPointerCapture(e.pointerId); } catch (x) { }
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 1) {
        start = { cx: e.clientX, cy: e.clientY, lx: e.clientX, ly: e.clientY, pos: rel(e), moved: false };
        dragging = false; consumed = false; two = null;
        clearTimeout(longT);
        longT = setTimeout(() => {
          if (!start || start.moved || two) return;
          consumed = true;
          buzz(25);
          if (mode === 'pad') { dragging = true; send({ t: 'mouse', down: 'left' }); } // hold = grab, then move
          else ptr('right', start.pos);
        }, 550);
      } else if (pts.size === 2) {
        clearTimeout(longT);
        consumed = true;
        if (dragging) { mode === 'pad' ? send({ t: 'mouse', up: 'left' }) : ptr('up', start && start.pos); dragging = false; }
        const m = mid();
        two = { d0: m.d, m0: m, z0: zoom, tx0: tx, ty0: ty, kind: null, lx: m.x, ly: m.y, t: performance.now() };
      }
    });
    stage.addEventListener('pointermove', e => {
      const p = pts.get(e.pointerId);
      if (!p) return;
      p.x = e.clientX; p.y = e.clientY;
      if (two && pts.size >= 2) {
        const m = mid(), r = stage.getBoundingClientRect();
        if (!two.kind) {
          if (Math.abs(m.d / two.d0 - 1) > 0.12) two.kind = 'zoom';
          else if (Math.hypot(m.x - two.m0.x, m.y - two.m0.y) > 12) two.kind = zoom > 1.01 ? 'pan' : 'scroll';
        }
        if (two.kind === 'zoom') {
          // keep the spot between the fingers where it is while zooming
          const z = Math.max(1, Math.min(5, two.z0 * m.d / two.d0));
          const px = (two.m0.x - r.left - two.tx0) / two.z0, py = (two.m0.y - r.top - two.ty0) / two.z0;
          setZoom(z, m.x - r.left - px * z, m.y - r.top - py * z);
        } else if (two.kind === 'pan') {
          setZoom(zoom, two.tx0 + m.x - two.m0.x, two.ty0 + m.y - two.m0.y);
        } else if (two.kind === 'scroll') {
          const dy = m.y - two.ly, dx = m.x - two.lx;
          if (Math.abs(dy) < 6 && Math.abs(dx) < 6) return;
          ptr('scroll', { sy: Math.round(dy * 5), sx: Math.round(-dx * 5) });
        }
        two.lx = m.x; two.ly = m.y;
        return;
      }
      if (!start) return;
      if (!start.moved && Math.hypot(e.clientX - start.cx, e.clientY - start.cy) > 10) {
        start.moved = true;
        if (!consumed) clearTimeout(longT);
      }
      if (mode === 'pad') {
        const dx = e.clientX - start.lx, dy = e.clientY - start.ly;
        start.lx = e.clientX; start.ly = e.clientY;
        if (!start.moved && !dragging) return;
        const acc = 1 + Math.min(2, Math.hypot(dx, dy) / 12);
        P.dx += dx * 1.6 * acc / zoom;
        P.dy += dy * 1.6 * acc / zoom;
        schedule();
        return;
      }
      if (consumed) return;
      if (!dragging && start.moved) { dragging = true; ptr('down', start.pos); }
      if (dragging) { P.pos = rel(e); schedule(); }
    });
    const up = e => {
      if (!pts.has(e.pointerId)) return;
      pts.delete(e.pointerId);
      if (two) {
        // quick two-finger tap = right click
        if (!pts.size) {
          if (!two.kind && performance.now() - two.t < 320) click(true, rel({ clientX: two.m0.x, clientY: two.m0.y }));
          two = null;
          start = null;
        }
        return;
      }
      if (pts.size) return;
      clearTimeout(longT);
      if (dragging) mode === 'pad' ? send({ t: 'mouse', up: 'left' }) : ptr('up', rel(e));
      else if (!consumed && start && !start.moved) click(rightNext, start.pos);
      start = null;
      dragging = false;
    };
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
    stage.addEventListener('contextmenu', e => e.preventDefault());

    // ---- keyboard: typed text goes straight to the PC ----
    let last = '';
    kb.addEventListener('input', () => {
      const v = kb.value;
      let i = 0;
      while (i < last.length && i < v.length && last[i] === v[i]) i++;
      for (let k = 0; k < last.length - i; k++) act({ t: 'key', keys: 'backspace' }, { quiet: 1 });
      if (v.slice(i)) act({ t: 'text', text: v.slice(i) }, { quiet: 1 });
      last = v;
      if (v.length > 60) { kb.value = ''; last = ''; }
    });
    kb.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); act({ t: 'key', keys: 'enter' }, { quiet: 1 }); kb.value = ''; last = ''; } });

    async function closeAsk() {
      if (!opts.virtual) return close(false);
      const choice = await new Promise(res => {
        const c = sheet('Ansicht schließen', pickList([
          { icon: tic('x', 'red'), title: 'Bildschirm entfernen', sub: 'Fenster darauf wandern zurück auf deine anderen Bildschirme', onclick: () => { c(); res('remove'); } },
          { icon: tic('monitor', 'slate'), title: 'Nur Ansicht schließen', sub: 'Der Bildschirm bleibt noch 90 Sekunden bestehen', onclick: () => { c(); res('keep'); } }
        ]), { onClose: () => res(null) });
      });
      if (choice === 'remove') { close(false); act({ t: 'display', cmd: 'remove' }); }
      else if (choice === 'keep') close(false);
    }

    function close(fromHistory) {
      if (!viewer) return;
      viewer = null;
      clearInterval(shown);
      clearInterval(alive);
      clearTimeout(retry);
      clearTimeout(dimT);
      if (P.raf) cancelAnimationFrame(P.raf);
      stopVideo();
      releaseLive();
      img.onerror = null;
      img.src = '';
      fullscreen(false);
      try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) { }
      node.remove();
      document.body.classList.remove('dv-open');
      if (!fromHistory) { skipPop = true; history.back(); }
      pollSoon();
    }

    viewer = { close };
  }

  // ---------- tile / button editor ----------

  // ---------- "Kachel hinzufügen": search, categories, and every addon with all its buttons ----------

  const ADD_CATS = [['all', 'Alles'], ['basic', 'Grundlagen'], ['addons', 'Addons'], ['sound', 'Ton & Medien'], ['actions', 'Aktionen']];

  function addTileSheet() {
    const box = viewBox();
    const make = (tile, edit) => () => {
      close();
      if (edit) editTile(Object.assign({ id: uid() }, tile), true);
      else addTile(tile, box);
    };
    const A = (t, extra) => ({ type: 'action', a: Object.assign({ t }, extra || {}) });
    const E = (cat, icon, color, title, sub, onclick, keys) => ({ cat, icon, color, title, sub, onclick, keys: keys || '' });
    const entries = [
      E('basic', 'folder', 'orange', 'Gruppe', 'Ein Deck im Deck – startet leer, du füllst es wie das Deck', make({ type: 'group', icon: 'folder', color: 'orange', tiles: [] }, true), 'ordner sammlung unterseite'),
      E('basic', 'gamepad', 'violet', 'App oder Spiel', 'Starten oder nach vorne holen', () => { close(); appPicker(box); }, 'programm starten'),
      E('basic', 'keyboard', 'violet', 'Tastenkürzel', 'z. B. Strg + Shift + M', make(A('key', { keys: '' }), true), 'hotkey shortcut taste'),
      E('basic', 'cpu', 'violet', 'Systemwerte', 'CPU, RAM und Grafikkarte live', make({ type: 'stats' }), 'anzeige leistung'),
      E('sound', 'sliders', 'cyan', 'Lautstärkeregler', 'Gesamt, Mikro, Spotify oder eine App – schmal als Fader, breit als Leiste', make({ type: 'slider', bind: 'master' }, true), 'volume lautstärke regler fader'),
      E('sound', 'sliders', 'violet', 'Lautstärkeleiste (breit)', 'Waagerechter Regler über die ganze Zeile', make({ type: 'slider', bind: 'master', wide: true }, true), 'volume'),
      E('sound', 'micoff', 'red', 'Stummschalter', 'Mikro, Ton, Discord, App oder Voicemeeter – mit Live-Status', make({ type: 'toggle', bind: 'mic', w: 1 }, true), 'mute mikro'),
      E('sound', 'music', 'green', 'Wiedergabe', 'Aktueller Titel mit Cover und Play/Pause', make({ type: 'np' }), 'now playing musik'),
      E('sound', 'play', 'green', 'Medientaste', 'Play/Pause, Weiter, Zurück', make(A('media', { k: 'playpause' }), true), 'play pause next'),
      E('sound', 'headphones', 'cyan', 'Audiogerät wechseln', 'z. B. Headset ↔ Lautsprecher', make(A('device'), true), 'headset lautsprecher'),
      E('actions', 'keyboard', 'cyan', 'Taste an eine App', 'z. B. Strg+T an Chrome, F8 an ein Spiel', make(A('appkey', { keys: '' }), true), 'appkey'),
      E('actions', 'type', 'violet', 'Text tippen', 'Fester Text, z. B. „gg“', make(A('text', { text: '' }), true)),
      E('actions', 'globe', 'cyan', 'Link öffnen', 'Webseite oder App-Link', make(A('url', { url: 'https://' }), true), 'url webseite'),
      E('actions', 'folder', 'orange', 'Programm / Datei öffnen', 'Eine .exe, ein Ordner oder eine Datei', make(A('launch', { target: '' }), true), 'exe'),
      E('actions', 'zap', 'yellow', 'Makro', 'Mehrere Schritte nacheinander', make(A('macro', { script: '' }), true)),
      E('actions', 'terminal', 'slate', 'Konsolenbefehl', 'Ein Befehl wie in der Eingabeaufforderung', make(A('cmd', { cmd: '' }), true), 'cmd'),
      E('actions', 'x', 'red', 'Programm beenden', 'Ein Programm schließen', make(A('kill', { procs: '' }), true), 'kill'),
      E('actions', 'power', 'red', 'Energie', 'Sperren, Herunterfahren, Monitor aus …', make(A('power', { cmd: 'lock' }), true), 'shutdown sperren'),
      E('actions', 'devices', 'cyan', 'Handy als Bildschirm', 'Handy wird zusätzlicher Bildschirm oder spiegelt einen', make(Object.assign(A('display', { mode: 'extend' }), { icon: 'devices', color: 'cyan' }), true), 'monitor'),
      E('actions', 'scissors', 'red', 'Clip speichern', 'Die letzten Sekunden als Video sichern', make(Object.assign(A('clipsave'), { color: 'red' })), 'aufnahme video')
    ];
    const addons = deckAddons();

    const q = el('input', { class: 'in', type: 'search', placeholder: 'Suchen – z. B. Discord, Clip, Lautstärke …', autocomplete: 'off' });
    let cat = LS.get('addCat', 'all');
    if (!ADD_CATS.some(c => c[0] === cat)) cat = 'all';
    const list = el('div', { class: 'add-body' });
    const card = e => el('button', { class: 'add-card', type: 'button', onclick: e.onclick }, tic(e.icon, e.color),
      el('span', { class: 'add-txt' }, el('b', null, e.title), e.sub ? el('small', null, e.sub) : null));
    const addonCard = ad => {
      const n = addonItems(ad, box).reduce((s, sec) => s + sec.items.length, 0);
      const app = appForAddon(ad);
      return el('button', { class: 'add-card addon', type: 'button', onclick: () => { close(); addonDeckSheet(ad, box); } },
        app && !ad.generic ? appIcon({ id: app.id }, ad.name) : tic(ad.icon, ad.color),
        el('span', { class: 'add-txt' }, el('b', null, addonTitle(ad)), el('small', null, n + ' Kacheln')));
    };
    const section = (title, items, cls) => items.length ? [heading(title), el('div', { class: 'add-grid' + (cls ? ' ' + cls : '') }, items)] : [];
    const draw = () => {
      list.innerHTML = '';
      const s = q.value.trim().toLowerCase();
      if (s) {
        // everything that matches: basics and every addon button
        const hits = entries.filter(e => (e.title + ' ' + (e.sub || '') + ' ' + e.keys).toLowerCase().includes(s)).map(card);
        const seen = new Set();
        for (const ad of addons)
          for (const sec of addonItems(ad, box))
            for (const it of sec.items) {
              const key = it.tile ? JSON.stringify(it.tile) : it.label;
              if (seen.has(key) || !(it.label + ' ' + addonTitle(ad) + ' ' + sec.title).toLowerCase().includes(s)) continue;
              seen.add(key);
              hits.push(el('button', { class: 'add-card', type: 'button', onclick: () => { close(); placeItem(it, box); } }, it.iconNode(),
                el('span', { class: 'add-txt' }, el('b', null, it.label), el('small', null, addonTitle(ad) + (it.missing ? ' · Kürzel fehlt noch' : '')))));
            }
        list.append(...(hits.length ? [el('div', { class: 'add-grid' }, hits)] : [el('div', { class: 'empty' }, 'Nichts gefunden.')]));
        return;
      }
      const show = c => cat === 'all' || cat === c;
      if (show('basic')) list.append(...section('Grundlagen', entries.filter(e => e.cat === 'basic').map(card)));
      if (show('addons')) list.append(...section('Addons – antippen zeigt alle Kacheln', addons.map(addonCard), 'addons'),
        ...(cat === 'addons' && !addons.length ? [el('div', { class: 'empty' }, 'Noch keine passenden Apps gefunden – unter „Apps“ neu scannen.')] : []));
      if (show('sound')) list.append(...section('Ton & Medien', entries.filter(e => e.cat === 'sound').map(card)));
      if (show('actions')) list.append(...section('Aktionen', entries.filter(e => e.cat === 'actions').map(card)));
    };
    q.addEventListener('input', draw);
    const seg = segTabs(ADD_CATS, cat, k => { cat = k; LS.set('addCat', k); draw(); }, 'add-cats');
    draw();
    const close = sheet('Kachel hinzufügen' + (isGroup(box) ? ' · ' + boxLabel(box) : ''), el('div', null,
      el('div', { class: 'search', style: 'margin-bottom:10px' }, ic('search'), q), seg, list), { wide: true });
  }

  // addons worth showing: switched on and the app is on this PC (Spotify also when it's connected).
  // All games share the same buttons, so they're one card "Spiele & Zocken" instead of one card per game.
  function deckAddons() {
    const list = ADDONS.filter(ad => !ad.game && addonOn(ad.id) && (appForAddon(ad) || (ad.id === 'spotify' && S.sp.connected)));
    if (addonOn('game')) list.unshift(GAME_ADDON);
    return list;
  }
  const addonTitle = ad => ad.generic ? 'Spiele & Zocken' : ad.name;

  // Everything one addon can put on the deck, by section: its buttons plus live tiles (toggles, sliders, playlists, games).
  function addonItems(ad, box) {
    const app = appForAddon(ad);
    const ctx = { addon: ad, app, procs: (app ? app.procs : []).concat((ad.match && ad.match.procs) || []), ups: [] };
    const color = ad.color || 'violet';
    const T = (label, icon, c, tile, extra) => Object.assign({ label, icon, color: c || color, tile, iconNode: () => tic(icon, c || color) }, extra || {});
    const secs = [];
    const top = [];
    if (app && !ad.generic) top.push(Object.assign(T(ad.name + ' starten', 'play', color, { type: 'app', app: app.id, name: app.name }), { iconNode: () => appIcon({ id: app.id }, app.name) }));
    if (ad.generic) {
      const games = S.apps.filter(a => a.kind === 'game');
      if (games.length) secs.push({ title: 'Spiele starten', items: games.map(a => Object.assign(T(a.name, 'gamepad', 'slate', { type: 'app', app: a.id, name: a.name }), { iconNode: () => appIcon({ id: a.id }, a.name) })) });
    }
    if (ad.id === 'spotify') {
      top.push(T('Playlist mit Cover', 'music', 'green', null, { run: () => playlistPicker(box) }),
        T('Spotify-Lautstärke', 'sliders', 'green', null, { run: () => editTile({ id: uid(), type: 'slider', bind: 'spotify' }, true) }));
      SPOTIFY_CMDS.filter(([cmd]) => cmd === 'toggle' || cmd === 'next' || cmd === 'prev')
        .forEach(([cmd, l]) => top.push(T(l, SPOTIFY_ICON[cmd] || 'music', 'green', { type: 'action', label: l, icon: SPOTIFY_ICON[cmd], color: 'green', a: { t: 'spotify', cmd } })));
    }
    if (ad.id === 'discord') {
      top.push(T('Mikro stumm (mit Status)', 'micoff', 'violet', { type: 'toggle', bind: 'discord:mute', color: 'violet' }),
        T('Ton aus (mit Status)', 'headphones', 'violet', { type: 'toggle', bind: 'discord:deaf', color: 'violet' }));
      DISCORD_CMDS.filter(([k]) => k !== 'mute' && k !== 'deaf').forEach(([k, l]) => top.push(T(l, DISCORD_ICON[k] || 'message', 'violet', { type: 'action', label: l, icon: DISCORD_ICON[k], color: 'violet', a: { t: 'discord', cmd: k } })));
    }
    if (ad.id === 'voicemeeter')
      top.push(T('Voicemeeter-Regler', 'sliders', 'cyan', null, { run: () => editTile({ id: uid(), type: 'slider', bind: 'vm:Strip[0].Gain' }, true) }),
        T('Voicemeeter stumm / Routing', 'mute', 'cyan', null, { run: () => editTile({ id: uid(), type: 'toggle', bind: 'vm:Strip[0].Mute' }, true) }));
    if (ad.id === 'nvidia') top.push(T('Systemwerte (CPU, RAM, GPU)', 'cpu', 'green', { type: 'stats' }));
    if (top.length) secs.unshift({ title: ad.name, items: top });
    for (const sec of ad.sections || []) {
      if (sec.type === 'buttons') {
        const items = sec.items.filter(i => i.needs !== 'spotify' || S.sp.connected).map(i => {
          const tile = deckTileFor(i, ctx);
          // shortcut still missing: ask for it, then the tile goes onto the deck right away
          return T(i.label, i.icon || (i.a ? actIcon(i.a) : 'zap'), i.color, tile, tile ? null : { missing: true,
            ask: done => askKey(i, ctx, () => { const t = deckTileFor(i, ctx); if (t) { addTile(clone(t), box); toast('„' + i.label + '“ ist jetzt auf dem Deck'); if (done) done(); } }) });
        });
        if (items.length) secs.push({ title: sec.title || 'Funktionen', items });
      } else if (sec.type === 'games') {
        const games = S.apps.filter(a => a.source === sec.source);
        if (games.length) secs.push({ title: sec.title || 'Spiele', items: games.map(a => Object.assign(T(a.name, 'gamepad', 'slate', { type: 'app', app: a.id, name: a.name }), { iconNode: () => appIcon({ id: a.id }, a.name) })) });
      }
    }
    const own = AD.buttons[ad.id] || [];
    if (own.length) secs.push({ title: 'Eigene Buttons', items: own.map(b => T(b.label || actLabel(b.a), b.icon || actIcon(b.a), b.color, { type: 'action', label: b.label, icon: b.icon, color: b.color, a: clone(b.a), confirm: b.confirm })) });
    return secs;
  }

  function placeItem(it, box) {
    if (it.run) return it.run();
    if (!it.tile) return it.ask ? it.ask() : toast('Dafür fehlt noch das Tastenkürzel – in den Addon-Einstellungen unter „Apps“ eintragen', 'err');
    addTile(clone(it.tile), box);
    toast('„' + it.label + '“ ist jetzt auf dem Deck');
  }

  // one addon: all its tiles at a glance – tap = onto the deck (the sheet stays open to add more)
  function addonDeckSheet(ad, box) {
    const secs = addonItems(ad, box);
    const body = el('div', null,
      el('p', { class: 'hint', style: 'margin:0 0 12px' }, 'Antippen legt die Kachel auf ' + (isGroup(box) ? 'die Gruppe „' + boxLabel(box) + '“' : 'die Seite „' + boxLabel(box) + '“') + '. Du kannst mehrere nacheinander antippen.'));
    if (!secs.length) body.append(el('div', { class: 'empty' }, 'Dieses Addon hat keine Kacheln fürs Deck.'));
    for (const sec of secs) {
      body.append(heading(sec.title), el('div', { class: 'abtn-grid' }, sec.items.map(it => {
        const b = el('button', { class: 'abtn add-pick c-' + it.color + (it.missing ? ' missing' : ''), type: 'button' }, it.iconNode(),
          el('span', { class: 'abtn-l' }, it.label, it.missing ? el('small', null, 'Kürzel fehlt') : null), el('span', { class: 'add-plus' }, ic(it.run ? 'right' : 'plus')));
        b.onclick = () => {
          if (it.run) { close(); return it.run(); }
          placeItem(it, box);
          if (it.tile) { flash(b); b.classList.add('added'); }
        };
        return b;
      })));
    }
    body.append(el('div', { class: 'sheet-actions' }, el('button', { class: 'btn primary', onclick: () => close() }, ic('check'), 'Fertig')));
    const close = sheet(addonTitle(ad) + ' aufs Deck', body, { wide: true });
  }

  function appPicker(box) {
    const list = el('div', { class: 'pick-list' });
    const q = el('input', { class: 'in', type: 'search', placeholder: 'Suchen …' });
    const draw = () => {
      list.innerHTML = '';
      const s = q.value.trim().toLowerCase();
      const apps = S.apps.filter(a => !s || a.name.toLowerCase().includes(s));
      if (!apps.length) list.append(el('div', { class: 'empty' }, S.apps.length ? 'Nichts gefunden.' : 'Noch keine Apps gefunden – unter „Apps“ neu scannen.'));
      for (const a of apps) list.append(el('button', { class: 'pick-item', onclick: () => { close(); addTile({ type: 'app', app: a.id, name: a.name }, box); } },
        appIcon({ id: a.id }, a.name), el('div', null, el('b', null, a.name), el('small', null, ({ game: 'Spiel', app: 'App', launcher: 'Launcher' })[a.kind] || ''))));
    };
    q.addEventListener('input', draw);
    draw();
    const close = sheet('App oder Spiel wählen', el('div', null, el('div', { class: 'search', style: 'margin-bottom:12px' }, ic('search'), q), list));
  }

  function field(label, input, hint) {
    return el('div', { class: 'field' }, label ? el('span', { class: 'field-label' }, label) : null, input, hint ? el('small', { class: 'field-hint', style: 'white-space:pre-line' }, hint) : null);
  }
  function textIn(obj, key, ph, type) {
    const i = el(type === 'area' ? 'textarea' : 'input', { class: 'in', placeholder: ph || '', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
    if (type === 'number') { i.type = 'number'; i.inputMode = 'numeric'; }
    i.value = obj[key] == null ? '' : obj[key];
    i.addEventListener('input', () => { obj[key] = type === 'number' ? (+i.value || 0) : i.value; });
    return i;
  }
  function selectIn(obj, key, options, onchange) {
    const s = el('select', { class: 'in' });
    const add = (parent, [v, l]) => parent.append(el('option', { value: v }, l));
    for (const o of options) {
      if (o.group) { const g = el('optgroup', { label: o.group }); o.items.forEach(x => add(g, x)); s.append(g); }
      else add(s, o);
    }
    s.value = obj[key] == null ? '' : obj[key];
    if (s.selectedIndex < 0 && s.options.length) { s.selectedIndex = 0; obj[key] = s.value; }
    s.addEventListener('change', () => { obj[key] = s.value; if (onchange) onchange(s); });
    return s;
  }
  function segIn(obj, key, options) {
    return segTabs(options.map(([v, l]) => [String(v), l]), String(obj[key]), k => { obj[key] = isNaN(+k) ? k : +k; });
  }

  async function bindOptions(forToggle, current) {
    const opts = [['master', 'Lautsprecher (Gesamt)'], ['mic', 'Mikrofon']];
    if (!forToggle) opts.push(['spotify', 'Spotify (Lautstärke in Spotify)']);
    else opts.push({ group: 'Discord', items: [['discord:mute', 'Discord – Mikro stumm'], ['discord:deaf', 'Discord – Ton aus']] });
    let mx = null;
    try { mx = await api('/api/mixer?vm=1'); } catch (e) { }
    const seen = new Set(['master', 'mic', 'spotify', 'discord:mute', 'discord:deaf']);
    const playing = [];
    for (const s of (mx && mx.sessions) || []) {
      if (s.key === 'system') continue;
      playing.push(['app:' + s.key, s.name + ' (Windows-Lautstärke)']);
      seen.add('app:' + s.key);
    }
    if (playing.length) opts.push({ group: 'Apps, die gerade Ton abspielen', items: playing });
    const known = [];
    for (const a of S.apps) {
      const p = a.procs[0];
      if (!p || seen.has('app:' + p)) continue;
      seen.add('app:' + p);
      known.push(['app:' + p, a.name]);
    }
    if (known.length) opts.push({ group: 'Weitere Apps', items: known });
    const vm = mx && mx.vm;
    if (vm && vm.ok) {
      S.vm = vm;
      const items = [];
      for (const s of vm.strips) {
        const b = 'vm:Strip[' + s.i + ']';
        if (forToggle) {
          items.push([b + '.Mute', s.label + ' – Stumm']);
          vm.buses.forEach(x => items.push([b + '.' + x.name, s.label + ' → ' + x.name]));
        } else items.push([b + '.Gain', s.label + ' – Gain']);
      }
      for (const x of vm.buses) items.push(['vm:Bus[' + x.i + '].' + (forToggle ? 'Mute' : 'Gain'), 'Bus ' + x.name + (forToggle ? ' – Stumm' : ' – Gain')]);
      opts.push({ group: 'Voicemeeter', items });
    }
    if (current && !seen.has(current) && !(vm && vm.ok && current.startsWith('vm:'))) opts.push([current, current.replace(/^app:/, '') + ' (aktuell)']);
    return opts;
  }

  // Lauter/Leiser buttons → which volume they change (null = not a volume button)
  const volBind = a => !a ? null : a.t === 'media' && (a.k === 'volup' || a.k === 'voldown') ? 'master'
    : a.t === 'spotify' && (a.cmd === 'volup' || a.cmd === 'voldown') ? 'spotify' : null;

  // Replace a volume button (and its Lauter/Leiser partner right next to it) by one slider in the same spot.
  function volumeToSlider(id, close) {
    const loc = findTile(id);
    if (!loc) return;
    const page = loc.page, tile = page.tiles[loc.i], bind = volBind(tile.a), dir = tile.a.k || tile.a.cmd;
    remember();
    const p = tile.pos;
    const partner = page.tiles.find(o => o !== tile && o.type === 'action' && volBind(o.a) === bind && (o.a.k || o.a.cmd) !== dir &&
      o.pos.w === 1 && o.pos.h === 1 && p.w === 1 && p.h === 1 &&
      ((o.pos.y === p.y && Math.abs(o.pos.x - p.x) === 1) || (o.pos.x === p.x && Math.abs(o.pos.y - p.y) === 1)));
    let r = { x: p.x, y: p.y, w: p.w, h: p.h };
    if (partner) {
      r = partner.pos.y === p.y ? { x: Math.min(p.x, partner.pos.x), y: p.y, w: 2, h: 1 } : { x: p.x, y: Math.min(p.y, partner.pos.y), w: 1, h: 2 };
      page.tiles.splice(page.tiles.indexOf(partner), 1);
    }
    page.tiles[page.tiles.indexOf(tile)] = { id: tile.id, type: 'slider', bind, pos: r };
    saveLayout();
    close();
    if (current === Deck) Deck.draw();
    toast(partner ? 'Lauter und Leiser sind jetzt ein Regler' : 'Jetzt ein Regler – zum Einstellen hoch/runter wischen');
  }

  // target: undefined = deck tile; otherwise { title, save(t) } for addon custom buttons
  function editTile(orig, isNew, target) {
    const t = clone(orig);
    const kind = TILES[t.type];
    const custom = !!target;
    const body = el('div', { class: 'form' });
    const loc = custom ? null : findTile(t.id);
    const where = { p: boxKey(loc ? loc.page : viewBox()) };
    const wantAt = isNew ? addAt : null; // tapped empty cell
    if (isNew) addAt = null;
    // live preview: name, symbol, colour and size exactly as on the deck
    const preview = el('div', { class: 'tile-preview' });
    const paintPreview = () => {
      if (custom || !t.pos || !TILES[t.type]) return;
      preview.innerHTML = '';
      preview.append(tilePreview(t), el('small', null, 'So sieht die Kachel aus · ' + t.pos.w + ' × ' + t.pos.h));
    };

    const draw = () => {
      body.innerHTML = '';
      const def = tileName(Object.assign({}, t, { label: '' }));
      if (!custom) body.append(preview);

      if (isGroup(t) && isNew)
        body.append(el('div', { class: 'convert-box' }, tic('folder', 'orange'),
          el('div', { class: 'grow' }, el('b', null, 'Ein Deck im Deck'), el('small', null, 'Die Gruppe startet leer. Antippen öffnet sie – dort fügst du Kacheln genauso hinzu wie überall. Vorhandene Kacheln kannst du im Bearbeiten-Modus auf die Gruppe ziehen.'))));

      if (t.type === 'playlist') {
        const holder = el('div', null, el('div', { class: 'hint' }, 'Lade Playlists …'));
        const firstSong = el('small', { class: 'field-hint' }, '');
        const showFirst = () => {
          firstSong.textContent = '';
          if (t.uri) api('/api/spotify?what=first&q=' + enc(t.uri)).then(f => { firstSong.textContent = f ? 'Beginnt mit: ' + f.name + (f.artists ? ' – ' + f.artists : '') : ''; }).catch(() => { });
        };
        body.append(field('Playlist', el('div', null, holder, firstSong)));
        api('/api/spotify?what=playlists').then(list => {
          holder.innerHTML = '';
          const opts = list.map(p => [p.uri, p.name]);
          if (t.uri && !list.some(p => p.uri === t.uri)) opts.unshift([t.uri, t.name || t.uri]);
          holder.append(selectIn(t, 'uri', opts, s => {
            const p = list.find(x => x.uri === s.value);
            if (p) { t.name = p.name; t.image = p.image || null; t.liked = p.kind === 'liked'; }
            showFirst();
          }));
          showFirst();
        }).catch(e => { holder.innerHTML = ''; holder.append(el('div', { class: 'hint' }, e.message)); });
        body.append(el('label', { class: 'check' }, 'In Reihenfolge abspielen (Zufallswiedergabe aus)', sw(t.noShuffle !== false, v => { t.noShuffle = v; })),
          el('small', { class: 'field-hint' }, 'Tippen startet die Playlist immer beim ersten Lied, bei 0:00 – auch wenn Spotify gerade zu ist.'));
      }

      if (t.type === 'slider' || t.type === 'toggle') {
        const holder = el('div', null, el('div', { class: 'hint' }, 'Lade Ziele …'));
        body.append(field(t.type === 'slider' ? 'Was soll der Regler steuern?' : 'Was soll geschaltet werden?', holder));
        bindOptions(t.type === 'toggle', t.bind).then(opts => { holder.innerHTML = ''; holder.append(selectIn(t, 'bind', opts, draw)); });
      }

      if (t.type === 'app') {
        body.append(field('App oder Spiel', selectIn(t, 'app', S.apps.map(a => [a.id, a.name]).concat(appById(t.app) ? [] : [[t.app, t.name || t.app]]), s => { t.name = s.options[s.selectedIndex].text; })));
        body.append(field('Beim Tippen', selectIn(t, 'op', [['smart', 'Starten – oder nach vorne holen, wenn es läuft'], ['launch', 'Immer neu starten'], ['focus', 'Nur nach vorne holen'], ['kill', 'Beenden']])));
      }

      if (t.type === 'action') {
        const types = Object.keys(ACTS).filter(k => !HIDDEN_ACTS[k]);
        if (!ACTS[t.a.t]) types.unshift(t.a.t);
        body.append(field('Was soll passieren?', selectIn(t.a, 't', types.map(k => [k, ACTS[k] ? ACTS[k].name : 'Addon-Aktion']), () => { t.a = { t: t.a.t }; delete t.icon; draw(); })));
        const d = ACTS[t.a.t];
        for (const [key, label, type, extra] of d ? d.fields : []) {
          if (type === 'select') body.append(field(label, selectIn(t.a, key, extra, draw)));
          else if (type === 'check') body.append(el('label', { class: 'check' }, label, sw(t.a[key], v => { t.a[key] = v; })));
          else if (type === 'keys') {
            const inp = textIn(t.a, key, 'z. B. ctrl+shift+m');
            const chips = el('div', { class: 'chips', style: 'margin-top:8px' }, ['ctrl', 'shift', 'alt', 'win', 'tab', 'enter', 'esc', 'space', 'f1', 'up', 'down'].map(k =>
              el('button', { class: 'chip', type: 'button', onclick: () => { inp.value = inp.value ? inp.value.replace(/\+?$/, '+') + k : k; inp.dispatchEvent(new Event('input')); } }, k)));
            body.append(field(label, el('div', null, inp, chips), 'Tasten mit + verbinden, mehrere Schritte mit Leerzeichen (z. B. „ctrl+k s“). Buchstaben, Zahlen, f1–f24, ctrl, shift, alt, win, enter, esc, tab, space, up/down/left/right, delete, home, end, printscreen …'));
          } else if (type === 'appsel') {
            const opts = S.apps.map(a => [a.id, a.name]);
            if (t.a.procs && !t.a.id) opts.unshift(['', 'Diese App (' + t.a.procs + ')']);
            body.append(field(label, selectIn(t.a, key, opts, () => { if (t.a.id) delete t.a.procs; })));
          } else if (type === 'device') {
            const holder = el('div', null, el('div', { class: 'hint' }, 'Lade Geräte …'));
            body.append(field(label, holder));
            api('/api/mixer').then(mx => {
              const opts = [];
              if (mx.outputs && mx.outputs.length) opts.push({ group: 'Ausgabe', items: mx.outputs.map(x => [x.id, x.name]) });
              if (mx.inputs && mx.inputs.length) opts.push({ group: 'Eingabe', items: mx.inputs.map(x => [x.id, x.name]) });
              holder.innerHTML = '';
              const sync = s => { t.a.devName = s.options[s.selectedIndex] ? s.options[s.selectedIndex].text : ''; };
              const s = selectIn(t.a, key, opts, sync);
              sync(s);
              holder.append(s);
            }).catch(e => { holder.textContent = e.message; });
          } else body.append(field(label, textIn(t.a, key, extra, type)));
        }
        if (d && d.hint) body.append(el('small', { class: 'field-hint', style: 'white-space:pre-line' }, d.hint));
        if (!custom && !isNew && volBind(t.a))
          body.append(el('div', { class: 'convert-box' }, tic('sliders', 'cyan'),
            el('div', { class: 'grow' }, el('b', null, 'Lieber ein Regler?'), el('small', null, 'Ersetzt diesen Button – und den passenden Lauter/Leiser-Button daneben – durch einen Lautstärkeregler.')),
            el('button', { class: 'btn small primary', type: 'button', onclick: () => volumeToSlider(t.id, close) }, 'Umwandeln')));
      }

      if (t.type !== 'np' && t.type !== 'stats') {
        const name = textIn(t, 'label', def);
        name.maxLength = 40;
        name.addEventListener('input', paintPreview);
        body.append(field('Name', name, 'Leer lassen = „' + def + '“. Lange Wörter werden automatisch sauber getrennt.'));
        if (!custom && t.type !== 'slider')
          body.append(el('label', { class: 'check' }, el('span', null, 'Name ausblenden', el('small', { class: 'hint', style: 'display:block' }, 'Nur das Symbol zeigen – gut für kleine Kacheln')),
            sw(t.hideLabel, v => { if (v) t.hideLabel = true; else delete t.hideLabel; paintPreview(); })));
      }

      if (t.type === 'action' || isGroup(t)) {
        const pick = el('div', { class: 'icon-pick' });
        const curIcon = t.icon || (isGroup(t) ? 'folder' : actIcon(t.a));
        const icons = isGroup(t) ? ['folder'].concat(PICK_ICONS.filter(n => n !== 'folder')) : PICK_ICONS;
        for (const n of icons)
          pick.append(el('button', { type: 'button', class: n === curIcon ? 'on' : '', 'aria-label': n, onclick: e => { t.icon = n; [...pick.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); paintPreview(); } }, ic(n)));
        body.append(field('Symbol', pick));
        // VIP: an emoji instead of the symbol
        if (isVip()) {
          const emo = el('input', { class: 'in emoji-in', placeholder: 'z. B. 🎮', maxlength: '8', autocomplete: 'off', value: t.emoji || '' });
          const setEmo = v => { v = String(v || '').trim(); if (v) t.emoji = v; else delete t.emoji; emo.value = v; paintPreview(); };
          emo.addEventListener('input', () => setEmo(emo.value));
          body.append(field(el('span', null, 'Emoji statt Symbol ', el('span', { class: 'role-badge r-vip' }, 'VIP')), el('div', null, emo,
            el('div', { class: 'chips emoji-chips' }, ['🎮', '🎵', '🔥', '⭐', '🚀', '💬', '🎧', '📸', '💡', '👑', '❤️', '🛑'].map(x => el('button', { class: 'chip', type: 'button', onclick: () => setEmo(x) }, x)),
              el('button', { class: 'chip', type: 'button', onclick: () => setEmo('') }, 'Kein Emoji'))),
            'Leer = das Symbol von oben.'));
        }
      }

      if (t.type === 'action' || t.type === 'toggle' || isGroup(t)) {
        const sws = el('div', { class: 'swatches' });
        const curColor = t.color || (isGroup(t) ? 'orange' : 'violet');
        for (const c of COLORS)
          sws.append(el('button', { type: 'button', class: 'c-' + c + (curColor === c ? ' on' : ''), 'aria-label': c, onclick: e => { t.color = c; [...sws.children].forEach(x => x.classList.remove('on')); e.currentTarget.classList.add('on'); paintPreview(); } }));
        body.append(field('Farbe', sws));
      }

      if (t.type === 'action')
        body.append(el('label', { class: 'check' }, 'Vor dem Ausführen nachfragen', sw(t.confirm, v => { t.confirm = v; })));

      if (!custom) {
        // size and spot on the grid (in edit mode: tap a tile for the size bar, or drag – this is the same in the editor)
        const pg = boxByKey(where.p) || viewBox(), cols = pageCols(pg), minW = MIN_W[t.type] || 1;
        if (!t.pos) {
          // a new volume slider starts upright (1×2) like a mixer channel, unless the wide one was picked
          const s = t.type === 'slider' && !t.wide ? { w: 1, h: 2 } : defSize(t, cols), want = wantAt || { x: 0, y: Math.max(0, pageRows(pg) - 1) };
          t.pos = { x: Math.min(want.x, cols - s.w), y: want.y, w: s.w, h: s.h };
        }
        delete t.wide;
        t.pos.w = Math.max(minW, Math.min(t.pos.w, cols));
        const pickSize = (w, h) => { t.pos.w = w; t.pos.h = h; t.pos.x = Math.min(t.pos.x, cols - w); draw(); };
        body.append(field('Größe', el('div', null,
          el('div', { class: 'tb-sizes' }, sizeButtons(cols, minW, t.pos, pickSize)),
          el('details', { class: 'sz-more' }, el('summary', null, 'Andere Größe (bis ' + cols + ' × 4)'), sizeGrid(cols, minW, t.pos, pickSize))),
          t.type === 'slider' ? 'Schmal oder hochkant = Fader: auf dem Regler hoch/runter wischen (am PC auch Mausrad). Breit = Schieberegler. Das Symbol schaltet stumm.' : null));
        if (!isNew) {
          const posLabel = el('span', { class: 'pos-label' });
          const paintPos = () => { posLabel.textContent = 'Spalte ' + (t.pos.x + 1) + ' · Zeile ' + (t.pos.y + 1); };
          const nudge = (dx, dy) => {
            t.pos.x = Math.max(0, Math.min(cols - t.pos.w, t.pos.x + dx));
            t.pos.y = Math.max(0, t.pos.y + dy);
            paintPos();
          };
          const nb = (icon, dx, dy, label) => el('button', { class: 'icon-btn', type: 'button', 'aria-label': label, onclick: () => nudge(dx, dy) }, ic(icon));
          paintPos();
          body.append(field('Position', el('div', { class: 'pos-pad' }, nb('left', -1, 0, 'Links'), nb('up', 0, -1, 'Hoch'), posLabel, nb('down', 0, 1, 'Runter'), nb('right', 1, 0, 'Rechts')),
            'Wird beim Speichern übernommen – eine Kachel am Ziel rückt zur Seite. Schneller geht es im Bearbeiten-Modus per Ziehen.'));
        }
        // where it lives: any page or group (a group can't go into itself)
        const places = allBoxes().filter(b => !(isGroup(orig) && !isNew && within(b.box, orig)));
        if (places.length > 1)
          body.append(field('Ort', selectIn(where, 'p', places.map(b => [b.key, (b.depth ? '↳ ' : '') + b.name]), () => draw()),
            places.some(b => b.depth) ? 'Seiten und Gruppen – „↳“ ist eine Gruppe.' : null));
      }

      body.append(el('div', { class: 'sheet-actions' },
        isNew || custom ? null : el('button', { class: 'btn danger', type: 'button', onclick: async () => {
          const cur = findTile(t.id);
          if (cur && await deleteTile(cur.page.tiles[cur.i])) close();
        } }, ic('trash')),
        el('button', { class: 'btn primary', type: 'button', onclick: save }, ic('check'), isNew ? 'Hinzufügen' : 'Speichern')));
      paintPreview();
    };

    const save = () => {
      if (t.type === 'action') {
        const need = { key: 'keys', appkey: 'keys', text: 'text', url: 'url', launch: 'target', cmd: 'cmd', macro: 'script', kill: 'procs', device: 'id' }[t.a.t];
        if (need && !String(t.a[need] || '').trim().replace(/^https:\/\/$/, '')) return toast('Bitte erst ausfüllen, was passieren soll', 'err');
        if (t.a.t === 'appkey' && !t.a.id && !t.a.procs) return toast('Bitte eine App wählen', 'err');
      }
      if (!t.label) delete t.label;
      close();
      if (target) return target.save(t);
      remember();
      const dest = boxByKey(where.p) || viewBox();
      if (isGroup(t)) { t.tiles = t.tiles || []; t.cols = t.cols || pageCols(dest); }
      const cur = findTile(t.id);
      if (cur) cur.page.tiles.splice(cur.i, 1);
      const cols = pageCols(dest);
      const w = Math.max(MIN_W[t.type] || 1, Math.min(cols, t.pos ? t.pos.w : defSize(t, cols).w)), h = t.pos ? t.pos.h : 1;
      const keep = cur && cur.page === dest ? { x: Math.min(t.pos.x, cols - w), y: t.pos.y, w, h } : null;
      const draft = t.pos;
      t.pos = null;
      dest.tiles.push(t);
      if (keep) placeAt(dest, t, keep); // same page: the spot from the editor, others make room
      else {
        const want = isNew && draft ? draft : { x: 0, y: Math.max(0, pageRows(dest) - 1) };
        const r = { x: Math.min(want.x, cols - w), y: want.y, w, h };
        t.pos = fits(dest, r, t) ? r : freeSpot(dest, w, h, r.x, r.y, t);
      }
      saveLayout();
      if (current === Deck) Deck.draw();
    };

    draw();
    const close = sheet(target ? target.title : isNew ? (t.type === 'action' ? ACTS[t.a.t].name : kind.name) + ' hinzufügen' : 'Kachel bearbeiten', body);
  }

  // ---------- navigation: tabs, each holding a stack of pages ----------

  const TABS = PC
    ? [['deck', 'Deck', 'grid', Deck, 'Steuern'], ['media', 'Medien', 'music', MediaView, 'Steuern'], ['clips', 'Clips', 'video', ClipsView, 'Steuern'], ['apps', 'Apps & Addons', 'puzzle', AppsView, 'Steuern'],
       ['mixer', 'Mixer', 'sliders', Mixer, 'Steuern'], ['display', 'Handy als Bildschirm', 'devices', DisplayView, 'Steuern'], ['system', 'System', 'cpu', SysSub, 'PC'], ['power', 'Energie', 'power', PowerSub, 'PC'],
       ['windows', 'Fenster', 'window', WinSub, 'PC'], ['tools', 'Werkzeuge', 'clipboard', ToolsSub, 'PC'],
       ['vip', 'VIP', 'crown', VipView, 'Konto'], ['support', 'Bug/Fix', 'bug', SupportView, 'Konto'], ['inbox', 'Nachrichten', 'inbox', InboxView, 'Konto'],
       ['test', 'Testen', 'flask', TestView, 'Konto'],
       ['accounts', 'Konto', 'users', AccountsView, 'Konto'],
       ['connect', 'Handy verbinden', 'qr', ConnectView, ''], ['settings', 'Einstellungen', 'settings', SettingsView, '']]
    : [['deck', 'Deck', 'grid', Deck], ['media', 'Medien', 'music', MediaView], ['clips', 'Clips', 'video', ClipsView], ['apps', 'Apps', 'puzzle', AppsView], ['mixer', 'Mixer', 'sliders', Mixer],
       ['more', 'Mehr', 'more', More]];

  const NAV = { tab: null, stack: [] };

  function mount() {
    const view = NAV.stack[NAV.stack.length - 1];
    [...$('#view').children].forEach(c => { c.style.display = c === view.el ? '' : 'none'; });
    // the page glides in softly
    view.el.classList.remove('v-in');
    void view.el.offsetWidth;
    view.el.classList.add('v-in');
    clearTimeout(view.el.vinT);
    view.el.vinT = setTimeout(() => view.el.classList.remove('v-in'), 700); // later updates of the page don't replay it
    current = view;
    const back = $('#backBtn');
    if (back) back.style.display = NAV.stack.length > 1 ? '' : 'none';
    const t = $('#viewTitle');
    if (t) t.textContent = view.title || '';
    document.querySelectorAll('.edit-btn').forEach(b => { b.style.display = view === Deck ? '' : 'none'; });
    paintUndo();
    startPoll();
  }

  function enter(view) {
    view.el = el('div', { class: 'page' });
    $('#view').append(view.el);
    view.render(view.el);
  }

  function show(tab) {
    const def = TABS.find(t => t[0] === tab) || TABS[0];
    stopPoll();
    if (S.editing) setEditing(false);
    S.groupPath = [];
    Deck.pushed = 0;
    NAV.stack.forEach(v => { if (v.destroy) v.destroy(); });
    NAV.stack = [];
    $('#view').innerHTML = '';
    NAV.tab = def[0];
    if (def[0] !== 'connect') LS.set('tab', def[0]);
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b.dataset.tab === def[0]));
    $('#view').className = 'view-' + def[0];
    NAV.stack.push(def[3]);
    enter(def[3]);
    window.scrollTo(0, 0);
    mount();
  }

  function push(view) {
    stopPoll();
    NAV.stack[NAV.stack.length - 1].scrollY = window.scrollY;
    NAV.stack.push(view);
    enter(view);
    history.pushState({ depth: NAV.stack.length }, '');
    window.scrollTo(0, 0);
    mount();
  }

  function pop() {
    if (NAV.stack.length < 2) return;
    stopPoll();
    const top = NAV.stack.pop();
    if (top.destroy) top.destroy();
    top.el.remove();
    mount();
    window.scrollTo(0, NAV.stack[NAV.stack.length - 1].scrollY || 0);
  }

  function goBack() { if (NAV.stack.length > 1) history.back(); }

  window.addEventListener('popstate', e => {
    if (skipPop) { skipPop = false; return; }
    if (viewer) { viewer.close(true); return; }
    const inGroup = current === Deck && S.groupPath.length && NAV.stack.length < 2;
    if (sheets.length) {
      sheets[sheets.length - 1]();
      if (NAV.stack.length > 1) history.pushState({ depth: NAV.stack.length }, '');
      else if (inGroup && Deck.pushed >= S.groupPath.length) history.pushState({ deckGroup: S.groupPath.length }, '');
      return;
    }
    if (inGroup) {
      // back gesture / "Zurück" inside a group: one group up
      const want = e.state && typeof e.state.deckGroup === 'number' ? e.state.deckGroup : 0;
      if (want < S.groupPath.length) { Deck.pushed = want; Deck.setDepth(want); return; }
    }
    pop();
  });
  window.pcGo = v => { if (S.pin && $('#view')) show(v); };

  // Live sync: every API answer carries the PC's change counter (X-Rev). A new deck/addon/look is fetched and shown
  // right away; new app files (web) reload the app by itself when nothing is being edited.
  let liveVer = null, pulling = false, lastPing = 0;
  function noteRev(rv, fromPoll) {
    if (fromPoll) S.revSeenAt = Date.now();
    if (S.rev == null) { S.rev = rv; return; }
    if (rv === S.rev || !S.layout || pulling) return;
    pulling = true;
    pullShared(rv).catch(() => { }).then(() => { pulling = false; });
  }
  function watchVersion() {
    if (watchVersion.on) return;
    watchVersion.on = true;
    let busy = false;
    const check = async () => {
      if (document.hidden || busy) return;
      // the page polls anyway (deck, mixer, media …): its answers already bring the counter – only check the app files now and then
      if (Date.now() - (S.revSeenAt || 0) < 2000 && Date.now() - lastPing < 9000) return;
      busy = true;
      lastPing = Date.now();
      try {
        const resp = await fetch('/api/ping', { cache: 'no-store' });
        noteClip(resp.headers.get('X-Clip'));
        const d = await resp.json();
        if (d.central) S.central = d.central;
        const v = d.web || d.version;
        if (liveVer == null) liveVer = v;
        else if (v && v !== liveVer) liveReload();
        if (d.rev != null) noteRev(d.rev, false);
      } catch (e) { }
      busy = false;
    };
    check();
    setInterval(check, 1500);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
  }
  // new app files on the PC: reload at once – unless something is open or being typed, then offer it
  function liveReload() {
    const typing = document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
    if (!sheets.length && !S.editing && !typing && !viewer) location.reload();
    else showUpdateBar();
  }
  function showUpdateBar() {
    if ($('.live-update')) return;
    const bar = el('div', { class: 'live-update' }, ic('refresh'),
      el('span', null, 'PC Remote wurde aktualisiert.'),
      el('button', { class: 'btn small primary', onclick: () => location.reload(true) }, 'Neu laden'),
      el('button', { class: 'icon-btn', 'aria-label': 'Später', onclick: () => bar.remove() }, ic('x')));
    document.body.append(bar);
  }

  async function startApp() {
    const app = $('#app');
    app.innerHTML = '';
    document.body.classList.toggle('pc', PC);
    watchVersion();
    accountHeartbeat();
    const editBtn = () => el('button', { class: 'btn small edit-btn', 'aria-label': 'Bearbeiten', onclick: () => setEditing(!S.editing) }, ic('edit'), el('span', null, 'Bearbeiten'));
    const status = () => el('small', { class: 'status' }, el('i', { class: 'dot' }), el('span', { class: 'status-text' }, 'Verbunden'), PC ? null : el('span', null, '· ' + (S.name || 'PC')));
    const tabBtn = ([k, l, i]) => el('button', { class: 'tab', 'data-tab': k, onclick: () => { buzz(); show(k); } }, ic(i), el('span', null, l));
    const topBar = () => el('header', { class: 'top' },
      el('button', { id: 'backBtn', class: 'icon-btn back-btn', 'aria-label': 'Zurück', onclick: goBack, style: 'display:none' }, ic('back')),
      el('div', { class: 'top-title' }, el('h1', { id: 'viewTitle' }, ''), PC ? null : status()),
      el('div', { class: 'top-actions' },
        el('button', { class: 'icon-btn undo-btn', 'aria-label': 'Rückgängig', title: 'Rückgängig', style: 'display:none', onclick: undoLast }, ic('undo')),
        editBtn()));

    if (PC) {
      const groups = [];
      for (const t of TABS.filter(x => (x[0] !== 'inbox' || isStaff()) && (x[0] !== 'test' || isRealStaff()))) {
        let g = groups.find(x => x.name === t[4]);
        if (!g) groups.push(g = { name: t[4], items: [] });
        g.items.push(t);
      }
      app.append(el('div', { class: 'pc-shell' },
        el('aside', { class: 'side' },
          el('div', { class: 'brand' }, el('img', { src: '/logo-64.png', alt: '' }), el('div', null, el('b', null, 'PC Remote', isVip() ? roleBadge(myRole() === 'admin' ? 'vip' : myRole()) : null), status())),
          groups.map(g => el('nav', { class: 'side-nav' + (g.name ? '' : ' bottom') }, g.name ? el('div', { class: 'side-label' }, g.name) : null, g.items.map(tabBtn))),
          el('div', { class: 'side-foot hint' }, S.name)),
        el('div', { class: 'pc-main' }, topBar(), el('main', { id: 'view' }, el('div', { class: 'empty' }, 'Lade …')))));
    } else {
      app.append(topBar(),
        el('main', { id: 'view' }, el('div', { class: 'empty' }, 'Lade …')),
        el('nav', { class: 'tabs' }, el('div', { class: 'tabs-in' }, TABS.map(tabBtn))),
        // tablets held across and phones on their side: the tabs move into a slim bar on the left (style.css decides)
        el('nav', { class: 'rail' }, el('img', { class: 'rail-logo', src: '/logo-64.png', alt: '' }), TABS.map(tabBtn)));
    }
    const pb = previewBar();
    if (pb) app.prepend(pb);
    S.online = true;
    document.title = PC ? 'PC Remote' : (S.name ? S.name + ' · ' : '') + 'PC Remote';
    if (PC) watchPairing();
    offerInstall();

    // remember the PC's change counter first, so nothing changed while loading is missed
    try { const pg = await fetch('/api/ping', { cache: 'no-store' }).then(r => r.json()); if (pg.rev != null) S.rev = pg.rev; } catch (e) { }
    // everything at once – the deck is only built once apps, addons and the layout are all there
    const layout = api('/api/layout');
    layout.catch(() => { });
    await Promise.all([loadApps(), loadAddons(), loadShared()]);
    await loadLayout(layout);
    api('/api/spotify?what=status').then(s => { S.sp = s; }).catch(() => { });
    const hash = location.hash.slice(1);
    show(hash && TABS.some(t => t[0] === hash) ? hash : LS.get('tab', 'deck'));
    if (hash) history.replaceState(null, '', location.pathname + location.search);

    // The PC scans apps in the background at startup; pick them up once ready.
    for (let i = 0; i < 6 && !S.apps.length; i++) {
      await new Promise(r => setTimeout(r, 2500));
      await loadApps();
      if (S.apps.length) {
        if (!S.layout.custom) S.layout = defaultLayout();
        show(NAV.tab);
      }
    }
  }

  function logout(msg) {
    stopPoll();
    NAV.stack.forEach(v => { if (v.destroy) v.destroy(); });
    NAV.stack = [];
    current = null;
    S.pin = null;
    S.token = null;
    S.deviceId = null;
    LS.del('pin');
    LS.del('token');
    clearInterval(pairWatch);
    sheets.slice().forEach(c => c());
    renderLogin(msg);
  }

  let loginPoll = null;
  function renderLogin(msg) {
    const app = $('#app');
    app.innerHTML = '';
    clearInterval(loginPoll);
    const sub = el('p', null, 'Mit deinem PC verbinden');
    const err = el('div', { class: 'err-text' }, msg || '');
    const askBox = el('div', { class: 'ask-box' });
    const failMsg = x => x.message === 'Failed to fetch' ? 'PC nicht erreichbar – läuft PC Remote?' : x.message;

    // 1) no PIN, no scanning: the PC asks "allow this device?"
    const askBtn = el('button', { class: 'btn primary block', type: 'button', onclick: async () => {
      err.textContent = '';
      askBtn.disabled = true;
      try {
        const r = await fetch('/api/pair/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: deviceName() }), cache: 'no-store' });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'Fehler ' + r.status);
        askBtn.style.display = 'none';
        askBox.innerHTML = '';
        askBox.append(el('div', { class: 'hint' }, 'Code'), el('div', { class: 'ask-code' }, d.code),
          el('p', { class: 'hint' }, 'Am PC erscheint jetzt „Gerät verbinden?“. Prüfe, dass dort derselbe Code steht, und klicke „Erlauben“.'),
          el('div', { class: 'disp-wait', style: 'justify-content:center' }, el('span', { class: 'spinner' }), 'Warte auf den PC …'));
        const t0 = Date.now();
        loginPoll = setInterval(async () => {
          try {
            const s = await fetch('/api/pair/status?req=' + enc(d.req) + '&secret=' + enc(d.secret), { cache: 'no-store' }).then(x => x.json());
            if (s.state === 'ok') { clearInterval(loginPoll); saveToken(s.token); verify(); return; }
            if (s.state === 'no' || s.state === 'gone' || Date.now() - t0 > 180000) {
              clearInterval(loginPoll);
              askBox.innerHTML = '';
              askBtn.style.display = '';
              askBtn.disabled = false;
              err.textContent = s.state === 'no' ? 'Am PC abgelehnt.' : 'Keine Antwort vom PC – bitte nochmal versuchen.';
            }
          } catch (e) { }
        }, 1500);
      } catch (x) { err.textContent = failMsg(x); askBtn.disabled = false; }
    } }, ic('phone'), 'Am PC bestätigen');

    // 2) or with the PIN
    const pin = el('input', { class: 'in pin-in', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: '8', placeholder: 'PIN', 'aria-label': 'PIN' });
    const btn = el('button', { class: 'btn block', type: 'submit' }, 'Mit PIN verbinden');
    const form = el('form', { class: 'login', onsubmit: async e => {
      e.preventDefault();
      const v = pin.value.trim();
      if (!v) return pin.focus();
      btn.disabled = true;
      err.textContent = '';
      try {
        if (isLocal()) {
          // a browser on the PC itself is not stored as a device
          const r = await fetch('/api/auth', { headers: { 'X-Pin': v }, cache: 'no-store' });
          const d = await r.json().catch(() => ({}));
          if (!r.ok) throw new Error(d.error || 'Fehler ' + r.status);
          S.pin = v;
          LS.set('pin', v);
        } else await pairWithPin(v);
        verify();
      } catch (x) {
        err.textContent = failMsg(x);
        pin.select();
      }
      btn.disabled = false;
    } },
      el('img', { class: 'logo', src: '/logo-192.png', alt: '' }),
      el('h1', null, 'PC Remote'), sub,
      askBtn, askBox, err,
      el('div', { class: 'or-line' }, el('span', null, 'oder mit PIN')),
      pin, btn,
      el('p', { class: 'hint' }, 'Einmal verbinden reicht – danach öffnet sich PC Remote auf diesem Gerät von selbst. Die PIN steht am PC unter „Handy verbinden“.'));
    app.append(el('div', { class: 'center' }, form));
    fetch('/api/ping', { cache: 'no-store' }).then(r => r.json()).then(d => { sub.textContent = 'Mit „' + d.name + '“ verbinden'; }).catch(() => { });
  }

  async function verify() {
    try {
      const d = await api('/api/auth');
      S.name = d.name;
      S.local = !!d.local;
      S.deviceId = d.device || null;
      // no way in without an account
      if (!Acct.get()) return renderAccountGate();
      startApp();
    } catch (e) {
      if (e.status === 401) return;
      const app = $('#app');
      app.innerHTML = '';
      // PC asleep or PC Remote not started yet: keep trying by itself, like an app does (not after too many wrong PINs)
      const again = el('p', { class: 'hint' }, '');
      app.append(el('div', { class: 'center' }, el('div', { class: 'login' },
        el('img', { class: 'logo', src: '/logo-192.png', alt: '' }),
        el('h1', null, 'Keine Verbindung'),
        el('p', null, e.status === 429 ? e.message : 'Der PC ist gerade nicht erreichbar. Ist er an und läuft PC Remote?'),
        el('button', { class: 'btn primary block', onclick: () => { clearInterval(retryTimer); verify(); } }, ic('refresh'), 'Erneut versuchen'), again)));
      clearInterval(retryTimer);
      if (e.status === 429) return;
      let n = 5;
      retryTimer = setInterval(() => {
        if (!again.isConnected) return clearInterval(retryTimer);
        if (document.hidden) return;
        if (--n > 0) { again.textContent = 'Neuer Versuch in ' + n + ' s …'; return; }
        clearInterval(retryTimer);
        again.textContent = 'Verbinde …';
        verify();
      }, 1000);
    }
  }
  let retryTimer = null;

  // ---------- connect page (shown on the PC itself) ----------

  function loadQr() {
    return new Promise((res, rej) => {
      if (window.qrcode) return res(window.qrcode);
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js';
      s.onload = () => window.qrcode ? res(window.qrcode) : rej(new Error('qr'));
      s.onerror = rej;
      document.head.append(s);
    });
  }

  function qrSvg(qrcode, text) {
    const q = qrcode(0, 'M');
    q.addData(text);
    q.make();
    const n = q.getModuleCount();
    let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + c + ' ' + r + 'h1v1h-1z';
    return '<svg viewBox="-1 -1 ' + (n + 2) + ' ' + (n + 2) + '" shape-rendering="crispEdges"><path fill="#0b0c10" d="' + d + '"/></svg>';
  }

  // Without a target it renders the full-screen page (browser on the PC), with one it fills that element (PC app).
  async function renderConnect(target) {
    const host = target || $('#app');
    host.innerHTML = '';
    let d;
    try {
      const r = await fetch('/api/connect', { cache: 'no-store' });
      d = await r.json();
      if (!r.ok) throw new Error(d.error);
    } catch (e) {
      host.append(el('div', { class: 'center' }, el('div', { class: 'login' },
        el('h1', null, 'Nur am PC'), el('p', null, 'Diese Seite funktioniert nur direkt am PC.'),
        el('a', { class: 'btn primary block', href: '/' }, 'Zur Fernbedienung'))));
      return;
    }
    let url = d.urls[0];
    const qrBox = el('div', { class: 'qr-box' }, el('div', { class: 'qr-fallback' }, 'QR-Code wird erstellt …'));
    const urlText = el('div', { class: 'url' }, url);
    const drawQr = () => {
      urlText.textContent = url;
      loadQr().then(qr => { qrBox.innerHTML = qrSvg(qr, url + '/#pin=' + d.pin); })
        .catch(() => { qrBox.innerHTML = ''; qrBox.append(el('div', { class: 'qr-fallback' }, 'Für den QR-Code braucht der PC Internet. Gib stattdessen die Adresse am Handy ein.')); });
    };
    const urlChips = d.urls.length > 1 ? el('div', { class: 'chips', style: 'margin-top:10px' }, d.urls.map(u =>
      el('button', { class: 'chip' + (u === url ? ' on' : ''), onclick: e => { url = u; [...e.currentTarget.parentNode.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); drawQr(); } }, u.replace('http://', '')))) : null;

    const content = el('div', { class: 'connect' },
      el('div', null, qrBox, urlChips),
      el('div', null,
        target ? null : el('div', { class: 'brand' }, el('img', { src: '/logo-64.png', alt: '' }), el('div', null, el('b', null, 'PC Remote'), el('small', null, d.name))),
        target ? null : el('h1', null, 'Handy verbinden'),
        el('p', { class: 'lead' }, 'Steuere Lautstärke, Musik, Apps, Spiele und Maus vom Handy aus.'),
        el('ol', { class: 'steps' },
          el('li', null, 'Handy ins selbe WLAN wie diesen PC.'),
          el('li', null, 'QR-Code mit der Handy-Kamera scannen – die Fernbedienung öffnet sich und verbindet sich automatisch.'),
          el('li', null, 'Im Browser-Menü „Zum Startbildschirm hinzufügen“ – dann startet sie wie eine App.')),
        el('div', { class: 'card manual' },
          el('div', null, el('div', { class: 'hint' }, 'Oder am Handy eintippen'), urlText),
          el('div', { style: 'text-align:right' }, el('div', { class: 'hint' }, 'PIN'), el('div', { class: 'pin' }, d.pin))),
        el('p', { class: 'hint' }, 'Klappt es nicht? Fragt Windows beim ersten Start nach der Firewall, „Private Netzwerke“ erlauben. Und das Handy darf nicht im Gäste-WLAN sein.'),
        target ? null : el('button', { class: 'btn', style: 'margin-top:8px', onclick: () => { S.pin = d.pin; LS.set('pin', d.pin); history.replaceState(null, '', '/'); verify(); } }, ic('grid'), 'Fernbedienung hier am PC öffnen')));
    host.append(target ? content : el('div', { class: 'center' }, content));
    drawQr();
  }

  // ---------- home-screen app (free, no App Store) ----------

  const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const isIOS = () => /iPhone|iPad|iPod/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);

  // iPhone/iPad show a start picture while the home-screen app opens – the PC draws it in exactly this screen's size
  function addSplash() {
    if (!isIOS() || standalone()) return;
    const r = devicePixelRatio || 1, w = Math.round(screen.width * r), h = Math.round(screen.height * r);
    const mq = o => '(device-width: ' + screen.width + 'px) and (device-height: ' + screen.height + 'px) and (-webkit-device-pixel-ratio: ' + r + ') and (orientation: ' + o + ')';
    document.head.append(el('link', { rel: 'apple-touch-startup-image', media: mq('portrait'), href: '/splash-' + Math.min(w, h) + 'x' + Math.max(w, h) + '.png' }),
      el('link', { rel: 'apple-touch-startup-image', media: mq('landscape'), href: '/splash-' + Math.max(w, h) + 'x' + Math.min(w, h) + '.png' }));
  }

  // step by step, for the browser this device really uses
  function installSheet() {
    const ua = navigator.userAgent, ios = isIOS(), ipad = ios && !/iPhone|iPod/.test(ua), samsung = /SamsungBrowser/i.test(ua);
    const steps = ios ? [
      (ipad ? 'Oben rechts' : 'Unten in der Mitte') + ' in Safari auf „Teilen“ tippen – das Viereck mit dem Pfeil nach oben.',
      '„Zum Home-Bildschirm“ wählen (eventuell etwas nach unten scrollen).',
      'Oben rechts „Hinzufügen“ tippen. Fertig – PC Remote liegt jetzt als App auf deinem Home-Bildschirm.']
      : samsung ? ['Unten rechts auf das Menü (☰) tippen.', '„Seite hinzufügen zu“ → „Startbildschirm“ wählen.', '„Hinzufügen“ tippen – PC Remote liegt jetzt auf dem Startbildschirm.']
      : ['Oben rechts im Browser auf das Menü (⋮) tippen.', '„Zum Startbildschirm hinzufügen“ oder „App installieren“ wählen.', '„Hinzufügen“ bestätigen – PC Remote liegt jetzt auf dem Startbildschirm.'];
    const body = el('div', { class: 'install' },
      el('div', { class: 'install-hero' }, el('img', { src: '/apple-touch-icon.png', alt: '' }),
        el('div', null, el('b', null, 'PC Remote als App'), el('small', null, 'Eigenes Symbol, Vollbild ohne Browserleiste, startet direkt – kostenlos und ohne App Store.'))),
      el('ol', { class: 'steps' }, steps.map(s => el('li', null, s))),
      ios && /CriOS|FxiOS|EdgiOS/i.test(ua) ? el('p', { class: 'hint' }, 'Am zuverlässigsten klappt das in Safari – öffne diese Seite am besten dort.') : null,
      el('div', { class: 'install-note' }, ic('users'), el('span', null, 'Beim ersten Öffnen der App einmal verbinden und anmelden – sie hat ihren eigenen Speicher. Danach geht alles von selbst.')),
      el('div', { class: 'install-note' }, ic('globe'), el('span', null, 'Die App merkt sich die Adresse ' + location.host + '. Damit sie deinen PC immer findet: im Router dem PC eine feste IP-Adresse geben („immer die gleiche IP zuweisen“).')),
      el('div', { class: 'sheet-actions' }, el('button', { class: 'btn primary', onclick: () => close() }, ic('check'), 'Verstanden')));
    const close = sheet('Als App installieren', body);
  }

  // once per phone/tablet in the browser: offer it
  function offerInstall() {
    if (DEV === 'pc' || standalone() || LS.get('installOffered', false)) return;
    setTimeout(() => {
      if ($('.live-update') || sheets.length) return;
      LS.set('installOffered', true);
      const bar = el('div', { class: 'live-update install-bar' }, ic('download'),
        el('span', null, 'PC Remote als App auf den Home-Bildschirm?'),
        el('button', { class: 'btn small primary', onclick: () => { bar.remove(); installSheet(); } }, 'Zeigen'),
        el('button', { class: 'icon-btn', 'aria-label': 'Nein danke', onclick: () => bar.remove() }, ic('x')));
      document.body.append(bar);
    }, 4000);
  }

  // ---------- boot ----------

  async function boot() {
    if (PC) document.body.classList.add('pc');
    document.body.classList.add('dev-' + DEV);
    document.body.classList.toggle('standalone', standalone());
    addSplash();
    applyBackground();
    const m = /pin=(\d+)/.exec(location.hash);
    if (m) {
      S.pin = m[1];
      history.replaceState(null, '', location.pathname + location.search);
    }
    if (location.hash === '#connect' && !PC) return renderConnect();
    if (PC || isLocal()) {
      // on the PC itself: PIN straight from the PC, no device key
      S.token = null;
      if (PC || !S.pin) {
        try {
          const r = await fetch('/api/connect', { cache: 'no-store' });
          if (r.ok) { S.pin = (await r.json()).pin; LS.set('pin', S.pin); }
        } catch (e) { }
      }
    } else {
      // a QR code was scanned although this device is already paired: keep the old key if it still works
      if (m && S.token) {
        const ok = await fetch('/api/auth', { headers: { 'X-Token': S.token }, cache: 'no-store' }).then(r => r.ok).catch(() => false);
        if (!ok) { S.token = null; LS.del('token'); }
      }
      // PIN from the QR code, typed earlier or kept by an older version: pair this device once
      if (!S.token && S.pin) {
        try { await pairWithPin(S.pin); }
        catch (e) {
          S.pin = null;
          LS.del('pin');
          return renderLogin(e.status === 401 ? 'Die PIN stimmt nicht mehr – bitte neu verbinden.' : e.status === 0 || e.message === 'Failed to fetch' ? 'PC nicht erreichbar – läuft PC Remote?' : e.message);
        }
      }
    }
    if (!S.token && !S.pin) return renderLogin();
    verify();
  }

  window.addEventListener('hashchange', () => {
    const h = location.hash.slice(1);
    if (!h) return;
    if (PC && S.pin && $('#view') && TABS.some(t => t[0] === h)) { show(h); history.replaceState(null, '', location.pathname + location.search); }
    else if (h === 'connect' && !PC) renderConnect();
  });
  boot();
})();
