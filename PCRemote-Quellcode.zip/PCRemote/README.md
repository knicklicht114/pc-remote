# PC Remote

Dein Handy als Fernbedienung für den PC – Deck, Medien, Clips, Mixer, Addons.

## Ordner

| Ordner / Datei | Was drin ist |
| --- | --- |
| `PCRemote.exe` + `*.dll` | Das fertige Programm (WebView2-Dateien müssen daneben liegen) |
| `data\` | **Deine persönlichen Daten**: PIN, verbundene Handys, Deck, Addons, Spotify-Anmeldung, Sprachbefehl, Protokoll. Wird nie veröffentlicht. |
| `src\` | Programmcode des PC-Programms (C#) |
| `web\` | Die App-Oberfläche für Handy, Tablet und PC (wird live vom PC geladen) |
| `website\` | Die Webseite (GitHub Pages) und `server\` – der zentrale Server für Konten, VIP und Support |
| `installer\` | Das Setup (`PCRemote-Setup.exe`) |
| `lib\` | WebView2-Bibliotheken zum Bauen |
| `tools\` | GitHub CLI zum Veröffentlichen |
| `dist\` | Fertige Downloads nach `release.ps1` (wird jedes Mal neu erstellt) |

## Bauen und veröffentlichen

- `build.bat` – baut `PCRemote.exe` (PC Remote vorher beenden).
- `release.ps1` – baut Setup, Portable-ZIP, Quellcode-ZIP und die Webseite nach `dist\`.
  Mit `-Publish` kommt alles auf GitHub. Persönliche Dateien und Server-Schlüssel werden vorher geprüft und nie mit hochgeladen.

Die Version steht in `src\Program.cs` (`Version = "…"`).
