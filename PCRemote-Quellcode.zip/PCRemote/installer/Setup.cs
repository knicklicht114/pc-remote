using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

// PC Remote setup: one exe with the program inside (payload.zip). Installs per user – no admin rights needed –
// into %LOCALAPPDATA%\Programs\PC Remote, adds shortcuts and an entry under "Apps & Features".
// The installed copy (Uninstall.exe) removes it again with --uninstall.
namespace PCRemoteSetup
{
    static class Setup
    {
        public const string AppName = "PC Remote";
        const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\PCRemote";
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        // the user's own files – since 1.2.0 in the "data" folder next to PCRemote.exe (older versions: right next to it)
        public static readonly string[] UserFiles = { "config.json", "devices.json", "layout.json", "addons.json", "spotify.json", "clips.json", "ui.json", "voice.json", "voice.wav", "pcremote.log" };

        public static string Version
        {
            get
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("version.txt"))
                    return s == null ? "" : new StreamReader(s).ReadToEnd().Trim();
            }
        }

        public static string DefaultDir { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "PC Remote"); } }
        public static string StartMenuLink { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "PC Remote.lnk"); } }
        public static string DesktopLink { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "PC Remote.lnk"); } }

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 3 && args[0] == "--remove") { Remove(args[1], args[2] == "1"); return; }
            if (args.Contains("--uninstall")) { Uninstall(); return; }
            Application.Run(new SetupForm());
        }

        public static string InstalledDir()
        {
            using (var k = Registry.CurrentUser.OpenSubKey(UninstallKey))
                return k == null ? null : k.GetValue("InstallLocation") as string;
        }

        // Closes every running PC Remote (only one can use the port). Returns the folders they ran from.
        public static List<string> CloseRunning(string dir)
        {
            var dirs = new List<string>();
            foreach (var p in Process.GetProcessesByName("PCRemote"))
            {
                try { dirs.Add(Path.GetDirectoryName(p.MainModule.FileName)); } catch { }
                try { p.Kill(); p.WaitForExit(5000); } catch { }
                p.Dispose();
            }
            return dirs;
        }

        public static void Install(string dir, bool desktop, bool autostart, Action<int, string> progress)
        {
            progress(5, "PC Remote wird beendet …");
            var ranFrom = CloseRunning(dir);
            Directory.CreateDirectory(dir);
            string root = Path.GetFullPath(dir).TrimEnd('\\') + "\\";

            // ran from somewhere else until now (e.g. an unpacked zip): take PIN, paired phones, deck … along
            // (the same folder needs nothing – PC Remote moves its old files into "data" by itself)
            foreach (var from in ranFrom)
            {
                if (string.Equals(Path.GetFullPath(from).TrimEnd('\\') + "\\", root, StringComparison.OrdinalIgnoreCase)) continue;
                foreach (var f in UserFiles.Where(x => x != "pcremote.log"))
                    foreach (var src in new[] { Path.Combine(from, "data", f), Path.Combine(from, f) })
                    {
                        string dst = Path.Combine(root, "data", f);
                        try { if (File.Exists(src) && !File.Exists(dst)) { Directory.CreateDirectory(Path.GetDirectoryName(dst)); File.Copy(src, dst); } } catch { }
                    }
            }

            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
            using (var zip = new ZipArchive(s, ZipArchiveMode.Read))
            {
                int i = 0, n = zip.Entries.Count;
                foreach (var e in zip.Entries)
                {
                    string dest = Path.GetFullPath(Path.Combine(root, e.FullName.Replace('/', '\\')));
                    if (!dest.StartsWith(root, StringComparison.OrdinalIgnoreCase)) continue;
                    if (e.Name.Length == 0) { Directory.CreateDirectory(dest); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(dest));
                    progress(10 + 70 * ++i / Math.Max(1, n), "Kopiere " + e.FullName);
                    for (int tries = 0; ; tries++)
                    {
                        try { e.ExtractToFile(dest, true); break; }
                        catch (IOException) { if (tries > 20) throw; Thread.Sleep(250); } // the old exe may need a moment to unlock
                    }
                }
            }

            progress(85, "Verknüpfungen …");
            string exe = Path.Combine(root, "PCRemote.exe"), un = Path.Combine(root, "Uninstall.exe");
            if (!string.Equals(Path.GetFullPath(Application.ExecutablePath), un, StringComparison.OrdinalIgnoreCase))
                File.Copy(Application.ExecutablePath, un, true);
            Shortcut(StartMenuLink, exe, "", root, "Steuere deinen PC vom Handy");
            if (desktop) Shortcut(DesktopLink, exe, "", root, "Steuere deinen PC vom Handy");
            else if (File.Exists(DesktopLink)) File.Delete(DesktopLink);

            progress(92, "Windows-Einträge …");
            using (var k = Registry.CurrentUser.CreateSubKey(UninstallKey))
            {
                k.SetValue("DisplayName", AppName);
                k.SetValue("DisplayVersion", Version);
                k.SetValue("Publisher", AppName);
                k.SetValue("DisplayIcon", exe);
                k.SetValue("InstallLocation", root);
                k.SetValue("UninstallString", "\"" + un + "\" --uninstall");
                k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                long kb = new DirectoryInfo(root).GetFiles("*", SearchOption.AllDirectories).Sum(f => f.Length) / 1024;
                k.SetValue("EstimatedSize", (int)kb, RegistryValueKind.DWord);
            }
            using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
            {
                if (autostart) k.SetValue("PCRemote", "\"" + exe + "\" --tray");
                else k.DeleteValue("PCRemote", false);
            }
            progress(100, "Fertig");
        }

        static void Shortcut(string lnk, string target, string args, string workDir, string desc)
        {
            var t = Type.GetTypeFromProgID("WScript.Shell");
            object shell = Activator.CreateInstance(t);
            try
            {
                object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                var st = sc.GetType();
                st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { target });
                st.InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { args });
                st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { workDir });
                st.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { desc });
                st.InvokeMember("IconLocation", BindingFlags.SetProperty, null, sc, new object[] { target + ",0" });
                st.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Marshal.FinalReleaseComObject(sc);
            }
            finally { Marshal.FinalReleaseComObject(shell); }
        }

        // Asks, then hands over to a copy in %TEMP%: a running exe can't delete its own folder.
        static void Uninstall()
        {
            string dir = InstalledDir() ?? Path.GetDirectoryName(Application.ExecutablePath);
            if (MessageBox.Show("PC Remote von diesem PC entfernen?", "PC Remote deinstallieren", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            bool wipe = MessageBox.Show("Auch deine Einstellungen löschen?\n\nDazu gehören PIN, verbundene Handys, Deck-Layout und die Spotify-Anmeldung. " +
                "Wähle „Nein“, wenn du PC Remote später wieder installieren willst.\n\nDeine gespeicherten Clips (Videos → PC Remote Clips) bleiben in jedem Fall erhalten.",
                "PC Remote deinstallieren", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
            string me = Path.GetFullPath(Application.ExecutablePath);
            if (!me.StartsWith(Path.GetFullPath(dir).TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase)) { Remove(dir, wipe); return; }
            string tmp = Path.Combine(Path.GetTempPath(), "PCRemote-Uninstall.exe");
            File.Copy(me, tmp, true);
            Process.Start(new ProcessStartInfo(tmp, "--remove \"" + dir.TrimEnd('\\') + "\" " + (wipe ? "1" : "0")) { UseShellExecute = false, WorkingDirectory = Path.GetTempPath() });
        }

        static void Remove(string dir, bool wipe)
        {
            string root = Path.GetFullPath(dir).TrimEnd('\\') + "\\";
            CloseRunning(dir);
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RunKey, true))
                {
                    var v = k == null ? null : k.GetValue("PCRemote") as string;
                    if (v != null && v.IndexOf(root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase) >= 0) k.DeleteValue("PCRemote", false);
                }
            }
            catch { }
            foreach (var l in new[] { StartMenuLink, DesktopLink }) try { if (File.Exists(l)) File.Delete(l); } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(UninstallKey, false); } catch { }

            // program files are exactly what the setup brought (the uninstaller carries the same payload) - plus Uninstall.exe,
            // which may still be closing: try for a few seconds
            var files = new List<string> { Path.Combine(root, "Uninstall.exe") };
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
            using (var zip = new ZipArchive(s, ZipArchiveMode.Read))
                files.AddRange(zip.Entries.Where(x => x.Name.Length > 0).Select(x => Path.Combine(root, x.FullName.Replace('/', '\\'))));
            string data = Path.Combine(root, "data");
            if (wipe && Directory.Exists(root))
            {
                files.AddRange(UserFiles.Concat(new[] { "layout.before-display.json" }).Select(f => Path.Combine(root, f)));
                files.AddRange(Directory.GetFiles(root, "*.bak").Concat(Directory.GetFiles(root, "*.tmp")));
                if (Directory.Exists(data)) files.AddRange(Directory.GetFiles(data));
            }
            for (int tries = 0; tries < 20; tries++)
            {
                files.RemoveAll(f => { try { if (File.Exists(f)) File.Delete(f); return true; } catch { return false; } });
                if (files.Count == 0) break;
                Thread.Sleep(250);
            }
            foreach (var d in new[] { data, Path.Combine(root, "web", "vendor"), Path.Combine(root, "web"), root })
                try { if (Directory.Exists(d) && !Directory.EnumerateFileSystemEntries(d).Any()) Directory.Delete(d); } catch { }

            MessageBox.Show(wipe || !Directory.Exists(root) ? "PC Remote wurde vollständig entfernt." : "PC Remote wurde entfernt. Deine Einstellungen liegen noch in\n" + root,
                "PC Remote", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        // Same logo as the app (gradient tile with a monitor and a play sign).
        public static Bitmap Logo(int s)
        {
            var bmp = new Bitmap(s, s);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                float u = s / 64f;
                using (var path = Round(new RectangleF(0, 0, s, s), 16 * u))
                using (var br = new LinearGradientBrush(new PointF(0, 0), new PointF(s, s), Color.FromArgb(124, 92, 255), Color.FromArgb(34, 211, 238)))
                    g.FillPath(br, path);
                using (var pen = new Pen(Color.White, 3.6f * u) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                {
                    using (var scr = Round(new RectangleF(15 * u, 17 * u, 34 * u, 23 * u), 4 * u)) g.DrawPath(pen, scr);
                    g.DrawLine(pen, 32 * u, 40 * u, 32 * u, 46 * u);
                    g.DrawLine(pen, 24 * u, 48 * u, 40 * u, 48 * u);
                }
                g.FillPolygon(Brushes.White, new[] { new PointF(29 * u, 24.5f * u), new PointF(29 * u, 32.5f * u), new PointF(35.5f * u, 28.5f * u) });
            }
            return bmp;
        }

        public static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    // ---------- the setup window ----------

    sealed class SetupForm : Form
    {
        static readonly Color Bg = Color.FromArgb(11, 12, 16), Card = Color.FromArgb(22, 24, 32), Line = Color.FromArgb(40, 43, 56);
        static readonly Color Text1 = Color.FromArgb(238, 240, 247), Muted = Color.FromArgb(141, 147, 168), Accent = Color.FromArgb(124, 92, 255);

        readonly TextBox path = new TextBox();
        readonly CheckBox desktop = new CheckBox(), autostart = new CheckBox(), launch = new CheckBox();
        readonly Button install = new Button(), cancel = new Button(), browse = new Button();
        readonly Label status = new Label();
        readonly ProgressBar bar = new ProgressBar();
        readonly Panel options = new Panel();
        bool done, busy;

        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        public SetupForm()
        {
            string existing = Setup.InstalledDir();
            Text = "PC Remote " + Setup.Version + " – Installation";
            ClientSize = new Size(560, 430);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Bg;
            ForeColor = Text1;
            Font = new Font("Segoe UI", 10f);
            AutoScaleMode = AutoScaleMode.Dpi;
            using (var b = Setup.Logo(64)) Icon = Icon.FromHandle(b.GetHicon());

            var logo = new PictureBox { Image = Setup.Logo(72), Size = new Size(72, 72), Location = new Point(28, 26) };
            var title = new Label { Text = "PC Remote", Font = new Font("Segoe UI Semibold", 20f), AutoSize = true, Location = new Point(112, 28), ForeColor = Text1 };
            var sub = new Label { Text = "Steuere deinen PC vom Handy – Deck, Medien, Clips, Mixer\nund das Handy als zweiter Bildschirm. Version " + Setup.Version + ".",
                AutoSize = true, Location = new Point(114, 66), ForeColor = Muted };

            options.Location = new Point(28, 120);
            options.Size = new Size(504, 236);
            options.BackColor = Card;

            var where = new Label { Text = "Installieren nach", ForeColor = Muted, AutoSize = true, Location = new Point(16, 14) };
            path.Text = existing ?? Setup.DefaultDir;
            path.Location = new Point(18, 38);
            path.Size = new Size(420, 26);
            path.BackColor = Color.FromArgb(16, 17, 23);
            path.ForeColor = Text1;
            path.BorderStyle = BorderStyle.FixedSingle;
            Style(browse, "…", false);
            browse.Location = new Point(446, 36);
            browse.Size = new Size(40, 29);
            browse.Click += delegate
            {
                using (var d = new FolderBrowserDialog { Description = "Wohin soll PC Remote installiert werden?", SelectedPath = path.Text })
                    if (d.ShowDialog(this) == DialogResult.OK) path.Text = Path.Combine(d.SelectedPath, d.SelectedPath.EndsWith("PC Remote") ? "" : "PC Remote");
            };

            Check(desktop, "Verknüpfung auf dem Desktop", true, 84);
            Check(autostart, "Mit Windows starten (unsichtbar im Tray)", true, 114);
            Check(launch, "PC Remote danach starten", true, 144);
            var fwHint = new Label { Text = "Beim ersten Start fragt Windows, ob Handys im WLAN zugreifen\ndürfen – dann „Zugriff zulassen“ wählen.", AutoSize = true, ForeColor = Muted, Location = new Point(16, 182) };
            options.Controls.AddRange(new Control[] { where, path, browse, desktop, autostart, launch, fwHint });

            bar.Location = new Point(28, 120 + 236 - 30);
            bar.Size = new Size(504, 8);
            bar.Visible = false;
            status.Location = new Point(28, 370);
            status.Size = new Size(240, 48);
            status.ForeColor = Muted;
            status.Text = existing != null ? "PC Remote ist schon installiert – wird aktualisiert.\nDeine Einstellungen bleiben erhalten." : "Keine Admin-Rechte nötig.";

            Style(install, existing != null ? "Aktualisieren" : "Installieren", true);
            install.Location = new Point(392, 372);
            install.Size = new Size(140, 40);
            install.Click += OnInstall;
            Style(cancel, "Abbrechen", false);
            cancel.Location = new Point(276, 372);
            cancel.Size = new Size(108, 40);
            cancel.Click += delegate { Close(); };
            AcceptButton = install;

            Controls.AddRange(new Control[] { logo, title, sub, options, bar, status, install, cancel });
            ActiveControl = install;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            int on = 1;
            try { DwmSetWindowAttribute(Handle, 20, ref on, 4); } catch { } // dark title bar
        }

        // Themed check boxes draw their text dark no matter what; a separate label stays readable on the dark card.
        void Check(CheckBox c, string text, bool on, int y)
        {
            c.Checked = on;
            c.AutoSize = true;
            c.Location = new Point(18, y + 4);
            c.Cursor = Cursors.Hand;
            var l = new Label { Text = text, AutoSize = true, ForeColor = Text1, Location = new Point(38, y + 1), Cursor = Cursors.Hand };
            l.Click += delegate { c.Checked = !c.Checked; };
            options.Controls.Add(l);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            path.Select(path.Text.Length, 0);
        }

        static void Style(Button b, string text, bool primary)
        {
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = primary ? Accent : Line;
            b.FlatAppearance.BorderSize = 1;
            b.BackColor = primary ? Accent : Color.FromArgb(28, 30, 40);
            b.ForeColor = Color.White;
            b.Cursor = Cursors.Hand;
            b.Font = new Font("Segoe UI Semibold", 10f);
        }

        void OnInstall(object sender, EventArgs e)
        {
            if (done)
            {
                Close();
                return;
            }
            if (busy) return;
            string dir = path.Text.Trim();
            if (dir.Length < 4 || !Path.IsPathRooted(dir)) { MessageBox.Show(this, "Bitte einen vollständigen Ordner angeben.", "PC Remote"); return; }
            busy = true;
            install.Enabled = cancel.Enabled = options.Enabled = false;
            bar.Visible = true;
            bool wantDesktop = desktop.Checked, wantAuto = autostart.Checked, wantLaunch = launch.Checked;
            var t = new Thread(() =>
            {
                string error = null, note = "";
                try
                {
                    Setup.Install(dir, wantDesktop, wantAuto, (p, s) => BeginInvoke((Action)(() => { bar.Value = p; status.Text = s; })));
                    if (wantLaunch) Process.Start(new ProcessStartInfo(Path.Combine(dir, "PCRemote.exe")) { WorkingDirectory = dir });
                }
                catch (Exception ex) { error = ex.Message; }
                BeginInvoke((Action)(() =>
                {
                    busy = false;
                    if (error != null)
                    {
                        status.Text = "Fehler: " + error;
                        install.Enabled = cancel.Enabled = options.Enabled = true;
                        return;
                    }
                    done = true;
                    cancel.Visible = false;
                    status.Width = 350;
                    status.ForeColor = Color.FromArgb(52, 211, 153);
                    status.Text = "Fertig! PC Remote findest du im Startmenü" + (wantAuto ? " und unten rechts im Tray." : ".") + note;
                    install.Text = "Schließen";
                    install.Enabled = true;
                }));
            }) { IsBackground = true };
            t.Start();
        }
    }
}
