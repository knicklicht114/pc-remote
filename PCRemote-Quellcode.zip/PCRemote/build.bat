@echo off
setlocal
cd /d "%~dp0"
set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FW%\csc.exe" set "FW=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
if not exist "%FW%\csc.exe" (
  echo .NET Framework 4 Compiler nicht gefunden.
  exit /b 1
)
set "WM=%WINDIR%\System32\WinMetadata"
set "ICON="
if exist app.ico set "ICON=/win32icon:app.ico"

"%FW%\csc.exe" /nologo /target:winexe /platform:x64 /optimize+ /unsafe /out:PCRemote.exe %ICON% ^
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Web.Extensions.dll ^
  /r:"%FW%\System.Runtime.dll" /r:"%FW%\WPF\UIAutomationClient.dll" /r:"%FW%\WPF\UIAutomationTypes.dll" /r:"%FW%\WPF\WindowsBase.dll" ^
  /r:"%WM%\Windows.Foundation.winmd" /r:"%WM%\Windows.Media.winmd" /r:"%WM%\Windows.Storage.winmd" ^
  /r:lib\Microsoft.Web.WebView2.Core.dll /r:lib\Microsoft.Web.WebView2.WinForms.dll ^
  src\*.cs
if errorlevel 1 exit /b 1

rem WebView2 libraries have to sit next to the exe
copy /y lib\*.dll . >nul

rem First build: create the app icon with the program itself, then build once more with it
if not exist app.ico (
  start /wait "" PCRemote.exe --make-ico app.ico
  if exist app.ico call "%~f0"
)
exit /b 0
