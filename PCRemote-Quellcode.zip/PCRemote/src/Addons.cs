using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace PCRemote
{
    static class Store
    {
        static readonly object L = new object();

        public static string Read(string path)
        {
            lock (L) return File.Exists(path) ? File.ReadAllText(path, Encoding.UTF8) : null;
        }

        // Write via temp file and keep one backup, so a crash never leaves a half-written file.
        public static void Write(string path, string json)
        {
            lock (L)
            {
                string tmp = path + ".tmp";
                File.WriteAllText(tmp, json, new UTF8Encoding(false));
                if (File.Exists(path)) File.Copy(path, path + ".bak", true);
                File.Copy(tmp, path, true);
                File.Delete(tmp);
            }
        }
    }

    // Addon settings + custom buttons, edited from the app. The app defines the addons; the PC stores them
    // and reads the few settings it needs itself (e.g. Discord fallback keybinds).
    static class Addons
    {
        static string path;
        static Dictionary<string, object> data = new Dictionary<string, object>();

        public static void Init(string p)
        {
            path = p;
            try
            {
                string s = Store.Read(p);
                if (!string.IsNullOrWhiteSpace(s)) data = J.Obj(s);
            }
            catch (Exception ex) { Log.Write("addons load: " + ex.Message); }
        }

        public static string Raw()
        {
            string s = Store.Read(path);
            return string.IsNullOrWhiteSpace(s) ? "{}" : s;
        }

        public static void Save(string json)
        {
            var d = J.Parse(json) as Dictionary<string, object>;
            if (d == null) throw new ArgumentException("Ungültige Addon-Daten");
            Store.Write(path, json);
            data = d;
        }

        public static string Setting(string addon, string key)
        {
            var d = data;
            object s, a;
            if (!d.TryGetValue("settings", out s) || !(s is Dictionary<string, object>)) return null;
            if (!((Dictionary<string, object>)s).TryGetValue(addon, out a)) return null;
            return J.Str(a as Dictionary<string, object>, key);
        }
    }

    // Per-app controls that work for every program: keys into its window, priority, window ops, live info.
    static class AppCtl
    {
        public static List<string> Procs(Dictionary<string, object> a)
        {
            var list = new List<string>();
            foreach (var p in J.StrList(a, "procs"))
                foreach (var part in p.Split(','))
                {
                    string n = part.Trim();
                    if (n.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) n = n.Substring(0, n.Length - 4);
                    if (n.Length > 0) list.Add(n);
                }
            string id = J.Str(a, "id");
            if (list.Count == 0 && !string.IsNullOrEmpty(id)) list.AddRange(Apps.ProcsOf(id));
            if (list.Count == 0) throw new ArgumentException("Keine App angegeben");
            return list;
        }

        // "ctrl+t" or chords separated by spaces: "ctrl+k ctrl+s"
        public static void SendKeys(List<string> procs, string keys, bool back)
        {
            if (string.IsNullOrWhiteSpace(keys)) throw new ArgumentException("Keine Taste angegeben");
            IntPtr prev = WindowList.Foreground();
            if (!WindowList.FocusProcs(procs)) throw new InvalidOperationException("Die App hat gerade kein offenes Fenster");
            Thread.Sleep(180);
            foreach (string chord in keys.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                Input.Hotkey(chord);
                Thread.Sleep(60);
            }
            if (back && prev != IntPtr.Zero)
            {
                Thread.Sleep(120);
                WindowList.Focus(prev);
            }
        }

        static readonly Dictionary<string, ProcessPriorityClass> Prio = new Dictionary<string, ProcessPriorityClass> {
            { "idle", ProcessPriorityClass.Idle }, { "below", ProcessPriorityClass.BelowNormal }, { "normal", ProcessPriorityClass.Normal },
            { "above", ProcessPriorityClass.AboveNormal }, { "high", ProcessPriorityClass.High } };

        public static string SetPriority(List<string> procs, string level)
        {
            ProcessPriorityClass pc;
            if (!Prio.TryGetValue(level ?? "", out pc)) throw new ArgumentException("Unbekannte Priorität");
            int n = 0, denied = 0;
            foreach (string name in procs)
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try { p.PriorityClass = pc; n++; }
                    catch { denied++; }
                    finally { p.Dispose(); }
                }
            if (n == 0 && denied > 0) throw new InvalidOperationException("Windows erlaubt das für dieses Programm nicht (Anti-Cheat oder Admin-Rechte)");
            if (n == 0) throw new InvalidOperationException("Läuft gerade nicht");
            return "Priorität gesetzt";
        }

        public static void Windows(List<string> procs, string op)
        {
            var hs = WindowList.HandlesFor(procs);
            if (hs.Count == 0) throw new InvalidOperationException("Kein offenes Fenster");
            foreach (var h in hs) WindowList.DoHandle(h, op);
        }

        class Sample { public TimeSpan Cpu; public DateTime At; }
        static readonly Dictionary<string, Sample> samples = new Dictionary<string, Sample>();

        public static object Info(List<string> procs)
        {
            int count = 0;
            long ram = 0;
            var cpu = TimeSpan.Zero;
            DateTime? start = null;
            string prio = null;
            foreach (string name in procs.Distinct(StringComparer.OrdinalIgnoreCase))
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try
                    {
                        count++;
                        ram += p.WorkingSet64;
                        cpu += p.TotalProcessorTime;
                        var st = p.StartTime;
                        if (!start.HasValue || st < start.Value) start = st;
                        if (prio == null && p.MainWindowHandle != IntPtr.Zero) prio = PrioName(p.PriorityClass);
                    }
                    catch { }
                    finally { p.Dispose(); }
                }

            double? cpuPct = null;
            string key = string.Join(",", procs.ToArray()).ToLowerInvariant();
            lock (samples)
            {
                Sample s;
                var now = DateTime.UtcNow;
                if (samples.TryGetValue(key, out s) && count > 0)
                {
                    double ms = (now - s.At).TotalMilliseconds;
                    if (ms > 200) cpuPct = Math.Max(0, Math.Min(100, (cpu - s.Cpu).TotalMilliseconds / (ms * Environment.ProcessorCount) * 100));
                }
                samples[key] = new Sample { Cpu = cpu, At = now };
                if (samples.Count > 200) samples.Clear();
            }

            object audio = null;
            string audioProc = null;
            try
            {
                var states = (Dictionary<string, object>)Audio.AppStates();
                foreach (string name in procs)
                {
                    object st;
                    if (states.TryGetValue(name.ToLowerInvariant(), out st)) { audio = st; audioProc = name.ToLowerInvariant(); break; }
                }
            }
            catch { }

            return new Dictionary<string, object> {
                { "running", count > 0 }, { "count", count }, { "ram", Math.Round(ram / 1048576.0) },
                { "cpu", cpuPct.HasValue ? (object)Math.Round(cpuPct.Value, 1) : null }, { "priority", prio },
                { "since", start.HasValue ? (object)(long)(DateTime.Now - start.Value).TotalSeconds : null },
                { "windows", WindowList.ForProcs(procs) }, { "audio", audio }, { "audioProc", audioProc }, { "procs", procs } };
        }

        static string PrioName(ProcessPriorityClass c)
        {
            foreach (var kv in Prio) if (kv.Value == c) return kv.Key;
            return c == ProcessPriorityClass.RealTime ? "realtime" : "normal";
        }

        // ---------- launchers ----------

        static string RiotClient()
        {
            string pd = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            string json = Path.Combine(pd, @"Riot Games\RiotClientInstalls.json");
            try
            {
                if (File.Exists(json))
                {
                    var d = J.Obj(File.ReadAllText(json));
                    foreach (string k in new[] { "rc_default", "rc_live", "rc_beta" })
                    {
                        string p = J.Str(d, k);
                        if (!string.IsNullOrEmpty(p) && File.Exists(p.Replace('/', '\\'))) return p.Replace('/', '\\');
                    }
                }
            }
            catch (Exception ex) { Log.Write("riot: " + ex.Message); }
            foreach (string drive in new[] { "C", "D", "E" })
            {
                string p = drive + @":\Riot Games\Riot Client\RiotClientServices.exe";
                if (File.Exists(p)) return p;
            }
            return null;
        }

        public static string Riot(string product, string patchline)
        {
            string exe = RiotClient();
            if (exe == null) throw new InvalidOperationException("Riot Client nicht gefunden");
            if (string.IsNullOrEmpty(product)) product = "valorant";
            var psi = new ProcessStartInfo(exe, "--launch-product=" + product + " --launch-patchline=" + (string.IsNullOrEmpty(patchline) ? "live" : patchline));
            psi.UseShellExecute = false;
            psi.WorkingDirectory = Path.GetDirectoryName(exe);
            Process.Start(psi).Dispose();
            return product == "valorant" ? "VALORANT wird gestartet" : product == "league_of_legends" ? "League of Legends wird gestartet" : "Wird gestartet";
        }
    }
}
