using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace PCRemote
{
    // Checks GitHub for a newer release and installs it (runs the downloaded setup, which updates in place and relaunches).
    static class Update
    {
        public const string Repo = "knicklicht114/pc-remote";

        static readonly object L = new object();
        static string latest, notes, error;
        static DateTime checkedAt = DateTime.MinValue;
        static bool busy;
        public static string State = "idle"; // idle | downloading | ready | error

        static string Api(string path)
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            var req = (HttpWebRequest)WebRequest.Create("https://api.github.com/repos/" + Repo + path);
            req.UserAgent = "PCRemote/" + Program.Version;
            req.Accept = "application/vnd.github+json";
            req.Timeout = 15000;
            using (var res = (HttpWebResponse)req.GetResponse())
            using (var sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
                return sr.ReadToEnd();
        }

        // Compares "2.1" / "v2.10.1": higher number wins, more parts win on a tie.
        public static bool IsNewer(string a, string b)
        {
            int[] pa = Parse(a), pb = Parse(b);
            for (int i = 0; i < Math.Max(pa.Length, pb.Length); i++)
            {
                int x = i < pa.Length ? pa[i] : 0, y = i < pb.Length ? pb[i] : 0;
                if (x != y) return x > y;
            }
            return false;
        }

        static int[] Parse(string v)
        {
            var m = Regex.Matches(v ?? "", @"\d+");
            var r = new int[m.Count];
            for (int i = 0; i < m.Count; i++) int.TryParse(m[i].Value, out r[i]);
            return r;
        }

        // Asks GitHub at most every 30 min (force=true ignores that).
        public static void Refresh(bool force)
        {
            lock (L) { if (busy || (!force && (DateTime.UtcNow - checkedAt).TotalMinutes < 30)) return; busy = true; }
            try
            {
                var d = J.Obj(Api("/releases/latest"));
                string tag = J.Str(d, "tag_name", "");
                lock (L) { latest = tag.TrimStart('v', 'V'); notes = J.Str(d, "body", ""); error = null; checkedAt = DateTime.UtcNow; }
            }
            catch (Exception ex) { lock (L) { error = ex.Message; checkedAt = DateTime.UtcNow; } Log.Warn("update check: " + ex.Message); }
            finally { lock (L) busy = false; }
        }

        public static object Status()
        {
            lock (L)
            {
                bool avail = latest != null && IsNewer(latest, Program.Version);
                return new Dictionary<string, object> {
                    { "current", Program.Version }, { "latest", latest }, { "available", avail },
                    { "notes", avail ? notes : null }, { "state", State }, { "error", error },
                    { "url", "https://github.com/" + Repo + "/releases/latest" } };
            }
        }

        // Downloads the newest setup and runs it; the installer closes this app, updates its folder and relaunches.
        public static void Install()
        {
            lock (L) { if (State == "downloading") return; State = "downloading"; error = null; }
            try
            {
                string file = Path.Combine(Path.GetTempPath(), "PCRemote-Update-Setup.exe");
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                var req = (HttpWebRequest)WebRequest.Create("https://github.com/" + Repo + "/releases/latest/download/PCRemote-Setup.exe");
                req.UserAgent = "PCRemote/" + Program.Version;
                req.Timeout = 30000;
                req.ReadWriteTimeout = 120000;
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var body = res.GetResponseStream())
                using (var fs = File.Create(file))
                    body.CopyTo(fs);
                if (new FileInfo(file).Length < 100000) throw new Exception("Download unvollständig");
                Log.Write("update: " + (latest ?? "?") + " heruntergeladen, Setup wird gestartet");
                lock (L) State = "ready";
                // /silent would be nicer, but the setup window lets the user see the progress and confirm
                Process.Start(new ProcessStartInfo(file) { UseShellExecute = true }).Dispose();
            }
            catch (Exception ex)
            {
                lock (L) { State = "error"; error = ex.Message; }
                Log.Error("update install: " + ex.Message);
                throw;
            }
        }

        // On start and then every few hours, so the app notices a new version on its own.
        public static void StartBackground()
        {
            var t = new Thread(() =>
            {
                while (!Program.Exiting)
                {
                    try { Refresh(true); } catch { }
                    for (int i = 0; i < 360 && !Program.Exiting; i++) Thread.Sleep(1000); // ~6 h
                }
            });
            t.IsBackground = true;
            t.Name = "update-check";
            t.Start();
        }
    }
}
