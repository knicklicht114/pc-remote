using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

namespace PCRemote
{
    static class J
    {
        static JavaScriptSerializer Make()
        {
            var s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            s.RecursionLimit = 256;
            return s;
        }

        public static string Ser(object o) { return Make().Serialize(o); }
        public static object Parse(string s) { return Make().DeserializeObject(s == null ? s : s.TrimStart('﻿')); }

        public static Dictionary<string, object> Obj(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return new Dictionary<string, object>();
            return Parse(s) as Dictionary<string, object> ?? new Dictionary<string, object>();
        }

        public static bool Has(Dictionary<string, object> d, string k)
        {
            object o;
            return d != null && d.TryGetValue(k, out o) && o != null;
        }

        public static string Str(Dictionary<string, object> d, string k, string def = null)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null) return Convert.ToString(o, CultureInfo.InvariantCulture);
            return def;
        }

        public static double Num(Dictionary<string, object> d, string k, double def = 0)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null)
            {
                try { return Convert.ToDouble(o, CultureInfo.InvariantCulture); } catch { }
            }
            return def;
        }

        public static bool Bool(Dictionary<string, object> d, string k, bool def = false)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null)
            {
                if (o is bool) return (bool)o;
                string s = o.ToString().ToLowerInvariant();
                return s == "true" || s == "1";
            }
            return def;
        }

        public static List<string> StrList(Dictionary<string, object> d, string k)
        {
            var list = new List<string>();
            object o;
            if (d == null || !d.TryGetValue(k, out o) || o == null) return list;
            if (o is string) { list.Add((string)o); return list; }
            var e = o as IEnumerable;
            if (e != null) foreach (var x in e) if (x != null) list.Add(x.ToString());
            return list;
        }
    }

    static class Log
    {
        static string path;
        static readonly object L = new object();

        public static void Init(string p)
        {
            path = p;
            try { if (File.Exists(p) && new FileInfo(p).Length > 1000000) File.Delete(p); } catch { }
        }

        public static void Write(string msg)
        {
            if (path == null) return;
            try
            {
                lock (L) File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
            }
            catch { }
        }
    }

    class Config
    {
        public int Port = 8765;
        public string Pin;
        public bool Welcomed;
        public int WinX, WinY, WinW, WinH;
        public bool WinMax;
        string path;

        public static Config Load(string path)
        {
            var c = new Config();
            c.path = path;
            try
            {
                if (File.Exists(path))
                {
                    var d = J.Obj(File.ReadAllText(path));
                    c.Port = (int)J.Num(d, "port", 8765);
                    c.Pin = J.Str(d, "pin", null);
                    c.Welcomed = J.Bool(d, "welcomed", false);
                    c.WinX = (int)J.Num(d, "winX"); c.WinY = (int)J.Num(d, "winY");
                    c.WinW = (int)J.Num(d, "winW"); c.WinH = (int)J.Num(d, "winH");
                    c.WinMax = J.Bool(d, "winMax");
                }
            }
            catch (Exception ex) { Log.Write("config: " + ex.Message); }

            if (string.IsNullOrEmpty(c.Pin) || c.Pin.Length < 4)
            {
                var b = new byte[4];
                using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
                c.Pin = ((BitConverter.ToUInt32(b, 0) % 900000) + 100000).ToString();
            }
            c.Save();
            return c;
        }

        public void Save()
        {
            try
            {
                File.WriteAllText(path, "{\r\n  \"port\": " + Port + ",\r\n  \"pin\": " + J.Ser(Pin) +
                    ",\r\n  \"welcomed\": " + (Welcomed ? "true" : "false") +
                    ",\r\n  \"winX\": " + WinX + ", \"winY\": " + WinY + ", \"winW\": " + WinW + ", \"winH\": " + WinH +
                    ", \"winMax\": " + (WinMax ? "true" : "false") + "\r\n}\r\n");
            }
            catch (Exception ex) { Log.Write("config save: " + ex.Message); }
        }

        public void NewPin()
        {
            var b = new byte[4];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            Pin = ((BitConverter.ToUInt32(b, 0) % 900000) + 100000).ToString();
            Save();
        }
    }

    static class Net
    {
        public static List<string> LanUrls(int port)
        {
            var good = new List<string>();
            var other = new List<string>();
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    string desc = (ni.Description + " " + ni.Name).ToLowerInvariant();
                    bool virt = desc.Contains("virtual") || desc.Contains("vmware") || desc.Contains("hyper-v") ||
                                desc.Contains("vpn") || desc.Contains("tap-") || desc.Contains("wsl");
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                        string ip = ua.Address.ToString();
                        if (ip.StartsWith("169.254.") || ip.StartsWith("127.")) continue;
                        (virt ? other : good).Add("http://" + ip + ":" + port);
                    }
                }
            }
            catch (Exception ex) { Log.Write("net: " + ex.Message); }
            if (good.Count == 0) good.AddRange(other);
            if (good.Count == 0) good.Add("http://" + Dns.GetHostName() + ":" + port);
            return good;
        }
    }

    static class Logo
    {
        public static Bitmap Draw(int s, bool fullBleed)
        {
            var bmp = new Bitmap(s, s, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                float u = s / 64f;
                using (var path = Round(new RectangleF(0, 0, s, s), fullBleed ? 0.01f : 16 * u))
                using (var br = new LinearGradientBrush(new PointF(0, 0), new PointF(s, s),
                    Color.FromArgb(124, 92, 255), Color.FromArgb(34, 211, 238)))
                    g.FillPath(br, path);

                using (var pen = new Pen(Color.White, 3.6f * u))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    pen.LineJoin = LineJoin.Round;
                    using (var scr = Round(new RectangleF(15 * u, 17 * u, 34 * u, 23 * u), 4 * u)) g.DrawPath(pen, scr);
                    g.DrawLine(pen, 32 * u, 40 * u, 32 * u, 46 * u);
                    g.DrawLine(pen, 24 * u, 48 * u, 40 * u, 48 * u);
                }
                using (var tri = new SolidBrush(Color.White))
                    g.FillPolygon(tri, new[] { new PointF(29 * u, 24.5f * u), new PointF(29 * u, 32.5f * u), new PointF(35.5f * u, 28.5f * u) });
            }
            return bmp;
        }

        static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static Icon MakeIcon()
        {
            return MakeIcon(Math.Max(16, System.Windows.Forms.SystemInformation.SmallIconSize.Width));
        }

        public static Icon MakeIcon(int s)
        {
            using (var b = Draw(s, false)) return Icon.FromHandle(b.GetHicon());
        }

        // Multi-size .ico (PNG entries) used as the exe icon at build time.
        public static void WriteIco(string file)
        {
            int[] sizes = { 16, 24, 32, 48, 64, 128, 256 };
            var pngs = new byte[sizes.Length][];
            for (int i = 0; i < sizes.Length; i++) pngs[i] = Png(sizes[i], false);
            using (var fs = File.Create(file))
            using (var w = new BinaryWriter(fs))
            {
                w.Write((short)0); w.Write((short)1); w.Write((short)sizes.Length);
                int offset = 6 + 16 * sizes.Length;
                for (int i = 0; i < sizes.Length; i++)
                {
                    w.Write((byte)(sizes[i] >= 256 ? 0 : sizes[i])); w.Write((byte)(sizes[i] >= 256 ? 0 : sizes[i]));
                    w.Write((byte)0); w.Write((byte)0); w.Write((short)1); w.Write((short)32);
                    w.Write(pngs[i].Length); w.Write(offset);
                    offset += pngs[i].Length;
                }
                foreach (var p in pngs) w.Write(p);
            }
        }

        public static byte[] Png(int s, bool fullBleed)
        {
            using (var b = Draw(s, fullBleed))
            using (var ms = new MemoryStream())
            {
                b.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }
    }
}
