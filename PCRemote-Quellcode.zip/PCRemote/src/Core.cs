using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

namespace PCRemote
{
    static class J
    {
        static JavaScriptSerializer Make()
        {
            var s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            s.RecursionLimit = 256;
            return s;
        }

        public static string Ser(object o) { return Make().Serialize(o); }
        public static object Parse(string s) { return Make().DeserializeObject(s == null ? s : s.TrimStart('﻿')); }

        public static Dictionary<string, object> Obj(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return new Dictionary<string, object>();
            return Parse(s) as Dictionary<string, object> ?? new Dictionary<string, object>();
        }

        public static bool Has(Dictionary<string, object> d, string k)
        {
            object o;
            return d != null && d.TryGetValue(k, out o) && o != null;
        }

        public static string Str(Dictionary<string, object> d, string k, string def = null)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null) return Convert.ToString(o, CultureInfo.InvariantCulture);
            return def;
        }

        public static double Num(Dictionary<string, object> d, string k, double def = 0)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null)
            {
                try { return Convert.ToDouble(o, CultureInfo.InvariantCulture); } catch { }
            }
            return def;
        }

        public static bool Bool(Dictionary<string, object> d, string k, bool def = false)
        {
            object o;
            if (d != null && d.TryGetValue(k, out o) && o != null)
            {
                if (o is bool) return (bool)o;
                string s = o.ToString().ToLowerInvariant();
                return s == "true" || s == "1";
            }
            return def;
        }

        public static List<string> StrList(Dictionary<string, object> d, string k)
        {
            var list = new List<string>();
            object o;
            if (d == null || !d.TryGetValue(k, out o) || o == null) return list;
            if (o is string) { list.Add((string)o); return list; }
            var e = o as IEnumerable;
            if (e != null) foreach (var x in e) if (x != null) list.Add(x.ToString());
            return list;
        }
    }

    // Writes to pcremote.log (rotated, one old copy kept) and keeps the last lines in memory for the in-app log view.
    static class Log
    {
        public struct Entry { public long T; public string Level, Msg; }

        static string path;
        static readonly object L = new object();
        static readonly Queue<Entry> recent = new Queue<Entry>();
        const int Keep = 400;

        public static void Init(string p)
        {
            path = p;
            try
            {
                // keep one previous log instead of throwing it away, so a crash from before is still readable
                if (File.Exists(p) && new FileInfo(p).Length > 1000000)
                {
                    string old = p + ".1";
                    if (File.Exists(old)) File.Delete(old);
                    File.Move(p, old);
                }
            }
            catch { }
            Write("--- PC Remote " + Program.Version + " gestartet ---");
        }

        public static void Write(string msg) { Add("info", msg); }
        public static void Warn(string msg) { Add("warn", msg); }
        public static void Error(string msg) { Add("error", msg); }

        static void Add(string level, string msg)
        {
            var e = new Entry { T = Now(), Level = level, Msg = msg };
            lock (L)
            {
                recent.Enqueue(e);
                while (recent.Count > Keep) recent.Dequeue();
                if (path != null)
                {
                    try { File.AppendAllText(path, Line(e) + Environment.NewLine); } catch { }
                }
            }
        }

        static long Now() { return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds; }

        static string Line(Entry e)
        {
            string time = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(e.T).ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss");
            string tag = e.Level == "info" ? "" : "[" + e.Level.ToUpperInvariant() + "] ";
            return time + "  " + tag + e.Msg;
        }

        // For the in-app log view (newest first, optionally only warnings/errors).
        public static List<object> Recent(bool problemsOnly)
        {
            lock (L)
                return recent.Reverse().Where(e => !problemsOnly || e.Level != "info")
                    .Select(e => (object)new Dictionary<string, object> { { "t", e.T }, { "level", e.Level }, { "msg", e.Msg } }).ToList();
        }
    }

    class Config
    {
        public int Port = 8765;
        public string Pin;
        public bool Welcomed;
        public int WinX, WinY, WinW, WinH;
        public bool WinMax;
        public bool ReportApps;     // opt-in: send names of found apps anonymously so the author can add support
        public bool ReportAsked;    // whether we already asked the user about it
        string path;

        public static Config Load(string path)
        {
            var c = new Config();
            c.path = path;
            try
            {
                if (File.Exists(path))
                {
                    var d = J.Obj(File.ReadAllText(path));
                    c.Port = (int)J.Num(d, "port", 8765);
                    c.Pin = J.Str(d, "pin", null);
                    c.Welcomed = J.Bool(d, "welcomed", false);
                    c.WinX = (int)J.Num(d, "winX"); c.WinY = (int)J.Num(d, "winY");
                    c.WinW = (int)J.Num(d, "winW"); c.WinH = (int)J.Num(d, "winH");
                    c.WinMax = J.Bool(d, "winMax");
                    c.ReportApps = J.Bool(d, "reportApps", false);
                    c.ReportAsked = J.Bool(d, "reportAsked", false);
                }
            }
            catch (Exception ex) { Log.Write("config: " + ex.Message); }

            if (string.IsNullOrEmpty(c.Pin) || c.Pin.Length < 4)
            {
                var b = new byte[4];
                using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
                c.Pin = ((BitConverter.ToUInt32(b, 0) % 900000) + 100000).ToString();
            }
            c.Save();
            return c;
        }

        public void Save()
        {
            try
            {
                File.WriteAllText(path, "{\r\n  \"port\": " + Port + ",\r\n  \"pin\": " + J.Ser(Pin) +
                    ",\r\n  \"welcomed\": " + (Welcomed ? "true" : "false") +
                    ",\r\n  \"winX\": " + WinX + ", \"winY\": " + WinY + ", \"winW\": " + WinW + ", \"winH\": " + WinH +
                    ", \"winMax\": " + (WinMax ? "true" : "false") +
                    ",\r\n  \"reportApps\": " + (ReportApps ? "true" : "false") +
                    ", \"reportAsked\": " + (ReportAsked ? "true" : "false") + "\r\n}\r\n");
            }
            catch (Exception ex) { Log.Write("config save: " + ex.Message); }
        }

        public void NewPin()
        {
            var b = new byte[4];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            Pin = ((BitConverter.ToUInt32(b, 0) % 900000) + 100000).ToString();
            Save();
        }
    }

    static class Net
    {
        public static List<string> LanUrls(int port)
        {
            var good = new List<string>();
            var other = new List<string>();
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    string desc = (ni.Description + " " + ni.Name).ToLowerInvariant();
                    bool virt = desc.Contains("virtual") || desc.Contains("vmware") || desc.Contains("hyper-v") ||
                                desc.Contains("vpn") || desc.Contains("tap-") || desc.Contains("wsl");
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                        string ip = ua.Address.ToString();
                        if (ip.StartsWith("169.254.") || ip.StartsWith("127.")) continue;
                        (virt ? other : good).Add("http://" + ip + ":" + port);
                    }
                }
            }
            catch (Exception ex) { Log.Write("net: " + ex.Message); }
            if (good.Count == 0) good.AddRange(other);
            if (good.Count == 0) good.Add("http://" + Dns.GetHostName() + ":" + port);
            return good;
        }
    }

    static class Logo
    {
        // The real logo (assets\logo-icon.png and logo-wordmark.png, built into the exe); the drawn one below is only the fallback.
        static readonly Bitmap icon = Res("logo-icon.png"), wordmark = Res("logo-wordmark.png");

        static Bitmap Res(string name)
        {
            try
            {
                using (var s = typeof(Logo).Assembly.GetManifestResourceStream(name))
                {
                    if (s == null) return null;
                    using (var tmp = new Bitmap(s)) return new Bitmap(tmp); // a copy: GDI+ would otherwise need the stream forever
                }
            }
            catch { return null; }
        }

        public static Bitmap Draw(int s, bool fullBleed)
        {
            var bmp = new Bitmap(s, s, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                float u = s / 64f;
                if (icon != null)
                {
                    // scaled once, then painted through the rounded shape – so the corners stay smooth
                    using (var scaled = new Bitmap(s, s, PixelFormat.Format32bppArgb))
                    {
                        using (var sg = Graphics.FromImage(scaled))
                        {
                            sg.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            sg.PixelOffsetMode = PixelOffsetMode.HighQuality;
                            lock (icon) sg.DrawImage(icon, new Rectangle(0, 0, s, s)); // one picture, many web requests: one at a time
                        }
                        using (var path = Round(new RectangleF(0, 0, s, s), fullBleed ? 0.01f : 16 * u))
                        using (var tb = new TextureBrush(scaled))
                            g.FillPath(tb, path);
                    }
                    return bmp;
                }
                using (var path = Round(new RectangleF(0, 0, s, s), fullBleed ? 0.01f : 16 * u))
                using (var br = new LinearGradientBrush(new PointF(0, 0), new PointF(s, s),
                    Color.FromArgb(124, 92, 255), Color.FromArgb(34, 211, 238)))
                    g.FillPath(br, path);

                using (var pen = new Pen(Color.White, 3.6f * u))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    pen.LineJoin = LineJoin.Round;
                    using (var scr = Round(new RectangleF(15 * u, 17 * u, 34 * u, 23 * u), 4 * u)) g.DrawPath(pen, scr);
                    g.DrawLine(pen, 32 * u, 40 * u, 32 * u, 46 * u);
                    g.DrawLine(pen, 24 * u, 48 * u, 40 * u, 48 * u);
                }
                using (var tri = new SolidBrush(Color.White))
                    g.FillPolygon(tri, new[] { new PointF(29 * u, 24.5f * u), new PointF(29 * u, 32.5f * u), new PointF(35.5f * u, 28.5f * u) });
            }
            return bmp;
        }

        static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static Icon MakeIcon()
        {
            return MakeIcon(Math.Max(16, System.Windows.Forms.SystemInformation.SmallIconSize.Width));
        }

        public static Icon MakeIcon(int s)
        {
            using (var b = Draw(s, false)) return Icon.FromHandle(b.GetHicon());
        }

        // Multi-size .ico (PNG entries) used as the exe icon at build time.
        public static void WriteIco(string file)
        {
            int[] sizes = { 16, 24, 32, 48, 64, 128, 256 };
            var pngs = new byte[sizes.Length][];
            for (int i = 0; i < sizes.Length; i++) pngs[i] = Png(sizes[i], false);
            using (var fs = File.Create(file))
            using (var w = new BinaryWriter(fs))
            {
                w.Write((short)0); w.Write((short)1); w.Write((short)sizes.Length);
                int offset = 6 + 16 * sizes.Length;
                for (int i = 0; i < sizes.Length; i++)
                {
                    w.Write((byte)(sizes[i] >= 256 ? 0 : sizes[i])); w.Write((byte)(sizes[i] >= 256 ? 0 : sizes[i]));
                    w.Write((byte)0); w.Write((byte)0); w.Write((short)1); w.Write((short)32);
                    w.Write(pngs[i].Length); w.Write(offset);
                    offset += pngs[i].Length;
                }
                foreach (var p in pngs) w.Write(p);
            }
        }

        public static byte[] Png(int s, bool fullBleed)
        {
            using (var b = Draw(s, fullBleed))
            using (var ms = new MemoryStream())
            {
                b.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        // Start screen of the home-screen app on iPhone/iPad (iOS shows it while the app opens): the app's dark
        // background with the logo and the name in the middle, in exactly the device's pixel size.
        public static byte[] Splash(int w, int h)
        {
            using (var bmp = new Bitmap(w, h, PixelFormat.Format24bppRgb))
            {
                using (var g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.FromArgb(10, 11, 15));
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                    if (wordmark != null)
                    {
                        // the word mark "PC Remote" in the middle, on its own background colour so it blends in
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                        lock (wordmark)
                        {
                            g.Clear(wordmark.GetPixel(2, 2));
                            float ww = Math.Min(w * 0.72f, h * 0.9f), wh = ww * wordmark.Height / wordmark.Width;
                            g.DrawImage(wordmark, new RectangleF((w - ww) / 2f, (h - wh) / 2f, ww, wh));
                        }
                    }
                    else
                    {
                        int s = (int)(Math.Min(w, h) * 0.24);
                        float y = (h - s) / 2f - s * 0.25f;
                        using (var logo = Draw(s, false)) g.DrawImage(logo, (w - s) / 2f, y, s, s);
                        using (var f = new Font("Segoe UI Semibold", s * 0.2f, FontStyle.Regular, GraphicsUnit.Pixel))
                        using (var br = new SolidBrush(Color.FromArgb(242, 243, 247)))
                        using (var fmt = new StringFormat { Alignment = StringAlignment.Center })
                            g.DrawString("PC Remote", f, br, new RectangleF(0, y + s * 1.18f, w, s * 0.5f), fmt);
                    }
                }
                using (var ms = new MemoryStream())
                {
                    bmp.Save(ms, ImageFormat.Png);
                    return ms.ToArray();
                }
            }
        }
    }
}
