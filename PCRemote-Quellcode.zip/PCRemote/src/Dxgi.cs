using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace PCRemote
{
    // Calls a COM method by its vtable slot (0-2 = IUnknown). Delegates are cached per function pointer.
    static class ComVt
    {
        static readonly Dictionary<IntPtr, Delegate> cache = new Dictionary<IntPtr, Delegate>();

        public static T Fn<T>(IntPtr obj, int slot) where T : class
        {
            IntPtr fp = Marshal.ReadIntPtr(Marshal.ReadIntPtr(obj), slot * IntPtr.Size);
            lock (cache)
            {
                Delegate d;
                if (!cache.TryGetValue(fp, out d) || d.GetType() != typeof(T))
                    cache[fp] = d = Marshal.GetDelegateForFunctionPointer(fp, typeof(T));
                return (T)(object)d;
            }
        }

        public static void Rel(ref IntPtr p) { if (p != IntPtr.Zero) { Marshal.Release(p); p = IntPtr.Zero; } }
    }

    // Screen capture through DXGI Desktop Duplication: the GPU hands over the finished desktop image.
    // Much cheaper than GDI, only reports a new image when something changed, and also sees fullscreen games.
    // COM is called through raw vtable slots (no interop assemblies needed).
    sealed class DesktopDup : IDisposable
    {
        [DllImport("dxgi.dll")] static extern int CreateDXGIFactory1(ref Guid riid, out IntPtr factory);
        [DllImport("d3d11.dll")] static extern int D3D11CreateDevice(IntPtr adapter, int driverType, IntPtr software, int flags, IntPtr levels, int nLevels, int sdk, out IntPtr device, out int level, out IntPtr context);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct OUTPUT_DESC
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            public int Left, Top, Right, Bottom, Attached, Rotation;
            public IntPtr Monitor;
        }
        [StructLayout(LayoutKind.Sequential)] struct DUPL_DESC { public int Width, Height, RefreshNum, RefreshDen, Format, Scanline, Scaling, Rotation, InSystemMemory; }
        [StructLayout(LayoutKind.Sequential)] struct FRAME_INFO { public long LastPresentTime, LastMouseUpdateTime; public int AccumulatedFrames, RectsCoalesced, ProtectedMasked, PtrX, PtrY, PtrVisible, MetaSize, ShapeSize; }
        [StructLayout(LayoutKind.Sequential)] struct TEX2D_DESC { public int Width, Height, MipLevels, ArraySize, Format, SampleCount, SampleQuality, Usage, BindFlags, CpuAccess, Misc; }
        [StructLayout(LayoutKind.Sequential)] struct MAPPED { public IntPtr Data; public int RowPitch, DepthPitch; }

        delegate int EnumD(IntPtr self, int i, out IntPtr item);
        delegate int OutDescD(IntPtr self, out OUTPUT_DESC d);
        delegate int DuplicateD(IntPtr self, IntPtr device, out IntPtr dup);
        delegate void DuplDescD(IntPtr self, out DUPL_DESC d);
        delegate int AcquireD(IntPtr self, int timeout, out FRAME_INFO info, out IntPtr res);
        delegate int ReleaseFrameD(IntPtr self);
        delegate int CreateTexD(IntPtr self, ref TEX2D_DESC d, IntPtr init, out IntPtr tex);
        delegate int MapD(IntPtr self, IntPtr res, int sub, int type, int flags, out MAPPED m);
        delegate void UnmapD(IntPtr self, IntPtr res, int sub);
        delegate void CopyD(IntPtr self, IntPtr dst, IntPtr src);

        static T Fn<T>(IntPtr obj, int slot) where T : class { return ComVt.Fn<T>(obj, slot); }
        static void Rel(ref IntPtr p) { ComVt.Rel(ref p); }

        const int WAIT_TIMEOUT = unchecked((int)0x887A0027), ACCESS_LOST = unchecked((int)0x887A0026);
        static Guid IID_Factory1 = new Guid("770aae78-f26f-4dba-a829-253c83d1b387");
        static Guid IID_Output1 = new Guid("00cddea8-939b-4b83-a340-a685226666cc");
        static Guid IID_Tex2D = new Guid("6f15aaf2-d208-4e89-9ab4-489535d34f9c");

        IntPtr device, context, dupl, staging;
        AcquireD acquire;
        ReleaseFrameD releaseFrame;
        CopyD copy;
        MapD map;
        UnmapD unmap;
        public readonly int W, H;
        bool haveImage;

        DesktopDup(int w, int h) { W = w; H = h; }

        // Opens the monitor with this GDI name (\\.\DISPLAYn); null when it can't be duplicated (rotated, HDR, too many users …).
        public static DesktopDup TryOpen(string dev, int w, int h)
        {
            var d = new DesktopDup(w, h);
            try
            {
                if (d.Open(dev)) return d;
            }
            catch (Exception ex) { Log.Write("dxgi: " + ex.Message); }
            d.Dispose();
            return null;
        }

        bool Open(string dev)
        {
            IntPtr factory = IntPtr.Zero, adapter = IntPtr.Zero, output = IntPtr.Zero, output1 = IntPtr.Zero;
            try
            {
                if (CreateDXGIFactory1(ref IID_Factory1, out factory) < 0) return false;
                var enumAdapters = Fn<EnumD>(factory, 12);
                for (int a = 0; enumAdapters(factory, a, out adapter) >= 0; a++)
                {
                    var enumOutputs = Fn<EnumD>(adapter, 7);
                    for (int o = 0; enumOutputs(adapter, o, out output) >= 0; o++)
                    {
                        OUTPUT_DESC od;
                        Fn<OutDescD>(output, 7)(output, out od);
                        if (string.Equals(od.DeviceName, dev, StringComparison.OrdinalIgnoreCase))
                        {
                            if (od.Rotation > 1) return false; // portrait: the image would come unrotated
                            int lvl;
                            if (D3D11CreateDevice(adapter, 0, IntPtr.Zero, 0x20, IntPtr.Zero, 0, 7, out device, out lvl, out context) < 0) return false;
                            if (Marshal.QueryInterface(output, ref IID_Output1, out output1) < 0) return false;
                            int hr = Fn<DuplicateD>(output1, 22)(output1, device, out dupl);
                            if (hr < 0) { Log.Write("dxgi: DuplicateOutput 0x" + hr.ToString("X8")); return false; }
                            DUPL_DESC dd;
                            Fn<DuplDescD>(dupl, 7)(dupl, out dd);
                            if (dd.Width != W || dd.Height != H || dd.Format != 87) return false; // only plain 8-bit BGRA at native size
                            var td = new TEX2D_DESC { Width = W, Height = H, MipLevels = 1, ArraySize = 1, Format = 87, SampleCount = 1, Usage = 3, CpuAccess = 0x20000 };
                            if (Fn<CreateTexD>(device, 5)(device, ref td, IntPtr.Zero, out staging) < 0) return false;
                            acquire = Fn<AcquireD>(dupl, 8);
                            releaseFrame = Fn<ReleaseFrameD>(dupl, 14);
                            copy = Fn<CopyD>(context, 47);
                            map = Fn<MapD>(context, 14);
                            unmap = Fn<UnmapD>(context, 15);
                            return true;
                        }
                        Rel(ref output);
                    }
                    Rel(ref adapter);
                }
                return false;
            }
            finally
            {
                Rel(ref output1); Rel(ref output); Rel(ref adapter); Rel(ref factory);
            }
        }

        public bool Lost { get; private set; }

        // Takes the newest desktop image if there is one. Returns true when the GPU copy changed.
        public bool Update()
        {
            if (Lost) return false;
            FRAME_INFO fi;
            IntPtr res;
            int hr = acquire(dupl, 0, out fi, out res);
            if (hr == WAIT_TIMEOUT) return false;
            if (hr < 0) { Lost = true; if (hr != ACCESS_LOST) Log.Write("dxgi: acquire 0x" + hr.ToString("X8")); return false; }
            bool changed = false;
            try
            {
                if (fi.LastPresentTime != 0 || !haveImage)
                {
                    IntPtr tex;
                    if (Marshal.QueryInterface(res, ref IID_Tex2D, out tex) >= 0)
                    {
                        copy(context, staging, tex);
                        Marshal.Release(tex);
                        changed = haveImage = true;
                    }
                }
            }
            finally
            {
                Marshal.Release(res);
                releaseFrame(dupl);
            }
            return changed;
        }

        public bool HasImage { get { return haveImage; } }

        // Copies the last image into a top-down BGRX buffer with stride W*4.
        public unsafe bool CopyTo(IntPtr dst)
        {
            if (!haveImage) return false;
            MAPPED m;
            if (map(context, staging, 0, 1, 0, out m) < 0) { Lost = true; return false; }
            try
            {
                int row = W * 4;
                if (m.RowPitch == row) Buffer.MemoryCopy((void*)m.Data, (void*)dst, (long)row * H, (long)row * H);
                else
                    for (int y = 0; y < H; y++)
                        Buffer.MemoryCopy((byte*)m.Data + (long)y * m.RowPitch, (byte*)dst + (long)y * row, row, row);
            }
            finally { unmap(context, staging, 0); }
            return true;
        }

        public void Dispose()
        {
            Rel(ref staging); Rel(ref dupl); Rel(ref context); Rel(ref device);
        }
    }
}
