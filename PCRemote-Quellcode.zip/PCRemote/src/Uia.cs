using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Automation;

namespace PCRemote
{
    // Reads and presses buttons inside Electron/Chromium apps (Discord) through Windows UI Automation,
    // so the app is controlled from the inside without needing its window in front.
    static class Uia
    {
        delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);

        // Top-level Chromium windows of the process, visible or hidden (Discord hides to the tray).
        public static List<IntPtr> AppWindows(string proc)
        {
            var pids = new HashSet<uint>();
            foreach (var p in Process.GetProcessesByName(proc)) { pids.Add((uint)p.Id); p.Dispose(); }
            var list = new List<IntPtr>();
            if (pids.Count == 0) return list;
            EnumWindows((h, l) =>
            {
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                if (!pids.Contains(pid) || GetWindow(h, 4) != IntPtr.Zero || GetWindowTextLength(h) == 0) return true;
                var sb = new StringBuilder(64);
                GetClassName(h, sb, 64);
                if (sb.ToString().StartsWith("Chrome_WidgetWin")) list.Add(h);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        public static readonly Condition Clickable = new OrCondition(
            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.CheckBox));

        public static bool? Toggled(AutomationElement e)
        {
            object p;
            if (e.TryGetCurrentPattern(TogglePattern.Pattern, out p)) return ((TogglePattern)p).Current.ToggleState == ToggleState.On;
            return null;
        }

        public static void Press(AutomationElement e)
        {
            object p;
            if (e.TryGetCurrentPattern(InvokePattern.Pattern, out p)) { ((InvokePattern)p).Invoke(); return; }
            if (e.TryGetCurrentPattern(TogglePattern.Pattern, out p)) { ((TogglePattern)p).Toggle(); return; }
            throw new InvalidOperationException("Knopf lässt sich nicht drücken");
        }
    }

    static class Discord
    {
        class Ctl { public string Key; public Regex Rx; public bool Inverted; }

        // German + English labels; "Inverted" labels mean the state is already on (older Discord builds rename the button).
        static readonly Ctl[] Controls = {
            new Ctl { Key = "mute", Rx = new Regex(@"^(Stummschalten|Mute)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "mute", Rx = new Regex(@"^(Stummschaltung aufheben|Unmute)$", RegexOptions.IgnoreCase), Inverted = true },
            new Ctl { Key = "deaf", Rx = new Regex(@"^(Ein- und Ausgabe deaktivieren|Deafen)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "deaf", Rx = new Regex(@"^(Ein- und Ausgabe aktivieren|Undeafen)$", RegexOptions.IgnoreCase), Inverted = true },
            new Ctl { Key = "disconnect", Rx = new Regex(@"^(Verbindung trennen|Disconnect)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "camera", Rx = new Regex(@"^(Kamera (ein|aus)schalten|Turn (On|Off) Camera|Kamera|Camera)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "screen", Rx = new Regex(@"^(Bildschirm teilen|Share Your Screen|Bildschirmübertragung beenden|Stop Streaming)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "noise", Rx = new Regex(@"(Rauschunterdrückung|Noise Suppression)", RegexOptions.IgnoreCase) },
            new Ctl { Key = "soundboard", Rx = new Regex(@"^(Soundboard öffnen|Open Soundboard|Soundboard)$", RegexOptions.IgnoreCase) },
            new Ctl { Key = "activity", Rx = new Regex(@"^(Aktivität starten|Start an Activity)$", RegexOptions.IgnoreCase) } };

        static readonly object L = new object();
        static Dictionary<string, AutomationElement> found = new Dictionary<string, AutomationElement>();
        static Dictionary<string, bool> inverted = new Dictionary<string, bool>();
        static DateTime scannedAt = DateTime.MinValue;

        static bool Scan(bool force)
        {
            if (!force && (DateTime.UtcNow - scannedAt).TotalSeconds < 8 && found.Count > 0) return true;
            if (!force && found.Count == 0 && (DateTime.UtcNow - scannedAt).TotalSeconds < 3) return false;
            scannedAt = DateTime.UtcNow;
            var f = new Dictionary<string, AutomationElement>();
            var inv = new Dictionary<string, bool>();
            foreach (var h in Uia.AppWindows("discord"))
            {
                AutomationElement root;
                try { root = AutomationElement.FromHandle(h); } catch { continue; }
                AutomationElementCollection all;
                try { all = root.FindAll(TreeScope.Descendants, Uia.Clickable); } catch { continue; }
                if (all.Count == 0)
                {
                    // Chromium builds its accessibility tree on the first request; ask once more.
                    System.Threading.Thread.Sleep(400);
                    try { all = root.FindAll(TreeScope.Descendants, Uia.Clickable); } catch { continue; }
                }
                foreach (AutomationElement e in all)
                {
                    string name;
                    try { name = e.Current.Name ?? ""; } catch { continue; }
                    foreach (var c in Controls)
                    {
                        if (f.ContainsKey(c.Key) || !c.Rx.IsMatch(name)) continue;
                        f[c.Key] = e;
                        inv[c.Key] = c.Inverted;
                    }
                }
                if (f.Count > 0) break;
            }
            found = f;
            inverted = inv;
            return f.Count > 0;
        }

        static bool? Read(string key)
        {
            AutomationElement e;
            if (!found.TryGetValue(key, out e)) return null;
            bool? t = Uia.Toggled(e);
            if (t.HasValue) return t;
            return inverted[key];
        }

        public static object State()
        {
            lock (L)
            {
                var d = new Dictionary<string, object>();
                bool running = Process.GetProcessesByName("discord").Length > 0;
                d["running"] = running;
                if (!running) { d["ok"] = false; return d; }
                bool ok;
                try { ok = Scan(false); } catch (Exception ex) { Log.Write("discord scan: " + ex.Message); ok = false; }
                if (ok)
                {
                    try
                    {
                        d["mute"] = Read("mute");
                        d["deaf"] = Read("deaf");
                    }
                    catch (ElementNotAvailableException)
                    {
                        Scan(true);
                        d["mute"] = Read("mute");
                        d["deaf"] = Read("deaf");
                    }
                    d["voice"] = found.ContainsKey("disconnect");
                    var has = new List<string>(found.Keys);
                    d["controls"] = has;
                }
                d["ok"] = ok;
                return d;
            }
        }

        // Returns the new on/off state when the button is a toggle.
        public static object Do(string cmd)
        {
            lock (L)
            {
                for (int attempt = 0; attempt < 2; attempt++)
                {
                    bool ok;
                    try { ok = Scan(attempt > 0); } catch { ok = false; }
                    AutomationElement e;
                    if (ok && found.TryGetValue(cmd, out e))
                    {
                        try
                        {
                            Uia.Press(e);
                            System.Threading.Thread.Sleep(120);
                            bool? now = Read(cmd);
                            return new Dictionary<string, object> { { "ok", true }, { "value", now } };
                        }
                        catch (ElementNotAvailableException) { continue; }
                    }
                }
            }
            // Discord not reachable through its window: fall back to the user's Discord keybind.
            string key = Addons.Setting("discord", cmd + "Key");
            if (!string.IsNullOrEmpty(key))
            {
                Input.Hotkey(key);
                return new Dictionary<string, object> { { "ok", true }, { "msg", "Discord: Tastenkürzel gesendet" } };
            }
            if (Process.GetProcessesByName("discord").Length == 0) throw new InvalidOperationException("Discord läuft nicht");
            if (cmd == "disconnect" || cmd == "camera" || cmd == "screen") throw new InvalidOperationException("Du bist gerade in keinem Sprachkanal");
            throw new InvalidOperationException("Discord-Knopf nicht gefunden. Öffne Discord einmal (minimiert reicht) oder trage in den Addon-Einstellungen ein Tastenkürzel ein.");
        }

        public static bool Toggle(string key, bool? target)
        {
            if (target.HasValue)
            {
                var st = (Dictionary<string, object>)State();
                object cur;
                if (st.TryGetValue(key, out cur) && cur is bool && (bool)cur == target.Value) return target.Value;
            }
            var r = Do(key) as Dictionary<string, object>;
            object v;
            return r != null && r.TryGetValue("value", out v) && v is bool && (bool)v;
        }
    }
}
