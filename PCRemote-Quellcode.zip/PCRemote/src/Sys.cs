using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace PCRemote
{
    static class Sys
    {
        [DllImport("user32.dll")] static extern bool LockWorkStation();
        [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
        [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
        [DllImport("powrprof.dll")] static extern bool SetSuspendState(bool hibernate, bool force, bool disableWake);
        [DllImport("kernel32.dll")] static extern bool GetSystemTimes(out long idle, out long kernel, out long user);
        [DllImport("kernel32.dll")] static extern ulong GetTickCount64();
        [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);

        [StructLayout(LayoutKind.Sequential)]
        struct MEMORYSTATUSEX
        {
            public uint dwLength; public uint dwMemoryLoad;
            public ulong ullTotalPhys; public ulong ullAvailPhys;
            public ulong ullTotalPageFile; public ulong ullAvailPageFile;
            public ulong ullTotalVirtual; public ulong ullAvailVirtual; public ulong ullAvailExtendedVirtual;
        }

        static void Later(int ms, Action a)
        {
            var t = new Thread(() =>
            {
                Thread.Sleep(ms);
                try { a(); } catch (Exception ex) { Log.Write("later: " + ex.Message); }
            });
            t.IsBackground = true;
            t.Start();
        }

        // ---------- launching / processes ----------

        public static void Launch(string target, string args)
        {
            if (string.IsNullOrWhiteSpace(target)) throw new ArgumentException("Kein Ziel angegeben");
            target = Environment.ExpandEnvironmentVariables(target.Trim().Trim('"'));
            var psi = new ProcessStartInfo(target);
            psi.UseShellExecute = true;
            if (!string.IsNullOrEmpty(args)) psi.Arguments = args;
            try
            {
                if (File.Exists(target)) psi.WorkingDirectory = Path.GetDirectoryName(target);
            }
            catch { }
            Process.Start(psi);
        }

        public static void Kill(List<string> names, bool force)
        {
            int n = 0;
            foreach (string raw in names)
            {
                string name = raw.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? raw.Substring(0, raw.Length - 4) : raw;
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try
                    {
                        n++;
                        if (!force && p.MainWindowHandle != IntPtr.Zero && p.CloseMainWindow())
                        {
                            var pp = p;
                            Later(6000, () => { try { if (!pp.HasExited) pp.Kill(); } catch { } });
                        }
                        else p.Kill();
                    }
                    catch (Exception ex) { Log.Write("kill " + name + ": " + ex.Message); }
                }
            }
            if (n == 0) throw new InvalidOperationException("Läuft gerade nicht");
        }

        // full path of the first running exe with one of these names (null when none runs or it can't be read)
        public static string ExeOfRunning(IEnumerable<string> names)
        {
            foreach (string name in names)
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try { using (p) { string f = p.MainModule.FileName; if (!string.IsNullOrEmpty(f)) return f; } }
                    catch { }
                }
            return null;
        }

        public static bool AnyRunning(IEnumerable<string> names)
        {
            foreach (string name in names)
            {
                var ps = Process.GetProcessesByName(name);
                bool any = ps.Length > 0;
                foreach (var p in ps) p.Dispose();
                if (any) return true;
            }
            return false;
        }

        static List<string> procCache;
        static int procCacheAt;

        // Every open page asks for this about once a second; listing all processes is the expensive part, so share it.
        public static object ProcNames()
        {
            lock (typeof(Sys))
            {
                if (procCache != null && Environment.TickCount - procCacheAt < 1000) return procCache;
                var set = new HashSet<string>();
                foreach (var p in Process.GetProcesses())
                {
                    try { set.Add(p.ProcessName.ToLowerInvariant()); } catch { }
                    p.Dispose();
                }
                procCache = set.ToList();
                procCacheAt = Environment.TickCount;
                return procCache;
            }
        }

        public static string RunCommand(string cmd)
        {
            if (string.IsNullOrWhiteSpace(cmd)) throw new ArgumentException("Kein Befehl angegeben");
            var psi = new ProcessStartInfo("cmd.exe", "/c " + cmd);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var p = Process.Start(psi);
            var outTask = p.StandardOutput.ReadToEndAsync();
            var errTask = p.StandardError.ReadToEndAsync();
            if (!p.WaitForExit(6000)) return "Befehl läuft im Hintergrund weiter";
            string o = (outTask.Result + errTask.Result).Trim();
            if (o.Length == 0) return "Befehl ausgeführt";
            return o.Length > 400 ? o.Substring(0, 400) + " …" : o;
        }

        // ---------- power ----------

        public static string Power(string cmd, int delay)
        {
            delay = Math.Max(0, Math.Min(86400, delay));
            switch (cmd)
            {
                case "lock":
                    LockWorkStation();
                    return "PC gesperrt";
                case "sleep":
                    Later(800, () => SetSuspendState(false, false, false));
                    return "PC geht in den Energiesparmodus";
                case "hibernate":
                    Later(800, () => SetSuspendState(true, false, false));
                    return "PC geht in den Ruhezustand";
                case "shutdown":
                    Hidden("shutdown.exe", "/s /t " + delay);
                    return delay > 0 ? "Herunterfahren in " + Human(delay) : "PC fährt herunter";
                case "restart":
                    Hidden("shutdown.exe", "/r /t " + delay);
                    return delay > 0 ? "Neustart in " + Human(delay) : "PC startet neu";
                case "cancel":
                    Hidden("shutdown.exe", "/a");
                    return "Geplantes Herunterfahren abgebrochen";
                case "logoff":
                    Hidden("shutdown.exe", "/l");
                    return "Abmelden …";
                case "monitoroff":
                    Later(700, () => PostMessage((IntPtr)0xFFFF, 0x0112, (IntPtr)0xF170, (IntPtr)2));
                    return "Monitor aus";
                case "monitoron":
                    Input.Mouse(new Dictionary<string, object> { { "dx", 1 } });
                    Input.Mouse(new Dictionary<string, object> { { "dx", -1 } });
                    return "Monitor an";
            }
            throw new ArgumentException("Unbekannter Befehl: " + cmd);
        }

        static string Human(int s)
        {
            if (s >= 3600) return (s / 3600) + " h " + (s % 3600 / 60) + " min";
            if (s >= 60) return (s / 60) + " min";
            return s + " s";
        }

        static void Hidden(string exe, string args)
        {
            var psi = new ProcessStartInfo(exe, args);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            using (var p = Process.Start(psi)) p.WaitForExit(3000);
        }

        // ---------- screen ----------

        public static object Monitors()
        {
            var list = new List<object>();
            var all = Screen.AllScreens;
            for (int i = 0; i < all.Length; i++)
                list.Add(new Dictionary<string, object> {
                    { "i", i }, { "w", all[i].Bounds.Width }, { "h", all[i].Bounds.Height }, { "primary", all[i].Primary } });
            return list;
        }

        static Screen PickScreen(int mon)
        {
            var all = Screen.AllScreens;
            return mon >= 0 && mon < all.Length ? all[mon] : Screen.PrimaryScreen;
        }

        public static byte[] Screenshot(int mon, int maxW, int quality)
        {
            Rectangle b = PickScreen(mon).Bounds;
            using (var full = new Bitmap(b.Width, b.Height, PixelFormat.Format24bppRgb))
            {
                using (var g = Graphics.FromImage(full))
                {
                    g.CopyFromScreen(b.Left, b.Top, 0, 0, b.Size, CopyPixelOperation.SourceCopy);
                    Point cp = Cursor.Position;
                    if (b.Contains(cp))
                    {
                        float r = Math.Max(7f, b.Width / 200f);
                        float x = cp.X - b.Left, y = cp.Y - b.Top;
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        using (var br = new SolidBrush(Color.FromArgb(235, 255, 255, 255)))
                        using (var pen = new Pen(Color.FromArgb(230, 124, 92, 255), r / 2.6f))
                        {
                            g.FillEllipse(br, x - r, y - r, 2 * r, 2 * r);
                            g.DrawEllipse(pen, x - r, y - r, 2 * r, 2 * r);
                        }
                    }
                }
                int w = Math.Max(200, Math.Min(maxW <= 0 ? 1280 : maxW, b.Width));
                int h = (int)Math.Round(b.Height * (w / (double)b.Width));
                using (var small = new Bitmap(w, h, PixelFormat.Format24bppRgb))
                {
                    using (var g = Graphics.FromImage(small))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBilinear;
                        g.DrawImage(full, 0, 0, w, h);
                    }
                    return Jpeg(small, Math.Max(20, Math.Min(95, quality)));
                }
            }
        }

        static byte[] Jpeg(Bitmap bmp, int q)
        {
            var codec = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
            using (var ep = new EncoderParameters(1))
            using (var ms = new MemoryStream())
            {
                ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)q);
                bmp.Save(ms, codec, ep);
                return ms.ToArray();
            }
        }

        public static void ClickAt(double fx, double fy, int mon, string button)
        {
            Rectangle b = PickScreen(mon).Bounds;
            int x = b.Left + (int)Math.Round(Math.Max(0, Math.Min(1, fx)) * (b.Width - 1));
            int y = b.Top + (int)Math.Round(Math.Max(0, Math.Min(1, fy)) * (b.Height - 1));
            SetCursorPos(x, y);
            if (button != "move")
            {
                Thread.Sleep(30);
                Input.Click(button, button == "double");
            }
        }

        // ---------- clipboard (needs an STA thread) ----------

        static T Sta<T>(Func<T> f)
        {
            T result = default(T);
            Exception err = null;
            var t = new Thread(() => { try { result = f(); } catch (Exception ex) { err = ex; } });
            t.SetApartmentState(ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
            t.Join(4000);
            if (err != null) throw err;
            return result;
        }

        public static string GetClipboard()
        {
            return Sta(() => Clipboard.ContainsText() ? Clipboard.GetText() : "");
        }

        public static void SetClipboard(string text)
        {
            Sta(() => { Clipboard.SetText(string.IsNullOrEmpty(text) ? " " : text); return true; });
        }

        // ---------- stats ----------

        static long pIdle, pKernel, pUser;
        static double lastCpu;
        static readonly object cpuLock = new object();

        static double Cpu()
        {
            lock (cpuLock)
            {
                long idle, kernel, user;
                if (!GetSystemTimes(out idle, out kernel, out user)) return lastCpu;
                long dIdle = idle - pIdle, total = (kernel - pKernel) + (user - pUser);
                pIdle = idle; pKernel = kernel; pUser = user;
                if (total > 0) lastCpu = Math.Max(0, Math.Min(100, (total - dIdle) * 100.0 / total));
                return lastCpu;
            }
        }

        static Dictionary<string, object> gpu;
        static DateTime gpuAt = DateTime.MinValue;
        static int gpuBusy;

        static void RefreshGpu()
        {
            if ((DateTime.UtcNow - gpuAt).TotalSeconds < 2.5) return;
            if (Interlocked.Exchange(ref gpuBusy, 1) == 1) return;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    string exe = Path.Combine(Environment.SystemDirectory, "nvidia-smi.exe");
                    if (!File.Exists(exe)) { gpu = null; return; }
                    var psi = new ProcessStartInfo(exe, "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw,power.limit,fan.speed,clocks.gr,clocks.mem,driver_version --format=csv,noheader,nounits");
                    psi.UseShellExecute = false;
                    psi.CreateNoWindow = true;
                    psi.RedirectStandardOutput = true;
                    using (var p = Process.Start(psi))
                    {
                        string o = p.StandardOutput.ReadToEnd();
                        p.WaitForExit(4000);
                        string[] parts = o.Split('\n')[0].Split(',');
                        if (parts.Length >= 5)
                        {
                            var g = new Dictionary<string, object> {
                                { "name", parts[0].Trim() }, { "util", Num(parts[1]) }, { "temp", Num(parts[2]) },
                                { "memUsed", Num(parts[3]) }, { "memTotal", Num(parts[4]) } };
                            if (parts.Length >= 11)
                            {
                                g["power"] = Num(parts[5]); g["powerLimit"] = Num(parts[6]); g["fan"] = Num(parts[7]);
                                g["clock"] = Num(parts[8]); g["memClock"] = Num(parts[9]); g["driver"] = parts[10].Trim();
                            }
                            gpu = g;
                        }
                    }
                }
                catch (Exception ex) { Log.Write("gpu: " + ex.Message); gpu = null; }
                finally { gpuAt = DateTime.UtcNow; Interlocked.Exchange(ref gpuBusy, 0); }
            });
        }

        static double Num(string s)
        {
            double d;
            return double.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out d) ? d : 0;
        }

        public static object Stats()
        {
            RefreshGpu();
            var m = new MEMORYSTATUSEX();
            m.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            GlobalMemoryStatusEx(ref m);
            double totalGb = m.ullTotalPhys / 1073741824.0, usedGb = (m.ullTotalPhys - m.ullAvailPhys) / 1073741824.0;
            return new Dictionary<string, object> {
                { "cpu", Math.Round(Cpu(), 1) },
                { "ram", new Dictionary<string, object> { { "pct", m.dwMemoryLoad }, { "used", Math.Round(usedGb, 1) }, { "total", Math.Round(totalGb, 1) } } },
                { "gpu", gpu },
                { "uptime", (long)(GetTickCount64() / 1000) } };
        }

        public static object Info()
        {
            var drives = new List<object>();
            foreach (var d in DriveInfo.GetDrives())
            {
                try
                {
                    if (d.DriveType != DriveType.Fixed || !d.IsReady) continue;
                    drives.Add(new Dictionary<string, object> {
                        { "name", d.Name.TrimEnd('\\') }, { "free", Math.Round(d.AvailableFreeSpace / 1073741824.0, 1) },
                        { "total", Math.Round(d.TotalSize / 1073741824.0, 1) } });
                }
                catch { }
            }
            return new Dictionary<string, object> {
                { "name", Environment.MachineName }, { "user", Environment.UserName },
                { "os", WindowsName() }, { "version", Program.Version },
                { "drives", drives }, { "urls", Net.LanUrls(Program.Cfg.Port) } };
        }

        // "Windows 10 Pro (22H2, Build 19045)" – Environment.OSVersion says "NT 6.2" for apps without a manifest
        static string WindowsName()
        {
            try
            {
                using (var k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                {
                    string name = k.GetValue("ProductName") as string ?? "Windows", disp = k.GetValue("DisplayVersion") as string, build = k.GetValue("CurrentBuild") as string;
                    int b;
                    if (int.TryParse(build, out b) && b >= 22000) name = name.Replace("Windows 10", "Windows 11"); // Windows 11 still reports "Windows 10" here
                    return name + " (" + (string.IsNullOrEmpty(disp) ? "" : disp + ", ") + "Build " + build + ")";
                }
            }
            catch { return Environment.OSVersion.VersionString; }
        }

        // ---------- now playing (from window titles) ----------

        static string lastTitle, lastArtist;

        public static object NowPlaying()
        {
            foreach (var p in Process.GetProcessesByName("Spotify"))
            {
                using (p)
                {
                    string t = p.MainWindowTitle;
                    if (string.IsNullOrEmpty(t)) continue;
                    bool paused = t.StartsWith("Spotify", StringComparison.OrdinalIgnoreCase) && t.IndexOf(" - ", StringComparison.Ordinal) < 0;
                    if (!paused)
                    {
                        int i = t.IndexOf(" - ", StringComparison.Ordinal);
                        if (i > 0) { lastArtist = t.Substring(0, i); lastTitle = t.Substring(i + 3); }
                        else { lastArtist = ""; lastTitle = t; }
                    }
                    return new Dictionary<string, object> {
                        { "app", "Spotify" }, { "playing", !paused }, { "title", lastTitle ?? "" }, { "artist", lastArtist ?? "" } };
                }
            }
            foreach (string browser in new[] { "chrome", "msedge" })
            {
                foreach (var p in Process.GetProcessesByName(browser))
                {
                    using (p)
                    {
                        string t = p.MainWindowTitle ?? "";
                        int i = t.IndexOf(" - YouTube", StringComparison.Ordinal);
                        if (i > 0)
                        {
                            string title = t.Substring(0, i);
                            if (title.StartsWith("(")) { int c = title.IndexOf(") "); if (c > 0) title = title.Substring(c + 2); }
                            return new Dictionary<string, object> {
                                { "app", "YouTube" }, { "playing", null }, { "title", title }, { "artist", browser == "chrome" ? "Chrome" : "Edge" } };
                        }
                    }
                }
            }
            return null;
        }
    }
}
