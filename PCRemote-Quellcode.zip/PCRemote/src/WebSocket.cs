using System;
using System.IO;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;

namespace PCRemote
{
    // Minimal WebSocket server side: the phone keeps one open line for touch/mouse input,
    // so every finger move arrives immediately and in order instead of as separate web requests.
    static class WebSocketLink
    {
        public static void Run(Request req, Stream input, Stream output, Action<string> onText)
        {
            string key = req.Header("Sec-WebSocket-Key");
            if (string.IsNullOrEmpty(key)) return;
            string accept;
            using (var sha = SHA1.Create())
                accept = Convert.ToBase64String(sha.ComputeHash(Encoding.ASCII.GetBytes(key.Trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")));
            byte[] head = Encoding.ASCII.GetBytes("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n");
            output.Write(head, 0, head.Length);
            output.Flush();
            var ns = output as NetworkStream;
            if (ns != null) ns.ReadTimeout = System.Threading.Timeout.Infinite;

            var msg = new MemoryStream();
            int msgOp = 0;
            try
            {
                while (!Program.Exiting)
                {
                    int b0 = input.ReadByte(), b1 = input.ReadByte();
                    if (b0 < 0 || b1 < 0) break;
                    bool fin = (b0 & 0x80) != 0;
                    int op = b0 & 0x0F;
                    long len = b1 & 0x7F;
                    if (len == 126) len = (ReadByte(input) << 8) | ReadByte(input);
                    else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | (uint)ReadByte(input); }
                    if (len > 1 << 20) break; // nothing we expect is this big
                    var mask = new byte[4];
                    if ((b1 & 0x80) != 0) ReadFull(input, mask, 4);
                    var data = new byte[len];
                    ReadFull(input, data, (int)len);
                    if ((b1 & 0x80) != 0) for (int i = 0; i < data.Length; i++) data[i] ^= mask[i & 3];

                    if (op == 8) { Send(output, 8, new byte[0]); break; }          // close
                    if (op == 9) { Send(output, 10, data); continue; }              // ping → pong
                    if (op == 10) continue;                                          // pong
                    if (op == 1 || op == 2) { msg.SetLength(0); msgOp = op; }
                    msg.Write(data, 0, data.Length);
                    if (!fin || msgOp != 1) continue;
                    string text = Encoding.UTF8.GetString(msg.GetBuffer(), 0, (int)msg.Length);
                    try { onText(text); }
                    catch (Exception ex) { Log.Write("ws action: " + ex.Message); }
                }
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
        }

        static int ReadByte(Stream s)
        {
            int b = s.ReadByte();
            if (b < 0) throw new IOException("closed");
            return b;
        }

        static void ReadFull(Stream s, byte[] buf, int len)
        {
            int read = 0;
            while (read < len)
            {
                int n = s.Read(buf, read, len - read);
                if (n <= 0) throw new IOException("closed");
                read += n;
            }
        }

        static void Send(Stream s, int op, byte[] payload)
        {
            var head = new MemoryStream();
            head.WriteByte((byte)(0x80 | op));
            if (payload.Length < 126) head.WriteByte((byte)payload.Length);
            else { head.WriteByte(126); head.WriteByte((byte)(payload.Length >> 8)); head.WriteByte((byte)payload.Length); }
            head.Write(payload, 0, payload.Length);
            head.WriteTo(s);
            s.Flush();
        }
    }
}
