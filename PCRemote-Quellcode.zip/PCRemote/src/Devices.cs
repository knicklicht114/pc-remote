using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace PCRemote
{
    // Paired phones/tablets. Each gets its own secret key once (via PIN, QR code or a "allow?" prompt on the PC),
    // so it reconnects on its own afterwards – even after the PIN was changed. Only a hash of the key is stored.
    static class Devices
    {
        class Device { public string Id, Name, Hash, Ip, Agent; public DateTime Created, Seen; }
        class Pending { public string Id, Secret, Name, Ip, Agent, Code, Token, State = "wait"; public DateTime Created; }

        static string path;
        static readonly object L = new object();
        static List<Device> list = new List<Device>();
        static readonly List<Pending> pending = new List<Pending>();
        static DateTime savedAt = DateTime.MinValue;
        static bool dirty;

        public static void Init(string p)
        {
            path = p;
            try
            {
                string s = Store.Read(p);
                if (string.IsNullOrWhiteSpace(s)) return;
                var arr = J.Parse(s) as object[];
                if (arr == null) return;
                foreach (var o in arr)
                {
                    var d = o as Dictionary<string, object>;
                    if (d == null || J.Str(d, "hash") == null) continue;
                    list.Add(new Device {
                        Id = J.Str(d, "id"), Name = J.Str(d, "name", "Gerät"), Hash = J.Str(d, "hash"), Ip = J.Str(d, "ip"), Agent = J.Str(d, "agent"),
                        Created = Time(J.Num(d, "created")), Seen = Time(J.Num(d, "seen")) });
                }
            }
            catch (Exception ex) { Log.Write("devices load: " + ex.Message); }
        }

        static DateTime Time(double ms) { return ms > 0 ? new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(ms) : DateTime.UtcNow; }
        static long Ms(DateTime t) { return (long)(t - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds; }

        static void Save()
        {
            dirty = false;
            savedAt = DateTime.UtcNow;
            var arr = list.Select(d => (object)new Dictionary<string, object> {
                { "id", d.Id }, { "name", d.Name }, { "hash", d.Hash }, { "ip", d.Ip }, { "agent", d.Agent },
                { "created", Ms(d.Created) }, { "seen", Ms(d.Seen) } }).ToList();
            try { Store.Write(path, J.Ser(arr)); }
            catch (Exception ex) { Log.Write("devices save: " + ex.Message); }
        }

        static string Random(int bytes)
        {
            var b = new byte[bytes];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            return BitConverter.ToString(b).Replace("-", "").ToLowerInvariant();
        }

        static string Hash(string token)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(token ?? ""))).Replace("-", "");
        }

        static string Clean(string name)
        {
            name = (name ?? "").Trim();
            if (name.Length > 40) name = name.Substring(0, 40);
            return name.Length == 0 ? "Gerät" : name;
        }

        // ---------- auth ----------

        public static string Check(string token, string ip)
        {
            if (string.IsNullOrEmpty(token) || token.Length < 32) return null;
            string h = Hash(token);
            lock (L)
            {
                var d = list.FirstOrDefault(x => x.Hash == h);
                if (d == null) return null;
                d.Seen = DateTime.UtcNow;
                if (d.Ip != ip) { d.Ip = ip; dirty = true; }
                // lastSeen is kept in memory and written now and then, not on every request
                if (dirty || (DateTime.UtcNow - savedAt).TotalMinutes > 5) Save();
                return d.Id;
            }
        }

        static string Add(string name, string ip, string agent)
        {
            string token = Random(32);
            var d = new Device { Id = Random(6), Name = Clean(name), Hash = Hash(token), Ip = ip, Agent = agent, Created = DateTime.UtcNow, Seen = DateTime.UtcNow };
            list.Add(d);
            Save();
            Log.Write("device paired: " + d.Name + " (" + ip + ")");
            return token;
        }

        // Pairing with the PIN (typed in or from the QR code).
        public static object PairWithPin(string name, string ip, string agent)
        {
            lock (L)
            {
                string token = Add(name, ip, agent);
                return new Dictionary<string, object> { { "ok", true }, { "token", token }, { "id", list[list.Count - 1].Id } };
            }
        }

        // ---------- pairing by asking on the PC ----------

        static void Expire()
        {
            pending.RemoveAll(p => (DateTime.UtcNow - p.Created).TotalMinutes > 3);
        }

        public static object Request(string name, string ip, string agent)
        {
            Pending p;
            lock (L)
            {
                Expire();
                if (pending.Count(x => x.Ip == ip && x.State == "wait") >= 2) throw new InvalidOperationException("Es wartet schon eine Anfrage – bitte am PC bestätigen");
                if (pending.Count >= 8) throw new InvalidOperationException("Zu viele offene Anfragen – bitte kurz warten");
                var rnd = new byte[2];
                using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(rnd);
                p = new Pending { Id = Random(6), Secret = Random(16), Name = Clean(name), Ip = ip, Agent = agent, Created = DateTime.UtcNow,
                    Code = ((rnd[0] << 8 | rnd[1]) % 9000 + 1000).ToString() };
                pending.Add(p);
            }
            Log.Write("pair request: " + p.Name + " (" + ip + ") code " + p.Code);
            Program.Balloon("Neues Gerät möchte sich verbinden", p.Name + " · Code " + p.Code + " – klicken, um es in PC Remote zu erlauben");
            return new Dictionary<string, object> { { "ok", true }, { "req", p.Id }, { "secret", p.Secret }, { "code", p.Code } };
        }

        public static object RequestStatus(string id, string secret)
        {
            lock (L)
            {
                Expire();
                var p = pending.FirstOrDefault(x => x.Id == id && x.Secret == secret);
                if (p == null) return new Dictionary<string, object> { { "state", "gone" } };
                if (p.State == "ok")
                {
                    pending.Remove(p); // the key is handed out exactly once
                    return new Dictionary<string, object> { { "state", "ok" }, { "token", p.Token } };
                }
                return new Dictionary<string, object> { { "state", p.State } };
            }
        }

        public static void Answer(string id, bool allow)
        {
            lock (L)
            {
                var p = pending.FirstOrDefault(x => x.Id == id && x.State == "wait");
                if (p == null) throw new InvalidOperationException("Diese Anfrage gibt es nicht mehr");
                if (allow) { p.Token = Add(p.Name, p.Ip, p.Agent); p.State = "ok"; }
                else { p.State = "no"; Log.Write("pair request denied: " + p.Name); }
            }
        }

        public static bool HasPending()
        {
            lock (L) { Expire(); return pending.Any(p => p.State == "wait"); }
        }

        // ---------- management ----------

        public static object List(string me, bool local)
        {
            lock (L)
            {
                Expire();
                var devs = list.OrderByDescending(d => d.Seen).Select(d => (object)new Dictionary<string, object> {
                    { "id", d.Id }, { "name", d.Name }, { "ip", d.Ip }, { "created", Ms(d.Created) }, { "seen", Ms(d.Seen) },
                    { "me", d.Id == me }, { "online", (DateTime.UtcNow - d.Seen).TotalSeconds < 30 } }).ToList();
                var reqs = local ? pending.Where(p => p.State == "wait").Select(p => (object)new Dictionary<string, object> {
                    { "id", p.Id }, { "name", p.Name }, { "ip", p.Ip }, { "code", p.Code } }).ToList() : new List<object>();
                return new Dictionary<string, object> { { "devices", devs }, { "pending", reqs }, { "me", me } };
            }
        }

        public static void Rename(string id, string name)
        {
            lock (L)
            {
                var d = list.FirstOrDefault(x => x.Id == id);
                if (d == null) throw new InvalidOperationException("Gerät nicht gefunden");
                d.Name = Clean(name);
                Save();
            }
        }

        public static void Remove(string id)
        {
            lock (L)
            {
                int n = id == "*" ? list.Count : list.RemoveAll(x => x.Id == id);
                if (id == "*") list.Clear();
                if (n == 0) throw new InvalidOperationException("Gerät nicht gefunden");
                Save();
                Log.Write("device removed: " + (id == "*" ? "all" : id));
            }
        }
    }
}
