using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace PCRemote
{
    // Instant replay: the screen (and what you hear) is recorded into memory all the time;
    // "save" writes the last N seconds as an MP4 into Videos\PC Remote Clips.
    static class Clips
    {
        class Settings
        {
            public bool Enabled, Audio = true, Sound = true, Overlay = true;
            public string Monitor = "", Quality = "high", Res = "native", Hotkey = "alt+shift+c", Folder = "";
            public int Fps = 30, Seconds = 30;
        }

        [DllImport("winmm.dll")] static extern int timeBeginPeriod(int ms);
        [DllImport("winmm.dll")] static extern int timeEndPeriod(int ms);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern int GetWindowThreadProcessId(IntPtr h, out int pid);

        static string path;
        static Settings cfg = new Settings();
        static readonly object L = new object();   // buffers
        static readonly object GL = new object();  // grabber (thumbnails come from it)
        static readonly List<H264Encoder.Au> video = new List<H264Encoder.Au>();
        static readonly List<AacFrame> audio = new List<AacFrame>();
        static Thread worker, audioWorker;
        static volatile bool stop;
        static Grabber grab;
        static string state = "off", error, encoderName, captureName;
        static int vw, vh, audioRate, audioChannels = 2;
        static string lastSaved;
        static long lastSavedAt;
        // when the newest clip was saved (0 = none yet) – every API answer carries it, so all phones can say "Clip gespeichert"
        public static long LastSavedAt { get { return lastSavedAt; } }
        static readonly Dictionary<string, Dictionary<string, object>> infoCache = new Dictionary<string, Dictionary<string, object>>();

        public static long Now() { return (long)(Stopwatch.GetTimestamp() * (10000000.0 / Stopwatch.Frequency)); }

        public static string Folder
        {
            get { return string.IsNullOrEmpty(cfg.Folder) ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "PC Remote Clips") : cfg.Folder; }
        }

        static string ThumbDir { get { return Path.Combine(Folder, ".thumbs"); } }

        public static void Init(string p)
        {
            path = p;
            try
            {
                var d = J.Obj(Store.Read(p));
                // records from the start – clipping should just work (the old "enabled" key from v2.1 defaulted to off)
                cfg.Enabled = J.Bool(d, "recording", true);
                cfg.Audio = J.Bool(d, "audio", true);
                cfg.Sound = J.Bool(d, "sound", true);
                cfg.Overlay = J.Bool(d, "overlay", true);
                cfg.Monitor = J.Str(d, "monitor", "");
                cfg.Quality = J.Str(d, "quality", "high");
                cfg.Res = J.Str(d, "res", "native");
                cfg.Hotkey = J.Str(d, "hotkey", "alt+shift+c");
                cfg.Folder = J.Str(d, "folder", "");
                cfg.Fps = (int)J.Num(d, "fps", 30) >= 60 ? 60 : 30;
                cfg.Seconds = Math.Max(10, Math.Min(300, (int)J.Num(d, "seconds", 30)));
            }
            catch (Exception ex) { Log.Write("clips settings: " + ex.Message); }
            if (cfg.Enabled) Start();
            Program.OnUi(() => ClipHotkey.Set(cfg.Hotkey));
        }

        static void SaveSettings()
        {
            try
            {
                Store.Write(path, J.Ser(new Dictionary<string, object> {
                    { "recording", cfg.Enabled }, { "audio", cfg.Audio }, { "sound", cfg.Sound }, { "overlay", cfg.Overlay }, { "monitor", cfg.Monitor }, { "quality", cfg.Quality },
                    { "res", cfg.Res }, { "hotkey", cfg.Hotkey }, { "folder", cfg.Folder }, { "fps", cfg.Fps }, { "seconds", cfg.Seconds } }));
            }
            catch (Exception ex) { Log.Write("clips save settings: " + ex.Message); }
        }

        // ---------- recording ----------

        static void Start()
        {
            if (worker != null) return;
            stop = false;
            error = null;
            state = "starting";
            worker = new Thread(VideoLoop) { IsBackground = true, Name = "clips video", Priority = ThreadPriority.AboveNormal };
            worker.Start();
            if (cfg.Audio)
            {
                audioWorker = new Thread(AudioLoop) { IsBackground = true, Name = "clips audio", Priority = ThreadPriority.AboveNormal };
                audioWorker.Start();
            }
        }

        static void StopRecording()
        {
            stop = true;
            if (worker != null) worker.Join(3000);
            if (audioWorker != null) audioWorker.Join(2000);
            worker = audioWorker = null;
            lock (L) { video.Clear(); audio.Clear(); }
            state = "off";
        }

        static int Bitrate(int w, int h, int fps)
        {
            double mbit = cfg.Quality == "max" ? 25 : cfg.Quality == "mid" ? 8 : 14; // at 1080p30
            mbit *= Math.Max(0.35, w * (double)h / (1920 * 1080)) * (fps >= 60 ? 1.5 : 1);
            return (int)(Math.Min(60, mbit) * 1000000);
        }

        static void VideoLoop()
        {
            timeBeginPeriod(1); // steady frame timing (Windows sleeps in 15 ms steps otherwise)
            try
            {
                while (!stop)
                {
                    Grabber g = null;
                    H264Encoder enc = null;
                    try
                    {
                        var mon = Monitors.Find(cfg.Monitor) ?? Monitors.Find(null);
                        if (mon == null) throw new InvalidOperationException("Kein Bildschirm gefunden");
                        var size = Grabber.Fit(mon, cfg.Res == "720" ? 1280 : cfg.Res == "1080" ? 1920 : 0);
                        int fps = cfg.Fps;
                        g = new Grabber(mon, size.Width, size.Height);
                        enc = H264Encoder.Open(size.Width, size.Height, fps, Bitrate(size.Width, size.Height, fps), true, true);
                        lock (GL) grab = g;
                        lock (L) video.Clear();
                        vw = size.Width; vh = size.Height;
                        encoderName = enc.Name;
                        captureName = g.UsesDxgi ? "DXGI" : "GDI";
                        state = "on";
                        error = null;
                        Log.Write("clips: " + vw + "x" + vh + "@" + fps + " · " + encoderName + " · " + captureName);

                        long interval = 10000000L / fps, next = Now(), lastEnc = 0, lastKey = 0, lastLook = Now(), lastPrune = 0;
                        while (!stop)
                        {
                            long t = Now();
                            if (t - lastLook > 20000000)
                            {
                                lastLook = t;
                                var m = Monitors.Find(cfg.Monitor) ?? Monitors.Find(null);
                                if (m == null || m.W != mon.W || m.H != mon.H || m.Dev != mon.Dev) break; // resolution changed: start over
                                if (m.X != mon.X || m.Y != mon.Y) { mon = m; g.Move(m); }
                            }
                            bool changed;
                            lock (GL) changed = g.Grab();
                            // unchanged screen: no need to encode every frame; a keyframe at least every 2 s keeps the clip start precise
                            if (changed || t - lastEnc >= 5000000)
                            {
                                if (t - lastKey >= 20000000) enc.ForceKey();
                                var aus = enc.EncodeAus(g.Bits, t, interval);
                                lastEnc = t;
                                lock (L)
                                {
                                    foreach (var au in aus) { video.Add(au); if (au.Key) lastKey = au.Time; }
                                    if (t - lastPrune > 10000000) { lastPrune = t; Prune(t); }
                                }
                            }
                            next += interval;
                            long wait = (next - Now()) / 10000;
                            if (wait > 0) Thread.Sleep((int)wait);
                            else if (wait < -200) next = Now();
                        }
                    }
                    catch (Exception ex)
                    {
                        error = ex.Message;
                        state = "error";
                        Log.Write("clips video: " + ex.Message);
                        for (int i = 0; i < 30 && !stop; i++) Thread.Sleep(100);
                    }
                    finally
                    {
                        lock (GL) grab = null;
                        if (enc != null) enc.Dispose();
                        if (g != null) g.Dispose();
                    }
                }
            }
            finally { timeEndPeriod(1); }
        }

        // Keep only what a clip can need: everything from the last keyframe before "now − length".
        static void Prune(long now)
        {
            long keep = now - (cfg.Seconds + 1) * 10000000L;
            int cut = -1;
            for (int i = 0; i < video.Count && video[i].Time <= keep; i++) if (video[i].Key) cut = i;
            if (cut > 0) video.RemoveRange(0, cut);
            long first = video.Count > 0 ? video[0].Time - 10000000 : keep;
            int a = 0;
            while (a < audio.Count && audio[a].Time < first) a++;
            if (a > 0) audio.RemoveRange(0, a);
        }

        static void AudioLoop()
        {
            while (!stop)
            {
                LoopbackAudio cap = null;
                AacEncoder aac = null;
                try
                {
                    cap = LoopbackAudio.Open();
                    aac = new AacEncoder(cap.Rate, 2);
                    audioRate = cap.Rate;
                    long t0 = 0, fed = 0, frames = 0, lastCheck = Now();
                    string devId = cap.DeviceId;
                    var outFrames = new List<byte[]>();
                    Action<short[], int> feed = (pcm, n) =>
                    {
                        aac.Feed(pcm, n, outFrames);
                        fed += n;
                        if (outFrames.Count == 0) return;
                        lock (L)
                            foreach (var f in outFrames)
                                audio.Add(new AacFrame { Time = t0 + frames++ * 1024 * 10000000L / cap.Rate, Data = f });
                        outFrames.Clear();
                    };
                    Action<long> silence = n =>
                    {
                        var z = new short[4096];
                        while (n > 0) { int k = (int)Math.Min(n, 2048); feed(z, k); n -= k; }
                    };
                    while (!stop)
                    {
                        bool got = cap.Poll((pcm, n, qpc) =>
                        {
                            if (t0 == 0) t0 = qpc;
                            long expect = t0 + fed * 10000000L / cap.Rate, diff = qpc - expect;
                            int skip = 0;
                            if (diff > 200000) silence(diff * cap.Rate / 10000000L);      // nothing was playing for a while
                            else if (diff < -400000) skip = (int)Math.Min(n, -diff * cap.Rate / 10000000L); // clock drift: drop a little
                            if (skip > 0) { Array.Copy(pcm, skip * 2, pcm, 0, (n - skip) * 2); n -= skip; }
                            if (n > 0) feed(pcm, n);
                        });
                        long now = Now();
                        if (t0 == 0) t0 = now;
                        // loopback delivers nothing while everything is quiet: fill in silence so sound and picture stay in step
                        long behind = now - 500000 - (t0 + fed * 10000000L / cap.Rate);
                        if (!got && behind > 1000000) silence(behind * cap.Rate / 10000000L);
                        if (now - lastCheck > 30000000)
                        {
                            lastCheck = now;
                            if (LoopbackAudio.DefaultId() != devId) break; // other speakers/headset chosen: follow it
                        }
                        Thread.Sleep(10);
                    }
                }
                catch (Exception ex)
                {
                    audioError = ex.Message;
                    Log.Write("clips audio: " + ex.Message);
                    for (int i = 0; i < 50 && !stop; i++) Thread.Sleep(100);
                }
                finally
                {
                    if (aac != null) aac.Dispose();
                    if (cap != null) cap.Dispose();
                }
            }
        }

        // ---------- saving ----------

        public static object Save(string why)
        {
            if (worker == null) throw new InvalidOperationException("Die Clip-Aufnahme ist pausiert – in „Clips“ fortsetzen");
            // right after starting the app or changing settings: give the recorder a moment instead of failing
            for (int i = 0; i < 40 && state == "starting"; i++) Thread.Sleep(100);
            if (state != "on") throw new InvalidOperationException(error ?? "Die Aufnahme startet noch – gleich nochmal versuchen");
            List<H264Encoder.Au> v;
            List<AacFrame> a;
            long now = Now();
            lock (L)
            {
                long from = now - cfg.Seconds * 10000000L;
                int start = -1;
                for (int i = 0; i < video.Count; i++)
                    if (video[i].Key && (video[i].Time <= from || start < 0)) start = i; else if (video[i].Time > from && start >= 0) break;
                if (start < 0) throw new InvalidOperationException("Noch nichts aufgenommen – gleich nochmal versuchen");
                v = video.GetRange(start, video.Count - start);
                long t0 = v[0].Time;
                a = audio.Where(x => x.Time >= t0).ToList();
            }
            byte[] thumb = null;
            lock (GL) if (grab != null) thumb = Thumb(grab);

            string game = ForegroundName();
            Directory.CreateDirectory(Folder);
            string name = Unique(Safe(game) + " " + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss"));
            string file = Path.Combine(Folder, name + ".mp4");
            double dur = Mp4.Write(file, v, vw, vh, cfg.Fps, a, audioRate, audioChannels);
            try
            {
                var td = Directory.CreateDirectory(ThumbDir);
                td.Attributes |= FileAttributes.Hidden;
                if (thumb != null) File.WriteAllBytes(Path.Combine(ThumbDir, name + ".jpg"), thumb);
            }
            catch (Exception ex) { Log.Write("clip thumb: " + ex.Message); }
            lastSaved = name + ".mp4";
            lastSavedAt = DateTime.UtcNow.Ticks;
            Log.Write("clip saved (" + why + "): " + lastSaved + " " + Math.Round(dur, 1) + " s");
            if (cfg.Sound) ClipToast.Chime();
            if (cfg.Overlay) ClipToast.Pop(thumb, game, dur, why); // the card top right (instead of the plain Windows bubble)
            else Program.Balloon("Clip gespeichert", name + " · " + Math.Round(dur) + " s");
            return new Dictionary<string, object> { { "ok", true }, { "name", lastSaved }, { "msg", "Clip gespeichert (" + Math.Round(dur) + " s)" } };
        }

        static string ForegroundName()
        {
            try
            {
                int pid;
                GetWindowThreadProcessId(GetForegroundWindow(), out pid);
                using (var p = Process.GetProcessById(pid))
                {
                    string proc = p.ProcessName.ToLowerInvariant();
                    if (proc == "explorer" || proc == "pcremote" || proc == "msedgewebview2") return "Clip";
                    string n = Apps.NameForProc(proc);
                    return string.IsNullOrEmpty(n) ? p.ProcessName : n;
                }
            }
            catch { return "Clip"; }
        }

        static string Safe(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s ?? "") sb.Append(Path.GetInvalidFileNameChars().Contains(c) ? ' ' : c);
            string r = sb.ToString().Trim();
            if (r.Length > 40) r = r.Substring(0, 40).Trim();
            return r.Length == 0 ? "Clip" : r;
        }

        static string Unique(string name)
        {
            string n = name;
            for (int i = 2; File.Exists(Path.Combine(Folder, n + ".mp4")); i++) n = name + " (" + i + ")";
            return n;
        }

        static byte[] Thumb(Grabber g)
        {
            using (var src = g.AsBitmap())
            {
                int w = 480, h = Math.Max(1, (int)Math.Round(480.0 * g.H / g.W));
                using (var dst = new Bitmap(w, h))
                {
                    using (var gr = Graphics.FromImage(dst))
                    {
                        gr.InterpolationMode = InterpolationMode.HighQualityBilinear;
                        gr.DrawImage(src, 0, 0, w, h);
                    }
                    var enc = ImageCodecInfo.GetImageEncoders().First(c => c.MimeType == "image/jpeg");
                    var ps = new EncoderParameters(1);
                    ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 78L);
                    using (var ms = new MemoryStream()) { dst.Save(ms, enc, ps); return ms.ToArray(); }
                }
            }
        }

        // ---------- library ----------

        public static string FileOf(string name)
        {
            if (string.IsNullOrEmpty(name) || name != Path.GetFileName(name) || !name.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Ungültiger Clip-Name");
            string f = Path.Combine(Folder, name);
            if (!File.Exists(f)) throw new FileNotFoundException("Clip nicht gefunden");
            return f;
        }

        public static byte[] ThumbOf(string name)
        {
            FileOf(name);
            string t = Path.Combine(ThumbDir, Path.GetFileNameWithoutExtension(name) + ".jpg");
            return File.Exists(t) ? File.ReadAllBytes(t) : null;
        }

        public static string Debug()
        {
            lock (L)
                return "video " + video.Count + (video.Count > 0 ? " " + video[0].Time + ".." + video[video.Count - 1].Time : "") +
                    " · audio " + audio.Count + (audio.Count > 0 ? " " + audio[0].Time + ".." + audio[audio.Count - 1].Time : "") + " · now " + Now() + " · " + audioError;
        }
        static string audioError;

        public static object Overview()
        {
            var list = new List<object>();
            long total = 0;
            if (Directory.Exists(Folder))
            {
                foreach (var f in new DirectoryInfo(Folder).GetFiles("*.mp4").OrderByDescending(x => x.LastWriteTimeUtc).Take(300))
                {
                    var info = Info(f);
                    total += f.Length;
                    var d = new Dictionary<string, object>(info);
                    d["thumb"] = File.Exists(Path.Combine(ThumbDir, Path.GetFileNameWithoutExtension(f.Name) + ".jpg"));
                    list.Add(d);
                }
            }
            var mons = Monitors.List().Select((m, i) => (object)new Dictionary<string, object> {
                { "dev", m.Dev }, { "name", "Bildschirm " + (i + 1) + (m.Primary ? " (Haupt)" : "") + " · " + m.W + "×" + m.H } }).ToList();
            int buffered;
            lock (L) buffered = video.Count > 1 ? (int)((video[video.Count - 1].Time - video[0].Time) / 10000000) : 0;
            return new Dictionary<string, object> {
                { "settings", new Dictionary<string, object> {
                    { "enabled", cfg.Enabled }, { "audio", cfg.Audio }, { "sound", cfg.Sound }, { "overlay", cfg.Overlay }, { "monitor", cfg.Monitor }, { "quality", cfg.Quality },
                    { "res", cfg.Res }, { "hotkey", cfg.Hotkey }, { "fps", cfg.Fps }, { "seconds", cfg.Seconds } } },
                { "status", new Dictionary<string, object> {
                    { "state", state }, { "error", error }, { "encoder", encoderName }, { "capture", captureName }, { "w", vw }, { "h", vh },
                    { "buffered", Math.Min(buffered, cfg.Seconds) }, { "audio", cfg.Audio && audioRate > 0 }, { "hotkeyOk", ClipHotkey.Ok },
                    { "lastSaved", lastSaved }, { "lastSavedAt", lastSavedAt } } },
                { "folder", Folder }, { "monitors", mons }, { "clips", list }, { "total", total } };
        }

        static Dictionary<string, object> Info(FileInfo f)
        {
            string key = f.FullName + "|" + f.LastWriteTimeUtc.Ticks + "|" + f.Length;
            lock (infoCache)
            {
                Dictionary<string, object> d;
                if (infoCache.TryGetValue(key, out d)) return d;
            }
            var info = new Dictionary<string, object> {
                { "name", f.Name }, { "size", f.Length }, { "time", (long)(f.LastWriteTimeUtc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds } };
            try { int w, h; info["dur"] = Mp4.ReadInfo(f.FullName, out w, out h); info["w"] = w; info["h"] = h; } catch { }
            lock (infoCache) infoCache[key] = info;
            return info;
        }

        public static object Command(Dictionary<string, object> a, bool local)
        {
            string cmd = J.Str(a, "cmd", "");
            switch (cmd)
            {
                case "save":
                    return Save("app");
                case "settings":
                    {
                        bool restart = false;
                        if (J.Has(a, "fps")) { int f = (int)J.Num(a, "fps") >= 60 ? 60 : 30; restart |= f != cfg.Fps; cfg.Fps = f; }
                        if (J.Has(a, "quality")) { string q = J.Str(a, "quality"); restart |= q != cfg.Quality; cfg.Quality = q; }
                        if (J.Has(a, "res")) { string r = J.Str(a, "res"); restart |= r != cfg.Res; cfg.Res = r; }
                        if (J.Has(a, "monitor")) { string m = J.Str(a, "monitor", ""); restart |= m != cfg.Monitor; cfg.Monitor = m; }
                        if (J.Has(a, "audio")) { bool au = J.Bool(a, "audio"); restart |= au != cfg.Audio; cfg.Audio = au; }
                        if (J.Has(a, "seconds")) cfg.Seconds = Math.Max(10, Math.Min(300, (int)J.Num(a, "seconds")));
                        if (J.Has(a, "sound")) cfg.Sound = J.Bool(a, "sound");
                        if (J.Has(a, "overlay")) cfg.Overlay = J.Bool(a, "overlay");
                        if (J.Has(a, "hotkey"))
                        {
                            cfg.Hotkey = (J.Str(a, "hotkey", "") ?? "").Trim().ToLowerInvariant();
                            string hk = cfg.Hotkey;
                            Program.OnUi(() => ClipHotkey.Set(hk));
                        }
                        if (J.Has(a, "enabled")) cfg.Enabled = J.Bool(a, "enabled");
                        SaveSettings();
                        if (!cfg.Enabled) StopRecording();
                        else if (worker == null) Start();
                        else if (restart) { StopRecording(); Start(); }
                        Thread.Sleep(300);
                        return Overview();
                    }
                case "delete":
                    {
                        string f = FileOf(J.Str(a, "name"));
                        File.Delete(f);
                        string t = Path.Combine(ThumbDir, Path.GetFileNameWithoutExtension(f) + ".jpg");
                        if (File.Exists(t)) File.Delete(t);
                        return new Dictionary<string, object> { { "ok", true } };
                    }
                case "rename":
                    {
                        string f = FileOf(J.Str(a, "name"));
                        string to = Safe(J.Str(a, "to", ""));
                        if (to.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase)) to = to.Substring(0, to.Length - 4).Trim();
                        string dest = Path.Combine(Folder, to + ".mp4");
                        if (!string.Equals(dest, f, StringComparison.OrdinalIgnoreCase))
                        {
                            if (File.Exists(dest)) throw new InvalidOperationException("Es gibt schon einen Clip mit diesem Namen");
                            File.Move(f, dest);
                            string t = Path.Combine(ThumbDir, Path.GetFileNameWithoutExtension(f) + ".jpg");
                            if (File.Exists(t)) File.Move(t, Path.Combine(ThumbDir, to + ".jpg"));
                        }
                        return new Dictionary<string, object> { { "ok", true }, { "name", to + ".mp4" } };
                    }
                case "play":
                    Process.Start(new ProcessStartInfo(FileOf(J.Str(a, "name"))) { UseShellExecute = true });
                    return new Dictionary<string, object> { { "ok", true }, { "msg", "Läuft am PC" } };
                case "folder":
                    {
                        Directory.CreateDirectory(Folder);
                        string n = J.Str(a, "name");
                        if (!string.IsNullOrEmpty(n)) Process.Start("explorer.exe", "/select,\"" + FileOf(n) + "\"");
                        else Process.Start("explorer.exe", "\"" + Folder + "\"");
                        return new Dictionary<string, object> { { "ok", true }, { "msg", "Ordner ist am PC offen" } };
                    }
                case "choosefolder":
                    {
                        if (!local) throw new InvalidOperationException("Nur direkt am PC verfügbar");
                        string chosen = null;
                        var done = new ManualResetEvent(false);
                        Program.OnUi(() =>
                        {
                            try
                            {
                                using (var dlg = new FolderBrowserDialog { Description = "Wo sollen die Clips gespeichert werden?", SelectedPath = Folder })
                                    if (dlg.ShowDialog() == DialogResult.OK) chosen = dlg.SelectedPath;
                            }
                            finally { done.Set(); }
                        });
                        done.WaitOne(TimeSpan.FromMinutes(5));
                        if (chosen != null) { cfg.Folder = chosen; SaveSettings(); }
                        return Overview();
                    }
            }
            throw new ArgumentException("Unbekannter Befehl");
        }
    }

    // ---------- global hotkey (works while a game is in front) ----------

    sealed class ClipHotkey : NativeWindow
    {
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, int mods, int vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);

        static ClipHotkey win;
        public static bool Ok { get; private set; }

        // Call on the UI thread. "" turns the hotkey off.
        public static void Set(string combo)
        {
            if (win == null) { win = new ClipHotkey(); win.CreateHandle(new CreateParams()); }
            UnregisterHotKey(win.Handle, 1);
            Ok = false;
            if (string.IsNullOrWhiteSpace(combo)) return;
            int mods = 0x4000, vk = 0; // MOD_NOREPEAT
            try
            {
                foreach (var part in combo.ToLowerInvariant().Split('+'))
                {
                    string k = part.Trim();
                    if (k == "ctrl" || k == "strg" || k == "control") mods |= 2;
                    else if (k == "alt") mods |= 1;
                    else if (k == "shift") mods |= 4;
                    else if (k == "win") mods |= 8;
                    else if (k.Length > 0) vk = Input.Vk(k);
                }
            }
            catch { vk = 0; }
            if (vk == 0) { Log.Write("clip hotkey: invalid " + combo); return; }
            Ok = RegisterHotKey(win.Handle, 1, mods, vk);
            if (!Ok) Log.Write("clip hotkey: " + combo + " is taken by another program");
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0312) // WM_HOTKEY
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try { Clips.Save("hotkey"); }
                    catch (Exception ex) { Program.Balloon("Clip nicht gespeichert", ex.Message); }
                });
            base.WndProc(ref m);
        }
    }

    // ---------- what you hear: WASAPI loopback ----------

    sealed class LoopbackAudio : IDisposable
    {
        delegate int InitD(IntPtr self, int shareMode, int flags, long bufferDur, long period, IntPtr format, IntPtr session);
        delegate int GetMixD(IntPtr self, out IntPtr fmt);
        delegate int SimpleD(IntPtr self);
        delegate int GetServiceD(IntPtr self, ref Guid riid, out IntPtr svc);
        delegate int GetBufferD(IntPtr self, out IntPtr data, out int frames, out int flags, out long devPos, out long qpcPos);
        delegate int ReleaseBufferD(IntPtr self, int frames);
        delegate int NextPacketD(IntPtr self, out int frames);

        static Guid IID_CLIENT = new Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), IID_CAPTURE = new Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317");
        static Guid FLOAT = new Guid("00000003-0000-0010-8000-00aa00389b71");

        IntPtr client, capture;
        int srcRate, channels, bits, decim = 1;
        bool isFloat;
        short[] buf = new short[0];
        public int Rate { get; private set; }
        public string DeviceId { get; private set; }

        public static string DefaultId()
        {
            try
            {
                var en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
                IMMDevice dev;
                if (en.GetDefaultAudioEndpoint(0, 0, out dev) < 0) return null;
                string id;
                dev.GetId(out id);
                return id;
            }
            catch { return null; }
        }

        public static LoopbackAudio Open()
        {
            var la = new LoopbackAudio();
            try { la.Init(); return la; }
            catch { la.Dispose(); throw; }
        }

        void Init()
        {
            var en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
            IMMDevice dev;
            if (en.GetDefaultAudioEndpoint(0, 0, out dev) < 0) throw new InvalidOperationException("Kein Ausgabegerät");
            string id;
            dev.GetId(out id);
            DeviceId = id;
            object o;
            int hr = dev.Activate(ref IID_CLIENT, 23, IntPtr.Zero, out o);
            if (hr < 0) throw new InvalidOperationException("Audio: 0x" + hr.ToString("X8"));
            IntPtr unk = Marshal.GetIUnknownForObject(o);
            try { Marshal.QueryInterface(unk, ref IID_CLIENT, out client); }
            finally { Marshal.Release(unk); Marshal.ReleaseComObject(o); }

            IntPtr fmt;
            hr = ComVt.Fn<GetMixD>(client, 8)(client, out fmt);
            if (hr < 0) throw new InvalidOperationException("Audio-Format: 0x" + hr.ToString("X8"));
            try
            {
                int tag = Marshal.ReadInt16(fmt) & 0xFFFF;
                channels = Marshal.ReadInt16(fmt, 2);
                srcRate = Marshal.ReadInt32(fmt, 4);
                bits = Marshal.ReadInt16(fmt, 14);
                isFloat = tag == 3;
                if (tag == 0xFFFE)
                {
                    var g = new byte[16];
                    Marshal.Copy(fmt + 24, g, 0, 16);
                    isFloat = new Guid(g) == FLOAT;
                }
                if (srcRate == 48000 || srcRate == 44100) decim = 1;
                else if (srcRate == 96000 || srcRate == 88200) decim = 2;
                else if (srcRate == 192000 || srcRate == 176400) decim = 4;
                else throw new InvalidOperationException("Abtastrate " + srcRate + " Hz wird nicht unterstützt");
                Rate = srcRate / decim;
                // shared mode, LOOPBACK, 200 ms buffer
                hr = ComVt.Fn<InitD>(client, 3)(client, 0, 0x00020000, 2000000, 0, fmt, IntPtr.Zero);
                if (hr < 0) throw new InvalidOperationException("Audio-Start: 0x" + hr.ToString("X8"));
            }
            finally { Marshal.FreeCoTaskMem(fmt); }
            hr = ComVt.Fn<GetServiceD>(client, 14)(client, ref IID_CAPTURE, out capture);
            if (hr < 0) throw new InvalidOperationException("Audio-Aufnahme: 0x" + hr.ToString("X8"));
            ComVt.Fn<SimpleD>(client, 10)(client); // Start
        }

        // Hands every waiting packet over as 16-bit stereo (frames, time in 100 ns). False when nothing was waiting.
        public unsafe bool Poll(Action<short[], int, long> sink)
        {
            bool any = false;
            var next = ComVt.Fn<NextPacketD>(capture, 5);
            var get = ComVt.Fn<GetBufferD>(capture, 3);
            var release = ComVt.Fn<ReleaseBufferD>(capture, 4);
            int n;
            while (next(capture, out n) >= 0 && n > 0)
            {
                IntPtr data; int frames, flags; long dpos, qpc;
                if (get(capture, out data, out frames, out flags, out dpos, out qpc) < 0) break;
                int outFrames = frames / decim;
                if (buf.Length < outFrames * 2) buf = new short[outFrames * 2 + 1024];
                bool silent = (flags & 2) != 0;
                if (silent) Array.Clear(buf, 0, outFrames * 2);
                else
                {
                    int bytesPer = bits / 8, stride = bytesPer * channels;
                    byte* p = (byte*)data;
                    for (int i = 0; i < outFrames; i++)
                    {
                        byte* f = p + (long)i * decim * stride;
                        float l = Sample(f), r = channels > 1 ? Sample(f + bytesPer) : l;
                        if (channels > 2) { float c = Sample(f + 2 * bytesPer) * 0.7f; l += c; r += c; } // fold the center (voices) in
                        buf[i * 2] = Clamp(l);
                        buf[i * 2 + 1] = Clamp(r);
                    }
                }
                release(capture, frames);
                any = true;
                if (outFrames > 0) sink(buf, outFrames, qpc);
            }
            return any;
        }

        unsafe float Sample(byte* p)
        {
            if (isFloat) return *(float*)p;
            if (bits == 16) return *(short*)p / 32768f;
            if (bits == 32) return *(int*)p / 2147483648f;
            if (bits == 24) return ((p[0] << 8) | (p[1] << 16) | (p[2] << 24)) / 2147483648f;
            return 0;
        }

        static short Clamp(float v)
        {
            int s = (int)(v * 32767f);
            return (short)(s > 32767 ? 32767 : s < -32768 ? -32768 : s);
        }

        public void Dispose()
        {
            if (client != IntPtr.Zero) try { ComVt.Fn<SimpleD>(client, 11)(client); } catch { } // Stop
            ComVt.Rel(ref capture);
            ComVt.Rel(ref client);
        }
    }

    // ---------- Windows' AAC encoder ----------

    sealed class AacEncoder : IDisposable
    {
        [DllImport("mfplat.dll")] static extern int MFStartup(int version, int flags);
        [DllImport("mfplat.dll")] static extern int MFCreateMediaType(out IMFMediaType type);
        [DllImport("mfplat.dll")] static extern int MFCreateSample(out IMFSample sample);
        [DllImport("mfplat.dll")] static extern int MFCreateMemoryBuffer(int max, out IMFMediaBuffer buffer);

        static Guid MT_MAJOR = new Guid("48eba18e-f8c9-4687-bf11-0a74c9f96a8f"), MT_SUBTYPE = new Guid("f7e34c9a-42e8-4714-b74b-cb29d72c35e5");
        static Guid AUDIO = new Guid("73647561-0000-0010-8000-00AA00389B71"), PCM = new Guid("00000001-0000-0010-8000-00AA00389B71"), AAC = new Guid("00001610-0000-0010-8000-00AA00389B71");
        static Guid CHANNELS = new Guid("37e48bf5-645e-4c5b-89de-ada9e29b696a"), RATE = new Guid("5faeeae7-0290-4c31-9e8a-c534f68d9dba");
        static Guid BITS = new Guid("f2deb57f-40fa-4764-aa33-ed4f2d1ff669"), ALIGN = new Guid("322de230-9eeb-43bd-ab7a-ff412251541d");
        static Guid AVG_BYTES = new Guid("1aab75c8-cfef-451c-ab95-ac034b8e1731"), PAYLOAD = new Guid("bfbabe79-7434-4d1c-94f0-72a3b9e17188");
        const int NEED_MORE_INPUT = unchecked((int)0xC00D6D72);
        const int MaxFrames = 8192;

        readonly IMFTransform mft;
        readonly IMFSample inSample, outSample;
        readonly IMFMediaBuffer inBuf, outBuf;
        readonly bool provides;
        readonly int ch, rate;
        long fed;

        public AacEncoder(int rate, int channels)
        {
            ch = channels;
            this.rate = rate;
            MFStartup(0x20070, 0);
            mft = (IMFTransform)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("93AF0C51-2275-45d2-A35B-F2BA21CAED00")));
            IMFMediaType i, o;
            MFCreateMediaType(out i);
            i.SetGUID(ref MT_MAJOR, ref AUDIO); i.SetGUID(ref MT_SUBTYPE, ref PCM);
            i.SetUINT32(ref BITS, 16); i.SetUINT32(ref RATE, rate); i.SetUINT32(ref CHANNELS, ch);
            i.SetUINT32(ref ALIGN, ch * 2); i.SetUINT32(ref AVG_BYTES, rate * ch * 2);
            MFCreateMediaType(out o);
            o.SetGUID(ref MT_MAJOR, ref AUDIO); o.SetGUID(ref MT_SUBTYPE, ref AAC);
            o.SetUINT32(ref BITS, 16); o.SetUINT32(ref RATE, rate); o.SetUINT32(ref CHANNELS, ch);
            o.SetUINT32(ref AVG_BYTES, 20000); o.SetUINT32(ref PAYLOAD, 0); // 160 kbit/s, raw AAC frames
            int hr = mft.SetInputType(0, i, 0);
            if (hr >= 0) hr = mft.SetOutputType(0, o, 0);
            else { hr = mft.SetOutputType(0, o, 0); if (hr >= 0) hr = mft.SetInputType(0, i, 0); }
            Marshal.ReleaseComObject(i); Marshal.ReleaseComObject(o);
            if (hr < 0) throw new InvalidOperationException("AAC-Encoder: 0x" + hr.ToString("X8"));

            MFT_OUTPUT_STREAM_INFO info;
            mft.GetOutputStreamInfo(0, out info);
            provides = (info.dwFlags & 0x100) != 0;
            MFCreateMemoryBuffer(MaxFrames * ch * 2, out inBuf);
            MFCreateSample(out inSample);
            inSample.AddBuffer(inBuf);
            MFCreateMemoryBuffer(Math.Max(info.cbSize, 8192), out outBuf);
            MFCreateSample(out outSample);
            outSample.AddBuffer(outBuf);
            mft.ProcessMessage(0x10000000, IntPtr.Zero);
            mft.ProcessMessage(0x10000003, IntPtr.Zero);
        }

        public void Feed(short[] pcm, int frames, List<byte[]> into)
        {
            int done = 0;
            while (done < frames)
            {
                int n = Math.Min(MaxFrames, frames - done);
                IntPtr p; int max, cur;
                inBuf.Lock(out p, out max, out cur);
                Marshal.Copy(pcm, done * ch, p, n * ch);
                inBuf.Unlock();
                inBuf.SetCurrentLength(n * ch * 2);
                inSample.SetSampleTime(fed * 10000000L / rate);
                inSample.SetSampleDuration(n * 10000000L / rate);
                fed += n;
                int hr = mft.ProcessInput(0, inSample, 0);
                if (hr < 0) throw new InvalidOperationException("AAC-Eingabe: 0x" + hr.ToString("X8"));
                Drain(into);
                done += n;
            }
        }

        void Drain(List<byte[]> into)
        {
            int size = IntPtr.Size == 8 ? 32 : 16;
            IntPtr arr = Marshal.AllocHGlobal(size);
            IntPtr sp = provides ? IntPtr.Zero : Marshal.GetComInterfaceForObject(outSample, typeof(IMFSample));
            try
            {
                while (true)
                {
                    for (int k = 0; k < size; k++) Marshal.WriteByte(arr, k, 0);
                    if (!provides) { outBuf.SetCurrentLength(0); Marshal.WriteIntPtr(arr, IntPtr.Size, sp); }
                    int status;
                    int hr = mft.ProcessOutput(0, 1, arr, out status);
                    IntPtr ev = Marshal.ReadIntPtr(arr, IntPtr.Size * 3);
                    if (ev != IntPtr.Zero) Marshal.Release(ev);
                    if (hr == NEED_MORE_INPUT) return;
                    if (hr < 0) throw new InvalidOperationException("AAC-Ausgabe: 0x" + hr.ToString("X8"));
                    IMFMediaBuffer b = outBuf;
                    IMFSample own = null;
                    if (provides)
                    {
                        IntPtr q = Marshal.ReadIntPtr(arr, IntPtr.Size);
                        if (q == IntPtr.Zero) continue;
                        own = (IMFSample)Marshal.GetObjectForIUnknown(q);
                        Marshal.Release(q);
                        own.ConvertToContiguousBuffer(out b);
                    }
                    IntPtr data; int max, cur;
                    b.Lock(out data, out max, out cur);
                    var bytes = new byte[cur];
                    Marshal.Copy(data, bytes, 0, cur);
                    b.Unlock();
                    if (own != null) { Marshal.ReleaseComObject(b); Marshal.ReleaseComObject(own); }
                    if (cur > 0) into.Add(bytes);
                }
            }
            finally
            {
                if (sp != IntPtr.Zero) Marshal.Release(sp);
                Marshal.FreeHGlobal(arr);
            }
        }

        public void Dispose()
        {
            try { mft.ProcessMessage(0x10000001, IntPtr.Zero); } catch { }
            foreach (object o in new object[] { inSample, outSample, inBuf, outBuf, mft })
                try { if (o != null) Marshal.ReleaseComObject(o); } catch { }
        }
    }
}
