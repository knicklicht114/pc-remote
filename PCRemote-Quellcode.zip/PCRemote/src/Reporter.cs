using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;

namespace PCRemote
{
    // Opt-in and anonymous: if the user agreed, the names of found apps are sent once so the author can add support.
    // Only names are sent – no PIN, no account, no personal data. Default is off.
    static class Reporter
    {
        // The author's always-on server collects the names and notifies the author (not reachable from here otherwise).
        public static string Url = Environment.GetEnvironmentVariable("PCREMOTE_REPORT_URL") ?? "http://144.76.222.28:40218/api/report";
        // the same server also holds the accounts (the app's "Konten" page signs in there)
        public static string Central { get { int i = Url.IndexOf("/api/"); return i > 0 ? Url.Substring(0, i) : Url.TrimEnd('/'); } }

        static int lastHash;
        static DateTime lastSent = DateTime.MinValue;

        public static void AfterScan(IEnumerable<string> names)
        {
            if (!Program.Cfg.ReportApps) return;
            var list = names.Where(n => !string.IsNullOrWhiteSpace(n)).Select(n => n.Trim()).Distinct().OrderBy(n => n).ToList();
            if (list.Count == 0) return;
            int hash = string.Join("|", list).GetHashCode();
            // only when the set changed, and at most every few hours
            if (hash == lastHash && (DateTime.UtcNow - lastSent).TotalHours < 6) return;
            lastHash = hash;
            lastSent = DateTime.UtcNow;

            var t = new Thread(() => Send(list)) { IsBackground = true, Name = "app-report" };
            t.Start();
        }

        static void Send(List<string> names)
        {
            try
            {
                string body = "{\"apps\":[" + string.Join(",", names.Select(J.Ser).ToArray()) + "]}";
                var req = (HttpWebRequest)WebRequest.Create(Url);
                req.Method = "POST";
                req.ContentType = "application/json";
                req.UserAgent = "PCRemote/" + Program.Version;
                req.Timeout = 10000;
                var bytes = Encoding.UTF8.GetBytes(body);
                req.ContentLength = bytes.Length;
                using (var s = req.GetRequestStream()) s.Write(bytes, 0, bytes.Length);
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(res.GetResponseStream()))
                {
                    var d = J.Obj(sr.ReadToEnd());
                    Log.Write("app report: " + names.Count + " Namen gesendet, " + (int)J.Num(d, "new") + " neu");
                }
            }
            catch (Exception ex) { Log.Warn("app report: " + ex.Message); }
        }
    }
}
