using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace PCRemote
{
    // Windows Core Audio: master/mic endpoint volume, per-app sessions, default device switching.
    static class Audio
    {
        const int eRender = 0, eCapture = 1;
        const int eConsole = 0, eCommunications = 2;
        const int CLSCTX_ALL = 23, DEVICE_STATE_ACTIVE = 1;

        static IMMDeviceEnumerator NewEnum() { return (IMMDeviceEnumerator)new MMDeviceEnumeratorCom(); }

        static IMMDevice DefaultDevice(int flow, int role)
        {
            IMMDevice d;
            return NewEnum().GetDefaultAudioEndpoint(flow, role, out d) == 0 ? d : null;
        }

        static T Activate<T>(IMMDevice dev) where T : class
        {
            Guid iid = typeof(T).GUID;
            object o;
            int hr = dev.Activate(ref iid, CLSCTX_ALL, IntPtr.Zero, out o);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            return (T)o;
        }

        static IAudioEndpointVolume Endpoint(int flow)
        {
            var d = DefaultDevice(flow, eConsole);
            if (d == null) throw new InvalidOperationException(flow == eRender ? "Kein Ausgabegerät gefunden" : "Kein Mikrofon gefunden");
            return Activate<IAudioEndpointVolume>(d);
        }

        static float Clamp(float v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

        static object EndpointState(int flow)
        {
            var d = DefaultDevice(flow, eConsole);
            if (d == null) return null;
            var ev = Activate<IAudioEndpointVolume>(d);
            float v; bool m;
            ev.GetMasterVolumeLevelScalar(out v);
            ev.GetMute(out m);
            return new Dictionary<string, object> { { "v", Math.Round(v, 3) }, { "m", m } };
        }

        public static object MasterState() { return EndpointState(eRender); }
        public static object MicState() { return EndpointState(eCapture); }

        public static void SetMasterVolume(float v)
        {
            var ev = Endpoint(eRender);
            Guid g = Guid.Empty;
            ev.SetMasterVolumeLevelScalar(Clamp(v), ref g);
            bool m;
            ev.GetMute(out m);
            if (m && v > 0.001f) ev.SetMute(false, ref g);
        }

        public static void StepMaster(float delta)
        {
            var ev = Endpoint(eRender);
            float v;
            ev.GetMasterVolumeLevelScalar(out v);
            Guid g = Guid.Empty;
            ev.SetMasterVolumeLevelScalar(Clamp(v + delta), ref g);
            if (delta > 0) ev.SetMute(false, ref g);
        }

        public static bool SetMasterMute(bool? target)
        {
            var ev = Endpoint(eRender);
            bool m;
            ev.GetMute(out m);
            bool n = target.HasValue ? target.Value : !m;
            Guid g = Guid.Empty;
            ev.SetMute(n, ref g);
            return n;
        }

        // The console and communications default mics can differ; mute/level both so it works everywhere.
        static List<IAudioEndpointVolume> Mics()
        {
            var list = new List<IAudioEndpointVolume>();
            var ids = new HashSet<string>();
            foreach (int role in new[] { eConsole, eCommunications })
            {
                var d = DefaultDevice(eCapture, role);
                if (d == null) continue;
                string id;
                d.GetId(out id);
                if (id != null && !ids.Add(id)) continue;
                list.Add(Activate<IAudioEndpointVolume>(d));
            }
            if (list.Count == 0) throw new InvalidOperationException("Kein Mikrofon gefunden");
            return list;
        }

        public static bool SetMicMute(bool? target)
        {
            var mics = Mics();
            bool m;
            mics[0].GetMute(out m);
            bool n = target.HasValue ? target.Value : !m;
            Guid g = Guid.Empty;
            foreach (var ev in mics) ev.SetMute(n, ref g);
            return n;
        }

        public static void SetMicVolume(float v)
        {
            Guid g = Guid.Empty;
            foreach (var ev in Mics()) ev.SetMasterVolumeLevelScalar(Clamp(v), ref g);
        }

        // ---------- per-app sessions ----------

        class SessionRef
        {
            public string Key;
            public uint Pid;
            public ISimpleAudioVolume Vol;
            public IAudioMeterInformation Meter;
        }

        static readonly Dictionary<uint, string> pidNames = new Dictionary<uint, string>();
        static DateTime pidNamesAt = DateTime.UtcNow;

        static string ProcKey(uint pid)
        {
            lock (pidNames)
            {
                if ((DateTime.UtcNow - pidNamesAt).TotalSeconds > 60) { pidNames.Clear(); pidNamesAt = DateTime.UtcNow; }
                string n;
                if (pidNames.TryGetValue(pid, out n)) return n;
                try { using (var p = Process.GetProcessById((int)pid)) n = p.ProcessName.ToLowerInvariant(); }
                catch { n = null; }
                if (n != null) pidNames[pid] = n;
                return n;
            }
        }

        static List<SessionRef> AllSessions()
        {
            var list = new List<SessionRef>();
            IMMDeviceCollection col;
            if (NewEnum().EnumAudioEndpoints(eRender, DEVICE_STATE_ACTIVE, out col) != 0) return list;
            int n;
            col.GetCount(out n);
            for (int i = 0; i < n; i++)
            {
                try
                {
                    IMMDevice dev;
                    if (col.Item(i, out dev) != 0) continue;
                    var mgr = Activate<IAudioSessionManager2>(dev);
                    IAudioSessionEnumerator en;
                    if (mgr.GetSessionEnumerator(out en) != 0 || en == null) continue;
                    int c;
                    en.GetCount(out c);
                    for (int j = 0; j < c; j++)
                    {
                        IAudioSessionControl2 ctl;
                        if (en.GetSession(j, out ctl) != 0 || ctl == null) continue;
                        int st;
                        ctl.GetState(out st);
                        if (st == 2) continue; // expired
                        uint pid;
                        ctl.GetProcessId(out pid);
                        bool sys = ctl.IsSystemSoundsSession() == 0;
                        string key = sys ? "system" : ProcKey(pid);
                        if (key == null) continue;
                        var vol = ctl as ISimpleAudioVolume;
                        if (vol == null) continue;
                        list.Add(new SessionRef { Key = key, Pid = pid, Vol = vol, Meter = ctl as IAudioMeterInformation });
                    }
                }
                catch (Exception ex) { Log.Write("sessions: " + ex.Message); }
            }
            return list;
        }

        public static object AppStates()
        {
            var d = new Dictionary<string, object>();
            var agg = new Dictionary<string, float[]>(); // [maxVol, allMuted]
            foreach (var s in AllSessions())
            {
                float v; bool m;
                s.Vol.GetMasterVolume(out v);
                s.Vol.GetMute(out m);
                float[] a;
                if (!agg.TryGetValue(s.Key, out a)) { a = new float[] { 0, 1 }; agg[s.Key] = a; }
                a[0] = Math.Max(a[0], v);
                if (!m) a[1] = 0;
            }
            foreach (var kv in agg)
                d[kv.Key] = new Dictionary<string, object> { { "v", Math.Round(kv.Value[0], 3) }, { "m", kv.Value[1] > 0.5f } };
            return d;
        }

        public static object MixerList()
        {
            var order = new List<string>();
            var rows = new Dictionary<string, Dictionary<string, object>>();
            foreach (var s in AllSessions())
            {
                float v; bool m; float peak = 0;
                s.Vol.GetMasterVolume(out v);
                s.Vol.GetMute(out m);
                if (s.Meter != null) s.Meter.GetPeakValue(out peak);
                Dictionary<string, object> r;
                if (!rows.TryGetValue(s.Key, out r))
                {
                    r = new Dictionary<string, object> {
                        { "key", s.Key }, { "name", Apps.NameForProc(s.Key) }, { "v", 0.0 }, { "m", true }, { "peak", 0.0 }, { "sys", s.Key == "system" } };
                    rows[s.Key] = r;
                    order.Add(s.Key);
                }
                r["v"] = Math.Round(Math.Max((double)r["v"], v), 3);
                r["m"] = (bool)r["m"] && m;
                r["peak"] = Math.Round(Math.Max((double)r["peak"], peak), 3);
            }
            order.Sort((a, b) =>
            {
                if (a == "system") return 1;
                if (b == "system") return -1;
                return string.Compare((string)rows[a]["name"], (string)rows[b]["name"], StringComparison.OrdinalIgnoreCase);
            });
            var list = new List<object>();
            foreach (var k in order) list.Add(rows[k]);
            return list;
        }

        static List<SessionRef> SessionsFor(string key)
        {
            key = (key ?? "").ToLowerInvariant();
            var list = AllSessions().FindAll(s => s.Key == key);
            if (list.Count == 0) throw new InvalidOperationException("Diese App spielt gerade keinen Ton ab");
            return list;
        }

        public static void SetAppVolume(string key, float v)
        {
            Guid g = Guid.Empty;
            foreach (var s in SessionsFor(key))
            {
                s.Vol.SetMasterVolume(Clamp(v), ref g);
                if (v > 0.001f) s.Vol.SetMute(false, ref g);
            }
        }

        public static bool SetAppMute(string key, bool? target)
        {
            var list = SessionsFor(key);
            bool all = true;
            foreach (var s in list) { bool m; s.Vol.GetMute(out m); if (!m) all = false; }
            bool n = target.HasValue ? target.Value : !all;
            Guid g = Guid.Empty;
            foreach (var s in list) s.Vol.SetMute(n, ref g);
            return n;
        }

        // ---------- devices ----------

        public static object Devices(int flow)
        {
            var list = new List<object>();
            var en = NewEnum();
            string defId = null;
            IMMDevice def;
            if (en.GetDefaultAudioEndpoint(flow, eConsole, out def) == 0) def.GetId(out defId);
            IMMDeviceCollection col;
            if (en.EnumAudioEndpoints(flow, DEVICE_STATE_ACTIVE, out col) != 0) return list;
            int n;
            col.GetCount(out n);
            for (int i = 0; i < n; i++)
            {
                IMMDevice dev;
                if (col.Item(i, out dev) != 0) continue;
                string id;
                dev.GetId(out id);
                list.Add(new Dictionary<string, object> { { "id", id }, { "name", FriendlyName(dev) }, { "def", id == defId } });
            }
            return list;
        }

        static string FriendlyName(IMMDevice dev)
        {
            IPropertyStore ps;
            if (dev.OpenPropertyStore(0, out ps) != 0 || ps == null) return "Audiogerät";
            var key = new PROPERTYKEY { fmtid = new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"), pid = 14 };
            PROPVARIANT pv;
            if (ps.GetValue(ref key, out pv) != 0) return "Audiogerät";
            try { return pv.vt == 31 ? Marshal.PtrToStringUni(pv.p) : "Audiogerät"; }
            finally { PropVariantClear(ref pv); }
        }

        public static void SetDefaultDevice(string id)
        {
            if (string.IsNullOrEmpty(id)) throw new ArgumentException("Gerät fehlt");
            var pc = (IPolicyConfig)new CPolicyConfigClient();
            for (int role = 0; role <= 2; role++)
            {
                int hr = pc.SetDefaultEndpoint(id, role);
                if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            }
        }

        [DllImport("ole32.dll")] static extern int PropVariantClear(ref PROPVARIANT pv);
    }

    // ---------- COM interop definitions ----------

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    class MMDeviceEnumeratorCom { }

    [ComImport, Guid("870af99c-171d-4f9e-af0d-e63df40c2bc9")]
    class CPolicyConfigClient { }

    [StructLayout(LayoutKind.Sequential)]
    struct PROPERTYKEY { public Guid fmtid; public int pid; }

    [StructLayout(LayoutKind.Explicit)]
    struct PROPVARIANT
    {
        [FieldOffset(0)] public short vt;
        [FieldOffset(8)] public IntPtr p;
        [FieldOffset(16)] public IntPtr p2;
    }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IMMDeviceCollection devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
        [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr client);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr client);
    }

    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceCollection
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int Item(int index, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
        [PreserveSig] int OpenPropertyStore(int access, out IPropertyStore props);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetState(out int state);
    }

    [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int GetAt(int index, out PROPERTYKEY key);
        [PreserveSig] int GetValue(ref PROPERTYKEY key, out PROPVARIANT value);
        [PreserveSig] int SetValue(ref PROPERTYKEY key, ref PROPVARIANT value);
        [PreserveSig] int Commit();
    }

    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioEndpointVolume
    {
        [PreserveSig] int RegisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int UnregisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int GetChannelCount(out uint count);
        [PreserveSig] int SetMasterVolumeLevel(float levelDB, ref Guid ctx);
        [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid ctx);
        [PreserveSig] int GetMasterVolumeLevel(out float levelDB);
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        [PreserveSig] int SetChannelVolumeLevel(uint channel, float levelDB, ref Guid ctx);
        [PreserveSig] int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid ctx);
        [PreserveSig] int GetChannelVolumeLevel(uint channel, out float levelDB);
        [PreserveSig] int GetChannelVolumeLevelScalar(uint channel, out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        [PreserveSig] int GetVolumeStepInfo(out uint step, out uint count);
        [PreserveSig] int VolumeStepUp(ref Guid ctx);
        [PreserveSig] int VolumeStepDown(ref Guid ctx);
        [PreserveSig] int QueryHardwareSupport(out uint mask);
        [PreserveSig] int GetVolumeRange(out float min, out float max, out float inc);
    }

    [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioSessionManager2
    {
        [PreserveSig] int GetAudioSessionControl(IntPtr guid, int flags, out IntPtr ctl);
        [PreserveSig] int GetSimpleAudioVolume(IntPtr guid, int flags, out IntPtr vol);
        [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator en);
        [PreserveSig] int RegisterSessionNotification(IntPtr n);
        [PreserveSig] int UnregisterSessionNotification(IntPtr n);
        [PreserveSig] int RegisterDuckNotification([MarshalAs(UnmanagedType.LPWStr)] string id, IntPtr n);
        [PreserveSig] int UnregisterDuckNotification(IntPtr n);
    }

    [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioSessionEnumerator
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int GetSession(int index, out IAudioSessionControl2 session);
    }

    [ComImport, Guid("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioSessionControl2
    {
        [PreserveSig] int GetState(out int state);
        [PreserveSig] int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        [PreserveSig] int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid ctx);
        [PreserveSig] int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        [PreserveSig] int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid ctx);
        [PreserveSig] int GetGroupingParam(out Guid g);
        [PreserveSig] int SetGroupingParam(ref Guid g, ref Guid ctx);
        [PreserveSig] int RegisterAudioSessionNotification(IntPtr n);
        [PreserveSig] int UnregisterAudioSessionNotification(IntPtr n);
        [PreserveSig] int GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetSessionInstanceIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetProcessId(out uint pid);
        [PreserveSig] int IsSystemSoundsSession();
        [PreserveSig] int SetDuckingPreference([MarshalAs(UnmanagedType.Bool)] bool optOut);
    }

    [ComImport, Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface ISimpleAudioVolume
    {
        [PreserveSig] int SetMasterVolume(float level, ref Guid ctx);
        [PreserveSig] int GetMasterVolume(out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }

    [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioMeterInformation
    {
        [PreserveSig] int GetPeakValue(out float peak);
        [PreserveSig] int GetMeteringChannelCount(out int count);
        [PreserveSig] int GetChannelsPeakValues(int count, IntPtr peaks);
        [PreserveSig] int QueryHardwareSupport(out int mask);
    }

    // Undocumented but stable since Windows 7; only SetDefaultEndpoint is used, the rest are vtable placeholders.
    [ComImport, Guid("f8679f50-850a-41cf-9c72-430f290290c8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPolicyConfig
    {
        [PreserveSig] int GetMixFormat();
        [PreserveSig] int GetDeviceFormat();
        [PreserveSig] int ResetDeviceFormat();
        [PreserveSig] int SetDeviceFormat();
        [PreserveSig] int GetProcessingPeriod();
        [PreserveSig] int SetProcessingPeriod();
        [PreserveSig] int GetShareMode();
        [PreserveSig] int SetShareMode();
        [PreserveSig] int GetPropertyValue();
        [PreserveSig] int SetPropertyValue();
        [PreserveSig] int SetDefaultEndpoint([MarshalAs(UnmanagedType.LPWStr)] string deviceId, int role);
        [PreserveSig] int SetEndpointVisibility();
    }
}
