using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace PCRemote
{
    static class Program
    {
        public const string Version = "1.2.0";
        public static string BaseDir;
        // personal files (PIN, phones, deck, Spotify login, log …) – in "data" next to the program, not between its files
        public static string DataDir;
        public static Config Cfg;
        public static volatile bool Exiting;

        static NotifyIcon tray;
        static HttpServer server;
        static Control ui;
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string RunName = "PCRemote";

        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

        static readonly string[] DataFiles = { "config.json", "devices.json", "layout.json", "layout.before-display.json", "addons.json", "spotify.json",
            "clips.json", "ui.json", "voice.json", "voice.wav", "pcremote.log", "pcremote.log.1" };

        // Older versions kept the personal files right next to PCRemote.exe: move them into "data" once. Never overwrites
        // anything there; a file that can't be moved (locked) is copied instead, so nothing is ever lost.
        static string UseDataDir()
        {
            DataDir = Path.Combine(BaseDir, "data");
            try { Directory.CreateDirectory(DataDir); }
            catch { DataDir = BaseDir; return null; } // no write access there: keep working the old way
            int n = 0;
            foreach (string f in DataFiles)
                foreach (string name in new[] { f, f + ".bak" })
                {
                    string from = Path.Combine(BaseDir, name), to = Path.Combine(DataDir, name);
                    if (!File.Exists(from) || File.Exists(to)) continue;
                    try { File.Move(from, to); n++; }
                    catch { try { File.Copy(from, to); n++; } catch { } }
                }
            return n > 0 ? n + " persönliche Dateien in den Ordner „data“ verschoben" : null;
        }

        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length == 2 && args[0] == "--make-ico") { Logo.WriteIco(args[1]); return; }
            if (args.Length == 3 && args[0] == "--make-png") { File.WriteAllBytes(args[1], Logo.Png(int.Parse(args[2]), false)); return; }
            if (args.Length >= 2 && args[0] == "--toast-png") { ClipToast.Preview(args[1], args.Length > 2 && File.Exists(args[2]) ? File.ReadAllBytes(args[2]) : null); return; }
            if (args.Length == 2 && args[0] == "--selftest") { SelfTest.Run(args[1]); return; }
            if (args.Length == 3 && args[0] == "--cliptest") { SelfTest.Clip(args[1], args[2]); return; }
            bool trayOnly = args.Contains("--tray");
            bool restarted = args.Contains("--restarted");

            bool created;
            using (var mutex = new Mutex(true, "PCRemote.SingleInstance", out created))
            using (var showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, "PCRemote.Show"))
            {
                if (!created && restarted)
                {
                    // started by the crashed instance: wait until it is really gone
                    try { created = mutex.WaitOne(20000); }
                    catch (AbandonedMutexException) { created = true; }
                }
                if (!created)
                {
                    // Already running: bring the existing window to the front instead.
                    if (!trayOnly) showEvent.Set();
                    return;
                }
                try { SetProcessDPIAware(); } catch { }

                BaseDir = AppDomain.CurrentDomain.BaseDirectory;
                string moved = UseDataDir();
                Log.Init(Path.Combine(DataDir, "pcremote.log"));
                if (moved != null) Log.Write(moved);
                if (restarted) Log.Warn("Nach einem Absturz automatisch neu gestartet");
                CatchCrashes();
                Cfg = Config.Load(Path.Combine(DataDir, "config.json"));
                Addons.Init(Path.Combine(DataDir, "addons.json"));
                SpotifyApi.Init(Path.Combine(DataDir, "spotify.json"));
                Devices.Init(Path.Combine(DataDir, "devices.json"));
                Apps.ScanAsync();
                MigrateAutostart();

                server = new HttpServer(Cfg.Port, new Api());
                try { server.Start(); }
                catch (Exception ex)
                {
                    Log.Write("start failed: " + ex);
                    MessageBox.Show("PC Remote konnte Port " + Cfg.Port + " nicht öffnen.\n\n" + ex.Message,
                        "PC Remote", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Log.Write("listening on port " + Cfg.Port + " (v" + Version + ")");

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                ui = new Control();
                var h = ui.Handle; // creates the handle so other threads can marshal onto the UI thread
                BuildTray();
                Clips.Init(Path.Combine(DataDir, "clips.json"));
                // clip by voice: starting the speech recognition takes a moment – not on the way of the window
                new Thread(() => VoiceClip.Init(Path.Combine(DataDir, "voice.json"))) { IsBackground = true }.Start();
                Update.StartBackground();

                var waiter = new Thread(() =>
                {
                    while (!Exiting)
                    {
                        showEvent.WaitOne();
                        if (Exiting) break;
                        OnUi(() => Desktop.Show(null));
                    }
                });
                waiter.IsBackground = true;
                waiter.Start();

                if (!Cfg.Welcomed)
                {
                    Cfg.Welcomed = true;
                    Cfg.Save();
                    Desktop.Show("connect");
                }
                else if (!trayOnly) Desktop.Show(null);

                Application.Run();
                Exiting = true;
                try { VirtualDisplay.RemoveAll(); } catch { }
                showEvent.Set();
                tray.Visible = false;
                server.Stop();
            }
        }

        // Errors must never just make PC Remote disappear: UI errors are logged and the app keeps running;
        // a fatal error is logged with all details and PC Remote starts itself again (window open if it was open).
        static int crashes;
        static void CatchCrashes()
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Log.Error("Fehler im Fenster (abgefangen, läuft weiter): " + e.Exception);
            System.Threading.Tasks.TaskScheduler.UnobservedTaskException += (s, e) => { Log.Warn("Hintergrund-Fehler: " + e.Exception.GetBaseException().Message); e.SetObserved(); };
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Log.Error("ABSTURZ: " + e.ExceptionObject);
                if (!e.IsTerminating || Exiting || Interlocked.Increment(ref crashes) > 1) return;
                try
                {
                    bool open = Desktop.IsOpen;
                    try { if (tray != null) tray.Visible = false; } catch { }
                    try { server.Stop(); } catch { }
                    Process.Start(new ProcessStartInfo(Application.ExecutablePath, open ? "--restarted" : "--tray --restarted") { UseShellExecute = false }).Dispose();
                }
                catch (Exception ex) { Log.Error("Neustart nach Absturz fehlgeschlagen: " + ex.Message); }
            };
        }

        public static void OnUi(Action a)
        {
            if (ui == null || ui.IsDisposed) return;
            try { ui.BeginInvoke(a); } catch (Exception ex) { Log.Write("ui: " + ex.Message); }
        }

        public static void Balloon(string title, string text)
        {
            OnUi(() => { if (tray != null) tray.ShowBalloonTip(5000, title, text, ToolTipIcon.Info); });
        }

        public static void Quit()
        {
            OnUi(() =>
            {
                Exiting = true;
                Desktop.CloseForExit();
                tray.Visible = false;
                Application.Exit();
            });
        }

        static void BuildTray()
        {
            tray = new NotifyIcon();
            tray.Icon = Logo.MakeIcon();
            tray.Text = "PC Remote – Port " + Cfg.Port;

            var menu = new ContextMenuStrip();
            var open = new ToolStripMenuItem("PC Remote öffnen", null, delegate { Desktop.Show(null); });
            open.Font = new System.Drawing.Font(open.Font, System.Drawing.FontStyle.Bold);
            menu.Items.Add(open);
            menu.Items.Add("Handy verbinden (QR-Code)", null, delegate { Desktop.Show("connect"); });
            menu.Items.Add("Adresse und PIN anzeigen", null, delegate { ShowInfo(); });
            menu.Items.Add("Clip speichern", null, delegate
            {
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try { Clips.Save("tray"); }
                    catch (Exception ex) { Balloon("Clip nicht gespeichert", ex.Message); }
                });
            });
            menu.Items.Add("Apps neu scannen", null, delegate
            {
                Apps.ScanAsync();
                tray.ShowBalloonTip(3000, "PC Remote", "Apps & Games werden neu gesucht …", ToolTipIcon.Info);
            });
            var auto = new ToolStripMenuItem("Mit Windows starten");
            auto.Checked = IsAutostart();
            auto.Click += delegate { SetAutostart(!IsAutostart()); auto.Checked = IsAutostart(); };
            menu.Opening += delegate { auto.Checked = IsAutostart(); };
            menu.Items.Add(auto);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Beenden", null, delegate { Quit(); });

            tray.ContextMenuStrip = menu;
            tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) Desktop.Show(null); };
            tray.BalloonTipClicked += delegate { Desktop.Show(Devices.HasPending() ? "settings" : null); };
            tray.Visible = true;
        }

        static void ShowInfo()
        {
            var urls = Net.LanUrls(Cfg.Port);
            MessageBox.Show("Am Handy (im selben WLAN) im Browser öffnen:\n\n" + string.Join("\n", urls.ToArray()) +
                "\n\nPIN:   " + Cfg.Pin, "PC Remote", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static bool IsAutostart()
        {
            using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                return k != null && k.GetValue(RunName) != null;
        }

        public static void SetAutostart(bool on)
        {
            using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
            {
                if (on) k.SetValue(RunName, "\"" + Application.ExecutablePath + "\" --tray");
                else k.DeleteValue(RunName, false);
            }
        }

        // Older versions registered autostart without --tray, which would now pop the window up at every boot.
        static void MigrateAutostart()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                {
                    var v = k == null ? null : k.GetValue(RunName) as string;
                    if (v == null || v.Contains("--tray")) return;
                }
                SetAutostart(true);
            }
            catch (Exception ex) { Log.Write("autostart: " + ex.Message); }
        }
    }
}
