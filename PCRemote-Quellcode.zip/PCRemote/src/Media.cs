using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Windows.Foundation;
using Windows.Media;
using Windows.Media.Control;
using Windows.Storage.Streams;

namespace PCRemote
{
    // Windows "now playing" sessions (GlobalSystemMediaTransportControls): every app that shows up in the
    // Windows media overlay (Spotify, Chrome/Edge/YouTube, Firefox, VLC …) can be read and controlled directly.
    static class Media
    {
        static GlobalSystemMediaTransportControlsSessionManager mgr;
        static readonly object L = new object();
        static readonly Dictionary<string, byte[]> art = new Dictionary<string, byte[]>();
        static readonly Dictionary<string, string> artType = new Dictionary<string, string>();

        static readonly Dictionary<string, string> Pretty = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) {
            { "spotify", "Spotify" }, { "chrome", "Chrome" }, { "msedge", "Edge" }, { "firefox", "Firefox" }, { "opera", "Opera" },
            { "brave", "Brave" }, { "vlc", "VLC" }, { "discord", "Discord" }, { "music.ui", "Media Player" }, { "zunemusic", "Media Player" } };

        static T Wait<T>(IAsyncOperation<T> op, int ms)
        {
            var sw = Stopwatch.StartNew();
            while (op.Status == AsyncStatus.Started)
            {
                if (sw.ElapsedMilliseconds > ms) { try { op.Cancel(); } catch { } throw new TimeoutException("Windows antwortet nicht"); }
                Thread.Sleep(2);
            }
            if (op.Status == AsyncStatus.Error) throw op.ErrorCode ?? new InvalidOperationException("Fehler");
            if (op.Status == AsyncStatus.Canceled) throw new OperationCanceledException();
            return op.GetResults();
        }

        static GlobalSystemMediaTransportControlsSessionManager Manager()
        {
            if (mgr == null) mgr = Wait(GlobalSystemMediaTransportControlsSessionManager.RequestAsync(), 5000);
            return mgr;
        }

        public static string ProcOf(string aumid)
        {
            if (string.IsNullOrEmpty(aumid)) return "";
            string a = aumid.ToLowerInvariant();
            if (a == "308046b0af4a39cb" || a.Contains("firefox")) return "firefox";
            if (a.Contains("spotify")) return "spotify";
            if (a.Contains("zunemusic")) return "zunemusic";
            int bang = a.LastIndexOf('!');
            if (bang >= 0) a = a.Substring(bang + 1);
            int slash = a.LastIndexOfAny(new[] { '\\', '/' });
            if (slash >= 0) a = a.Substring(slash + 1);
            if (a.EndsWith(".exe")) a = a.Substring(0, a.Length - 4);
            return a;
        }

        public static string AppName(string proc)
        {
            string n;
            if (Pretty.TryGetValue(proc, out n)) return n;
            return Apps.NameForProc(proc);
        }

        class Entry { public string Id; public GlobalSystemMediaTransportControlsSession S; }

        static List<Entry> Entries()
        {
            var list = new List<Entry>();
            var seen = new Dictionary<string, int>();
            foreach (var s in Manager().GetSessions())
            {
                string id = s.SourceAppUserModelId ?? "app";
                int n;
                seen.TryGetValue(id, out n);
                seen[id] = n + 1;
                if (n > 0) id += "#" + (n + 1);
                list.Add(new Entry { Id = id, S = s });
            }
            return list;
        }

        static string Status(GlobalSystemMediaTransportControlsSessionPlaybackStatus st)
        {
            switch (st)
            {
                case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing: return "playing";
                case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Paused: return "paused";
                case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Stopped: return "stopped";
                case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Changing: return "changing";
                default: return "closed";
            }
        }

        public static List<object> List()
        {
            lock (L)
            {
                var res = new List<object>();
                var m = Manager();
                var cur = m.GetCurrentSession();
                string curAumid = cur != null ? cur.SourceAppUserModelId : null;
                foreach (var e in Entries())
                {
                    var s = e.S;
                    GlobalSystemMediaTransportControlsSessionMediaProperties p = null;
                    try { p = Wait(s.TryGetMediaPropertiesAsync(), 1500); } catch { }
                    var pb = s.GetPlaybackInfo();
                    var tl = s.GetTimelineProperties();
                    var c = pb.Controls;
                    string status = Status(pb.PlaybackStatus);

                    double start = tl.StartTime.TotalSeconds, end = tl.EndTime.TotalSeconds;
                    double dur = Math.Max(0, end - start), pos = Math.Max(0, tl.Position.TotalSeconds - start);
                    // Spotify & browsers only update the timeline now and then; extrapolate while playing.
                    if (status == "playing" && tl.LastUpdatedTime.Year > 2000)
                    {
                        double rate = pb.PlaybackRate.HasValue ? pb.PlaybackRate.Value : 1.0;
                        pos += Math.Max(0, (DateTimeOffset.Now - tl.LastUpdatedTime).TotalSeconds) * rate;
                    }
                    if (dur > 0) pos = Math.Min(pos, dur);

                    string proc = ProcOf(s.SourceAppUserModelId);
                    string title = p != null ? p.Title ?? "" : "", artist = p != null ? p.Artist ?? "" : "", album = p != null ? p.AlbumTitle ?? "" : "";
                    if (artist.Length == 0 && p != null && !string.IsNullOrEmpty(p.AlbumArtist)) artist = p.AlbumArtist;
                    bool hasArt = p != null && p.Thumbnail != null;

                    var d = new Dictionary<string, object> {
                        { "id", e.Id }, { "proc", proc }, { "app", AppName(proc) },
                        { "title", title }, { "artist", artist }, { "album", album },
                        { "status", status }, { "pos", Math.Round(pos, 2) }, { "dur", Math.Round(dur, 2) },
                        { "shuffle", pb.IsShuffleActive }, { "repeat", Repeat(pb.AutoRepeatMode) },
                        { "canPlay", c.IsPlayEnabled || c.IsPlayPauseToggleEnabled }, { "canPause", c.IsPauseEnabled || c.IsPlayPauseToggleEnabled },
                        { "canNext", c.IsNextEnabled }, { "canPrev", c.IsPreviousEnabled },
                        { "canSeek", c.IsPlaybackPositionEnabled && dur > 0 }, { "canShuffle", c.IsShuffleEnabled }, { "canRepeat", c.IsRepeatEnabled },
                        { "art", hasArt ? ArtKey(title, artist, album) : null },
                        { "current", s.SourceAppUserModelId == curAumid } };
                    res.Add(d);
                }
                // Playing sessions first, then the one Windows considers current.
                res.Sort((a, b) => Rank((Dictionary<string, object>)a) - Rank((Dictionary<string, object>)b));
                return res;
            }
        }

        static int Rank(Dictionary<string, object> d)
        {
            int r = (string)d["status"] == "playing" ? 0 : 2;
            if ((bool)d["current"]) r--;
            return r;
        }

        static string Repeat(MediaPlaybackAutoRepeatMode? m)
        {
            if (!m.HasValue) return null;
            return m.Value == MediaPlaybackAutoRepeatMode.Track ? "track" : m.Value == MediaPlaybackAutoRepeatMode.List ? "list" : "none";
        }

        static string ArtKey(string t, string a, string al)
        {
            return ((uint)(t + "|" + a + "|" + al).GetHashCode()).ToString("x");
        }

        // The session that "now playing" widgets should show: first playing one, else Windows' current one.
        public static object NowPlaying()
        {
            var list = List();
            if (list.Count == 0) return null;
            var d = (Dictionary<string, object>)list[0];
            return new Dictionary<string, object> {
                { "id", d["id"] }, { "app", d["app"] }, { "proc", d["proc"] }, { "title", d["title"] }, { "artist", d["artist"] },
                { "playing", (string)d["status"] == "playing" }, { "art", d["art"] }, { "pos", d["pos"] }, { "dur", d["dur"] } };
        }

        static GlobalSystemMediaTransportControlsSession Find(string id)
        {
            var entries = Entries();
            if (string.IsNullOrEmpty(id))
            {
                var cur = Manager().GetCurrentSession();
                if (cur != null) return cur;
                if (entries.Count > 0) return entries[0].S;
                return null;
            }
            foreach (var e in entries) if (e.Id == id) return e.S;
            // also accept a process name ("spotify", "chrome")
            foreach (var e in entries) if (ProcOf(e.S.SourceAppUserModelId) == id.ToLowerInvariant()) return e.S;
            return null;
        }

        public static bool Has(string id)
        {
            lock (L) { try { return Find(id) != null; } catch { return false; } }
        }

        public static void Do(string id, string cmd, double value)
        {
            lock (L)
            {
                var s = Find(id);
                if (s == null) throw new InvalidOperationException("Gerade läuft keine Wiedergabe");
                IAsyncOperation<bool> op;
                switch (cmd)
                {
                    case "play": op = s.TryPlayAsync(); break;
                    case "pause": op = s.TryPauseAsync(); break;
                    case "toggle": case "playpause": op = s.TryTogglePlayPauseAsync(); break;
                    case "next": op = s.TrySkipNextAsync(); break;
                    case "prev": case "previous": op = s.TrySkipPreviousAsync(); break;
                    case "stop": op = s.TryStopAsync(); break;
                    case "seek":
                        {
                            var tl = s.GetTimelineProperties();
                            long ticks = tl.StartTime.Ticks + (long)(Math.Max(0, value) * TimeSpan.TicksPerSecond);
                            op = s.TryChangePlaybackPositionAsync(ticks);
                            break;
                        }
                    case "shuffle": op = s.TryChangeShuffleActiveAsync(value > 0.5); break;
                    case "repeat":
                        op = s.TryChangeAutoRepeatModeAsync(value >= 2 ? MediaPlaybackAutoRepeatMode.List : value >= 1 ? MediaPlaybackAutoRepeatMode.Track : MediaPlaybackAutoRepeatMode.None);
                        break;
                    default: throw new ArgumentException("Unbekannt: " + cmd);
                }
                if (!Wait(op, 3000)) throw new InvalidOperationException("Die App hat den Befehl abgelehnt");
            }
        }

        public static byte[] Art(string id, out string type)
        {
            type = "image/png";
            lock (L)
            {
                var s = Find(id);
                if (s == null) return null;
                var p = Wait(s.TryGetMediaPropertiesAsync(), 2000);
                if (p == null || p.Thumbnail == null) return null;
                string key = id + "|" + ArtKey(p.Title ?? "", p.Artist ?? "", p.AlbumTitle ?? "");
                byte[] b;
                if (art.TryGetValue(key, out b)) { type = artType[key]; return b; }
                using (var st = Wait(p.Thumbnail.OpenReadAsync(), 3000))
                {
                    uint size = (uint)st.Size;
                    if (size == 0 || size > 8 * 1024 * 1024) return null;
                    using (var reader = new DataReader(st.GetInputStreamAt(0)))
                    {
                        Wait(reader.LoadAsync(size), 3000);
                        b = new byte[size];
                        reader.ReadBytes(b);
                    }
                    if (!string.IsNullOrEmpty(st.ContentType)) type = st.ContentType;
                }
                if (art.Count > 40) { art.Clear(); artType.Clear(); }
                art[key] = b;
                artType[key] = type;
                return b;
            }
        }
    }
}
