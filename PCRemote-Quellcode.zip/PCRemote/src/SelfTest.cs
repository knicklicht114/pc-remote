using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace PCRemote
{
    // "PCRemote.exe --selftest out.txt": checks screen capture and video encoders on this PC and times them.
    // Runs on an MTA thread like the server does; every step is written right away so a crash shows where it happened.
    static class SelfTest
    {
        static string file;
        static void Say(string s) { File.AppendAllText(file, s + Environment.NewLine); }

        public static void Run(string outFile)
        {
            file = outFile;
            File.WriteAllText(file, "");
            var t = new Thread(Body);
            t.SetApartmentState(ApartmentState.MTA);
            t.Start();
            t.Join();
        }

        // "PCRemote.exe --cliptest out.txt dir": records ~8 s into dir and saves a clip.
        public static void Clip(string outFile, string dir)
        {
            file = outFile;
            File.WriteAllText(file, "");
            var t = new Thread(() =>
            {
                try
                {
                    Directory.CreateDirectory(dir);
                    string cfg = Path.Combine(dir, "clips.json");
                    File.WriteAllText(cfg, J.Ser(new System.Collections.Generic.Dictionary<string, object> {
                        { "enabled", true }, { "fps", 60 }, { "seconds", 6 }, { "folder", dir }, { "hotkey", "" } }));
                    var cpu = Process.GetCurrentProcess().TotalProcessorTime;
                    Clips.Init(cfg);
                    Thread.Sleep(9000);
                    double cpuMs = (Process.GetCurrentProcess().TotalProcessorTime - cpu).TotalMilliseconds;
                    Say("CPU während 9 s Aufnahme: " + Math.Round(cpuMs) + " ms (" + Math.Round(cpuMs / 90.0 / Environment.ProcessorCount, 1) + " % aller Kerne)");
                    Say(Clips.Debug());
                    Say(J.Ser(Clips.Save("test")));
                    Say(J.Ser(Clips.Overview()));
                }
                catch (Exception ex) { Say("Fehler: " + ex); }
            });
            t.Start();
            t.Join();
            Environment.Exit(0);
        }

        static void Body()
        {
            try
            {
                var mon = Monitors.List()[0];
                Say("Monitor " + mon.Dev + " " + mon.W + "x" + mon.H);
                using (var g = new Grabber(mon, mon.W & ~1, mon.H & ~1))
                {
                    Say("Aufnahme: " + (g.UsesDxgi ? "DXGI" : "GDI"));
                    var sw = Stopwatch.StartNew();
                    var cpu = Process.GetCurrentProcess().TotalProcessorTime;
                    int changed = 0;
                    for (int i = 0; i < 60; i++) { if (g.Grab()) changed++; Thread.Sleep(16); }
                    double cpuMs = (Process.GetCurrentProcess().TotalProcessorTime - cpu).TotalMilliseconds;
                    Say("  60 Bilder in " + sw.ElapsedMilliseconds + " ms, " + changed + " geändert, CPU " + Math.Round(cpuMs) + " ms");
                    foreach (bool hw in new[] { true, false })
                    {
                        try
                        {
                            Say("Encoder hw=" + hw + " öffnen …");
                            using (var e = H264Encoder.Open(g.W, g.H, 60, 12000000, hw))
                            {
                                Say("  " + e.Name + (e.Hardware ? " (Hardware)" : "") + (e.RgbInput ? " · RGB direkt" : " · NV12"));
                                cpu = Process.GetCurrentProcess().TotalProcessorTime;
                                sw.Restart();
                                long bytes = 0; int aus = 0, keys = 0;
                                for (int i = 0; i < 120; i++)
                                {
                                    g.Grab();
                                    foreach (var au in e.EncodeAus(g.Bits, i * 166666L, 166666L)) { bytes += au.Data.Length; aus++; if (au.Key) keys++; }
                                    if (i == 0) Say("  erstes Bild ok");
                                }
                                cpuMs = (Process.GetCurrentProcess().TotalProcessorTime - cpu).TotalMilliseconds;
                                Say("  120 Bilder in " + sw.ElapsedMilliseconds + " ms, CPU " + Math.Round(cpuMs) + " ms, " + aus + " AUs, " + keys + " Keyframes, " + bytes / 1024 + " KB");
                            }
                            Say("  geschlossen");
                        }
                        catch (Exception ex) { Say("  Fehler: " + ex.Message); }
                    }
                }
            }
            catch (Exception ex) { Say("Fehler: " + ex); }
        }
    }
}
