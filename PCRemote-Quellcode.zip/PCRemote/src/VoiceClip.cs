using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Speech.Recognition;
using System.Text;
using System.Threading;

namespace PCRemote
{
    // Clip by voice: the user records one sentence in the settings (with the PC microphone). While it is switched on,
    // Windows' own offline speech recognition listens for exactly that sentence and saves a clip. Nothing leaves the PC.
    static class VoiceClip
    {
        static readonly object L = new object();
        static string path, wavPath;
        static bool enabled;
        static string phrase = "", level = "normal";  // level: locker / normal / streng = how sure the recognition must be
        static SpeechRecognitionEngine engine;
        static string status = "aus", error, lang;
        static volatile bool recording;
        static DateTime lastClip = DateTime.MinValue, heardAt = DateTime.MinValue;
        static string heard;

        public static void Init(string p)
        {
            path = p;
            wavPath = Path.Combine(Path.GetDirectoryName(p), "voice.wav");
            try
            {
                var d = J.Obj(Store.Read(p));
                enabled = J.Bool(d, "enabled");
                phrase = J.Str(d, "phrase", "");
                level = J.Str(d, "level", "normal");
            }
            catch (Exception ex) { Log.Write("voice load: " + ex.Message); }
            Restart();
        }

        static void Save()
        {
            Store.Write(path, J.Ser(new Dictionary<string, object> { { "enabled", enabled }, { "phrase", phrase }, { "level", level } }));
        }

        // German first (the app speaks German), otherwise whatever Windows has
        static RecognizerInfo Recognizer()
        {
            var all = SpeechRecognitionEngine.InstalledRecognizers();
            var info = all.FirstOrDefault(r => r.Culture.Name == "de-DE") ?? all.FirstOrDefault(r => r.Culture.TwoLetterISOLanguageName == "de") ?? all.FirstOrDefault();
            if (info == null) throw new InvalidOperationException("Windows hat keine Spracherkennung installiert (Einstellungen → Zeit und Sprache → Sprache → Deutsch → Optionen → Spracherkennung).");
            lang = info.Culture.Name;
            return info;
        }

        static double Threshold()
        {
            return level == "streng" ? 0.85 : level == "locker" ? 0.55 : 0.72;
        }

        // the sentence as the recognizer wants it: words only, no punctuation
        static string Words(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s ?? "") sb.Append(char.IsLetterOrDigit(c) || c == '\'' || c == '-' ? c : ' ');
            return string.Join(" ", sb.ToString().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
        }

        static void Stop()
        {
            var e = engine;
            engine = null;
            if (e == null) return;
            try { e.SpeechRecognized -= Heard; e.RecognizeAsyncCancel(); } catch { }
            ThreadPool.QueueUserWorkItem(_ => { try { Thread.Sleep(800); e.Dispose(); } catch { } });
        }

        static void Restart()
        {
            lock (L)
            {
                Stop();
                error = null;
                if (recording) { status = "nimmt auf"; return; }
                if (!enabled) { status = "aus"; return; }
                string words = Words(phrase);
                if (words.Length == 0) { status = "kein Satz"; return; }
                SpeechRecognitionEngine e = null;
                try
                {
                    var info = Recognizer();
                    e = new SpeechRecognitionEngine(info);
                    var gb = new GrammarBuilder(words);
                    gb.Culture = info.Culture;
                    e.LoadGrammar(new Grammar(gb) { Name = "clip" });
                    e.SpeechRecognized += Heard;
                    e.RecognizeCompleted += Ended;
                    e.SetInputToDefaultAudioDevice();
                    e.RecognizeAsync(RecognizeMode.Multiple);
                    engine = e;
                    status = "hört zu";
                }
                catch (Exception ex)
                {
                    if (e != null) try { e.Dispose(); } catch { }
                    status = "fehler";
                    error = ex.Message;
                    Log.Write("voice: " + ex.Message);
                }
            }
        }

        // the microphone went away (unplugged, other default device): listen again a bit later
        static void Ended(object sender, RecognizeCompletedEventArgs e)
        {
            if (sender != engine || !enabled) return;
            if (e.Error != null) Log.Write("voice stopped: " + e.Error.Message);
            ThreadPool.QueueUserWorkItem(_ => { Thread.Sleep(3000); if (sender == engine) Restart(); });
        }

        static void Heard(object sender, SpeechRecognizedEventArgs e)
        {
            var r = e.Result;
            if (r == null || sender != engine) return;
            heard = r.Text;
            heardAt = DateTime.Now;
            if (r.Confidence < Threshold()) return;
            if ((DateTime.UtcNow - lastClip).TotalSeconds < 5) return; // one sentence = one clip
            lastClip = DateTime.UtcNow;
            Log.Write("voice: \"" + r.Text + "\" erkannt (" + Math.Round(r.Confidence * 100) + " %)");
            ThreadPool.QueueUserWorkItem(_ => { try { Clips.Save("Stimme"); } catch (Exception ex) { Log.Write("voice clip: " + ex.Message); } });
        }

        // Record the sentence once: free dictation on the PC microphone; the words become the trigger, the audio is kept to listen to.
        static object Record()
        {
            lock (L)
            {
                if (recording) throw new InvalidOperationException("Es wird schon aufgenommen");
                recording = true;
                Stop();
                status = "nimmt auf";
            }
            try
            {
                var info = Recognizer();
                using (var e = new SpeechRecognitionEngine(info))
                {
                    e.LoadGrammar(new DictationGrammar());
                    e.SetInputToDefaultAudioDevice();
                    e.EndSilenceTimeout = TimeSpan.FromSeconds(0.8);
                    e.BabbleTimeout = TimeSpan.FromSeconds(8);
                    var r = e.Recognize(TimeSpan.FromSeconds(7));
                    if (r == null || Words(r.Text).Length == 0)
                        throw new InvalidOperationException("Nichts verstanden – sprich deinen Satz deutlich ins PC-Mikrofon und versuch es nochmal.");
                    if (r.Audio != null) using (var f = File.Create(wavPath)) r.Audio.WriteToWaveStream(f);
                    lock (L)
                    {
                        phrase = Words(r.Text);
                        enabled = true;
                        Save();
                    }
                    Log.Write("voice: neuer Satz aufgenommen");
                }
            }
            finally
            {
                recording = false;
                Restart();
            }
            return Overview();
        }

        public static object Overview()
        {
            var d = new Dictionary<string, object> {
                { "ok", true }, { "enabled", enabled }, { "phrase", phrase }, { "level", level }, { "status", status }, { "error", error },
                { "recording", recording }, { "hasAudio", wavPath != null && File.Exists(wavPath) }, { "lang", lang } };
            if (heard != null && (DateTime.Now - heardAt).TotalMinutes < 10)
                d["heard"] = heard + " · vor " + Math.Max(1, (int)(DateTime.Now - heardAt).TotalSeconds) + " s";
            return d;
        }

        public static object Command(Dictionary<string, object> a)
        {
            switch (J.Str(a, "op", ""))
            {
                case "record":
                    return Record();
                case "set":
                    lock (L)
                    {
                        if (J.Has(a, "enabled")) enabled = J.Bool(a, "enabled");
                        if (J.Has(a, "phrase")) phrase = Words(J.Str(a, "phrase", ""));
                        if (J.Has(a, "level")) level = J.Str(a, "level", "normal");
                        Save();
                    }
                    Restart();
                    return Overview();
                case "delete":
                    lock (L)
                    {
                        enabled = false;
                        phrase = "";
                        Save();
                    }
                    try { if (File.Exists(wavPath)) File.Delete(wavPath); } catch { }
                    Restart();
                    return Overview();
            }
            throw new ArgumentException("Unbekannter Befehl");
        }

        public static byte[] Audio()
        {
            return wavPath != null && File.Exists(wavPath) ? File.ReadAllBytes(wavPath) : null;
        }
    }
}
