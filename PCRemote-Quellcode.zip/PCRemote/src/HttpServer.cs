using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace PCRemote
{
    class Request
    {
        public string Method;
        public string Path;
        public bool KeepAlive;
        public byte[] Body;
        public IPAddress Remote;
        public readonly Dictionary<string, string> Query = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<string, string> Headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public bool IsLocal { get { return IPAddress.IsLoopback(Remote); } }
        public string BodyText { get { return Body == null ? "" : Encoding.UTF8.GetString(Body); } }

        public string Header(string k) { string v; return Headers.TryGetValue(k, out v) ? v : null; }
        public string Q(string k) { string v; return Query.TryGetValue(k, out v) ? v : null; }

        public int QInt(string k, int def)
        {
            int v;
            return int.TryParse(Q(k), out v) ? v : def;
        }

        public static Request Read(Stream s, IPAddress remote)
        {
            string line = ReadLine(s);
            while (line != null && line.Length == 0) line = ReadLine(s);
            if (line == null) return null;

            string[] parts = line.Split(' ');
            if (parts.Length < 2) throw new IOException("bad request line");

            var r = new Request();
            r.Method = parts[0].ToUpperInvariant();
            r.Remote = remote;
            string target = parts[1];
            string version = parts.Length > 2 ? parts[2] : "HTTP/1.0";
            int q = target.IndexOf('?');
            r.Path = Uri.UnescapeDataString(q >= 0 ? target.Substring(0, q) : target);
            if (q >= 0) ParseQuery(target.Substring(q + 1), r.Query);

            int count = 0;
            while (true)
            {
                string hl = ReadLine(s);
                if (hl == null) return null;
                if (hl.Length == 0) break;
                if (++count > 100) throw new IOException("too many headers");
                int c = hl.IndexOf(':');
                if (c > 0) r.Headers[hl.Substring(0, c).Trim()] = hl.Substring(c + 1).Trim();
            }

            string conn = (r.Header("Connection") ?? "").ToLowerInvariant();
            r.KeepAlive = version == "HTTP/1.1" ? !conn.Contains("close") : conn.Contains("keep-alive");

            int len;
            if (int.TryParse(r.Header("Content-Length"), out len) && len > 0)
            {
                if (len > 8 * 1024 * 1024) throw new IOException("body too large");
                r.Body = new byte[len];
                int read = 0;
                while (read < len)
                {
                    int n = s.Read(r.Body, read, len - read);
                    if (n <= 0) throw new IOException("unexpected end of body");
                    read += n;
                }
            }
            return r;
        }

        static string ReadLine(Stream s)
        {
            var buf = new List<byte>(128);
            while (true)
            {
                int b = s.ReadByte();
                if (b < 0) return buf.Count == 0 ? null : Encoding.UTF8.GetString(buf.ToArray());
                if (b == '\n') break;
                if (b != '\r') buf.Add((byte)b);
                if (buf.Count > 16384) throw new IOException("line too long");
            }
            return Encoding.UTF8.GetString(buf.ToArray());
        }

        static void ParseQuery(string qs, Dictionary<string, string> into)
        {
            foreach (string pair in qs.Split('&'))
            {
                if (pair.Length == 0) continue;
                int e = pair.IndexOf('=');
                string k = e >= 0 ? pair.Substring(0, e) : pair;
                string v = e >= 0 ? pair.Substring(e + 1) : "";
                into[Uri.UnescapeDataString(k.Replace('+', ' '))] = Uri.UnescapeDataString(v.Replace('+', ' '));
            }
        }
    }

    class Response
    {
        public int Status = 200;
        public string ContentType = "application/json; charset=utf-8";
        public byte[] Body;
        public Action<Stream> Streamer; // endless responses (live picture); the connection closes afterwards
        public Action<Stream, Stream> Socket; // upgraded connection (WebSocket): gets the buffered input and the raw output
        public string FilePath; // body comes straight from this file (FileStart/FileCount), for big videos
        public long FileStart, FileCount;

        // A file with HTTP Range support, so video players can seek and downloads don't load everything into memory.
        public static Response FromFile(string path, string type, string range, string downloadName)
        {
            long total = new FileInfo(path).Length, start = 0, end = total - 1;
            var r = new Response { ContentType = type, FilePath = path };
            r.Headers["Accept-Ranges"] = "bytes";
            var m = System.Text.RegularExpressions.Regex.Match(range ?? "", @"^bytes=(\d*)-(\d*)$");
            if (m.Success && total > 0)
            {
                if (m.Groups[1].Value.Length > 0)
                {
                    start = Math.Min(long.Parse(m.Groups[1].Value), total - 1);
                    if (m.Groups[2].Value.Length > 0) end = Math.Min(long.Parse(m.Groups[2].Value), total - 1);
                }
                else if (m.Groups[2].Value.Length > 0) start = Math.Max(0, total - long.Parse(m.Groups[2].Value));
                if (end < start) end = start;
                r.Status = 206;
                r.Headers["Content-Range"] = "bytes " + start + "-" + end + "/" + total;
            }
            r.FileStart = start;
            r.FileCount = total == 0 ? 0 : end - start + 1;
            if (downloadName != null)
                r.Headers["Content-Disposition"] = "attachment; filename=\"clip.mp4\"; filename*=UTF-8''" + Uri.EscapeDataString(downloadName);
            r.Headers["Cache-Control"] = "private, max-age=3600";
            return r;
        }
        public readonly Dictionary<string, string> Headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public void WriteStreamHead(Stream s)
        {
            byte[] head = Encoding.ASCII.GetBytes("HTTP/1.1 200 OK\r\nContent-Type: " + ContentType +
                "\r\nCache-Control: no-store\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n\r\n");
            s.Write(head, 0, head.Length);
            s.Flush();
        }

        public static Response Json(object o)
        {
            var r = new Response();
            r.Body = Encoding.UTF8.GetBytes(J.Ser(o));
            return r;
        }

        public static Response RawJson(string json)
        {
            var r = new Response();
            r.Body = Encoding.UTF8.GetBytes(json);
            return r;
        }

        public static Response Html(string html)
        {
            var r = new Response();
            r.Body = Encoding.UTF8.GetBytes(html);
            r.ContentType = "text/html; charset=utf-8";
            return r;
        }

        public static Response Error(int status, string msg)
        {
            var r = Json(new Dictionary<string, object> { { "ok", false }, { "error", msg } });
            r.Status = status;
            return r;
        }

        public static Response Bytes(byte[] b, string type)
        {
            var r = new Response();
            r.Body = b;
            r.ContentType = type;
            return r;
        }

        public static bool Compressible(string type)
        {
            return type.StartsWith("text/") || type.StartsWith("application/json") || type.StartsWith("application/javascript") || type.StartsWith("image/svg");
        }

        public static byte[] Gzip(byte[] data, bool best)
        {
            using (var ms = new MemoryStream())
            {
                using (var gz = new GZipStream(ms, best ? CompressionLevel.Optimal : CompressionLevel.Fastest, true)) gz.Write(data, 0, data.Length);
                return ms.ToArray();
            }
        }

        public void WriteTo(Stream s, bool keepAlive, bool headOnly, bool acceptGzip)
        {
            if (FilePath != null) { WriteFile(s, keepAlive, headOnly); return; }
            byte[] body = Body ?? new byte[0];
            // bigger JSON answers (app lists, playlists …) go out compressed – noticeably faster over WLAN
            if (acceptGzip && body.Length > 2048 && Status == 200 && !Headers.ContainsKey("Content-Encoding") && Compressible(ContentType))
            {
                body = Gzip(body, false);
                Headers["Content-Encoding"] = "gzip";
                Headers["Vary"] = "Accept-Encoding";
            }
            var sb = new StringBuilder();
            sb.Append("HTTP/1.1 ").Append(Status).Append(' ').Append(Reason(Status)).Append("\r\n");
            sb.Append("Content-Type: ").Append(ContentType).Append("\r\n");
            sb.Append("Content-Length: ").Append(body.Length).Append("\r\n");
            sb.Append("Connection: ").Append(keepAlive ? "keep-alive" : "close").Append("\r\n");
            if (!Headers.ContainsKey("Cache-Control")) sb.Append("Cache-Control: no-store\r\n");
            foreach (var kv in Headers) sb.Append(kv.Key).Append(": ").Append(kv.Value).Append("\r\n");
            sb.Append("X-Content-Type-Options: nosniff\r\n\r\n");

            byte[] head = Encoding.ASCII.GetBytes(sb.ToString());
            using (var ms = new MemoryStream(head.Length + (headOnly ? 0 : body.Length)))
            {
                ms.Write(head, 0, head.Length);
                if (!headOnly) ms.Write(body, 0, body.Length);
                ms.WriteTo(s);
            }
            s.Flush();
        }

        void WriteFile(Stream s, bool keepAlive, bool headOnly)
        {
            var sb = new StringBuilder();
            sb.Append("HTTP/1.1 ").Append(Status).Append(' ').Append(Reason(Status)).Append("\r\n");
            sb.Append("Content-Type: ").Append(ContentType).Append("\r\n");
            sb.Append("Content-Length: ").Append(FileCount).Append("\r\n");
            sb.Append("Connection: ").Append(keepAlive ? "keep-alive" : "close").Append("\r\n");
            foreach (var kv in Headers) sb.Append(kv.Key).Append(": ").Append(kv.Value).Append("\r\n");
            sb.Append("X-Content-Type-Options: nosniff\r\n\r\n");
            byte[] head = Encoding.ASCII.GetBytes(sb.ToString());
            s.Write(head, 0, head.Length);
            if (!headOnly && FileCount > 0)
                using (var fs = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16))
                {
                    fs.Position = FileStart;
                    var buf = new byte[1 << 16];
                    long left = FileCount;
                    while (left > 0)
                    {
                        int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left));
                        if (n <= 0) break;
                        s.Write(buf, 0, n);
                        left -= n;
                    }
                }
            s.Flush();
        }

        static string Reason(int c)
        {
            switch (c)
            {
                case 200: return "OK";
                case 206: return "Partial Content";
                case 304: return "Not Modified";
                case 400: return "Bad Request";
                case 401: return "Unauthorized";
                case 403: return "Forbidden";
                case 404: return "Not Found";
                case 405: return "Method Not Allowed";
                case 429: return "Too Many Requests";
                default: return c >= 500 ? "Internal Server Error" : "OK";
            }
        }
    }

    class HttpServer
    {
        readonly int port;
        readonly Api api;
        TcpListener listener;
        volatile bool running;

        public HttpServer(int port, Api api)
        {
            this.port = port;
            this.api = api;
        }

        public void Start()
        {
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            running = true;
            var t = new Thread(AcceptLoop);
            t.IsBackground = true;
            t.Name = "http-accept";
            t.Start();
        }

        public void Stop()
        {
            running = false;
            try { listener.Stop(); } catch { }
        }

        void AcceptLoop()
        {
            while (running)
            {
                try
                {
                    TcpClient c = listener.AcceptTcpClient();
                    var t = new Thread(Serve);
                    t.IsBackground = true;
                    t.Start(c);
                }
                catch (Exception ex)
                {
                    if (!running) return;
                    Log.Write("accept: " + ex.Message);
                    Thread.Sleep(200);
                }
            }
        }

        void Serve(object o)
        {
            var client = (TcpClient)o;
            try
            {
                client.NoDelay = true;
                client.ReceiveTimeout = 30000;
                client.SendTimeout = 15000;
                var remote = ((IPEndPoint)client.Client.RemoteEndPoint).Address;
                NetworkStream ns = client.GetStream();
                var input = new BufferedStream(ns, 8192);

                while (running)
                {
                    Request req = Request.Read(input, remote);
                    if (req == null) break;
                    Response res;
                    try { res = api.Handle(req); }
                    catch (Exception ex)
                    {
                        Log.Write("handler " + req.Path + ": " + ex);
                        res = Response.Error(500, ex.Message);
                    }
                    if (res.Socket != null)
                    {
                        res.Socket(input, ns);
                        break;
                    }
                    if (res.Streamer != null)
                    {
                        res.WriteStreamHead(ns);
                        res.Streamer(ns);
                        break;
                    }
                    res.WriteTo(ns, req.KeepAlive, req.Method == "HEAD", (req.Header("Accept-Encoding") ?? "").Contains("gzip"));
                    if (!req.KeepAlive) break;
                }
            }
            catch (IOException) { }
            catch (SocketException) { }
            catch (ObjectDisposedException) { }
            catch (Exception ex) { Log.Write("serve: " + ex.Message); }
            finally
            {
                try { client.Close(); } catch { }
            }
        }
    }
}
