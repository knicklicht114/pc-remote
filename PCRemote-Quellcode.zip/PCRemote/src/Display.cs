using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace PCRemote
{
    // Monitors as Windows sees them right now (fresh on every call, unlike Screen.AllScreens).
    class Mon
    {
        public string Dev, Adapter;
        public int X, Y, W, H, Hz;
        public bool Primary, Virtual;
    }

    static class Monitors
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DISPLAY_DEVICE
        {
            public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DEVMODE
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
            public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
            public int dmFields;
            public int dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
            public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
            public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern bool EnumDisplayDevices(string dev, int i, ref DISPLAY_DEVICE dd, int flags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern bool EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int ChangeDisplaySettingsEx(string dev, ref DEVMODE dm, IntPtr hwnd, int flags, IntPtr param);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int ChangeDisplaySettingsEx(string dev, IntPtr dm, IntPtr hwnd, int flags, IntPtr param);

        const int ATTACHED = 0x1, PRIMARY = 0x4, ENUM_CURRENT = -1;

        public static DEVMODE NewMode()
        {
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            return dm;
        }

        public static List<DISPLAY_DEVICE> Devices()
        {
            var list = new List<DISPLAY_DEVICE>();
            for (int i = 0; i < 64; i++)
            {
                var dd = new DISPLAY_DEVICE();
                dd.cb = Marshal.SizeOf(dd);
                if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
                list.Add(dd);
            }
            return list;
        }

        public static bool IsVirtual(DISPLAY_DEVICE d) { return (d.DeviceString ?? "").IndexOf("Parsec", StringComparison.OrdinalIgnoreCase) >= 0; }

        public static List<Mon> List()
        {
            var list = new List<Mon>();
            foreach (var d in Devices())
            {
                if ((d.StateFlags & ATTACHED) == 0) continue;
                var dm = NewMode();
                if (!EnumDisplaySettings(d.DeviceName, ENUM_CURRENT, ref dm)) continue;
                list.Add(new Mon {
                    Dev = d.DeviceName, Adapter = d.DeviceString, X = dm.dmPositionX, Y = dm.dmPositionY, W = dm.dmPelsWidth, H = dm.dmPelsHeight,
                    Hz = dm.dmDisplayFrequency, Primary = (d.StateFlags & PRIMARY) != 0, Virtual = IsVirtual(d) });
            }
            // Real monitors keep their numbers (primary first, then left to right); the phone screen always comes last.
            list.Sort((a, b) => a.Virtual != b.Virtual ? (a.Virtual ? 1 : -1) : a.Primary != b.Primary ? (a.Primary ? -1 : 1) : a.X != b.X ? a.X - b.X : a.Y - b.Y);
            return list;
        }

        public static Mon Find(string dev)
        {
            var all = List();
            if (!string.IsNullOrEmpty(dev))
                foreach (var m in all) if (string.Equals(m.Dev, dev, StringComparison.OrdinalIgnoreCase)) return m;
            return string.IsNullOrEmpty(dev) && all.Count > 0 ? all[0] : null;
        }

        public static List<object> ForClient()
        {
            var res = new List<object>();
            int n = 0;
            foreach (var m in List())
            {
                n++;
                res.Add(new Dictionary<string, object> {
                    { "dev", m.Dev }, { "nr", n }, { "w", m.W }, { "h", m.H }, { "hz", m.Hz }, { "x", m.X }, { "y", m.Y },
                    { "primary", m.Primary }, { "virtual", m.Virtual }, { "adapter", m.Adapter } });
            }
            return res;
        }

        // Supported mode closest to the wanted size (landscape w×h); portrait = the same mode turned by 90°.
        public static DEVMODE PickMode(string dev, int w, int h, bool portrait)
        {
            var modes = new List<DEVMODE>();
            for (int i = 0; i < 400; i++)
            {
                var dm = NewMode();
                if (!EnumDisplaySettings(dev, i, ref dm)) break;
                if (dm.dmBitsPerPel >= 24) modes.Add(dm);
            }
            if (modes.Count == 0) throw new InvalidOperationException("Der virtuelle Bildschirm meldet keine Auflösungen");
            int lw = Math.Max(w, h), lh = Math.Min(w, h);
            double want = lw / (double)lh;
            DEVMODE best = modes[0];
            double bestScore = double.MaxValue;
            foreach (var m in modes)
            {
                int mw = Math.Max(m.dmPelsWidth, m.dmPelsHeight), mh = Math.Min(m.dmPelsWidth, m.dmPelsHeight);
                // Readable size on the phone matters more than a perfect shape (a little black border is fine).
                double score = Math.Abs(mw / (double)mh - want) * 1000 + Math.Abs(mh - lh) + (m.dmDisplayFrequency == 60 ? 0 : 5);
                if (score < bestScore) { bestScore = score; best = m; }
            }
            int bw = Math.Max(best.dmPelsWidth, best.dmPelsHeight), bh = Math.Min(best.dmPelsWidth, best.dmPelsHeight);
            best.dmPelsWidth = portrait ? bh : bw;
            best.dmPelsHeight = portrait ? bw : bh;
            best.dmDisplayOrientation = portrait ? 1 : 0; // DMDO_90 / DMDO_DEFAULT
            best.dmFields = 0x80000 | 0x100000 | 0x400000 | 0x80; // width, height, frequency, orientation
            return best;
        }

        // Where the extra monitor goes: next to monitor "of" on side left/right/above/below, aligned start/center/end.
        public static Rectangle Spot(Mon target, int w, int h, string side, string align)
        {
            int x, y;
            Func<int, int, int> along = (start, len) => align == "center" ? start + (len - (side == "left" || side == "right" ? h : w)) / 2
                                                       : align == "end" ? start + len - (side == "left" || side == "right" ? h : w) : start;
            switch (side)
            {
                case "left": x = target.X - w; y = along(target.Y, target.H); break;
                case "above": y = target.Y - h; x = along(target.X, target.W); break;
                case "below": y = target.Y + target.H; x = along(target.X, target.W); break;
                default: x = target.X + target.W; y = along(target.Y, target.H); break;
            }
            return new Rectangle(x, y, w, h);
        }

        public static void Place(string dev, int w, int h, bool portrait, string of, string side, string align)
        {
            var dm = PickMode(dev, w, h, portrait);
            var others = List().Where(m => !string.Equals(m.Dev, dev, StringComparison.OrdinalIgnoreCase)).ToList();
            var target = others.FirstOrDefault(m => string.Equals(m.Dev, of, StringComparison.OrdinalIgnoreCase)) ?? others.FirstOrDefault(m => m.Primary) ?? others.FirstOrDefault();
            if (target != null)
            {
                var spot = Spot(target, dm.dmPelsWidth, dm.dmPelsHeight, side, align);
                var all = List();
                foreach (var m in others)
                    if (m != target && new Rectangle(m.X, m.Y, m.W, m.H).IntersectsWith(spot))
                        throw new InvalidOperationException("Dort ist schon Bildschirm " + (all.FindIndex(x => x.Dev == m.Dev) + 1) + " – bitte eine andere Seite wählen");
                dm.dmPositionX = spot.X;
                dm.dmPositionY = spot.Y;
                dm.dmFields |= 0x20; // position
            }
            int r = ChangeDisplaySettingsEx(dev, ref dm, IntPtr.Zero, 0x1 | 0x10000000, IntPtr.Zero); // UPDATEREGISTRY | NORESET
            ChangeDisplaySettingsEx(null, IntPtr.Zero, IntPtr.Zero, 0, IntPtr.Zero);
            if (r != 0)
            {
                Log.Write("display place " + dev + " " + dm.dmPelsWidth + "x" + dm.dmPelsHeight + " o" + dm.dmDisplayOrientation + ": " + r);
                if (portrait) throw new InvalidOperationException("Windows lässt diesen Bildschirm nicht hochkant drehen");
                throw new InvalidOperationException("Windows hat die Anordnung abgelehnt (Code " + r + ")");
            }
        }
    }

    // Parsec Virtual Display Driver: adds real extra monitors without admin rights once the driver is installed.
    // Displays only live while this program keeps pinging the driver.
    static class VirtualDisplay
    {
        const string InstallerUrl = "https://builds.parsec.app/vdd/parsec-vdd-0.45.0.0.exe";
        const string InstallerSha256 = "E23332448FDAF5AA017CB308DB5EF6855FAC526A7DED05D80C039404126D5362";
        const uint IOCTL_ADD = 0x0022e004, IOCTL_REMOVE = 0x0022a008, IOCTL_UPDATE = 0x0022a00c, IOCTL_VERSION = 0x0022e010;
        static Guid AdapterGuid = new Guid("00b41627-04c4-429e-a26e-0265cf50c8fa");

        [StructLayout(LayoutKind.Sequential)]
        struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid InterfaceClassGuid; public int Flags; public IntPtr Reserved; }

        [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid cls, IntPtr enumerator, IntPtr hwnd, int flags);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr devInfo, ref Guid cls, int index, ref SP_DEVICE_INTERFACE_DATA data);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref SP_DEVICE_INTERFACE_DATA data, IntPtr detail, int size, out int required, IntPtr devInfo);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr template);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool DeviceIoControl(SafeFileHandle h, uint code, IntPtr inBuf, int inSize, IntPtr outBuf, int outSize, IntPtr returned, IntPtr overlapped);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetOverlappedResultEx(SafeFileHandle h, IntPtr overlapped, out uint transferred, uint ms, bool alertable);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetOverlappedResult(SafeFileHandle h, IntPtr overlapped, out uint transferred, bool wait);
        [DllImport("kernel32.dll")] static extern bool CancelIoEx(SafeFileHandle h, IntPtr overlapped);
        [DllImport("kernel32.dll")] static extern IntPtr CreateEvent(IntPtr sec, bool manual, bool initial, string name);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

        static readonly object L = new object();   // state (added displays)
        static readonly object IoL = new object(); // driver calls; the keepalive only needs this one
        static SafeFileHandle handle;
        static readonly List<int> added = new List<int>();
        static readonly List<string> devs = new List<string>();
        static Thread pinger;
        static int viewers;
        static DateTime lastViewer = DateTime.UtcNow;
        static volatile bool installing;
        static string installMsg;

        static string DevicePath()
        {
            IntPtr set = SetupDiGetClassDevs(ref AdapterGuid, IntPtr.Zero, IntPtr.Zero, 0x2 | 0x10); // PRESENT | DEVICEINTERFACE
            if (set == IntPtr.Zero || set == new IntPtr(-1)) return null;
            try
            {
                var data = new SP_DEVICE_INTERFACE_DATA();
                data.cbSize = Marshal.SizeOf(data);
                if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref AdapterGuid, 0, ref data)) return null;
                int size;
                SetupDiGetDeviceInterfaceDetail(set, ref data, IntPtr.Zero, 0, out size, IntPtr.Zero);
                if (size <= 0) return null;
                IntPtr buf = Marshal.AllocHGlobal(size);
                try
                {
                    Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
                    if (!SetupDiGetDeviceInterfaceDetail(set, ref data, buf, size, out size, IntPtr.Zero)) return null;
                    return Marshal.PtrToStringUni(new IntPtr(buf.ToInt64() + 4));
                }
                finally { Marshal.FreeHGlobal(buf); }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
        }

        static bool Open()
        {
            if (handle != null && !handle.IsInvalid && !handle.IsClosed) return true;
            string path = DevicePath();
            if (path == null) return false;
            var h = CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0x80 | 0x20000000 | 0x40000000 | 0x80000000, IntPtr.Zero);
            if (h.IsInvalid) { Log.Write("vdd open: " + Marshal.GetLastWin32Error()); return false; }
            handle = h;
            return true;
        }

        // Overlapped IOCTL with unmanaged buffers so nothing moves while the driver works.
        static int Ioctl(uint code, byte[] data)
        {
            lock (IoL) return IoctlRaw(code, data);
        }

        static int IoctlRaw(uint code, byte[] data)
        {
            IntPtr inBuf = Marshal.AllocHGlobal(32), outBuf = Marshal.AllocHGlobal(4);
            IntPtr ov = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(NativeOverlapped)));
            IntPtr ev = CreateEvent(IntPtr.Zero, true, false, null);
            try
            {
                for (int i = 0; i < 32; i++) Marshal.WriteByte(inBuf, i, 0);
                Marshal.WriteInt32(outBuf, 0);
                if (data != null) Marshal.Copy(data, 0, inBuf, Math.Min(32, data.Length));
                Marshal.StructureToPtr(new NativeOverlapped { EventHandle = ev }, ov, false);
                DeviceIoControl(handle, code, inBuf, 32, outBuf, 4, IntPtr.Zero, ov);
                uint n;
                if (!GetOverlappedResultEx(handle, ov, out n, 5000, false))
                {
                    CancelIoEx(handle, ov);
                    GetOverlappedResult(handle, ov, out n, true);
                    return -1;
                }
                return Marshal.ReadInt32(outBuf);
            }
            finally
            {
                CloseHandle(ev);
                Marshal.FreeHGlobal(inBuf);
                Marshal.FreeHGlobal(outBuf);
                Marshal.FreeHGlobal(ov);
            }
        }

        public static bool Installed()
        {
            lock (L)
            {
                try { return Open(); } catch (Exception ex) { Log.Write("vdd: " + ex.Message); return false; }
            }
        }

        public static object Status()
        {
            bool inst = Installed();
            lock (L)
                return new Dictionary<string, object> {
                    { "installed", inst }, { "installing", installing }, { "installMsg", installMsg },
                    { "active", devs.ToList() }, { "viewers", viewers }, { "monitors", Monitors.ForClient() }, { "custom", CustomModes() },
                    { "layout", new Dictionary<string, object> {
                        { "w", layout.W }, { "h", layout.H }, { "portrait", layout.Portrait }, { "of", layout.Of }, { "side", layout.Side }, { "align", layout.Align } } } };
        }

        public class Layout { public int W = 1600, H = 720; public bool Portrait; public string Of, Side = "below", Align = "center"; }
        static Layout layout = new Layout();

        public static Layout ReadLayout(Dictionary<string, object> a)
        {
            return new Layout {
                W = (int)J.Num(a, "w", 1600), H = (int)J.Num(a, "h", 720), Portrait = J.Bool(a, "portrait"),
                Of = J.Str(a, "of"), Side = J.Str(a, "side", "below"), Align = J.Str(a, "align", "center") };
        }

        static void PlaceOurs(string dev)
        {
            Monitors.Place(dev, layout.W, layout.H, layout.Portrait, layout.Of, layout.Side, layout.Align);
        }

        // Change size / orientation / position of the active extra monitor right away.
        public static void Arrange(Layout l)
        {
            string dev;
            lock (L) dev = devs.FirstOrDefault();
            var old = layout;
            layout = l;
            if (dev == null) return;
            try { PlaceOurs(dev); }
            catch { layout = old; throw; }
        }

        public static object Add(Layout l)
        {
            lock (L)
            {
                if (!Open()) throw new InvalidOperationException("Der Bildschirm-Treiber ist noch nicht eingerichtet");
                layout = l;
                if (devs.Count > 0) return new Dictionary<string, object> { { "ok", true }, { "dev", devs[0] } };
                var before = new HashSet<string>(Monitors.List().Select(m => m.Dev), StringComparer.OrdinalIgnoreCase);
                int idx = Ioctl(IOCTL_ADD, null);
                if (idx < 0) throw new InvalidOperationException("Der Treiber hat keinen Bildschirm angelegt");
                Ioctl(IOCTL_UPDATE, null);
                added.Add(idx);
                lastViewer = DateTime.UtcNow;
                StartPinger();

                // Windows needs a moment to plug the new monitor in.
                string dev = null;
                for (int i = 0; i < 60 && dev == null; i++)
                {
                    Thread.Sleep(100);
                    foreach (var m in Monitors.List()) if (m.Virtual && !before.Contains(m.Dev)) { dev = m.Dev; break; }
                    if (dev == null && i == 25)
                    {
                        // not attached to the desktop yet: attach it ourselves
                        foreach (var d in Monitors.Devices())
                            if (Monitors.IsVirtual(d) && (d.StateFlags & 1) == 0)
                            {
                                try { PlaceOurs(d.DeviceName); } catch (Exception ex) { Log.Write("vdd attach: " + ex.Message); }
                                break;
                            }
                    }
                }
                if (dev == null) throw new InvalidOperationException("Der neue Bildschirm ist nicht erschienen – bitte nochmal versuchen");
                string warn = null;
                try { PlaceOurs(dev); }
                catch (Exception ex) { warn = ex.Message; Log.Write("vdd place: " + ex.Message); }
                devs.Add(dev);
                Log.Write("virtual display added " + dev + " (" + layout.W + "x" + layout.H + (layout.Portrait ? " hochkant" : "") + ", " + layout.Side + ")");
                return new Dictionary<string, object> { { "ok", true }, { "dev", dev }, { "warn", warn } };
            }
        }

        public static void RemoveAll()
        {
            lock (L)
            {
                if (handle == null || handle.IsInvalid) { added.Clear(); devs.Clear(); return; }
                foreach (int idx in added)
                    Ioctl(IOCTL_REMOVE, new[] { (byte)((idx >> 8) & 0xFF), (byte)(idx & 0xFF) }); // 16-bit big-endian index
                if (added.Count > 0) Ioctl(IOCTL_UPDATE, null);
                if (added.Count > 0) Log.Write("virtual display removed");
                added.Clear();
                devs.Clear();
            }
        }


        // Keepalive for the driver (it unplugs displays without it) + cleanup when no phone watches any more.
        static void StartPinger()
        {
            if (pinger != null) return;
            pinger = new Thread(() =>
            {
                while (!Program.Exiting)
                {
                    Thread.Sleep(100);
                    if (added.Count == 0) continue;
                    try { Ioctl(IOCTL_UPDATE, null); } catch (Exception ex) { Log.Write("vdd ping: " + ex.Message); }
                    if (viewers == 0 && (DateTime.UtcNow - lastViewer).TotalSeconds > 90)
                    {
                        Log.Write("virtual display: no viewer for 90 s");
                        RemoveAll();
                    }
                }
            });
            pinger.IsBackground = true;
            pinger.Name = "vdd-ping";
            pinger.Start();
        }

        public static bool IsOurs(string dev)
        {
            lock (L) return devs.Any(d => string.Equals(d, dev, StringComparison.OrdinalIgnoreCase));
        }

        public static void ViewerStart() { Interlocked.Increment(ref viewers); lastViewer = DateTime.UtcNow; }
        public static void ViewerEnd() { Interlocked.Decrement(ref viewers); lastViewer = DateTime.UtcNow; }

        // ---------- one-time driver setup (asks Windows for admin rights on the PC) ----------

        public static string Install(int w, int h)
        {
            if (Installed()) return "Der Treiber ist schon eingerichtet";
            if (installing) return "Einrichtung läuft schon …";
            installing = true;
            installMsg = "Lade den Treiber herunter …";
            var t = new Thread(() =>
            {
                try { installMsg = RunInstall(w, h); }
                catch (Exception ex) { installMsg = "Fehler: " + ex.Message; Log.Write("vdd install: " + ex); }
                finally { installing = false; }
            });
            t.SetApartmentState(ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
            return "Am PC erscheint gleich eine Windows-Abfrage – bitte mit „Ja“ bestätigen";
        }

        // Extra resolutions the driver offers besides its built-in list (readable without admin rights).
        static List<object> CustomModes()
        {
            var list = new List<object>();
            try
            {
                using (var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Parsec\vdd"))
                    if (k != null)
                        foreach (string sub in k.GetSubKeyNames())
                            using (var s = k.OpenSubKey(sub))
                            {
                                if (s == null) continue;
                                object w = s.GetValue("width"), h = s.GetValue("height");
                                if (w is int && h is int) list.Add(new Dictionary<string, object> { { "w", (int)w }, { "h", (int)h } });
                            }
            }
            catch (Exception ex) { Log.Write("vdd modes: " + ex.Message); }
            return list;
        }

        static string ModeLines(int w, int h, bool ps)
        {
            double aspect = w > 0 && h > 0 ? Math.Max(w, h) / (double)Math.Min(w, h) : 20.0 / 9;
            var sb = new StringBuilder();
            int slot = 0;
            foreach (int hh in new[] { 576, 720, 864, 1080 })
            {
                int ww = (int)(Math.Round(hh * aspect / 8) * 8);
                string key = "HKLM\\SOFTWARE\\Parsec\\vdd\\" + slot++;
                if (ps) sb.Append("New-Item -Path 'HKLM:\\SOFTWARE\\Parsec\\vdd\\" + (slot - 1) + "' -Force | Out-Null\r\n");
                foreach (var v in new[] { new[] { "width", ww.ToString() }, new[] { "height", hh.ToString() }, new[] { "hz", "60" } })
                    sb.Append(ps ? "Set-ItemProperty -Path 'HKLM:\\SOFTWARE\\Parsec\\vdd\\" + (slot - 1) + "' -Name " + v[0] + " -Value " + v[1] + " -Type DWord\r\n"
                                 : "reg add \"" + key + "\" /v " + v[0] + " /t REG_DWORD /d " + v[1] + " /f >nul\r\n");
            }
            return sb.ToString();
        }

        // Rewrites the extra resolutions for this phone's shape and restarts the driver so it picks them up.
        public static string SetModes(int w, int h)
        {
            if (installing) return "Läuft schon …";
            RemoveAll();
            lock (L)
            {
                if (handle != null) { handle.Dispose(); handle = null; }
            }
            installing = true;
            installMsg = "Bitte am PC die Windows-Abfrage mit „Ja“ bestätigen …";
            var t = new Thread(() =>
            {
                try
                {
                    string dir = Path.Combine(Path.GetTempPath(), "PCRemote-vdd");
                    Directory.CreateDirectory(dir);
                    string ps1 = Path.Combine(dir, "modes.ps1");
                    File.WriteAllText(ps1, ModeLines(w, h, true) +
                        "Get-PnpDevice | Where-Object { $_.FriendlyName -like 'Parsec Virtual Display*' } | ForEach-Object {\r\n" +
                        "  Disable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false; Start-Sleep -Seconds 1; Enable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false }\r\n",
                        new UTF8Encoding(true));
                    var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + ps1 + "\"");
                    psi.Verb = "runas";
                    psi.UseShellExecute = true;
                    psi.WindowStyle = ProcessWindowStyle.Hidden;
                    Process p;
                    try { p = Process.Start(psi); }
                    catch (Win32Exception ex)
                    {
                        installMsg = ex.NativeErrorCode == 1223 ? "Abgebrochen – die Windows-Abfrage wurde nicht bestätigt" : "Fehler: " + ex.Message;
                        return;
                    }
                    installMsg = "Treiber wird neu gestartet …";
                    if (p != null) { p.WaitForExit(60000); p.Dispose(); }
                    for (int i = 0; i < 20 && !Installed(); i++) Thread.Sleep(500);
                    installMsg = "Fertig – die Handy-Auflösungen sind eingerichtet";
                }
                catch (Exception ex) { installMsg = "Fehler: " + ex.Message; Log.Write("vdd modes: " + ex); }
                finally { installing = false; }
            });
            t.SetApartmentState(ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
            return "Am PC erscheint gleich eine Windows-Abfrage – bitte mit „Ja“ bestätigen";
        }

        static string RunInstall(int w, int h)
        {
            string dir = Path.Combine(Path.GetTempPath(), "PCRemote-vdd");
            Directory.CreateDirectory(dir);
            string exe = Path.Combine(dir, "parsec-vdd-0.45.0.0.exe");
            if (!File.Exists(exe) || Hash(exe) != InstallerSha256)
            {
                using (var wc = new WebClient()) wc.DownloadFile(InstallerUrl, exe);
            }
            if (Hash(exe) != InstallerSha256) { File.Delete(exe); throw new InvalidOperationException("Die heruntergeladene Datei ist nicht die erwartete – abgebrochen"); }

            // Extra resolutions shaped like the phone (landscape), read by the driver from the registry.
            var sb = new StringBuilder("@echo off\r\n" + ModeLines(w, h, false) + "\"" + exe + "\" /S\r\nexit /b 0\r\n");
            string cmd = Path.Combine(dir, "setup.cmd");
            File.WriteAllText(cmd, sb.ToString(), Encoding.ASCII);

            installMsg = "Bitte am PC die Windows-Abfrage mit „Ja“ bestätigen …";
            var psi = new ProcessStartInfo("cmd.exe", "/c \"" + cmd + "\"");
            psi.Verb = "runas";
            psi.UseShellExecute = true;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            Process p;
            try { p = Process.Start(psi); }
            catch (Win32Exception ex)
            {
                if (ex.NativeErrorCode == 1223) return "Abgebrochen – die Windows-Abfrage wurde nicht bestätigt";
                throw;
            }
            installMsg = "Treiber wird installiert …";
            if (p != null) { p.WaitForExit(180000); p.Dispose(); }
            for (int i = 0; i < 30; i++)
            {
                if (Installed()) return "Fertig – der Bildschirm-Treiber ist eingerichtet";
                Thread.Sleep(500);
            }
            return "Installation beendet, aber der Treiber antwortet nicht. Ein Neustart des PCs hilft meist.";
        }

        static string Hash(string file)
        {
            using (var sha = SHA256.Create())
            using (var fs = File.OpenRead(file))
                return BitConverter.ToString(sha.ComputeHash(fs)).Replace("-", "");
        }
    }

    // Live picture of one monitor as MJPEG (an <img> on the phone shows it directly) + touch → mouse on that monitor.
    static class ScreenStream
    {
        [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
        [DllImport("user32.dll")] static extern bool GetCursorInfo(ref CURSORINFO ci);
        [DllImport("user32.dll")] static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr icon, int w, int h, int step, IntPtr brush, int flags);
        [DllImport("user32.dll")] static extern bool GetIconInfo(IntPtr h, out ICONINFO info);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);

        [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] struct CURSORINFO { public int cbSize, flags; public IntPtr hCursor; public POINT pt; }
        [StructLayout(LayoutKind.Sequential)] struct ICONINFO { public bool fIcon; public int xHotspot, yHotspot; public IntPtr hbmMask, hbmColor; }

        static readonly byte[] Crlf = { 13, 10 };

        public static void Run(Stream s, string dev, int maxW, int quality, int fps)
        {
            bool ours = VirtualDisplay.IsOurs(dev);
            if (ours) VirtualDisplay.ViewerStart();
            fps = Math.Max(2, Math.Min(30, fps));
            var codec = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
            var ep = new EncoderParameters(1);
            ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)Math.Max(20, Math.Min(95, quality)));
            Grabber grab = null;
            Bitmap frame = null;
            var lastLook = DateTime.MinValue;
            ulong lastPrint = 0;
            var lastSent = DateTime.MinValue;
            var sw = new Stopwatch();
            try
            {
                var mon = Monitors.Find(dev);
                if (mon == null) return;
                var size = Grabber.Fit(mon, maxW);
                grab = new Grabber(mon, size.Width, size.Height);
                frame = grab.AsBitmap();
                using (var ms = new MemoryStream())
                    while (!Program.Exiting)
                    {
                        sw.Restart();
                        if ((DateTime.UtcNow - lastLook).TotalSeconds > 1)
                        {
                            lastLook = DateTime.UtcNow;
                            var m = Monitors.Find(dev);
                            if (m == null || m.W != mon.W || m.H != mon.H) break; // gone or resized: the phone reconnects
                            if (m.X != mon.X || m.Y != mon.Y) { mon = m; grab.Move(m); }
                        }
                        grab.Grab();
                        ulong print = grab.Fingerprint();
                        // Unchanged picture: only resend now and then so the connection stays alive.
                        if (print != lastPrint || (DateTime.UtcNow - lastSent).TotalSeconds > 2)
                        {
                            ms.SetLength(0);
                            frame.Save(ms, codec, ep);
                            byte[] head = Encoding.ASCII.GetBytes("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + ms.Length + "\r\n\r\n");
                            s.Write(head, 0, head.Length);
                            s.Write(ms.GetBuffer(), 0, (int)ms.Length);
                            s.Write(Crlf, 0, 2);
                            s.Flush();
                            lastPrint = print;
                            lastSent = DateTime.UtcNow;
                        }
                        int wait = 1000 / fps - (int)sw.ElapsedMilliseconds;
                        if (wait > 0) Thread.Sleep(wait);
                    }
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
            finally
            {
                if (frame != null) frame.Dispose();
                if (grab != null) grab.Dispose();
                ep.Dispose();
                if (ours) VirtualDisplay.ViewerEnd();
            }
        }

        static void DrawCursor(Graphics g, Mon mon)
        {
            var ci = new CURSORINFO();
            ci.cbSize = Marshal.SizeOf(ci);
            if (!GetCursorInfo(ref ci) || (ci.flags & 1) == 0) return;
            int x = ci.pt.X - mon.X, y = ci.pt.Y - mon.Y;
            if (x < -32 || y < -32 || x > mon.W || y > mon.H) return;
            ICONINFO ii;
            if (GetIconInfo(ci.hCursor, out ii))
            {
                x -= ii.xHotspot;
                y -= ii.yHotspot;
                if (ii.hbmMask != IntPtr.Zero) DeleteObject(ii.hbmMask);
                if (ii.hbmColor != IntPtr.Zero) DeleteObject(ii.hbmColor);
            }
            IntPtr hdc = g.GetHdc();
            try { DrawIconEx(hdc, x, y, ci.hCursor, 0, 0, 0, IntPtr.Zero, 3); }
            finally { g.ReleaseHdc(hdc); }
        }

        // Touch on the phone picture: x/y are 0..1 of that monitor.
        public static void Pointer(Dictionary<string, object> a)
        {
            var mon = Monitors.Find(J.Str(a, "dev"));
            if (mon == null) throw new InvalidOperationException("Diesen Bildschirm gibt es nicht mehr");
            string op = J.Str(a, "op", "move");
            if (op != "scroll")
            {
                double fx = Math.Max(0, Math.Min(1, J.Num(a, "x"))), fy = Math.Max(0, Math.Min(1, J.Num(a, "y")));
                SetCursorPos(mon.X + (int)Math.Round(fx * (mon.W - 1)), mon.Y + (int)Math.Round(fy * (mon.H - 1)));
            }
            switch (op)
            {
                case "down": Input.Mouse(new Dictionary<string, object> { { "down", "left" } }); break;
                case "up": Input.Mouse(new Dictionary<string, object> { { "up", "left" } }); break;
                case "click": Thread.Sleep(15); Input.Click("left", false); break;
                case "double": Thread.Sleep(15); Input.Click("left", true); break;
                case "right": Thread.Sleep(15); Input.Click("right", false); break;
                case "scroll": Input.Mouse(new Dictionary<string, object> { { "sy", J.Num(a, "sy") }, { "sx", J.Num(a, "sx") } }); break;
            }
        }
    }
}
