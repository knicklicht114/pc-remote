using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace PCRemote
{
    static class WindowList
    {
        delegate bool EnumWindowsProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr l);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
        [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int idx);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
        [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
        [DllImport("user32.dll")] static extern void SwitchToThisWindow(IntPtr h, bool altTab);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int val, int size);

        static readonly HashSet<string> SkipTitles = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
            "Program Manager", "NVIDIA GeForce Overlay", "Microsoft Text Input Application", "Windows Input Experience" };

        class Win { public IntPtr H; public string Title; public string Proc; }

        static List<Win> Enumerate()
        {
            var list = new List<Win>();
            uint self = (uint)Process.GetCurrentProcess().Id;
            var names = new Dictionary<uint, string>();
            EnumWindows((h, l) =>
            {
                if (!IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero) return true;
                if ((GetWindowLong(h, -20) & 0x80) != 0) return true; // tool window
                int cloaked;
                if (DwmGetWindowAttribute(h, 14, out cloaked, 4) == 0 && cloaked != 0) return true;
                int len = GetWindowTextLength(h);
                if (len == 0) return true;
                var sb = new StringBuilder(len + 1);
                GetWindowText(h, sb, sb.Capacity);
                string title = sb.ToString();
                if (SkipTitles.Contains(title)) return true;
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                if (pid == self) return true;
                string proc;
                if (!names.TryGetValue(pid, out proc))
                {
                    try { using (var p = Process.GetProcessById((int)pid)) proc = p.ProcessName.ToLowerInvariant(); }
                    catch { proc = ""; }
                    names[pid] = proc;
                }
                list.Add(new Win { H = h, Title = title, Proc = proc });
                return true;
            }, IntPtr.Zero);
            return list;
        }

        public static object List()
        {
            IntPtr fg = GetForegroundWindow();
            var list = new List<object>();
            foreach (var w in Enumerate())
            {
                list.Add(new Dictionary<string, object> {
                    { "h", w.H.ToInt64().ToString() }, { "title", w.Title }, { "proc", w.Proc },
                    { "app", Apps.NameForProc(w.Proc) }, { "min", IsIconic(w.H) }, { "max", IsZoomed(w.H) }, { "fg", w.H == fg } });
            }
            return list;
        }

        public static IntPtr Foreground() { return GetForegroundWindow(); }

        public static List<IntPtr> HandlesFor(IEnumerable<string> procs)
        {
            var set = new HashSet<string>(procs, StringComparer.OrdinalIgnoreCase);
            var list = new List<IntPtr>();
            foreach (var w in Enumerate()) if (set.Contains(w.Proc)) list.Add(w.H);
            return list;
        }

        public static List<object> ForProcs(IEnumerable<string> procs)
        {
            var set = new HashSet<string>(procs, StringComparer.OrdinalIgnoreCase);
            IntPtr fg = GetForegroundWindow();
            var list = new List<object>();
            foreach (var w in Enumerate())
            {
                if (!set.Contains(w.Proc)) continue;
                list.Add(new Dictionary<string, object> {
                    { "h", w.H.ToInt64().ToString() }, { "title", w.Title }, { "min", IsIconic(w.H) }, { "max", IsZoomed(w.H) }, { "fg", w.H == fg } });
            }
            return list;
        }

        public static void Do(string hs, string op)
        {
            long v;
            if (!long.TryParse(hs, out v)) throw new ArgumentException("Ungültiges Fenster");
            DoHandle(new IntPtr(v), op);
        }

        public static void DoHandle(IntPtr h, string op)
        {
            if (!IsWindow(h)) throw new InvalidOperationException("Fenster existiert nicht mehr");
            switch (op)
            {
                case "focus": Focus(h); break;
                case "min": ShowWindow(h, 6); break;
                case "max": ShowWindow(h, IsZoomed(h) ? 9 : 3); Focus(h); break;
                case "restore": ShowWindow(h, 9); break;
                case "close": PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); break;
                default: throw new ArgumentException("Unbekannt: " + op);
            }
        }

        public static void Focus(IntPtr h)
        {
            if (IsIconic(h)) ShowWindow(h, 9);
            IntPtr fg = GetForegroundWindow();
            uint pid;
            uint fgThread = GetWindowThreadProcessId(fg, out pid);
            uint me = GetCurrentThreadId();
            bool attached = fgThread != 0 && fgThread != me && AttachThreadInput(me, fgThread, true);
            try
            {
                BringWindowToTop(h);
                SetForegroundWindow(h);
            }
            finally
            {
                if (attached) AttachThreadInput(me, fgThread, false);
            }
            if (GetForegroundWindow() != h) SwitchToThisWindow(h, true);
        }

        public static bool FocusProcs(IEnumerable<string> procs)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in procs) set.Add(p);
            foreach (var w in Enumerate())
            {
                if (set.Contains(w.Proc)) { Focus(w.H); return true; }
            }
            return false;
        }
    }
}
