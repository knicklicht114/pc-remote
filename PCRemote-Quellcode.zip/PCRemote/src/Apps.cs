using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace PCRemote
{
    class AppInfo
    {
        public string Id, Name, Kind, Source, Target, IconPath;
        public int IconIndex;
        public List<string> Procs = new List<string>();
    }

    // Finds installed apps & games (Start menu, desktop, Steam, Epic) and serves their icons.
    static class Apps
    {
        static List<AppInfo> apps = new List<AppInfo>();
        static readonly object L = new object();
        static readonly object scanLock = new object();
        static readonly Dictionary<string, byte[]> iconCache = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<string, string> descCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // lower-case name fragment -> process names
        static readonly string[][] KnownProcs = {
            new[] { "valorant", "VALORANT-Win64-Shipping", "VALORANT" },
            new[] { "fortnite", "FortniteClient-Win64-Shipping", "FortniteLauncher" },
            new[] { "roblox player", "RobloxPlayerBeta" },
            new[] { "roblox studio", "RobloxStudioBeta" },
            new[] { "battlefield 6", "bf6" },
            new[] { "league of legends", "League of Legends", "LeagueClient" },
            new[] { "riot client", "Riot Client", "RiotClientServices" },
            new[] { "discord", "Discord" },
            new[] { "spotify", "Spotify" },
            new[] { "medal", "Medal" },
            new[] { "epic games launcher", "EpicGamesLauncher" },
            new[] { "nvidia app", "NVIDIA App" },
            new[] { "voicemeeter", "voicemeeter", "voicemeeter_x64", "voicemeeterpro", "voicemeeterpro_x64", "voicemeeter8", "voicemeeter8x64" },
            new[] { "visual studio code", "Code" },
            new[] { "google chrome", "chrome" },
            new[] { "microsoft edge", "msedge" },
            new[] { "minecraft", "javaw", "Minecraft.Windows" },
            new[] { "obs studio", "obs64" },
        };

        static readonly string[] Launchers = { "steam", "epic games launcher", "riot client", "battle.net", "ea app", "ea", "ubisoft connect", "gog galaxy", "rockstar games launcher", "xbox" };
        static readonly string[] GameWords = { "valorant", "fortnite", "roblox player", "battlefield", "minecraft", "league of legends", "counter-strike", "rocket league",
            "apex legends", "overwatch", "grand theft auto", "call of duty", "rainbow six", "the finals", "marvel rivals", "pubg", "dota", "warzone", "genshin", "fall guys" };
        static readonly string[] SkipFolders = { "administrative tools", "windows administrative tools", "accessibility", "accessories", "system tools",
            "windows powershell", "startup", "maintenance", "windows accessories", "windows ease of access", "windows system", "windows tools" };
        static readonly string[] SkipWords = { "uninstall", "deinstall", "readme", "read me", "help", "support center", "website", "manual", "documentation",
            "release notes", "license", "immersive control panel", "onedrive", "15 bands graphic eq", "8x8 output matrix", "vban-2-midi",
            "virtual io control panel", "vm streamer view", "voicemeeter x64", "macro buttons", "pc remote" };
        static readonly string[] BadExe = { "unins", "crash", "report", "anticheat", "anti-cheat", "setup", "redist", "helper", "updater", "install",
            "battleye", "beservice", "cefprocess", "service", "uploader", "dump", "launcherhelper" };

        // ---------- public api ----------

        public static void ScanAsync()
        {
            var t = new Thread(() => { try { Scan(); } catch (Exception ex) { Log.Write("scan: " + ex); } });
            t.IsBackground = true;
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
        }

        public static void ScanBlocking()
        {
            Exception err = null;
            var t = new Thread(() => { try { Scan(); } catch (Exception ex) { err = ex; } });
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join(30000);
            if (err != null) throw err;
        }

        public static object ListForClient()
        {
            var list = new List<object>();
            foreach (var a in Snapshot())
            {
                list.Add(new Dictionary<string, object> {
                    { "id", a.Id }, { "name", a.Name }, { "kind", a.Kind }, { "source", a.Source },
                    { "procs", a.Procs.Select(p => p.ToLowerInvariant()).ToList() } });
            }
            return list;
        }

        public static object Do(string id, string op)
        {
            var a = Find(id);
            if (a == null) throw new ArgumentException("App nicht gefunden \u2013 bitte Apps neu scannen");
            bool running = a.Procs.Count > 0 && Sys.AnyRunning(a.Procs);
            switch (op)
            {
                case "launch":
                    Sys.Launch(a.Target, null);
                    return Msg(a.Name + " wird gestartet");
                case "kill":
                    if (!running) return Msg(a.Name + " l\u00e4uft gerade nicht");
                    Sys.Kill(a.Procs, false);
                    return Msg(a.Name + " wird beendet");
                case "focus":
                    if (WindowList.FocusProcs(a.Procs)) return Msg(a.Name + " im Vordergrund");
                    return Msg(a.Name + " hat kein offenes Fenster");
                case "forcekill":
                    if (!running) return Msg(a.Name + " läuft gerade nicht");
                    Sys.Kill(a.Procs, true);
                    return Msg(a.Name + " wurde sofort beendet");
                case "restart":
                    {
                        if (running) Sys.Kill(a.Procs, false);
                        var app = a;
                        var t = new Thread(() =>
                        {
                            for (int i = 0; i < 40 && app.Procs.Count > 0 && Sys.AnyRunning(app.Procs); i++) Thread.Sleep(250);
                            try { Sys.Launch(app.Target, null); } catch (Exception ex) { Log.Write("restart " + app.Name + ": " + ex.Message); }
                        });
                        t.IsBackground = true;
                        t.Start();
                        return Msg(a.Name + " wird neu gestartet");
                    }
                default:
                    if (running && WindowList.FocusProcs(a.Procs)) return Msg(a.Name + " im Vordergrund");
                    Sys.Launch(a.Target, null);
                    return Msg(a.Name + " wird gestartet");
            }
        }

        static object Msg(string m) { return new Dictionary<string, object> { { "ok", true }, { "msg", m } }; }

        public static List<string> ProcsOf(string id)
        {
            var a = Find(id);
            return a == null ? new List<string>() : new List<string>(a.Procs);
        }

        public static string NameForProc(string proc)
        {
            if (string.IsNullOrEmpty(proc)) return "";
            if (proc == "system") return "Systemkl\u00e4nge";
            var a = FindByProc(proc);
            if (a != null) return a.Name;
            lock (descCache)
            {
                string d;
                if (descCache.TryGetValue(proc, out d)) return d;
            }
            string name = Pretty(proc);
            try
            {
                string exe = ExeOfProc(proc);
                if (exe != null)
                {
                    var fvi = FileVersionInfo.GetVersionInfo(exe);
                    string desc = (fvi.FileDescription ?? "").Trim();
                    if (desc.Length > 1 && desc.Length < 40) name = desc;
                }
            }
            catch { }
            lock (descCache) descCache[proc] = name;
            return name;
        }

        public static byte[] IconById(string id)
        {
            var a = Find(id);
            if (a == null) return null;
            return Cached("id:" + id, () => ExtractFor(a));
        }

        public static byte[] IconByProc(string proc)
        {
            if (string.IsNullOrEmpty(proc) || proc == "system") return null;
            var a = FindByProc(proc);
            if (a != null)
            {
                var b = IconById(a.Id);
                if (b != null) return b;
            }
            return Cached("proc:" + proc, () =>
            {
                string exe = ExeOfProc(proc);
                return exe == null ? null : IconUtil.Extract(exe, 0);
            });
        }

        // ---------- lookup ----------

        static List<AppInfo> Snapshot() { lock (L) return new List<AppInfo>(apps); }

        static AppInfo Find(string id)
        {
            if (id == null) return null;
            lock (L) return apps.FirstOrDefault(a => a.Id == id);
        }

        static AppInfo FindByProc(string proc)
        {
            lock (L) return apps.FirstOrDefault(a => a.Procs.Any(p => string.Equals(p, proc, StringComparison.OrdinalIgnoreCase)));
        }

        static byte[] Cached(string key, Func<byte[]> make)
        {
            lock (iconCache)
            {
                byte[] b;
                if (iconCache.TryGetValue(key, out b)) return b;
            }
            byte[] r = null;
            try { r = make(); } catch (Exception ex) { Log.Write("icon " + key + ": " + ex.Message); }
            lock (iconCache) iconCache[key] = r;
            return r;
        }

        static byte[] ExtractFor(AppInfo a)
        {
            byte[] r = null;
            if (!string.IsNullOrEmpty(a.IconPath))
            {
                string p = Environment.ExpandEnvironmentVariables(a.IconPath.Trim('"'));
                if (File.Exists(p)) r = IconUtil.Extract(p, a.IconIndex);
            }
            if (r == null && a.Target != null && File.Exists(a.Target)) r = IconUtil.Associated(a.Target);
            if (r == null && a.Procs.Count > 0)
            {
                string exe = ExeOfProc(a.Procs[0]);
                if (exe != null) r = IconUtil.Extract(exe, 0);
            }
            return r;
        }

        [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder sb, ref int size);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

        static string ExeOfProc(string proc)
        {
            foreach (var p in Process.GetProcessesByName(proc))
            {
                using (p)
                {
                    IntPtr h = OpenProcess(0x1000, false, p.Id);
                    if (h == IntPtr.Zero) continue;
                    try
                    {
                        var sb = new StringBuilder(1024);
                        int n = sb.Capacity;
                        if (QueryFullProcessImageName(h, 0, sb, ref n)) return sb.ToString();
                    }
                    finally { CloseHandle(h); }
                }
            }
            return null;
        }

        // ---------- scanning ----------

        static void Scan()
        {
            lock (scanLock)
            {
                var found = new List<AppInfo>();
                var seen = new HashSet<string>();
                Step("steam", () => ScanSteam(found, seen));
                Step("epic", () => ScanEpic(found, seen));
                Step("shortcuts", () => ScanShortcuts(found, seen));
                Step("known", () => ScanKnownFolders(found, seen));

                var ids = new HashSet<string>();
                foreach (var a in found)
                {
                    string id = Slug(a.Name), baseId = id;
                    for (int i = 2; !ids.Add(id); i++) id = baseId + "-" + i;
                    a.Id = id;
                }
                found.Sort((x, y) => string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase));
                lock (L) apps = found;
                lock (iconCache) iconCache.Clear();
                Log.Write("scan: " + found.Count + " apps (" + string.Join(", ", found.Select(f => f.Name).ToArray()) + ")");
            }
        }

        static void Step(string name, Action a)
        {
            try { a(); } catch (Exception ex) { Log.Write("scan " + name + ": " + ex.Message); }
        }

        static string Normalize(string name)
        {
            name = name.Replace("\u2122", "").Replace("\u00ae", "").Replace("\u00a9", "");
            return Regex.Replace(name, @"\s+", " ").Trim();
        }

        static string Slug(string name)
        {
            string s = Regex.Replace(name.ToLowerInvariant(), "[^a-z0-9]+", "-").Trim('-');
            return s.Length == 0 ? "app" : s;
        }

        static string Pretty(string proc)
        {
            string s = proc.Replace('_', ' ').Replace('-', ' ');
            return s.Length == 0 ? s : char.ToUpperInvariant(s[0]) + s.Substring(1);
        }

        static List<string> KnownFor(string name)
        {
            string n = name.ToLowerInvariant();
            if (n == "steam") return new List<string> { "steam" };
            foreach (var k in KnownProcs)
                if (n.Contains(k[0])) return k.Skip(1).ToList();
            return null;
        }

        static string Classify(string name, string target, string source)
        {
            string n = name.ToLowerInvariant();
            if (source == "steam" || source == "epic") return "game";
            if (Launchers.Contains(n)) return "launcher";
            if (GameWords.Any(w => n.Contains(w))) return "game";
            string t = (target ?? "").ToLowerInvariant();
            if (t.StartsWith("steam://rungameid") || t.StartsWith("com.epicgames.launcher://apps")) return "game";
            return "app";
        }

        static void Add(List<AppInfo> found, HashSet<string> seen, AppInfo a)
        {
            a.Name = Normalize(a.Name);
            if (a.Name.Length == 0 || !seen.Add(a.Name.ToLowerInvariant())) return;
            if (a.Kind == null) a.Kind = Classify(a.Name, a.Target, a.Source);
            found.Add(a);
        }

        static void ScanSteam(List<AppInfo> found, HashSet<string> seen)
        {
            string steam = null;
            using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
                if (k != null) steam = k.GetValue("SteamPath") as string;
            if (steam == null)
                using (var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam"))
                    if (k != null) steam = k.GetValue("InstallPath") as string;
            if (steam == null) return;
            steam = steam.Replace('/', '\\');

            var libs = new List<string> { steam };
            string vdf = Path.Combine(steam, @"steamapps\libraryfolders.vdf");
            if (File.Exists(vdf))
                foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"(.+?)\""))
                {
                    string lib = m.Groups[1].Value.Replace("\\\\", "\\");
                    if (!libs.Any(l => string.Equals(l.TrimEnd('\\'), lib.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))) libs.Add(lib);
                }

            foreach (string lib in libs)
            {
                string steamapps = Path.Combine(lib, "steamapps");
                if (!Directory.Exists(steamapps)) continue;
                foreach (string acf in Directory.GetFiles(steamapps, "appmanifest_*.acf"))
                {
                    string txt = File.ReadAllText(acf, Encoding.UTF8);
                    string appid = Field(txt, "appid"), name = Field(txt, "name"), dir = Field(txt, "installdir");
                    if (appid == null || name == null) continue;
                    if (appid == "228980" || Regex.IsMatch(name, "Redistributable|Steamworks|Proton|Steam Linux Runtime|SteamVR", RegexOptions.IgnoreCase)) continue;
                    string exe = dir == null ? null : BestExe(Path.Combine(steamapps, "common", dir));
                    var a = new AppInfo { Name = name, Source = "steam", Kind = "game", Target = "steam://rungameid/" + appid, IconPath = exe };
                    a.Procs = KnownFor(Normalize(name)) ?? (exe != null ? new List<string> { Path.GetFileNameWithoutExtension(exe) } : new List<string>());
                    Add(found, seen, a);
                }
            }
        }

        static string Field(string acf, string key)
        {
            var m = Regex.Match(acf, "\"" + key + "\"\\s+\"([^\"]*)\"", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value : null;
        }

        static string BestExe(string dir)
        {
            if (!Directory.Exists(dir)) return null;
            for (int depth = 0; depth <= 3; depth++)
            {
                var opt = depth == 0 ? SearchOption.TopDirectoryOnly : SearchOption.AllDirectories;
                string[] files;
                try { files = Directory.GetFiles(dir, "*.exe", opt); }
                catch { return null; }
                var good = files.Where(f => !BadExe.Any(b => Path.GetFileName(f).ToLowerInvariant().Contains(b))).ToList();
                if (good.Count > 0) return good.OrderByDescending(f => new FileInfo(f).Length).First();
                if (depth == 0) continue;
                break;
            }
            return null;
        }

        static void ScanEpic(List<AppInfo> found, HashSet<string> seen)
        {
            string pd = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            string man = Path.Combine(pd, @"Epic\EpicGamesLauncher\Data\Manifests");
            var items = new List<string>();
            if (Directory.Exists(man))
            {
                items.AddRange(Directory.GetFiles(man, "*.item"));
                string pending = Path.Combine(man, "Pending");
                if (Directory.Exists(pending)) items.AddRange(Directory.GetFiles(pending, "*.item"));
            }
            foreach (string f in items)
            {
                var d = J.Obj(File.ReadAllText(f));
                string appName = J.Str(d, "AppName"), display = J.Str(d, "DisplayName");
                if (string.IsNullOrEmpty(appName) || appName.StartsWith("UE_")) continue;
                string ns = J.Str(d, "CatalogNamespace"), item = J.Str(d, "CatalogItemId");
                string loc = J.Str(d, "InstallLocation"), exe = J.Str(d, "LaunchExecutable");
                string launchId = !string.IsNullOrEmpty(ns) && !string.IsNullOrEmpty(item) ? ns + ":" + item + ":" + appName : appName;
                var a = new AppInfo
                {
                    Name = string.IsNullOrEmpty(display) ? appName : display,
                    Source = "epic",
                    Kind = "game",
                    Target = "com.epicgames.launcher://apps/" + Uri.EscapeDataString(launchId) + "?action=launch&silent=true",
                    IconPath = loc != null && exe != null ? Path.Combine(loc, exe) : null
                };
                a.Procs = KnownFor(a.Name) ?? (exe != null ? new List<string> { Path.GetFileNameWithoutExtension(exe) } : new List<string>());
                Add(found, seen, a);
            }

            string dat = Path.Combine(pd, @"Epic\UnrealEngineLauncher\LauncherInstalled.dat");
            if (File.Exists(dat))
            {
                var d = J.Obj(File.ReadAllText(dat));
                object listObj;
                if (d.TryGetValue("InstallationList", out listObj) && listObj is object[])
                {
                    foreach (var o in (object[])listObj)
                    {
                        var e = o as Dictionary<string, object>;
                        string appName = J.Str(e, "AppName");
                        if (string.IsNullOrEmpty(appName) || appName.StartsWith("UE_")) continue;
                        var a = new AppInfo
                        {
                            Name = appName,
                            Source = "epic",
                            Kind = "game",
                            Target = "com.epicgames.launcher://apps/" + Uri.EscapeDataString(appName) + "?action=launch&silent=true",
                            IconPath = BestExe(J.Str(e, "InstallLocation") ?? "")
                        };
                        a.Procs = KnownFor(appName) ?? new List<string>();
                        Add(found, seen, a);
                    }
                }
            }
        }

        static void ScanKnownFolders(List<AppInfo> found, HashSet<string> seen)
        {
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string fn = Path.Combine(pf, @"Epic Games\Fortnite");
            if (Directory.Exists(fn) && !seen.Contains("fortnite"))
            {
                string exe = Path.Combine(fn, @"FortniteGame\Binaries\Win64\FortniteLauncher.exe");
                Add(found, seen, new AppInfo
                {
                    Name = "Fortnite",
                    Source = "epic",
                    Kind = "game",
                    Target = "com.epicgames.launcher://apps/fn%3A4fe75bbc5a674f4f9b356b5c90567da5%3AFortnite?action=launch&silent=true",
                    IconPath = File.Exists(exe) ? exe : null,
                    Procs = KnownFor("fortnite")
                });
            }
        }

        static void ScanShortcuts(List<AppInfo> found, HashSet<string> seen)
        {
            var roots = new[] {
                Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms),
                Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory) };

            object wsh = null;
            try { wsh = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell")); }
            catch (Exception ex) { Log.Write("wsh: " + ex.Message); }

            foreach (string root in roots)
            {
                if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
                foreach (string file in Walk(root, 0))
                {
                    string ext = Path.GetExtension(file).ToLowerInvariant();
                    if (ext != ".lnk" && ext != ".url") continue;
                    string rel = file.Substring(root.Length).ToLowerInvariant();
                    if (SkipFolders.Any(f => rel.Contains("\\" + f + "\\"))) continue;
                    string name = Normalize(Path.GetFileNameWithoutExtension(file));
                    string lname = name.ToLowerInvariant();
                    if (SkipWords.Any(w => lname.Contains(w))) continue;

                    if (ext == ".url") { AddUrl(found, seen, file, name); continue; }
                    if (seen.Contains(lname)) continue;

                    string target = null, args = null, iconLoc = null;
                    if (wsh != null) ResolveLnk(wsh, file, out target, out args, out iconLoc);
                    var a = new AppInfo { Name = name, Source = "shortcut", Target = file };
                    ParseIconLocation(iconLoc, a);
                    if (string.IsNullOrEmpty(a.IconPath) && !string.IsNullOrEmpty(target)) a.IconPath = target;
                    a.Procs = KnownFor(name) ?? DeriveProcs(target, args);
                    a.Kind = Classify(name, target, "shortcut");
                    Add(found, seen, a);
                }
            }
            if (wsh != null) try { Marshal.FinalReleaseComObject(wsh); } catch { }
        }

        static IEnumerable<string> Walk(string dir, int depth)
        {
            string[] files = new string[0], dirs = new string[0];
            try { files = Directory.GetFiles(dir); } catch { }
            foreach (var f in files) yield return f;
            if (depth > 4) yield break;
            try { dirs = Directory.GetDirectories(dir); } catch { }
            foreach (var d in dirs)
                foreach (var f in Walk(d, depth + 1)) yield return f;
        }

        static void AddUrl(List<AppInfo> found, HashSet<string> seen, string file, string name)
        {
            string url = null, iconFile = null;
            int iconIndex = 0;
            foreach (string line in File.ReadAllLines(file))
            {
                if (line.StartsWith("URL=", StringComparison.OrdinalIgnoreCase)) url = line.Substring(4).Trim();
                else if (line.StartsWith("IconFile=", StringComparison.OrdinalIgnoreCase)) iconFile = line.Substring(9).Trim();
                else if (line.StartsWith("IconIndex=", StringComparison.OrdinalIgnoreCase)) int.TryParse(line.Substring(10).Trim(), out iconIndex);
            }
            if (string.IsNullOrEmpty(url)) return;

            // Steam's own desktop shortcut carries a nicer .ico than the game exe.
            AppInfo existing = found.FirstOrDefault(x => string.Equals(x.Target, url, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                if (!string.IsNullOrEmpty(iconFile) && File.Exists(iconFile)) { existing.IconPath = iconFile; existing.IconIndex = iconIndex; }
                return;
            }
            if (!url.Contains("://") || url.StartsWith("http", StringComparison.OrdinalIgnoreCase)) return;
            var a = new AppInfo { Name = name, Source = "shortcut", Target = url, IconPath = iconFile, IconIndex = iconIndex };
            a.Procs = KnownFor(name) ?? new List<string>();
            Add(found, seen, a);
        }

        static void ResolveLnk(object wsh, string path, out string target, out string args, out string iconLoc)
        {
            target = args = iconLoc = null;
            try
            {
                object sc = wsh.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, wsh, new object[] { path });
                Type t = sc.GetType();
                target = t.InvokeMember("TargetPath", BindingFlags.GetProperty, null, sc, null) as string;
                args = t.InvokeMember("Arguments", BindingFlags.GetProperty, null, sc, null) as string;
                iconLoc = t.InvokeMember("IconLocation", BindingFlags.GetProperty, null, sc, null) as string;
                Marshal.FinalReleaseComObject(sc);
            }
            catch (Exception ex) { Log.Write("lnk " + path + ": " + ex.Message); }
        }

        static void ParseIconLocation(string loc, AppInfo a)
        {
            if (string.IsNullOrEmpty(loc)) return;
            int c = loc.LastIndexOf(',');
            string p = c >= 0 ? loc.Substring(0, c) : loc;
            int idx = 0;
            if (c >= 0) int.TryParse(loc.Substring(c + 1), out idx);
            if (p.Trim().Length == 0) return;
            a.IconPath = p.Trim();
            a.IconIndex = idx;
        }

        static List<string> DeriveProcs(string target, string args)
        {
            var list = new List<string>();
            if (string.IsNullOrEmpty(target)) return list;
            string file = Path.GetFileName(target);
            if (file.Equals("Update.exe", StringComparison.OrdinalIgnoreCase) && args != null)
            {
                var m = Regex.Match(args, "--processStart\\s+\"?([^\"\\s]+)", RegexOptions.IgnoreCase);
                if (m.Success) { list.Add(Path.GetFileNameWithoutExtension(m.Groups[1].Value)); return list; }
            }
            if (target.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) list.Add(Path.GetFileNameWithoutExtension(target));
            return list;
        }
    }

    static class IconUtil
    {
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern int SHDefExtractIcon(string file, int index, uint flags, out IntPtr large, out IntPtr small, uint size);
        [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr h);
        [DllImport("user32.dll")] static extern bool GetIconInfo(IntPtr h, out ICONINFO info);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);
        [DllImport("gdi32.dll")] static extern int GetObject(IntPtr h, int size, out BITMAP bm);
        [DllImport("gdi32.dll")] static extern int GetDIBits(IntPtr hdc, IntPtr hbm, uint start, uint lines, byte[] bits, ref BITMAPINFOHEADER bmi, uint usage);
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);

        [StructLayout(LayoutKind.Sequential)]
        struct ICONINFO { public int fIcon; public int xHotspot; public int yHotspot; public IntPtr hbmMask; public IntPtr hbmColor; }

        [StructLayout(LayoutKind.Sequential)]
        struct BITMAP { public int bmType; public int bmWidth; public int bmHeight; public int bmWidthBytes; public ushort bmPlanes; public ushort bmBitsPixel; public IntPtr bmBits; }

        [StructLayout(LayoutKind.Sequential)]
        struct BITMAPINFOHEADER
        {
            public uint biSize; public int biWidth; public int biHeight; public ushort biPlanes; public ushort biBitCount;
            public uint biCompression; public uint biSizeImage; public int biXPelsPerMeter; public int biYPelsPerMeter;
            public uint biClrUsed; public uint biClrImportant;
        }

        public static byte[] Extract(string path, int index)
        {
            if (path.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
            {
                try { using (var ic = new Icon(path, 256, 256)) using (var bmp = ic.ToBitmap()) return Png(bmp); }
                catch { }
            }
            IntPtr large, small;
            if (SHDefExtractIcon(path, index, 0, out large, out small, 128 | (16u << 16)) == 0 && large != IntPtr.Zero)
            {
                try { using (var bmp = ToBitmap(large)) return Png(bmp); }
                finally
                {
                    DestroyIcon(large);
                    if (small != IntPtr.Zero) DestroyIcon(small);
                }
            }
            return Associated(path);
        }

        public static byte[] Associated(string path)
        {
            try
            {
                using (var ic = Icon.ExtractAssociatedIcon(path))
                    if (ic != null) using (var bmp = ic.ToBitmap()) return Png(bmp);
            }
            catch { }
            return null;
        }

        static byte[] Png(Bitmap b)
        {
            using (var ms = new MemoryStream()) { b.Save(ms, ImageFormat.Png); return ms.ToArray(); }
        }

        // Reads the colour bitmap directly so 32-bit alpha survives (Icon.ToBitmap can lose it for HICONs).
        static Bitmap ToBitmap(IntPtr hIcon)
        {
            ICONINFO ii;
            if (!GetIconInfo(hIcon, out ii)) return Icon.FromHandle(hIcon).ToBitmap();
            try
            {
                if (ii.hbmColor == IntPtr.Zero) return Icon.FromHandle(hIcon).ToBitmap();
                BITMAP bm;
                GetObject(ii.hbmColor, Marshal.SizeOf(typeof(BITMAP)), out bm);
                int w = bm.bmWidth, h = bm.bmHeight;
                var bmi = new BITMAPINFOHEADER { biSize = 40, biWidth = w, biHeight = -h, biPlanes = 1, biBitCount = 32 };
                var bits = new byte[w * h * 4];
                IntPtr dc = GetDC(IntPtr.Zero);
                GetDIBits(dc, ii.hbmColor, 0, (uint)h, bits, ref bmi, 0);
                ReleaseDC(IntPtr.Zero, dc);

                bool hasAlpha = false;
                for (int i = 3; i < bits.Length; i += 4) if (bits[i] != 0) { hasAlpha = true; break; }
                if (!hasAlpha) return Icon.FromHandle(hIcon).ToBitmap();

                var bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
                var data = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
                Marshal.Copy(bits, 0, data.Scan0, bits.Length);
                bmp.UnlockBits(data);
                return bmp;
            }
            finally
            {
                if (ii.hbmColor != IntPtr.Zero) DeleteObject(ii.hbmColor);
                if (ii.hbmMask != IntPtr.Zero) DeleteObject(ii.hbmMask);
            }
        }
    }
}
