using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace PCRemote
{
    // Spotify Web API (official): volume inside Spotify, like, playlists, search, queue, devices.
    // Login uses PKCE with the user's own Client ID, so no secret is stored.
    static class SpotifyApi
    {
        const string Scopes = "user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private " +
                              "playlist-read-collaborative user-library-read user-library-modify user-read-recently-played";
        static readonly object L = new object();
        static string path, clientId, refresh, access, userName, userId, verifier, oauthState;
        static DateTime expires = DateTime.MinValue;
        static readonly Dictionary<string, bool> liked = new Dictionary<string, bool>();

        public static string Redirect { get { return "http://127.0.0.1:" + Program.Cfg.Port + "/spotify/callback"; } }
        public static bool Connected { get { return !string.IsNullOrEmpty(refresh); } }

        public static void Init(string p)
        {
            path = p;
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            ServicePointManager.Expect100Continue = false;
            try
            {
                if (!File.Exists(p)) return;
                var d = J.Obj(File.ReadAllText(p));
                clientId = J.Str(d, "clientId");
                refresh = J.Str(d, "refresh");
                userName = J.Str(d, "user");
                userId = J.Str(d, "userId");
            }
            catch (Exception ex) { Log.Write("spotify load: " + ex.Message); }
        }

        static void Save()
        {
            try
            {
                Store.Write(path, J.Ser(new Dictionary<string, object> {
                    { "clientId", clientId }, { "refresh", refresh }, { "user", userName }, { "userId", userId } }));
            }
            catch (Exception ex) { Log.Write("spotify save: " + ex.Message); }
        }

        public static object Status()
        {
            return new Dictionary<string, object> {
                { "connected", Connected }, { "user", userName }, { "clientId", clientId ?? "" }, { "redirect", Redirect } };
        }

        static string E(string s) { return Uri.EscapeDataString(s ?? ""); }

        static string B64Url(byte[] b) { return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }

        static string RandomUrl(int bytes)
        {
            var b = new byte[bytes];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            return B64Url(b);
        }

        public static string BeginLogin(string cid)
        {
            lock (L)
            {
                if (!string.IsNullOrWhiteSpace(cid)) clientId = cid.Trim();
                if (string.IsNullOrEmpty(clientId)) throw new ArgumentException("Bitte zuerst die Client ID eintragen");
                if (clientId.Length < 20) throw new ArgumentException("Die Client ID sieht nicht richtig aus (32 Zeichen)");
                Save();
                verifier = RandomUrl(48);
                oauthState = RandomUrl(16);
                string challenge;
                using (var sha = SHA256.Create()) challenge = B64Url(sha.ComputeHash(Encoding.ASCII.GetBytes(verifier)));
                return "https://accounts.spotify.com/authorize?response_type=code&client_id=" + E(clientId) + "&scope=" + E(Scopes) +
                       "&redirect_uri=" + E(Redirect) + "&code_challenge_method=S256&code_challenge=" + challenge + "&state=" + oauthState;
            }
        }

        public static void Logout()
        {
            lock (L)
            {
                refresh = access = userName = userId = null;
                liked.Clear();
                Save();
            }
        }

        public static string Callback(string code, string st, string err)
        {
            if (!string.IsNullOrEmpty(err)) return Page("Abgebrochen", "Spotify meldet: " + err);
            if (string.IsNullOrEmpty(code) || st == null || st != oauthState) return Page("Ungültige Anfrage", "Bitte in PC Remote noch einmal auf „Mit Spotify verbinden“ tippen.");
            try
            {
                lock (L)
                {
                    Apply(TokenRequest("grant_type=authorization_code&code=" + E(code) + "&redirect_uri=" + E(Redirect) +
                                       "&client_id=" + E(clientId) + "&code_verifier=" + E(verifier)));
                    oauthState = null;
                }
                var me = Call("GET", "/me", null) as Dictionary<string, object>;
                userName = J.Str(me, "display_name") ?? J.Str(me, "id");
                userId = J.Str(me, "id");
                Save();
                return Page("Spotify ist verbunden ✓", "Angemeldet als " + userName + ". Du kannst dieses Fenster schließen.");
            }
            catch (Exception ex)
            {
                Log.Write("spotify callback: " + ex.Message);
                return Page("Verbindung fehlgeschlagen", ex.Message);
            }
        }

        static string Page(string title, string text)
        {
            return "<!doctype html><html lang=de><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>PC Remote</title>" +
                   "<body style='margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#08090d;color:#eef0f7;font:16px system-ui,Segoe UI,sans-serif;text-align:center'>" +
                   "<div style='max-width:420px;padding:24px'><h1 style='font-size:24px'>" + WebUtility.HtmlEncode(title) + "</h1><p style='color:#8d93a8'>" +
                   WebUtility.HtmlEncode(text) + "</p></div><script>setTimeout(function(){window.close()},4000)</script></body></html>";
        }

        static Dictionary<string, object> TokenRequest(string body)
        {
            var req = (HttpWebRequest)WebRequest.Create("https://accounts.spotify.com/api/token");
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            req.Timeout = 10000;
            byte[] b = Encoding.UTF8.GetBytes(body);
            req.ContentLength = b.Length;
            using (var s = req.GetRequestStream()) s.Write(b, 0, b.Length);
            try
            {
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
                    return J.Obj(sr.ReadToEnd());
            }
            catch (WebException ex)
            {
                var r = ex.Response as HttpWebResponse;
                if (r == null) throw new InvalidOperationException("Spotify nicht erreichbar – hat der PC Internet?");
                string txt;
                using (var sr = new StreamReader(r.GetResponseStream(), Encoding.UTF8)) txt = sr.ReadToEnd();
                var d = J.Obj(txt);
                string e = J.Str(d, "error", ""), desc = J.Str(d, "error_description", txt);
                if (e == "invalid_grant") { refresh = null; Save(); throw new InvalidOperationException("Spotify-Anmeldung abgelaufen – bitte neu verbinden"); }
                if (e == "invalid_client") throw new InvalidOperationException("Client ID ungültig – bitte im Spotify-Dashboard prüfen");
                throw new InvalidOperationException("Spotify: " + desc);
            }
        }

        static void Apply(Dictionary<string, object> d)
        {
            access = J.Str(d, "access_token");
            expires = DateTime.UtcNow.AddSeconds(J.Num(d, "expires_in", 3600) - 60);
            string r = J.Str(d, "refresh_token");
            if (!string.IsNullOrEmpty(r)) refresh = r;
        }

        static string Token()
        {
            lock (L)
            {
                if (string.IsNullOrEmpty(refresh)) throw new InvalidOperationException("Spotify ist nicht verbunden");
                if (access != null && DateTime.UtcNow < expires) return access;
                Apply(TokenRequest("grant_type=refresh_token&refresh_token=" + E(refresh) + "&client_id=" + E(clientId)));
                Save();
                return access;
            }
        }

        // after a 429 Spotify says how long to wait; asking again earlier only makes the block longer
        static DateTime backoffUntil = DateTime.MinValue;
        public static bool Blocked { get { return DateTime.UtcNow < backoffUntil; } }

        // ---------- protection: Spotify must never block this app again ----------
        // Once (24.10.2026) too many requests got the app blocked for ~23 h. Now there are hard limits: every request
        // counts, at most 20 per 30 s; background reads (state, devices, liked) only while fewer than 6 went out in the
        // last 30 s. Playback commands don't need Spotify's servers at all while the app runs on this PC (see Do).
        const int MaxPer30 = 20, BgPer30 = 6;
        static readonly Queue<DateTime> sent = new Queue<DateTime>();
        [ThreadStatic] static bool background;

        class LimitException : InvalidOperationException { public LimitException(string m) : base(m) { } }

        static void Budget()
        {
            lock (sent)
            {
                var cut = DateTime.UtcNow.AddSeconds(-30);
                while (sent.Count > 0 && sent.Peek() < cut) sent.Dequeue();
                if (sent.Count >= (background ? BgPer30 : MaxPer30))
                    throw new LimitException(background ? "Spotify: kurze Pause" : "Spotify: gerade sehr viele Befehle – kurz warten (Schutz vor einer Spotify-Sperre)");
                sent.Enqueue(DateTime.UtcNow);
            }
        }

        public static object Call(string method, string pathQ, object body)
        {
            int wait = (int)Math.Ceiling((backoffUntil - DateTime.UtcNow).TotalSeconds);
            if (wait > 0) throw new LimitException("Spotify pausiert die Extras noch " + (wait > 90 ? (wait + 59) / 60 + " Min." : wait + " s") + " – Play, Pause und Weiter gehen trotzdem");
            for (int attempt = 0; ; attempt++)
            {
                Budget();
                var req = (HttpWebRequest)WebRequest.Create("https://api.spotify.com/v1" + pathQ);
                req.Method = method;
                req.Timeout = 10000;
                req.Headers["Authorization"] = "Bearer " + Token();
                if (method != "GET")
                {
                    byte[] b = body == null ? new byte[0] : Encoding.UTF8.GetBytes(J.Ser(body));
                    req.ContentType = "application/json";
                    req.ContentLength = b.Length;
                    if (b.Length > 0) using (var s = req.GetRequestStream()) s.Write(b, 0, b.Length);
                }
                try
                {
                    using (var res = (HttpWebResponse)req.GetResponse())
                    using (var sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
                    {
                        string txt = sr.ReadToEnd();
                        if ((int)res.StatusCode == 204 || txt.Trim().Length == 0) return null;
                        try { return J.Parse(txt); } catch { return null; }
                    }
                }
                catch (WebException ex)
                {
                    var r = ex.Response as HttpWebResponse;
                    if (r == null) throw new InvalidOperationException("Spotify nicht erreichbar – hat der PC Internet?");
                    int code = (int)r.StatusCode;
                    string txt;
                    using (var sr = new StreamReader(r.GetResponseStream(), Encoding.UTF8)) txt = sr.ReadToEnd();
                    if (code == 401 && attempt == 0) { lock (L) access = null; continue; }
                    string msg = txt, reason = "";
                    try
                    {
                        var err = J.Obj(txt);
                        object eo;
                        if (err.TryGetValue("error", out eo) && eo is Dictionary<string, object>)
                        {
                            msg = J.Str((Dictionary<string, object>)eo, "message", txt);
                            reason = J.Str((Dictionary<string, object>)eo, "reason", "");
                        }
                    }
                    catch { }
                    if (code == 404 || reason == "NO_ACTIVE_DEVICE") throw new InvalidOperationException("Kein aktives Spotify-Gerät – starte die Wiedergabe kurz in Spotify");
                    if (reason == "PREMIUM_REQUIRED") throw new InvalidOperationException("Dafür braucht Spotify ein Premium-Konto");
                    if (code == 429)
                    {
                        int secs;
                        if (!int.TryParse(r.Headers["Retry-After"], out secs) || secs <= 0) secs = 30;
                        backoffUntil = DateTime.UtcNow.AddSeconds(Math.Min(secs, 6 * 3600));
                        Log.Warn("Spotify: zu viele Anfragen – Pause für " + secs + " s");
                        throw new LimitException("Spotify pausiert die Extras " + (secs > 90 ? (secs + 59) / 60 + " Min." : secs + " s") + " – Play, Pause und Weiter gehen trotzdem");
                    }
                    if (code == 403 && msg.IndexOf("restrict", StringComparison.OrdinalIgnoreCase) >= 0) throw new InvalidOperationException("Spotify erlaubt das gerade nicht");
                    throw new InvalidOperationException("Spotify: " + msg);
                }
            }
        }

        // ---------- helpers for compact client objects ----------

        static Dictionary<string, object> D(object o) { return o as Dictionary<string, object>; }

        static IEnumerable<object> Arr(object o)
        {
            var e = o as IEnumerable;
            if (e == null || o is string) yield break;
            foreach (var x in e) if (x != null) yield return x;
        }

        static string Image(object images, int prefer)
        {
            var list = new List<object>(Arr(images));
            if (list.Count == 0) return null;
            var d = D(list[Math.Min(prefer, list.Count - 1)]);
            return J.Str(d, "url");
        }

        static string Artists(object arr)
        {
            var names = new List<string>();
            foreach (var a in Arr(arr)) names.Add(J.Str(D(a), "name", ""));
            return string.Join(", ", names.ToArray());
        }

        static Dictionary<string, object> Track(Dictionary<string, object> t)
        {
            if (t == null) return null;
            bool episode = J.Str(t, "type") == "episode";
            var album = D(t.ContainsKey("album") ? t["album"] : null);
            var show = D(t.ContainsKey("show") ? t["show"] : null);
            return new Dictionary<string, object> {
                { "id", J.Str(t, "id") }, { "uri", J.Str(t, "uri") }, { "name", J.Str(t, "name", "") },
                { "artists", episode ? J.Str(show, "name", "") : Artists(t.ContainsKey("artists") ? t["artists"] : null) },
                { "album", episode ? "" : J.Str(album, "name", "") }, { "albumUri", J.Str(album, "uri") },
                { "image", episode ? Image(t.ContainsKey("images") ? t["images"] : null, 1) : Image(album != null && album.ContainsKey("images") ? album["images"] : null, 1) },
                { "dur", J.Num(t, "duration_ms") / 1000.0 }, { "episode", episode } };
        }

        static Dictionary<string, object> Ctx(Dictionary<string, object> p, string kind)
        {
            if (p == null) return null;
            int total = 0;
            var tr = D(p.ContainsKey("tracks") ? p["tracks"] : p.ContainsKey("items") ? p["items"] : null);
            if (tr != null) total = (int)J.Num(tr, "total");
            var owner = D(p.ContainsKey("owner") ? p["owner"] : null);
            return new Dictionary<string, object> {
                { "kind", kind }, { "name", J.Str(p, "name", "") }, { "uri", J.Str(p, "uri") }, { "image", Image(p.ContainsKey("images") ? p["images"] : null, 1) },
                { "count", total }, { "owner", J.Str(owner, "display_name", "") }, { "artists", p.ContainsKey("artists") ? Artists(p["artists"]) : "" } };
        }

        static bool likedForbidden; // Spotify doesn't let this app read the liked songs (403) – then don't ask every 30 s again

        static bool? IsLiked(string id)
        {
            if (string.IsNullOrEmpty(id) || likedForbidden) return null;
            lock (liked)
            {
                bool v;
                if (liked.TryGetValue(id, out v)) return v;
            }
            try
            {
                var r = new List<object>(Arr(Call("GET", "/me/tracks/contains?ids=" + E(id), null)));
                bool v = r.Count > 0 && r[0] is bool && (bool)r[0];
                lock (liked) { if (liked.Count > 300) liked.Clear(); liked[id] = v; }
                return v;
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("Forbidden", StringComparison.OrdinalIgnoreCase) >= 0) likedForbidden = true;
                if (backoffUntil <= DateTime.UtcNow) Log.Write("spotify liked: " + ex.Message + (likedForbidden ? " – frage nicht mehr nach" : ""));
                return null;
            }
        }

        // ---------- reads ----------

        static object cachedState;
        static DateTime cachedAt = DateTime.MinValue, lastTry = DateTime.MinValue, refreshAt = DateTime.MaxValue;
        static string cachedSig = "", lastFail;

        // Spotify's own session in Windows (only while the Spotify app runs on this PC): title, playing, position,
        // shuffle, repeat – live and without any request to Spotify. Cached for a moment, phone and PC both poll.
        static Dictionary<string, object> localCache;
        static DateTime localAt = DateTime.MinValue;
        static Dictionary<string, object> LocalSession(bool fresh)
        {
            lock (sent) { if (!fresh && (DateTime.UtcNow - localAt).TotalMilliseconds < 700) return localCache; }
            Dictionary<string, object> found = null;
            try
            {
                foreach (var o in Media.List())
                {
                    var d = D(o);
                    if (d != null && J.Str(d, "proc") == "spotify") { found = d; break; }
                }
            }
            catch { }
            lock (sent) { localCache = found; localAt = DateTime.UtcNow; }
            return found;
        }

        // A playback command through Windows – instant and no request to Spotify. False when that isn't possible here.
        static bool LocalCmd(string cmd, double value)
        {
            try
            {
                if (!Media.Has("spotify")) return false;
                Media.Do("spotify", cmd, value);
                lock (sent) localAt = DateTime.MinValue;
                return true;
            }
            catch { return false; }
        }

        // What the app shows: the live part from Windows (when Spotify runs here) on top of Spotify's own data,
        // which is only fetched every 30 s, after a song change or after a command – never more often.
        public static object StateCached()
        {
            if (!Connected) return Status();
            var loc = LocalSession(false);
            string sig = loc == null ? "" : J.Str(loc, "title", "") + "|" + J.Str(loc, "artist", "");
            Dictionary<string, object> c;
            bool need;
            var now = DateTime.UtcNow;
            lock (liked)
            {
                c = cachedState as Dictionary<string, object>;
                double age = (now - cachedAt).TotalSeconds;
                double ttl = loc != null ? 30 : c != null && J.Bool(c, "idle") ? 30 : 8;
                need = c == null || age > ttl || (sig != cachedSig && age > 3) || now >= refreshAt;
                if ((now - lastTry).TotalSeconds < 3) need = false;
                if (need) lastTry = now;
            }
            if (need && !Blocked)
            {
                try
                {
                    background = true;
                    var s = State(loc != null && J.Str(loc, "title", "") != "") as Dictionary<string, object>;
                    lock (liked) { cachedState = s; cachedAt = DateTime.UtcNow; cachedSig = sig; refreshAt = DateTime.MaxValue; lastFail = null; }
                    c = s;
                }
                catch (Exception ex)
                {
                    if (!(ex is LimitException) && ex.Message != lastFail) { lastFail = ex.Message; Log.Write("spotify state: " + ex.Message); }
                }
                finally { background = false; }
            }
            var res = Overlay(c, loc);
            if (Blocked) res["limited"] = backoffUntil.ToLocalTime().ToString("HH:mm");
            lock (sent) res["calls30"] = sent.Count; // requests to Spotify in the last 30 s (hard limit 20)
            return res;
        }

        static Dictionary<string, object> Overlay(Dictionary<string, object> web, Dictionary<string, object> loc)
        {
            var d = web != null ? new Dictionary<string, object>(web) : new Dictionary<string, object> { { "connected", Connected }, { "user", userName } };
            string title = loc == null ? "" : J.Str(loc, "title", "");
            if (title.Length == 0) return d;
            d["active"] = true;
            d["idle"] = false;
            d["local"] = true;
            d["playing"] = J.Str(loc, "status") == "playing";
            d["progress"] = loc["pos"];
            if (loc["shuffle"] is bool) d["shuffle"] = loc["shuffle"];
            string rep = loc["repeat"] as string;
            if (rep != null) d["repeat"] = rep == "list" ? "context" : rep == "track" ? "track" : "off";
            var t = D(d.ContainsKey("track") ? d["track"] : null);
            if (t == null || !string.Equals(J.Str(t, "name", "").Trim(), title.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                // the song changed since Spotify was last asked: show Windows' info until the next refresh
                d["track"] = new Dictionary<string, object> {
                    { "id", null }, { "uri", null }, { "name", title }, { "artists", J.Str(loc, "artist", "") }, { "album", J.Str(loc, "album", "") },
                    { "albumUri", null }, { "image", null }, { "dur", loc["dur"] }, { "episode", false } };
                d.Remove("liked");
            }
            return d;
        }

        static bool playlistItemsForbidden;
        static List<object> idleDevices;
        static object idleLast;
        static DateTime idleAt = DateTime.MinValue;

        static void Invalidate() { lock (liked) { cachedState = null; idleDevices = null; refreshAt = DateTime.MaxValue; } }
        // after a command that went to Spotify's servers: fetch the result once, a moment later
        static void Soon() { lock (liked) refreshAt = DateTime.UtcNow.AddSeconds(1.5); }

        public static object State() { return State(false); }

        static object State(bool localKnown)
        {
            var d = new Dictionary<string, object> { { "connected", Connected }, { "user", userName } };
            if (!Connected) return d;
            var p = D(Call("GET", "/me/player?additional_types=episode", null));
            if (p == null && localKnown) { d["active"] = false; return d; } // Windows shows the song, no need for more requests
            if (p == null)
            {
                // nothing active right now: still find Spotify (open devices, the app on this PC, the last song)
                // so the deck can resume instead of showing "nothing is playing"
                d["active"] = false;
                d["idle"] = true;
                bool running = SpotifyRunning();
                d["spotifyRunning"] = running;
                // devices and the last song change rarely: ask Spotify for them at most every 30 s
                List<object> devs;
                object last;
                lock (liked)
                {
                    devs = idleDevices; last = idleLast;
                    if (devs != null && (DateTime.UtcNow - idleAt).TotalSeconds > 30) devs = null;
                }
                if (devs == null)
                {
                    devs = DeviceList();
                    last = null;
                    try
                    {
                        var rp = D(Call("GET", "/me/player/recently-played?limit=1", null));
                        foreach (var it in Arr(rp != null && rp.ContainsKey("items") ? rp["items"] : null))
                        {
                            var ri = D(it);
                            last = Track(D(ri != null && ri.ContainsKey("track") ? ri["track"] : null));
                            break;
                        }
                    }
                    catch { }
                    lock (liked) { idleDevices = devs; idleLast = last; idleAt = DateTime.UtcNow; }
                }
                d["devices"] = devs;
                d["canResume"] = running || devs.Count > 0;
                if (last != null) d["lastTrack"] = last;
                return d;
            }
            d["active"] = true;
            d["playing"] = J.Bool(p, "is_playing");
            d["shuffle"] = J.Bool(p, "shuffle_state");
            d["repeat"] = J.Str(p, "repeat_state", "off");
            d["progress"] = J.Num(p, "progress_ms") / 1000.0;
            var dev = D(p.ContainsKey("device") ? p["device"] : null);
            if (dev != null)
                d["device"] = new Dictionary<string, object> {
                    { "id", J.Str(dev, "id") }, { "name", J.Str(dev, "name", "") }, { "type", J.Str(dev, "type", "") },
                    { "volume", dev.ContainsKey("volume_percent") ? dev["volume_percent"] : null }, { "canVolume", J.Bool(dev, "supports_volume", true) } };
            var item = Track(D(p.ContainsKey("item") ? p["item"] : null));
            d["track"] = item;
            if (item != null && !(bool)item["episode"]) d["liked"] = IsLiked((string)item["id"]);
            var ctx = D(p.ContainsKey("context") ? p["context"] : null);
            if (ctx != null) d["context"] = J.Str(ctx, "uri");
            return d;
        }

        public static object Get(string what, string q)
        {
            switch (what)
            {
                case "status": return Status();
                case "state": return StateCached();
                case "playlists":
                    {
                        var list = new List<object>();
                        if (!string.IsNullOrEmpty(userId))
                            list.Add(new Dictionary<string, object> { { "kind", "liked" }, { "name", "Lieblingssongs" }, { "uri", "spotify:user:" + userId + ":collection" }, { "image", null }, { "count", 0 }, { "owner", userName } });
                        var r = D(Call("GET", "/me/playlists?limit=50", null));
                        foreach (var x in Arr(r != null && r.ContainsKey("items") ? r["items"] : null)) list.Add(Ctx(D(x), "playlist"));
                        return list;
                    }
                case "search":
                    {
                        if (string.IsNullOrWhiteSpace(q)) return new Dictionary<string, object>();
                        var r = D(Call("GET", "/search?type=track,artist,album,playlist&limit=8&q=" + E(q), null)) ?? new Dictionary<string, object>();
                        var res = new Dictionary<string, object>();
                        res["tracks"] = Items(r, "tracks", x => Track(x));
                        res["artists"] = Items(r, "artists", x => new Dictionary<string, object> { { "kind", "artist" }, { "name", J.Str(x, "name", "") }, { "uri", J.Str(x, "uri") }, { "image", Image(x.ContainsKey("images") ? x["images"] : null, 1) } });
                        res["albums"] = Items(r, "albums", x => Ctx(x, "album"));
                        res["playlists"] = Items(r, "playlists", x => Ctx(x, "playlist"));
                        return res;
                    }
                case "first":
                    {
                        // first song of a playlist / album / Lieblingssongs (shown in the deck tile editor)
                        string uri = q ?? "";
                        Dictionary<string, object> r = null;
                        if (uri.EndsWith(":collection")) r = D(Call("GET", "/me/tracks?limit=1", null));
                        else if (uri.StartsWith("spotify:playlist:"))
                        {
                            // Spotify doesn't let this kind of app read playlist contents (403) – then don't ask again
                            if (playlistItemsForbidden) return null;
                            string id = E(uri.Substring(17));
                            try { r = D(Call("GET", "/playlists/" + id + "/items?limit=1", null)); }
                            catch (Exception e1)
                            {
                                if (e1 is LimitException) return null;
                                try { r = D(Call("GET", "/playlists/" + id + "/tracks?limit=1", null)); }
                                catch (Exception e2)
                                {
                                    if (e2.Message.IndexOf("Forbidden", StringComparison.OrdinalIgnoreCase) >= 0) playlistItemsForbidden = true;
                                    Log.Write("Spotify erstes Lied: " + e1.Message + " / " + e2.Message);
                                    r = null;
                                }
                            }
                        }
                        else if (uri.StartsWith("spotify:album:")) r = D(Call("GET", "/albums/" + E(uri.Substring(14)) + "/tracks?limit=1", null));
                        else return null;
                        foreach (var x in Arr(r != null && r.ContainsKey("items") ? r["items"] : null))
                        {
                            var it = D(x);
                            if (it == null) continue;
                            if (it.ContainsKey("track") && D(it["track"]) != null) return Track(D(it["track"]));
                            if (it.ContainsKey("item") && D(it["item"]) != null) return Track(D(it["item"]));
                            return Track(it);
                        }
                        return null;
                    }
                case "queue":
                    {
                        var r = D(Call("GET", "/me/player/queue", null));
                        var list = new List<object>();
                        foreach (var x in Arr(r != null && r.ContainsKey("queue") ? r["queue"] : null)) { list.Add(Track(D(x))); if (list.Count >= 25) break; }
                        return new Dictionary<string, object> { { "current", r != null && r.ContainsKey("currently_playing") ? Track(D(r["currently_playing"])) : null }, { "queue", list } };
                    }
                case "devices":
                    {
                        var r = D(Call("GET", "/me/player/devices", null));
                        var list = new List<object>();
                        foreach (var x in Arr(r != null && r.ContainsKey("devices") ? r["devices"] : null))
                        {
                            var dv = D(x);
                            list.Add(new Dictionary<string, object> { { "id", J.Str(dv, "id") }, { "name", J.Str(dv, "name", "") }, { "type", J.Str(dv, "type", "") }, { "active", J.Bool(dv, "is_active") }, { "volume", dv.ContainsKey("volume_percent") ? dv["volume_percent"] : null } });
                        }
                        return list;
                    }
                case "recent":
                    {
                        var r = D(Call("GET", "/me/player/recently-played?limit=30", null));
                        var list = new List<object>();
                        var seen = new HashSet<string>();
                        foreach (var x in Arr(r != null && r.ContainsKey("items") ? r["items"] : null))
                        {
                            var t = Track(D(D(x)["track"]));
                            if (t == null || !seen.Add((string)t["uri"] ?? "")) continue;
                            list.Add(t);
                        }
                        return list;
                    }
            }
            throw new ArgumentException("Unbekannt: " + what);
        }

        static List<object> Items(Dictionary<string, object> r, string key, Func<Dictionary<string, object>, object> map)
        {
            var list = new List<object>();
            var box = D(r.ContainsKey(key) ? r[key] : null);
            foreach (var x in Arr(box != null && box.ContainsKey("items") ? box["items"] : null))
            {
                var d = D(x);
                if (d != null) list.Add(map(d));
            }
            return list;
        }

        // ---------- commands ----------

        public static object Do(Dictionary<string, object> a)
        {
            string cmd = J.Str(a, "cmd", "");
            string dev = J.Str(a, "device");
            string devQ = string.IsNullOrEmpty(dev) ? "" : "device_id=" + E(dev);
            var local = string.IsNullOrEmpty(dev) ? DoLocal(cmd, a) : null;
            if (local != null) return local;
            if (cmd != "volume") Soon();
            switch (cmd)
            {
                case "login":
                    {
                        Invalidate();
                        string url = BeginLogin(J.Str(a, "clientId"));
                        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                        return Msg("Am PC hat sich der Browser geöffnet – bitte dort bei Spotify zustimmen");
                    }
                case "logout": Logout(); Invalidate(); return Msg("Spotify getrennt");
                case "play": case "resume": return PlaySmart(dev);
                case "pause": Call("PUT", "/me/player/pause", null); break;
                case "toggle":
                    {
                        if (Blocked) return PlayWithoutWeb();
                        var p = D(Call("GET", "/me/player", null));
                        if (p != null && J.Bool(p, "is_playing")) { Call("PUT", "/me/player/pause", null); break; }
                        return PlaySmart(dev);
                    }
                case "next": Call("POST", "/me/player/next", null); break;
                case "prev": Call("POST", "/me/player/previous", null); break;
                case "volume":
                    QueueVolume((int)Math.Round(Math.Max(0, Math.Min(100, J.Num(a, "value")))));
                    break;
                case "volstep":
                case "volup":
                case "voldown":
                    {
                        int cur = KnownVolume();
                        if (cur < 0)
                        {
                            var p = D(Call("GET", "/me/player", null));
                            var d = p == null || !p.ContainsKey("device") ? null : D(p["device"]);
                            if (d == null) throw new InvalidOperationException("Kein aktives Spotify-Gerät");
                            cur = (int)J.Num(d, "volume_percent");
                        }
                        double step = cmd == "volstep" ? J.Num(a, "value", 10) : (cmd == "voldown" ? -1 : 1) * Math.Abs(J.Num(a, "value", 10));
                        int v = (int)Math.Max(0, Math.Min(100, cur + step));
                        QueueVolume(v);
                        return new Dictionary<string, object> { { "ok", true }, { "msg", "Spotify " + v + " %" } };
                    }
                case "seek": Call("PUT", "/me/player/seek?position_ms=" + (long)(Math.Max(0, J.Num(a, "value")) * 1000), null); break;
                case "shuffle":
                    {
                        bool on;
                        if (J.Has(a, "value")) on = J.Bool(a, "value");
                        else { var p = D(Call("GET", "/me/player", null)); on = p == null || !J.Bool(p, "shuffle_state"); }
                        Call("PUT", "/me/player/shuffle?state=" + (on ? "true" : "false"), null);
                        return new Dictionary<string, object> { { "ok", true }, { "value", on } };
                    }
                case "repeat":
                    {
                        string st = J.Str(a, "value");
                        if (string.IsNullOrEmpty(st))
                        {
                            var p = D(Call("GET", "/me/player", null));
                            string cur = p == null ? "off" : J.Str(p, "repeat_state", "off");
                            st = cur == "off" ? "context" : cur == "context" ? "track" : "off";
                        }
                        Call("PUT", "/me/player/repeat?state=" + E(st), null);
                        return new Dictionary<string, object> { { "ok", true }, { "value", st } };
                    }
                case "like":
                    {
                        string id = J.Str(a, "id");
                        if (string.IsNullOrEmpty(id)) id = CachedTrackId();
                        if (string.IsNullOrEmpty(id))
                        {
                            var p = D(Call("GET", "/me/player/currently-playing", null));
                            var t = p == null || !p.ContainsKey("item") ? null : D(p["item"]);
                            id = J.Str(t, "id");
                        }
                        if (string.IsNullOrEmpty(id)) throw new InvalidOperationException("Gerade läuft kein Song");
                        bool on;
                        if (J.Has(a, "value")) on = J.Bool(a, "value");
                        else { bool? cur = IsLiked(id); on = !(cur ?? false); }
                        Call(on ? "PUT" : "DELETE", "/me/tracks?ids=" + E(id), null);
                        lock (liked) liked[id] = on;
                        return new Dictionary<string, object> { { "ok", true }, { "value", on }, { "msg", on ? "Zu Lieblingssongs hinzugefügt" : "Aus Lieblingssongs entfernt" } };
                    }
                case "playUri":
                    {
                        string uri = J.Str(a, "uri", ""), ctx = J.Str(a, "context");
                        object body;
                        if (uri.StartsWith("spotify:track:") || uri.StartsWith("spotify:episode:"))
                            body = string.IsNullOrEmpty(ctx)
                                ? (object)new Dictionary<string, object> { { "uris", new[] { uri } } }
                                : new Dictionary<string, object> { { "context_uri", ctx }, { "offset", new Dictionary<string, object> { { "uri", uri } } } };
                        else body = new Dictionary<string, object> { { "context_uri", uri } };
                        Call("PUT", "/me/player/play" + Q(EnsureDeviceQuery(devQ)), body);
                        break;
                    }
                case "playlist":
                    {
                        // a playlist tile on the deck: always from the very first song at 0:00
                        string uri = J.Str(a, "uri", "");
                        if (string.IsNullOrEmpty(uri)) throw new ArgumentException("Keine Playlist angegeben");
                        if (Blocked)
                        {
                            // Spotify's servers are paused for this app: at least open the playlist in the Spotify app
                            Process.Start(new ProcessStartInfo(uri.EndsWith(":collection") ? "spotify:collection:tracks" : uri) { UseShellExecute = true });
                            return Msg("Spotify pausiert die Extras bis " + backoffUntil.ToLocalTime().ToString("HH:mm") + " – die Playlist ist in Spotify geöffnet, dort auf Play tippen");
                        }
                        string q = EnsureDeviceQuery(devQ);
                        Call("PUT", "/me/player/play" + Q(q), new Dictionary<string, object> {
                            { "context_uri", uri }, { "offset", new Dictionary<string, object> { { "position", 0 } } }, { "position_ms", 0 } });
                        // keep the order from the top – with shuffle on, Spotify would jump around after the first song
                        if (J.Bool(a, "noShuffle", true))
                        {
                            string sq = "state=false" + (q.Length > 0 ? "&" + q : "");
                            try { Call("PUT", "/me/player/shuffle?" + sq, null); }
                            catch { System.Threading.Thread.Sleep(600); try { Call("PUT", "/me/player/shuffle?" + sq, null); } catch { } }
                        }
                        return Msg("Playlist startet von vorne");
                    }
                case "queue":
                    Call("POST", "/me/player/queue?uri=" + E(J.Str(a, "uri")), null);
                    return Msg("Zur Warteschlange hinzugefügt");
                case "transfer":
                    Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { dev } }, { "play", true } });
                    Invalidate();
                    return Msg("Wiedergabe gewechselt");
                default: throw new ArgumentException("Unbekannter Spotify-Befehl: " + cmd);
            }
            return new Dictionary<string, object> { { "ok", true } };
        }

        static string Q(string q) { return string.IsNullOrEmpty(q) ? "" : "?" + q; }
        static object Msg(string m) { return new Dictionary<string, object> { { "ok", true }, { "msg", m } }; }

        // Play/pause/next/prev/seek/shuffle/repeat through Windows while Spotify runs on this PC – instant, and
        // without a single request to Spotify (so these keep working even if Spotify ever paused the app). Null = not here.
        static object DoLocal(string cmd, Dictionary<string, object> a)
        {
            switch (cmd)
            {
                case "pause": case "next": case "prev": case "toggle":
                    return LocalCmd(cmd, 0) ? Msg(null) : null;
                case "play": case "resume":
                    {
                        var s = LocalSession(true);
                        return s != null && J.Str(s, "title", "") != "" && LocalCmd("play", 0) ? Msg(null) : null;
                    }
                case "seek":
                    return LocalCmd("seek", Math.Max(0, J.Num(a, "value"))) ? Msg(null) : null;
                case "shuffle":
                    {
                        var s = LocalSession(true);
                        if (s == null || !(s["shuffle"] is bool)) return null;
                        bool on = J.Has(a, "value") ? J.Bool(a, "value") : !(bool)s["shuffle"];
                        return LocalCmd("shuffle", on ? 1 : 0) ? new Dictionary<string, object> { { "ok", true }, { "value", on } } : null;
                    }
                case "repeat":
                    {
                        var s = LocalSession(true);
                        if (s == null || !(s["repeat"] is string)) return null;
                        string st = J.Str(a, "value");
                        if (string.IsNullOrEmpty(st)) { string cur = (string)s["repeat"]; st = cur == "none" ? "context" : cur == "list" ? "track" : "off"; }
                        return LocalCmd("repeat", st == "context" ? 2 : st == "track" ? 1 : 0) ? new Dictionary<string, object> { { "ok", true }, { "value", st } } : null;
                    }
            }
            return null;
        }

        // ---------- volume: a fader sends many values, Spotify gets at most one per second (the last one wins) ----------

        static readonly object VL = new object();
        static int pendingVol = -1, lastVol = -1;
        static DateTime lastVolAt = DateTime.MinValue;
        static bool volBusy;

        static void QueueVolume(int v)
        {
            lock (liked)
            {
                var c = cachedState as Dictionary<string, object>;
                var dv = c == null || !c.ContainsKey("device") ? null : D(c["device"]);
                if (dv != null) dv["volume"] = v; // the app shows the new value right away
            }
            lock (VL)
            {
                pendingVol = v; lastVol = v; lastVolAt = DateTime.UtcNow;
                if (volBusy) return;
                volBusy = true;
            }
            var t = new System.Threading.Thread(() =>
            {
                while (true)
                {
                    int x;
                    lock (VL) { x = pendingVol; pendingVol = -1; if (x < 0) { volBusy = false; return; } }
                    try { Call("PUT", "/me/player/volume?volume_percent=" + x, null); }
                    catch (LimitException)
                    {
                        // paused by Spotify for a long time: turn the Spotify app down in Windows instead; budget full: try again shortly
                        if (Blocked) { try { Audio.SetAppVolume("spotify", x / 100f); } catch { } }
                        else lock (VL) { if (pendingVol < 0) pendingVol = x; }
                    }
                    catch (Exception ex) { Log.Write("spotify volume: " + ex.Message); }
                    System.Threading.Thread.Sleep(1000);
                }
            });
            t.IsBackground = true;
            t.Start();
        }

        // last known Spotify volume without asking Spotify (-1 = unknown)
        static int KnownVolume()
        {
            lock (VL) { if (lastVol >= 0 && (DateTime.UtcNow - lastVolAt).TotalSeconds < 120) return lastVol; }
            lock (liked)
            {
                var c = cachedState as Dictionary<string, object>;
                var dv = c == null || !c.ContainsKey("device") ? null : D(c["device"]);
                if (dv != null && dv["volume"] != null && (DateTime.UtcNow - cachedAt).TotalSeconds < 120) return (int)J.Num(dv, "volume");
            }
            return -1;
        }

        // id of the current song from the last refresh, if Windows still shows the same song
        static string CachedTrackId()
        {
            var shown = StateCached() as Dictionary<string, object>;
            var t = shown == null || !shown.ContainsKey("track") ? null : D(shown["track"]);
            return t == null ? null : J.Str(t, "id");
        }

        // Spotify's servers are paused for this app (or unreachable): start the Spotify app and press play through Windows.
        static object PlayWithoutWeb()
        {
            if (!SpotifyRunning()) OpenSpotify();
            for (int i = 0; i < 16; i++)
            {
                if (LocalCmd("play", 0)) return Msg("Wiedergabe gestartet");
                System.Threading.Thread.Sleep(500);
            }
            Input.Tap((ushort)0xB3);
            return Msg("Spotify geöffnet – Play gedrückt");
        }

        // ---------- find Spotify even when nothing is actively playing ----------

        static bool SpotifyRunning() { try { return Process.GetProcessesByName("Spotify").Length > 0; } catch { return false; } }

        static List<object> DeviceList()
        {
            var list = new List<object>();
            var r = D(Call("GET", "/me/player/devices", null));
            foreach (var x in Arr(r != null && r.ContainsKey("devices") ? r["devices"] : null))
            {
                var dv = D(x);
                if (dv == null) continue;
                list.Add(new Dictionary<string, object> {
                    { "id", J.Str(dv, "id") }, { "name", J.Str(dv, "name", "") }, { "type", J.Str(dv, "type", "") },
                    { "active", J.Bool(dv, "is_active") }, { "restricted", J.Bool(dv, "is_restricted") },
                    { "volume", dv.ContainsKey("volume_percent") ? dv["volume_percent"] : null } });
            }
            return list;
        }

        // Where to resume when nothing is active: this PC's own Spotify first, then the active one, then any computer.
        static string BestDeviceId(List<object> devs)
        {
            if (devs == null) return null;
            string self = null, active = null, comp = null, any = null;
            foreach (var o in devs)
            {
                var x = D(o);
                if (x == null || J.Bool(x, "restricted")) continue;
                string id = J.Str(x, "id");
                if (string.IsNullOrEmpty(id)) continue;
                if (any == null) any = id;
                if (comp == null && J.Str(x, "type") == "Computer") comp = id;
                if (active == null && J.Bool(x, "active")) active = id;
                if (self == null && string.Equals(J.Str(x, "name"), Environment.MachineName, StringComparison.OrdinalIgnoreCase)) self = id;
            }
            return self ?? active ?? comp ?? any;
        }

        // Device part of a play call: the given device, nothing when one is already active,
        // else the best available one (opening the Spotify app and waiting for it if needed).
        static string EnsureDeviceQuery(string devQ)
        {
            if (!string.IsNullOrEmpty(devQ)) return devQ;
            if (D(Call("GET", "/me/player", null)) != null) return "";
            string best = BestDeviceId(DeviceList());
            if (best == null) { OpenSpotify(); for (int i = 0; i < 8 && best == null; i++) { System.Threading.Thread.Sleep(1000); best = BestDeviceId(DeviceList()); } }
            return best != null ? "device_id=" + E(best) : "";
        }

        static void OpenSpotify()
        {
            try { Process.Start(new ProcessStartInfo("spotify:") { UseShellExecute = true }); }
            catch { try { Process.Start(new ProcessStartInfo("spotify") { UseShellExecute = true }); } catch { } }
        }

        // Start/resume even when nothing is active: resume the active device, else the best available device
        // (opening the Spotify app and waiting for it to appear if needed), else nudge the desktop with the media key.
        static object PlaySmart(string dev)
        {
            if (Blocked) return PlayWithoutWeb();
            try { return PlayWeb(dev); }
            catch (LimitException) { return PlayWithoutWeb(); }
        }

        static object PlayWeb(string dev)
        {
            if (!string.IsNullOrEmpty(dev)) { Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { dev } }, { "play", true } }); return Msg("Wiedergabe gestartet"); }
            if (D(Call("GET", "/me/player", null)) != null) { Call("PUT", "/me/player/play", null); return new Dictionary<string, object> { { "ok", true } }; }

            string best = BestDeviceId(DeviceList());
            if (best == null)
            {
                OpenSpotify();
                for (int i = 0; i < 8 && best == null; i++) { System.Threading.Thread.Sleep(1000); best = BestDeviceId(DeviceList()); }
            }
            if (best == null) { Input.Tap((ushort)0xB3); return Msg("Spotify wird geöffnet – falls nichts startet, kurz warten und erneut auf Play tippen"); }

            try { Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { best } }, { "play", true } }); return Msg("Wiedergabe gestartet"); }
            catch
            {
                // a fresh device may have nothing queued: start the most recently played context/track
                try
                {
                    var rp = D(Call("GET", "/me/player/recently-played?limit=1", null));
                    foreach (var it in Arr(rp != null && rp.ContainsKey("items") ? rp["items"] : null))
                    {
                        var item = D(it);
                        var ctx = D(item != null && item.ContainsKey("context") ? item["context"] : null);
                        var tr = D(item != null && item.ContainsKey("track") ? item["track"] : null);
                        object pbody = ctx != null ? (object)new Dictionary<string, object> { { "context_uri", J.Str(ctx, "uri") } }
                            : tr != null ? new Dictionary<string, object> { { "uris", new[] { J.Str(tr, "uri") } } } : null;
                        Call("PUT", "/me/player/play?device_id=" + E(best), pbody);
                        return Msg("Letzte Wiedergabe fortgesetzt");
                    }
                }
                catch { }
                Call("PUT", "/me/player/play?device_id=" + E(best), null);
                return new Dictionary<string, object> { { "ok", true } };
            }
        }
    }
}
