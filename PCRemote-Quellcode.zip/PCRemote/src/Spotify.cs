using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace PCRemote
{
    // Spotify Web API (official): volume inside Spotify, like, playlists, search, queue, devices.
    // Login uses PKCE with the user's own Client ID, so no secret is stored.
    static class SpotifyApi
    {
        const string Scopes = "user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private " +
                              "playlist-read-collaborative user-library-read user-library-modify user-read-recently-played";
        static readonly object L = new object();
        static string path, clientId, refresh, access, userName, userId, verifier, oauthState;
        static DateTime expires = DateTime.MinValue;
        static readonly Dictionary<string, bool> liked = new Dictionary<string, bool>();

        public static string Redirect { get { return "http://127.0.0.1:" + Program.Cfg.Port + "/spotify/callback"; } }
        public static bool Connected { get { return !string.IsNullOrEmpty(refresh); } }

        public static void Init(string p)
        {
            path = p;
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            ServicePointManager.Expect100Continue = false;
            try
            {
                if (!File.Exists(p)) return;
                var d = J.Obj(File.ReadAllText(p));
                clientId = J.Str(d, "clientId");
                refresh = J.Str(d, "refresh");
                userName = J.Str(d, "user");
                userId = J.Str(d, "userId");
            }
            catch (Exception ex) { Log.Write("spotify load: " + ex.Message); }
        }

        static void Save()
        {
            try
            {
                Store.Write(path, J.Ser(new Dictionary<string, object> {
                    { "clientId", clientId }, { "refresh", refresh }, { "user", userName }, { "userId", userId } }));
            }
            catch (Exception ex) { Log.Write("spotify save: " + ex.Message); }
        }

        public static object Status()
        {
            return new Dictionary<string, object> {
                { "connected", Connected }, { "user", userName }, { "clientId", clientId ?? "" }, { "redirect", Redirect } };
        }

        static string E(string s) { return Uri.EscapeDataString(s ?? ""); }

        static string B64Url(byte[] b) { return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }

        static string RandomUrl(int bytes)
        {
            var b = new byte[bytes];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            return B64Url(b);
        }

        public static string BeginLogin(string cid)
        {
            lock (L)
            {
                if (!string.IsNullOrWhiteSpace(cid)) clientId = cid.Trim();
                if (string.IsNullOrEmpty(clientId)) throw new ArgumentException("Bitte zuerst die Client ID eintragen");
                if (clientId.Length < 20) throw new ArgumentException("Die Client ID sieht nicht richtig aus (32 Zeichen)");
                Save();
                verifier = RandomUrl(48);
                oauthState = RandomUrl(16);
                string challenge;
                using (var sha = SHA256.Create()) challenge = B64Url(sha.ComputeHash(Encoding.ASCII.GetBytes(verifier)));
                return "https://accounts.spotify.com/authorize?response_type=code&client_id=" + E(clientId) + "&scope=" + E(Scopes) +
                       "&redirect_uri=" + E(Redirect) + "&code_challenge_method=S256&code_challenge=" + challenge + "&state=" + oauthState;
            }
        }

        public static void Logout()
        {
            lock (L)
            {
                refresh = access = userName = userId = null;
                liked.Clear();
                Save();
            }
        }

        public static string Callback(string code, string st, string err)
        {
            if (!string.IsNullOrEmpty(err)) return Page("Abgebrochen", "Spotify meldet: " + err);
            if (string.IsNullOrEmpty(code) || st == null || st != oauthState) return Page("Ungültige Anfrage", "Bitte in PC Remote noch einmal auf „Mit Spotify verbinden“ tippen.");
            try
            {
                lock (L)
                {
                    Apply(TokenRequest("grant_type=authorization_code&code=" + E(code) + "&redirect_uri=" + E(Redirect) +
                                       "&client_id=" + E(clientId) + "&code_verifier=" + E(verifier)));
                    oauthState = null;
                }
                var me = Call("GET", "/me", null) as Dictionary<string, object>;
                userName = J.Str(me, "display_name") ?? J.Str(me, "id");
                userId = J.Str(me, "id");
                Save();
                return Page("Spotify ist verbunden ✓", "Angemeldet als " + userName + ". Du kannst dieses Fenster schließen.");
            }
            catch (Exception ex)
            {
                Log.Write("spotify callback: " + ex.Message);
                return Page("Verbindung fehlgeschlagen", ex.Message);
            }
        }

        static string Page(string title, string text)
        {
            return "<!doctype html><html lang=de><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>PC Remote</title>" +
                   "<body style='margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#08090d;color:#eef0f7;font:16px system-ui,Segoe UI,sans-serif;text-align:center'>" +
                   "<div style='max-width:420px;padding:24px'><h1 style='font-size:24px'>" + WebUtility.HtmlEncode(title) + "</h1><p style='color:#8d93a8'>" +
                   WebUtility.HtmlEncode(text) + "</p></div><script>setTimeout(function(){window.close()},4000)</script></body></html>";
        }

        static Dictionary<string, object> TokenRequest(string body)
        {
            var req = (HttpWebRequest)WebRequest.Create("https://accounts.spotify.com/api/token");
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            req.Timeout = 10000;
            byte[] b = Encoding.UTF8.GetBytes(body);
            req.ContentLength = b.Length;
            using (var s = req.GetRequestStream()) s.Write(b, 0, b.Length);
            try
            {
                using (var res = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
                    return J.Obj(sr.ReadToEnd());
            }
            catch (WebException ex)
            {
                var r = ex.Response as HttpWebResponse;
                if (r == null) throw new InvalidOperationException("Spotify nicht erreichbar – hat der PC Internet?");
                string txt;
                using (var sr = new StreamReader(r.GetResponseStream(), Encoding.UTF8)) txt = sr.ReadToEnd();
                var d = J.Obj(txt);
                string e = J.Str(d, "error", ""), desc = J.Str(d, "error_description", txt);
                if (e == "invalid_grant") { refresh = null; Save(); throw new InvalidOperationException("Spotify-Anmeldung abgelaufen – bitte neu verbinden"); }
                if (e == "invalid_client") throw new InvalidOperationException("Client ID ungültig – bitte im Spotify-Dashboard prüfen");
                throw new InvalidOperationException("Spotify: " + desc);
            }
        }

        static void Apply(Dictionary<string, object> d)
        {
            access = J.Str(d, "access_token");
            expires = DateTime.UtcNow.AddSeconds(J.Num(d, "expires_in", 3600) - 60);
            string r = J.Str(d, "refresh_token");
            if (!string.IsNullOrEmpty(r)) refresh = r;
        }

        static string Token()
        {
            lock (L)
            {
                if (string.IsNullOrEmpty(refresh)) throw new InvalidOperationException("Spotify ist nicht verbunden");
                if (access != null && DateTime.UtcNow < expires) return access;
                Apply(TokenRequest("grant_type=refresh_token&refresh_token=" + E(refresh) + "&client_id=" + E(clientId)));
                Save();
                return access;
            }
        }

        public static object Call(string method, string pathQ, object body)
        {
            for (int attempt = 0; ; attempt++)
            {
                var req = (HttpWebRequest)WebRequest.Create("https://api.spotify.com/v1" + pathQ);
                req.Method = method;
                req.Timeout = 10000;
                req.Headers["Authorization"] = "Bearer " + Token();
                if (method != "GET")
                {
                    byte[] b = body == null ? new byte[0] : Encoding.UTF8.GetBytes(J.Ser(body));
                    req.ContentType = "application/json";
                    req.ContentLength = b.Length;
                    if (b.Length > 0) using (var s = req.GetRequestStream()) s.Write(b, 0, b.Length);
                }
                try
                {
                    using (var res = (HttpWebResponse)req.GetResponse())
                    using (var sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
                    {
                        string txt = sr.ReadToEnd();
                        if ((int)res.StatusCode == 204 || txt.Trim().Length == 0) return null;
                        try { return J.Parse(txt); } catch { return null; }
                    }
                }
                catch (WebException ex)
                {
                    var r = ex.Response as HttpWebResponse;
                    if (r == null) throw new InvalidOperationException("Spotify nicht erreichbar – hat der PC Internet?");
                    int code = (int)r.StatusCode;
                    string txt;
                    using (var sr = new StreamReader(r.GetResponseStream(), Encoding.UTF8)) txt = sr.ReadToEnd();
                    if (code == 401 && attempt == 0) { lock (L) access = null; continue; }
                    string msg = txt, reason = "";
                    try
                    {
                        var err = J.Obj(txt);
                        object eo;
                        if (err.TryGetValue("error", out eo) && eo is Dictionary<string, object>)
                        {
                            msg = J.Str((Dictionary<string, object>)eo, "message", txt);
                            reason = J.Str((Dictionary<string, object>)eo, "reason", "");
                        }
                    }
                    catch { }
                    if (code == 404 || reason == "NO_ACTIVE_DEVICE") throw new InvalidOperationException("Kein aktives Spotify-Gerät – starte die Wiedergabe kurz in Spotify");
                    if (reason == "PREMIUM_REQUIRED") throw new InvalidOperationException("Dafür braucht Spotify ein Premium-Konto");
                    if (code == 429) throw new InvalidOperationException("Spotify: zu viele Anfragen – kurz warten");
                    if (code == 403 && msg.IndexOf("restrict", StringComparison.OrdinalIgnoreCase) >= 0) throw new InvalidOperationException("Spotify erlaubt das gerade nicht");
                    throw new InvalidOperationException("Spotify: " + msg);
                }
            }
        }

        // ---------- helpers for compact client objects ----------

        static Dictionary<string, object> D(object o) { return o as Dictionary<string, object>; }

        static IEnumerable<object> Arr(object o)
        {
            var e = o as IEnumerable;
            if (e == null || o is string) yield break;
            foreach (var x in e) if (x != null) yield return x;
        }

        static string Image(object images, int prefer)
        {
            var list = new List<object>(Arr(images));
            if (list.Count == 0) return null;
            var d = D(list[Math.Min(prefer, list.Count - 1)]);
            return J.Str(d, "url");
        }

        static string Artists(object arr)
        {
            var names = new List<string>();
            foreach (var a in Arr(arr)) names.Add(J.Str(D(a), "name", ""));
            return string.Join(", ", names.ToArray());
        }

        static Dictionary<string, object> Track(Dictionary<string, object> t)
        {
            if (t == null) return null;
            bool episode = J.Str(t, "type") == "episode";
            var album = D(t.ContainsKey("album") ? t["album"] : null);
            var show = D(t.ContainsKey("show") ? t["show"] : null);
            return new Dictionary<string, object> {
                { "id", J.Str(t, "id") }, { "uri", J.Str(t, "uri") }, { "name", J.Str(t, "name", "") },
                { "artists", episode ? J.Str(show, "name", "") : Artists(t.ContainsKey("artists") ? t["artists"] : null) },
                { "album", episode ? "" : J.Str(album, "name", "") }, { "albumUri", J.Str(album, "uri") },
                { "image", episode ? Image(t.ContainsKey("images") ? t["images"] : null, 1) : Image(album != null && album.ContainsKey("images") ? album["images"] : null, 1) },
                { "dur", J.Num(t, "duration_ms") / 1000.0 }, { "episode", episode } };
        }

        static Dictionary<string, object> Ctx(Dictionary<string, object> p, string kind)
        {
            if (p == null) return null;
            int total = 0;
            var tr = D(p.ContainsKey("tracks") ? p["tracks"] : p.ContainsKey("items") ? p["items"] : null);
            if (tr != null) total = (int)J.Num(tr, "total");
            var owner = D(p.ContainsKey("owner") ? p["owner"] : null);
            return new Dictionary<string, object> {
                { "kind", kind }, { "name", J.Str(p, "name", "") }, { "uri", J.Str(p, "uri") }, { "image", Image(p.ContainsKey("images") ? p["images"] : null, 1) },
                { "count", total }, { "owner", J.Str(owner, "display_name", "") }, { "artists", p.ContainsKey("artists") ? Artists(p["artists"]) : "" } };
        }

        static bool? IsLiked(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            lock (liked)
            {
                bool v;
                if (liked.TryGetValue(id, out v)) return v;
            }
            try
            {
                var r = new List<object>(Arr(Call("GET", "/me/tracks/contains?ids=" + E(id), null)));
                bool v = r.Count > 0 && r[0] is bool && (bool)r[0];
                lock (liked) { if (liked.Count > 300) liked.Clear(); liked[id] = v; }
                return v;
            }
            catch (Exception ex) { Log.Write("spotify liked: " + ex.Message); return null; }
        }

        // ---------- reads ----------

        static object cachedState;
        static DateTime cachedAt = DateTime.MinValue;

        // Phone and PC window may both poll; one Spotify request per ~0.8 s is plenty.
        public static object StateCached()
        {
            lock (liked)
            {
                if (cachedState != null && (DateTime.UtcNow - cachedAt).TotalMilliseconds < 800) return cachedState;
            }
            var s = State();
            lock (liked) { cachedState = s; cachedAt = DateTime.UtcNow; }
            return s;
        }

        static void Invalidate() { lock (liked) cachedState = null; }

        public static object State()
        {
            var d = new Dictionary<string, object> { { "connected", Connected }, { "user", userName } };
            if (!Connected) return d;
            var p = D(Call("GET", "/me/player?additional_types=episode", null));
            if (p == null)
            {
                // nothing active right now: still find Spotify (open devices, the app on this PC, the last song)
                // so the deck can resume instead of showing "nothing is playing"
                d["active"] = false;
                d["idle"] = true;
                bool running = SpotifyRunning();
                d["spotifyRunning"] = running;
                var devs = DeviceList();
                d["devices"] = devs;
                d["canResume"] = running || devs.Count > 0;
                try
                {
                    var rp = D(Call("GET", "/me/player/recently-played?limit=1", null));
                    foreach (var it in Arr(rp != null && rp.ContainsKey("items") ? rp["items"] : null))
                    {
                        var ri = D(it);
                        d["lastTrack"] = Track(D(ri != null && ri.ContainsKey("track") ? ri["track"] : null));
                        break;
                    }
                }
                catch { }
                return d;
            }
            d["active"] = true;
            d["playing"] = J.Bool(p, "is_playing");
            d["shuffle"] = J.Bool(p, "shuffle_state");
            d["repeat"] = J.Str(p, "repeat_state", "off");
            d["progress"] = J.Num(p, "progress_ms") / 1000.0;
            var dev = D(p.ContainsKey("device") ? p["device"] : null);
            if (dev != null)
                d["device"] = new Dictionary<string, object> {
                    { "id", J.Str(dev, "id") }, { "name", J.Str(dev, "name", "") }, { "type", J.Str(dev, "type", "") },
                    { "volume", dev.ContainsKey("volume_percent") ? dev["volume_percent"] : null }, { "canVolume", J.Bool(dev, "supports_volume", true) } };
            var item = Track(D(p.ContainsKey("item") ? p["item"] : null));
            d["track"] = item;
            if (item != null && !(bool)item["episode"]) d["liked"] = IsLiked((string)item["id"]);
            var ctx = D(p.ContainsKey("context") ? p["context"] : null);
            if (ctx != null) d["context"] = J.Str(ctx, "uri");
            return d;
        }

        public static object Get(string what, string q)
        {
            switch (what)
            {
                case "status": return Status();
                case "state": return State();
                case "playlists":
                    {
                        var list = new List<object>();
                        if (!string.IsNullOrEmpty(userId))
                            list.Add(new Dictionary<string, object> { { "kind", "liked" }, { "name", "Lieblingssongs" }, { "uri", "spotify:user:" + userId + ":collection" }, { "image", null }, { "count", 0 }, { "owner", userName } });
                        var r = D(Call("GET", "/me/playlists?limit=50", null));
                        foreach (var x in Arr(r != null && r.ContainsKey("items") ? r["items"] : null)) list.Add(Ctx(D(x), "playlist"));
                        return list;
                    }
                case "search":
                    {
                        if (string.IsNullOrWhiteSpace(q)) return new Dictionary<string, object>();
                        var r = D(Call("GET", "/search?type=track,artist,album,playlist&limit=8&q=" + E(q), null)) ?? new Dictionary<string, object>();
                        var res = new Dictionary<string, object>();
                        res["tracks"] = Items(r, "tracks", x => Track(x));
                        res["artists"] = Items(r, "artists", x => new Dictionary<string, object> { { "kind", "artist" }, { "name", J.Str(x, "name", "") }, { "uri", J.Str(x, "uri") }, { "image", Image(x.ContainsKey("images") ? x["images"] : null, 1) } });
                        res["albums"] = Items(r, "albums", x => Ctx(x, "album"));
                        res["playlists"] = Items(r, "playlists", x => Ctx(x, "playlist"));
                        return res;
                    }
                case "queue":
                    {
                        var r = D(Call("GET", "/me/player/queue", null));
                        var list = new List<object>();
                        foreach (var x in Arr(r != null && r.ContainsKey("queue") ? r["queue"] : null)) { list.Add(Track(D(x))); if (list.Count >= 25) break; }
                        return new Dictionary<string, object> { { "current", r != null && r.ContainsKey("currently_playing") ? Track(D(r["currently_playing"])) : null }, { "queue", list } };
                    }
                case "devices":
                    {
                        var r = D(Call("GET", "/me/player/devices", null));
                        var list = new List<object>();
                        foreach (var x in Arr(r != null && r.ContainsKey("devices") ? r["devices"] : null))
                        {
                            var dv = D(x);
                            list.Add(new Dictionary<string, object> { { "id", J.Str(dv, "id") }, { "name", J.Str(dv, "name", "") }, { "type", J.Str(dv, "type", "") }, { "active", J.Bool(dv, "is_active") }, { "volume", dv.ContainsKey("volume_percent") ? dv["volume_percent"] : null } });
                        }
                        return list;
                    }
                case "recent":
                    {
                        var r = D(Call("GET", "/me/player/recently-played?limit=30", null));
                        var list = new List<object>();
                        var seen = new HashSet<string>();
                        foreach (var x in Arr(r != null && r.ContainsKey("items") ? r["items"] : null))
                        {
                            var t = Track(D(D(x)["track"]));
                            if (t == null || !seen.Add((string)t["uri"] ?? "")) continue;
                            list.Add(t);
                        }
                        return list;
                    }
            }
            throw new ArgumentException("Unbekannt: " + what);
        }

        static List<object> Items(Dictionary<string, object> r, string key, Func<Dictionary<string, object>, object> map)
        {
            var list = new List<object>();
            var box = D(r.ContainsKey(key) ? r[key] : null);
            foreach (var x in Arr(box != null && box.ContainsKey("items") ? box["items"] : null))
            {
                var d = D(x);
                if (d != null) list.Add(map(d));
            }
            return list;
        }

        // ---------- commands ----------

        public static object Do(Dictionary<string, object> a)
        {
            Invalidate();
            string cmd = J.Str(a, "cmd", "");
            string dev = J.Str(a, "device");
            string devQ = string.IsNullOrEmpty(dev) ? "" : "device_id=" + E(dev);
            switch (cmd)
            {
                case "login":
                    {
                        string url = BeginLogin(J.Str(a, "clientId"));
                        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
                        return Msg("Am PC hat sich der Browser geöffnet – bitte dort bei Spotify zustimmen");
                    }
                case "logout": Logout(); return Msg("Spotify getrennt");
                case "play": case "resume": return PlaySmart(dev);
                case "pause": Call("PUT", "/me/player/pause", null); break;
                case "toggle":
                    {
                        var p = D(Call("GET", "/me/player", null));
                        if (p != null && J.Bool(p, "is_playing")) { Call("PUT", "/me/player/pause", null); break; }
                        return PlaySmart(dev);
                    }
                case "next": Call("POST", "/me/player/next", null); break;
                case "prev": Call("POST", "/me/player/previous", null); break;
                case "volume":
                    {
                        int v = (int)Math.Round(Math.Max(0, Math.Min(100, J.Num(a, "value"))));
                        Call("PUT", "/me/player/volume?volume_percent=" + v, null);
                        break;
                    }
                case "volstep":
                case "volup":
                case "voldown":
                    {
                        var p = D(Call("GET", "/me/player", null));
                        var d = p == null || !p.ContainsKey("device") ? null : D(p["device"]);
                        if (d == null) throw new InvalidOperationException("Kein aktives Spotify-Gerät");
                        double step = cmd == "volstep" ? J.Num(a, "value", 10) : (cmd == "voldown" ? -1 : 1) * Math.Abs(J.Num(a, "value", 10));
                        int v = (int)Math.Max(0, Math.Min(100, J.Num(d, "volume_percent") + step));
                        Call("PUT", "/me/player/volume?volume_percent=" + v, null);
                        return new Dictionary<string, object> { { "ok", true }, { "msg", "Spotify " + v + " %" } };
                    }
                case "seek": Call("PUT", "/me/player/seek?position_ms=" + (long)(Math.Max(0, J.Num(a, "value")) * 1000), null); break;
                case "shuffle":
                    {
                        bool on;
                        if (J.Has(a, "value")) on = J.Bool(a, "value");
                        else { var p = D(Call("GET", "/me/player", null)); on = p == null || !J.Bool(p, "shuffle_state"); }
                        Call("PUT", "/me/player/shuffle?state=" + (on ? "true" : "false"), null);
                        return new Dictionary<string, object> { { "ok", true }, { "value", on } };
                    }
                case "repeat":
                    {
                        string st = J.Str(a, "value");
                        if (string.IsNullOrEmpty(st))
                        {
                            var p = D(Call("GET", "/me/player", null));
                            string cur = p == null ? "off" : J.Str(p, "repeat_state", "off");
                            st = cur == "off" ? "context" : cur == "context" ? "track" : "off";
                        }
                        Call("PUT", "/me/player/repeat?state=" + E(st), null);
                        return new Dictionary<string, object> { { "ok", true }, { "value", st } };
                    }
                case "like":
                    {
                        string id = J.Str(a, "id");
                        if (string.IsNullOrEmpty(id))
                        {
                            var p = D(Call("GET", "/me/player/currently-playing", null));
                            var t = p == null ? null : D(p["item"]);
                            id = J.Str(t, "id");
                        }
                        if (string.IsNullOrEmpty(id)) throw new InvalidOperationException("Gerade läuft kein Song");
                        bool on;
                        if (J.Has(a, "value")) on = J.Bool(a, "value");
                        else { bool? cur = IsLiked(id); on = !(cur ?? false); }
                        Call(on ? "PUT" : "DELETE", "/me/tracks?ids=" + E(id), null);
                        lock (liked) liked[id] = on;
                        return new Dictionary<string, object> { { "ok", true }, { "value", on }, { "msg", on ? "Zu Lieblingssongs hinzugefügt" : "Aus Lieblingssongs entfernt" } };
                    }
                case "playUri":
                    {
                        string uri = J.Str(a, "uri", ""), ctx = J.Str(a, "context");
                        object body;
                        if (uri.StartsWith("spotify:track:") || uri.StartsWith("spotify:episode:"))
                            body = string.IsNullOrEmpty(ctx)
                                ? (object)new Dictionary<string, object> { { "uris", new[] { uri } } }
                                : new Dictionary<string, object> { { "context_uri", ctx }, { "offset", new Dictionary<string, object> { { "uri", uri } } } };
                        else body = new Dictionary<string, object> { { "context_uri", uri } };
                        string q = devQ;
                        // nothing active yet? pick the best device (open Spotify if needed) so the song actually starts
                        if (string.IsNullOrEmpty(q) && D(Call("GET", "/me/player", null)) == null)
                        {
                            string best = BestDeviceId(DeviceList());
                            if (best == null) { OpenSpotify(); for (int i = 0; i < 12 && best == null; i++) { System.Threading.Thread.Sleep(600); best = BestDeviceId(DeviceList()); } }
                            if (best != null) q = "device_id=" + E(best);
                        }
                        Call("PUT", "/me/player/play" + Q(q), body);
                        break;
                    }
                case "queue":
                    Call("POST", "/me/player/queue?uri=" + E(J.Str(a, "uri")), null);
                    return Msg("Zur Warteschlange hinzugefügt");
                case "transfer":
                    Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { dev } }, { "play", true } });
                    return Msg("Wiedergabe gewechselt");
                default: throw new ArgumentException("Unbekannter Spotify-Befehl: " + cmd);
            }
            return new Dictionary<string, object> { { "ok", true } };
        }

        static string Q(string q) { return string.IsNullOrEmpty(q) ? "" : "?" + q; }
        static object Msg(string m) { return new Dictionary<string, object> { { "ok", true }, { "msg", m } }; }

        // ---------- find Spotify even when nothing is actively playing ----------

        static bool SpotifyRunning() { try { return Process.GetProcessesByName("Spotify").Length > 0; } catch { return false; } }

        static List<object> DeviceList()
        {
            var list = new List<object>();
            var r = D(Call("GET", "/me/player/devices", null));
            foreach (var x in Arr(r != null && r.ContainsKey("devices") ? r["devices"] : null))
            {
                var dv = D(x);
                if (dv == null) continue;
                list.Add(new Dictionary<string, object> {
                    { "id", J.Str(dv, "id") }, { "name", J.Str(dv, "name", "") }, { "type", J.Str(dv, "type", "") },
                    { "active", J.Bool(dv, "is_active") }, { "restricted", J.Bool(dv, "is_restricted") },
                    { "volume", dv.ContainsKey("volume_percent") ? dv["volume_percent"] : null } });
            }
            return list;
        }

        // Where to resume when nothing is active: this PC's own Spotify first, then the active one, then any computer.
        static string BestDeviceId(List<object> devs)
        {
            if (devs == null) return null;
            string self = null, active = null, comp = null, any = null;
            foreach (var o in devs)
            {
                var x = D(o);
                if (x == null || J.Bool(x, "restricted")) continue;
                string id = J.Str(x, "id");
                if (string.IsNullOrEmpty(id)) continue;
                if (any == null) any = id;
                if (comp == null && J.Str(x, "type") == "Computer") comp = id;
                if (active == null && J.Bool(x, "active")) active = id;
                if (self == null && string.Equals(J.Str(x, "name"), Environment.MachineName, StringComparison.OrdinalIgnoreCase)) self = id;
            }
            return self ?? active ?? comp ?? any;
        }

        static void OpenSpotify()
        {
            try { Process.Start(new ProcessStartInfo("spotify:") { UseShellExecute = true }); }
            catch { try { Process.Start(new ProcessStartInfo("spotify") { UseShellExecute = true }); } catch { } }
        }

        // Start/resume even when nothing is active: resume the active device, else the best available device
        // (opening the Spotify app and waiting for it to appear if needed), else nudge the desktop with the media key.
        static object PlaySmart(string dev)
        {
            if (!string.IsNullOrEmpty(dev)) { Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { dev } }, { "play", true } }); return Msg("Wiedergabe gestartet"); }
            if (D(Call("GET", "/me/player", null)) != null) { Call("PUT", "/me/player/play", null); return new Dictionary<string, object> { { "ok", true } }; }

            string best = BestDeviceId(DeviceList());
            if (best == null)
            {
                OpenSpotify();
                for (int i = 0; i < 12 && best == null; i++) { System.Threading.Thread.Sleep(600); best = BestDeviceId(DeviceList()); }
            }
            if (best == null) { Input.Tap((ushort)0xB3); return Msg("Spotify wird geöffnet – falls nichts startet, kurz warten und erneut auf Play tippen"); }

            try { Call("PUT", "/me/player", new Dictionary<string, object> { { "device_ids", new[] { best } }, { "play", true } }); return Msg("Wiedergabe gestartet"); }
            catch
            {
                // a fresh device may have nothing queued: start the most recently played context/track
                try
                {
                    var rp = D(Call("GET", "/me/player/recently-played?limit=1", null));
                    foreach (var it in Arr(rp != null && rp.ContainsKey("items") ? rp["items"] : null))
                    {
                        var item = D(it);
                        var ctx = D(item != null && item.ContainsKey("context") ? item["context"] : null);
                        var tr = D(item != null && item.ContainsKey("track") ? item["track"] : null);
                        object pbody = ctx != null ? (object)new Dictionary<string, object> { { "context_uri", J.Str(ctx, "uri") } }
                            : tr != null ? new Dictionary<string, object> { { "uris", new[] { J.Str(tr, "uri") } } } : null;
                        Call("PUT", "/me/player/play?device_id=" + E(best), pbody);
                        return Msg("Letzte Wiedergabe fortgesetzt");
                    }
                }
                catch { }
                Call("PUT", "/me/player/play?device_id=" + E(best), null);
                return new Dictionary<string, object> { { "ok", true } };
            }
        }
    }
}
