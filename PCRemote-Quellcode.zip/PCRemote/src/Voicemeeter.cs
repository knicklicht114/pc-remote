using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace PCRemote
{
    // Voicemeeter Remote API (VoicemeeterRemote64.dll, loaded on demand).
    static class Voicemeeter
    {
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int FnVoid();
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int FnGetType(out int type);
        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)] delegate int FnGetFloat(string name, out float value);
        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)] delegate int FnSetFloat(string name, float value);
        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)] delegate int FnGetStringW(string name, IntPtr buffer);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr LoadLibrary(string path);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr h, string name);

        static FnVoid login, dirty;
        static FnGetType getType;
        static FnGetFloat getF;
        static FnSetFloat setF;
        static FnGetStringW getS;
        static bool loaded, loggedIn;
        static DateTime lastTry = DateTime.MinValue;
        static readonly object L = new object();
        static readonly Regex ParamRx = new Regex(@"^(Strip|Bus)\[\d\]\.(Mute|Gain|Solo|Mono|A[1-5]|B[1-3])$|^Command\.(Restart|Show)$");

        static string FindDll()
        {
            string file = IntPtr.Size == 8 ? "VoicemeeterRemote64.dll" : "VoicemeeterRemote.dll";
            var dirs = new List<string>();
            foreach (var root in new[] { @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" })
            {
                using (var k = Registry.LocalMachine.OpenSubKey(root))
                {
                    if (k == null) continue;
                    foreach (string sub in k.GetSubKeyNames())
                    {
                        if (!sub.StartsWith("VB:Voicemeeter", StringComparison.OrdinalIgnoreCase)) continue;
                        using (var s = k.OpenSubKey(sub))
                        {
                            var u = s == null ? null : s.GetValue("UninstallString") as string;
                            if (!string.IsNullOrEmpty(u)) dirs.Add(Path.GetDirectoryName(u.Trim('"')));
                        }
                    }
                }
            }
            dirs.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"VB\Voicemeeter"));
            foreach (var d in dirs)
            {
                string p = Path.Combine(d, file);
                if (File.Exists(p)) return p;
            }
            return null;
        }

        static T Fn<T>(IntPtr lib, string name) where T : class
        {
            IntPtr p = GetProcAddress(lib, name);
            if (p == IntPtr.Zero) throw new EntryPointNotFoundException(name);
            return Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
        }

        static bool Ensure()
        {
            if (loggedIn) return true;
            if ((DateTime.UtcNow - lastTry).TotalSeconds < 15) return false;
            lastTry = DateTime.UtcNow;
            try
            {
                if (!loaded)
                {
                    string dll = FindDll();
                    if (dll == null) return false;
                    IntPtr lib = LoadLibrary(dll);
                    if (lib == IntPtr.Zero) return false;
                    login = Fn<FnVoid>(lib, "VBVMR_Login");
                    dirty = Fn<FnVoid>(lib, "VBVMR_IsParametersDirty");
                    getType = Fn<FnGetType>(lib, "VBVMR_GetVoicemeeterType");
                    getF = Fn<FnGetFloat>(lib, "VBVMR_GetParameterFloat");
                    setF = Fn<FnSetFloat>(lib, "VBVMR_SetParameterFloat");
                    getS = Fn<FnGetStringW>(lib, "VBVMR_GetParameterStringW");
                    loaded = true;
                }
                loggedIn = login() >= 0;
                if (loggedIn) dirty();
            }
            catch (Exception ex) { Log.Write("voicemeeter: " + ex.Message); }
            return loggedIn;
        }

        static float Get(string p)
        {
            float v;
            return getF(p, out v) == 0 ? v : 0;
        }

        static string GetString(string p)
        {
            IntPtr buf = Marshal.AllocHGlobal(1024);
            try { return getS(p, buf) == 0 ? Marshal.PtrToStringUni(buf) : ""; }
            finally { Marshal.FreeHGlobal(buf); }
        }

        static string[] BusNames(int type)
        {
            if (type == 3) return new[] { "A1", "A2", "A3", "A4", "A5", "B1", "B2", "B3" };
            if (type == 2) return new[] { "A1", "A2", "A3", "B1", "B2" };
            return new[] { "A1", "B1" };
        }

        public static object State()
        {
            lock (L)
            {
                var res = new Dictionary<string, object>();
                if (!Ensure()) { res["ok"] = false; return res; }
                int type;
                if (getType(out type) != 0) { res["ok"] = false; res["reason"] = "Voicemeeter läuft nicht"; return res; }
                dirty();

                int strips = type == 3 ? 8 : type == 2 ? 5 : 3;
                int hardware = type == 3 ? 5 : type == 2 ? 3 : 2;
                string[] buses = BusNames(type);
                var ps = new Dictionary<string, object>();
                var stripList = new List<object>();
                for (int i = 0; i < strips; i++)
                {
                    string pre = "Strip[" + i + "].";
                    string label = GetString(pre + "Label");
                    bool virt = i >= hardware;
                    if (string.IsNullOrWhiteSpace(label))
                        label = virt ? (i == hardware ? "Virtual Input" : "Virtual " + (i - hardware + 1)) : "Eingang " + (i + 1);
                    stripList.Add(new Dictionary<string, object> { { "i", i }, { "label", label }, { "virtual", virt } });
                    ps[pre + "Mute"] = Math.Round(Get(pre + "Mute"));
                    ps[pre + "Gain"] = Math.Round(Get(pre + "Gain"), 1);
                    foreach (string b in buses) ps[pre + b] = Math.Round(Get(pre + b));
                }
                var busList = new List<object>();
                for (int i = 0; i < buses.Length; i++)
                {
                    string pre = "Bus[" + i + "].";
                    busList.Add(new Dictionary<string, object> { { "i", i }, { "name", buses[i] } });
                    ps[pre + "Mute"] = Math.Round(Get(pre + "Mute"));
                    ps[pre + "Gain"] = Math.Round(Get(pre + "Gain"), 1);
                }
                res["ok"] = true;
                res["type"] = type;
                res["typeName"] = type == 3 ? "Potato" : type == 2 ? "Banana" : "Voicemeeter";
                res["strips"] = stripList;
                res["buses"] = busList;
                res["params"] = ps;
                return res;
            }
        }

        static void Check(string param)
        {
            if (!ParamRx.IsMatch(param ?? "")) throw new ArgumentException("Ungültiger Voicemeeter-Parameter: " + param);
            if (!Ensure()) throw new InvalidOperationException("Voicemeeter nicht erreichbar");
        }

        public static void Set(string param, float value)
        {
            lock (L)
            {
                Check(param);
                if (param.EndsWith(".Gain")) value = Math.Max(-60f, Math.Min(12f, value));
                if (setF(param, value) != 0) throw new InvalidOperationException("Voicemeeter hat den Wert abgelehnt");
            }
        }

        public static double Toggle(string param, bool? target)
        {
            lock (L)
            {
                Check(param);
                dirty();
                float cur = Get(param);
                float n = target.HasValue ? (target.Value ? 1f : 0f) : (cur > 0.5f ? 0f : 1f);
                if (setF(param, n) != 0) throw new InvalidOperationException("Voicemeeter hat den Wert abgelehnt");
                return n;
            }
        }

        public static void Command(string cmd)
        {
            lock (L)
            {
                if (!Ensure()) throw new InvalidOperationException("Voicemeeter nicht erreichbar");
                if (cmd == "restart") setF("Command.Restart", 1);
                else if (cmd == "show") setF("Command.Show", 1);
                else throw new ArgumentException("Unbekannt: " + cmd);
            }
        }
    }
}
