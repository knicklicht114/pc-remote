using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace PCRemote
{
    // Screen grab into a DIB we can read without copying: DXGI Desktop Duplication when the size is native,
    // otherwise (or when DXGI isn't available) BitBlt/StretchBlt.
    sealed class Grabber : IDisposable
    {
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc, IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool BitBlt(IntPtr dst, int x, int y, int w, int h, IntPtr src, int sx, int sy, int rop);
        [DllImport("gdi32.dll")] static extern bool StretchBlt(IntPtr dst, int x, int y, int w, int h, IntPtr src, int sx, int sy, int sw, int sh, int rop);
        [DllImport("gdi32.dll")] static extern int SetStretchBltMode(IntPtr dc, int mode);
        [DllImport("gdi32.dll")] static extern bool SetBrushOrgEx(IntPtr dc, int x, int y, IntPtr old);
        [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr dc, ref BITMAPINFOHEADER bi, int usage, out IntPtr bits, IntPtr section, int offset);
        [DllImport("user32.dll")] static extern bool GetCursorInfo(ref CURSORINFO ci);
        [DllImport("user32.dll")] static extern bool GetIconInfo(IntPtr h, out ICONINFO info);
        [DllImport("user32.dll")] static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr icon, int w, int h, int step, IntPtr brush, int flags);

        [StructLayout(LayoutKind.Sequential)]
        struct BITMAPINFOHEADER { public int biSize, biWidth, biHeight; public short biPlanes, biBitCount; public int biCompression, biSizeImage, biXPelsPerMeter, biYPelsPerMeter, biClrUsed, biClrImportant; }
        [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] struct CURSORINFO { public int cbSize, flags; public IntPtr hCursor; public POINT pt; }
        [StructLayout(LayoutKind.Sequential)] struct ICONINFO { public bool fIcon; public int xHotspot, yHotspot; public IntPtr hbmMask, hbmColor; }

        public readonly int W, H;
        public readonly IntPtr Bits; // BGRX, top-down, stride = W * 4
        Mon mon;
        readonly IntPtr mem, dib, old;
        DesktopDup dup;
        bool dupWorked, dupCopied;
        long retryAt;
        CURSORINFO lastCursor;

        public bool UsesDxgi { get { return dup != null; } }

        public Grabber(Mon m, int w, int h)
        {
            mon = m;
            W = w; H = h;
            if (w == m.W && h == m.H) { dup = DesktopDup.TryOpen(m.Dev, w, h); dupWorked = dup != null; }
            IntPtr screen = GetDC(IntPtr.Zero);
            mem = CreateCompatibleDC(screen);
            ReleaseDC(IntPtr.Zero, screen);
            var bi = new BITMAPINFOHEADER { biSize = 40, biWidth = w, biHeight = -h, biPlanes = 1, biBitCount = 32 };
            IntPtr bits;
            dib = CreateDIBSection(mem, ref bi, 0, out bits, IntPtr.Zero, 0);
            if (dib == IntPtr.Zero) throw new InvalidOperationException("Bildpuffer konnte nicht angelegt werden");
            Bits = bits;
            old = SelectObject(mem, dib);
            SetStretchBltMode(mem, 4); // HALFTONE keeps text readable when shrinking
            SetBrushOrgEx(mem, 0, 0, IntPtr.Zero);
        }

        public void Move(Mon m) { mon = m; }

        // Returns false when the picture is known to be unchanged (DXGI only; GDI always returns true).
        public bool Grab()
        {
            var ci = new CURSORINFO();
            ci.cbSize = Marshal.SizeOf(ci);
            if (!GetCursorInfo(ref ci)) ci.flags = 0;
            bool cursorMoved = ci.pt.X != lastCursor.pt.X || ci.pt.Y != lastCursor.pt.Y || ci.hCursor != lastCursor.hCursor || ci.flags != lastCursor.flags;
            lastCursor = ci;

            if (dup != null && dup.Lost) { dup.Dispose(); dup = null; retryAt = Environment.TickCount + 1000; }
            // DXGI goes away on mode switches, UAC prompts, fullscreen changes: open it again a moment later
            if (dup == null && dupWorked && Environment.TickCount - retryAt > 0)
            {
                dup = DesktopDup.TryOpen(mon.Dev, W, H);
                dupCopied = false;
                if (dup == null) retryAt = Environment.TickCount + 2000;
            }
            if (dup != null)
            {
                bool changed = dup.Update();
                if (dup.HasImage && !dup.Lost)
                {
                    if (!changed && !cursorMoved && dupCopied) return false;
                    if (dup.CopyTo(Bits))
                    {
                        dupCopied = true;
                        DrawCursor(ci);
                        return true;
                    }
                }
            }

            IntPtr screen = GetDC(IntPtr.Zero);
            try
            {
                if (W == mon.W && H == mon.H) BitBlt(mem, 0, 0, W, H, screen, mon.X, mon.Y, 0x00CC0020);
                else StretchBlt(mem, 0, 0, W, H, screen, mon.X, mon.Y, mon.W, mon.H, 0x00CC0020);
            }
            finally { ReleaseDC(IntPtr.Zero, screen); }
            DrawCursor(ci);
            return true;
        }

        void DrawCursor(CURSORINFO ci)
        {
            if ((ci.flags & 1) == 0) return;
            if (ci.pt.X < mon.X - 32 || ci.pt.Y < mon.Y - 32 || ci.pt.X > mon.X + mon.W || ci.pt.Y > mon.Y + mon.H) return;
            int hx = 0, hy = 0;
            ICONINFO ii;
            if (GetIconInfo(ci.hCursor, out ii))
            {
                hx = ii.xHotspot; hy = ii.yHotspot;
                if (ii.hbmMask != IntPtr.Zero) DeleteObject(ii.hbmMask);
                if (ii.hbmColor != IntPtr.Zero) DeleteObject(ii.hbmColor);
            }
            double sx = W / (double)mon.W, sy = H / (double)mon.H;
            int size = Math.Max(16, (int)(32 * Math.Max(sx, 0.75)));
            DrawIconEx(mem, (int)((ci.pt.X - mon.X - hx) * sx), (int)((ci.pt.Y - mon.Y - hy) * sy), ci.hCursor, size, size, 0, IntPtr.Zero, 3);
        }

        // Cheap change check: sample a grid of pixels.
        public unsafe ulong Fingerprint()
        {
            ulong h = 1469598103934665603UL;
            uint* p = (uint*)Bits;
            int stepY = Math.Max(1, H / 48), stepX = Math.Max(1, W / 64);
            for (int y = 0; y < H; y += stepY)
            {
                uint* row = p + y * W;
                for (int x = (y * 7) % stepX; x < W; x += stepX) { h ^= row[x]; h *= 1099511628211UL; }
            }
            return h;
        }

        public Bitmap AsBitmap() { return new Bitmap(W, H, W * 4, System.Drawing.Imaging.PixelFormat.Format32bppRgb, Bits); }

        public void Dispose()
        {
            if (dup != null) dup.Dispose();
            SelectObject(mem, old);
            DeleteObject(dib);
            DeleteDC(mem);
        }

        // Fit the monitor into maxW×maxH (even sizes for the video encoder).
        public static Size Fit(Mon m, int maxW)
        {
            int w = m.W, h = m.H;
            if (maxW > 0 && w > maxW) { h = (int)Math.Round(h * (maxW / (double)w)); w = maxW; }
            if (Math.Max(w, h) > 2560) { double s = 2560.0 / Math.Max(w, h); w = (int)(w * s); h = (int)(h * s); }
            return new Size(w & ~1, h & ~1);
        }
    }

    // ---------- Media Foundation H.264 encoder: the graphics card's (NVENC, Quick Sync, AMF) or Windows' software one ----------

    [ComImport, Guid("44ae0fa8-ea31-4109-8d2e-4cae4997c555"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMFMediaType
    {
        void _GetItem(); void _GetItemType(); void _CompareItem(); void _Compare();
        [PreserveSig] int GetUINT32(ref Guid key, out int value);
        void _GetUINT64(); void _GetDouble(); void _GetGUID(); void _GetStringLength(); void _GetString(); void _GetAllocatedString();
        [PreserveSig] int GetBlobSize(ref Guid key, out int size);
        [PreserveSig] int GetBlob(ref Guid key, [Out] byte[] buf, int size, out int written);
        void _GetAllocatedBlob(); void _GetUnknown(); void _SetItem(); void _DeleteItem(); void _DeleteAllItems();
        [PreserveSig] int SetUINT32(ref Guid key, int value);
        [PreserveSig] int SetUINT64(ref Guid key, long value);
        void _SetDouble();
        [PreserveSig] int SetGUID(ref Guid key, ref Guid value);
    }

    [ComImport, Guid("c40a00f2-b93a-4d80-ae8c-5a1c634f58e4"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMFSample
    {
        void _GetItem(); void _GetItemType(); void _CompareItem(); void _Compare();
        [PreserveSig] int GetUINT32(ref Guid key, out int value);
        void _GetUINT64(); void _GetDouble(); void _GetGUID(); void _GetStringLength(); void _GetString(); void _GetAllocatedString();
        void _GetBlobSize(); void _GetBlob(); void _GetAllocatedBlob(); void _GetUnknown(); void _SetItem(); void _DeleteItem(); void _DeleteAllItems();
        void _SetUINT32(); void _SetUINT64(); void _SetDouble(); void _SetGUID(); void _SetString(); void _SetBlob(); void _SetUnknown();
        void _LockStore(); void _UnlockStore(); void _GetCount(); void _GetItemByIndex(); void _CopyAllItems();
        void _GetSampleFlags(); void _SetSampleFlags();
        [PreserveSig] int GetSampleTime(out long time);
        [PreserveSig] int SetSampleTime(long time);
        void _GetSampleDuration();
        [PreserveSig] int SetSampleDuration(long duration);
        void _GetBufferCount(); void _GetBufferByIndex();
        [PreserveSig] int ConvertToContiguousBuffer(out IMFMediaBuffer buffer);
        [PreserveSig] int AddBuffer(IMFMediaBuffer buffer);
        void _RemoveBufferByIndex();
        [PreserveSig] int RemoveAllBuffers();
    }

    [ComImport, Guid("045FA593-8799-42b8-BC8D-8968C6453507"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMFMediaBuffer
    {
        [PreserveSig] int Lock(out IntPtr buffer, out int max, out int current);
        [PreserveSig] int Unlock();
        [PreserveSig] int GetCurrentLength(out int length);
        [PreserveSig] int SetCurrentLength(int length);
        [PreserveSig] int GetMaxLength(out int length);
    }

    [StructLayout(LayoutKind.Sequential)]
    struct MFT_OUTPUT_STREAM_INFO { public int dwFlags, cbSize, cbAlignment; }

    [ComImport, Guid("bf94c121-5b05-4e6f-8000-ba598961414d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMFTransform
    {
        void _GetStreamLimits(); void _GetStreamCount(); void _GetStreamIDs(); void _GetInputStreamInfo();
        [PreserveSig] int GetOutputStreamInfo(int id, out MFT_OUTPUT_STREAM_INFO info);
        void _GetAttributes(); void _GetInputStreamAttributes(); void _GetOutputStreamAttributes(); void _DeleteInputStream(); void _AddInputStreams();
        void _GetInputAvailableType();
        [PreserveSig] int GetOutputAvailableType(int id, int index, out IMFMediaType type);
        [PreserveSig] int SetInputType(int id, IMFMediaType type, int flags);
        [PreserveSig] int SetOutputType(int id, IMFMediaType type, int flags);
        void _GetInputCurrentType();
        [PreserveSig] int GetOutputCurrentType(int id, out IMFMediaType type);
        void _GetInputStatus(); void _GetOutputStatus(); void _SetOutputBounds(); void _ProcessEvent();
        [PreserveSig] int ProcessMessage(int msg, IntPtr param);
        [PreserveSig] int ProcessInput(int id, IMFSample sample, int flags);
        [PreserveSig] int ProcessOutput(int flags, int count, IntPtr buffers, out int status);
    }

    [ComImport, Guid("901db4c7-31ce-41a2-85dc-8fa0bf41b8da"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface ICodecAPI
    {
        void _IsSupported(); void _IsModifiable(); void _GetParameterRange(); void _GetParameterValues(); void _GetDefaultValue(); void _GetValue();
        [PreserveSig] int SetValue(ref Guid api, [In, MarshalAs(UnmanagedType.Struct)] ref object value);
    }

    sealed class H264Encoder : IDisposable
    {
        [DllImport("mfplat.dll")] static extern int MFStartup(int version, int flags);
        [DllImport("mfplat.dll")] static extern int MFCreateMediaType(out IMFMediaType type);
        [DllImport("mfplat.dll")] static extern int MFCreateSample(out IMFSample sample);
        [DllImport("mfplat.dll")] static extern int MFCreateMemoryBuffer(int max, out IMFMediaBuffer buffer);
        [DllImport("mfplat.dll")] static extern int MFTEnumEx(Guid category, int flags, IntPtr inType, IntPtr outType, out IntPtr activates, out int count);
        [DllImport("ole32.dll")] static extern void CoTaskMemFree(IntPtr p);

        delegate int ActivateD(IntPtr self, ref Guid riid, out IntPtr obj);
        delegate int SimpleD(IntPtr self);
        delegate int AllocStrD(IntPtr self, ref Guid key, out IntPtr str, out int len);
        delegate int GetAttrsD(IntPtr self, out IntPtr attrs);
        delegate int SetU32D(IntPtr self, ref Guid key, int value);
        delegate int GetEventD(IntPtr self, int flags, out IntPtr ev);
        delegate int GetTypeD(IntPtr self, out int type);

        public struct Au { public long Time; public byte[] Data; public bool Key; }

        static Guid MT_MAJOR = new Guid("48eba18e-f8c9-4687-bf11-0a74c9f96a8f"), MT_SUBTYPE = new Guid("f7e34c9a-42e8-4714-b74b-cb29d72c35e5");
        static Guid VIDEO = new Guid("73646976-0000-0010-8000-00AA00389B71"), H264 = new Guid("34363248-0000-0010-8000-00AA00389B71"), NV12 = new Guid("3231564E-0000-0010-8000-00AA00389B71");
        static Guid FRAME_SIZE = new Guid("1652c33d-d6b2-4012-b834-72030849a37d"), FRAME_RATE = new Guid("c459a2e8-3d2c-4e44-b132-fee5156c7bb0");
        static Guid BITRATE = new Guid("20332624-fb0d-4d9e-bd0d-cbf6786c102e"), INTERLACE = new Guid("e2724bb8-e676-4806-b4b2-a8d6efb44ccd");
        static Guid PAR = new Guid("c6376a1e-8d0a-4027-be45-6d9a0ad39bb6"), PROFILE = new Guid("ad76a80b-2d5c-4e0b-b375-64e520137036");
        static Guid SEQ_HEADER = new Guid("3c036de7-3ad0-4c9e-9216-ee6d6ac21cb3");
        static Guid LOW_LATENCY = new Guid("9c27891a-ed7a-40e1-88e8-b22727a024ee"), RATE_MODE = new Guid("1c0608e9-370c-4710-8a58-cb6181c42423");
        static Guid GOP = new Guid("95f31b26-95a4-41aa-9303-246a7fc6eef1"), MEAN_BITRATE = new Guid("f7222374-2144-4815-b550-a37f8e12ee52");
        static Guid SPEED = new Guid("98332df8-03cd-476b-89fa-3f9e442dec9f");
        static Guid RGB32 = new Guid("00000016-0000-0010-8000-00AA00389B71"), STRIDE = new Guid("644b4e48-1e02-4516-b0eb-c01ca9d49ac6");
        static Guid BFRAMES = new Guid("8d390aac-dc5c-4200-b57f-814d04babab2"), FORCE_KEY = new Guid("398c1b98-8353-475a-9ef2-8f265d260345");
        static Guid CAT_ENCODER = new Guid("f79eac7d-e545-4387-bdee-d647d7bde42a"), IID_TRANSFORM = new Guid("bf94c121-5b05-4e6f-8000-ba598961414d");
        static Guid ASYNC_UNLOCK = new Guid("e5666d6b-3422-4eb6-a421-da7db1f8e207"), FRIENDLY_NAME = new Guid("314ffbae-5b41-4c95-9c19-4e7d586face3");
        static Guid IID_EVENTGEN = new Guid("2CD0BD52-BCD5-4B89-B62C-EADC0C031E7D"), IID_SHUTDOWN = new Guid("97ec2ea4-0e42-4937-97ac-9d6d328824e1");
        const int NEED_MORE_INPUT = unchecked((int)0xC00D6D72), STREAM_CHANGE = unchecked((int)0xC00D6D61);
        static int started;
        static bool hwBroken;

        readonly IMFTransform mft;
        readonly int w, h, fps, frameBytes;
        readonly bool rgbIn;
        IMFMediaBuffer inBuf, outBuf;
        IMFSample inSample, outSample;
        byte[] seqHeader;
        bool providesSamples;
        public readonly int Width, Height;
        public readonly string Name;

        // hardware encoders work asynchronously: they ask for input and announce output through events
        readonly bool asyncMode;
        IntPtr activate, gen;
        Thread pump;
        readonly object L = new object();
        int need;
        readonly List<Au> ready = new List<Au>();
        Exception pumpError;
        volatile bool closing;

        public bool Hardware { get { return asyncMode; } }
        public bool RgbInput { get { return rgbIn; } }

        // Hardware first (much less CPU), the Windows software encoder when there is none or it refuses.
        // mainProfile: better quality per bit (clips); the live stream stays on Baseline, which every phone decodes.
        public static H264Encoder Open(int width, int height, int fps, int bitrate, bool hardware, bool mainProfile = false)
        {
            if (hardware && !hwBroken)
            {
                try { return new H264Encoder(width, height, fps, bitrate, true, mainProfile); }
                catch (Exception ex) { Log.Write("hw encoder: " + ex.Message + " – using software"); }
            }
            return new H264Encoder(width, height, fps, bitrate, false, false);
        }

        H264Encoder(int width, int height, int fps, int bitrate, bool hardware, bool mainProfile)
        {
            w = width; h = height; Width = w; Height = h;
            this.fps = fps;
            frameBytes = w * h * 3 / 2;
            if (Interlocked.Exchange(ref started, 1) == 0) Check(MFStartup(0x20070, 0), "MFStartup");
            try
            {
                if (hardware)
                {
                    mft = FindHardware(out activate, out Name);
                    if (mft == null) throw new InvalidOperationException("kein Hardware-Encoder");
                    asyncMode = true;
                    IntPtr unk = Marshal.GetIUnknownForObject(mft), t = IntPtr.Zero, attrs = IntPtr.Zero;
                    try
                    {
                        Check(Marshal.QueryInterface(unk, ref IID_TRANSFORM, out t), "transform");
                        Check(ComVt.Fn<GetAttrsD>(t, 8)(t, out attrs), "attributes");
                        Check(ComVt.Fn<SetU32D>(attrs, 21)(attrs, ref ASYNC_UNLOCK, 1), "unlock");
                        ComVt.Fn<SetU32D>(attrs, 21)(attrs, ref LOW_LATENCY, 1);
                        Check(Marshal.QueryInterface(unk, ref IID_EVENTGEN, out gen), "events");
                    }
                    finally { ComVt.Rel(ref attrs); ComVt.Rel(ref t); Marshal.Release(unk); }
                }
                else
                {
                    mft = (IMFTransform)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("6CA50344-051A-4DED-9779-A43305165E35")));
                    Name = "Windows (Software)";
                }

                var codec = mft as ICodecAPI;
                if (codec != null)
                {
                    Set(codec, LOW_LATENCY, true);
                    Set(codec, RATE_MODE, (uint)0);          // CBR: steady bitrate over WLAN
                    Set(codec, MEAN_BITRATE, (uint)bitrate);
                    Set(codec, GOP, (uint)(fps * 2));        // a keyframe every 2 s
                    Set(codec, BFRAMES, (uint)0);            // frames come out in order (simple MP4 for clips)
                    if (!hardware) Set(codec, SPEED, (uint)0); // fastest software encoding
                }

                IMFMediaType o;
                Check(MFCreateMediaType(out o), "type");
                o.SetGUID(ref MT_MAJOR, ref VIDEO);
                o.SetGUID(ref MT_SUBTYPE, ref H264);
                o.SetUINT32(ref BITRATE, bitrate);
                o.SetUINT64(ref FRAME_SIZE, ((long)w << 32) | (uint)h);
                o.SetUINT64(ref FRAME_RATE, ((long)fps << 32) | 1);
                o.SetUINT64(ref PAR, (1L << 32) | 1);
                o.SetUINT32(ref INTERLACE, 2);
                o.SetUINT32(ref PROFILE, mainProfile ? 77 : 66);
                Check(mft.SetOutputType(0, o, 0), "H.264-Ausgabeformat");

                // GPU encoders can often take the screen image as it is (RGB) and convert it themselves – saves the CPU work
                if (hardware && SetInput(RGB32, w * 4) >= 0) rgbIn = true;
                else Check(SetInput(NV12, w), "Eingabeformat");
                frameBytes = rgbIn ? w * h * 4 : w * h * 3 / 2;

                ReadStreamInfo();
                if (!asyncMode)
                {
                    Check(MFCreateMemoryBuffer(frameBytes, out inBuf), "buffer");
                    Check(MFCreateSample(out inSample), "sample");
                    inSample.AddBuffer(inBuf);
                }

                mft.ProcessMessage(0x10000000, IntPtr.Zero); // NOTIFY_BEGIN_STREAMING
                mft.ProcessMessage(0x10000003, IntPtr.Zero); // NOTIFY_START_OF_STREAM
                if (asyncMode)
                {
                    pump = new Thread(Pump) { IsBackground = true, Name = "encoder events" };
                    pump.Start();
                }
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        int SetInput(Guid sub, int stride)
        {
            IMFMediaType i;
            Check(MFCreateMediaType(out i), "type");
            try
            {
                i.SetGUID(ref MT_MAJOR, ref VIDEO);
                i.SetGUID(ref MT_SUBTYPE, ref sub);
                i.SetUINT64(ref FRAME_SIZE, ((long)w << 32) | (uint)h);
                i.SetUINT64(ref FRAME_RATE, ((long)fps << 32) | 1);
                i.SetUINT64(ref PAR, (1L << 32) | 1);
                i.SetUINT32(ref INTERLACE, 2);
                i.SetUINT32(ref STRIDE, stride); // positive = top-down rows, like our screen buffer
                return mft.SetInputType(0, i, 0);
            }
            finally { Marshal.ReleaseComObject(i); }
        }

        static IMFTransform FindHardware(out IntPtr activate, out string name)
        {
            activate = IntPtr.Zero;
            name = null;
            IMFTransform found = null;
            IntPtr arr = IntPtr.Zero, info = Marshal.AllocHGlobal(32);
            int count = 0;
            try
            {
                Marshal.Copy(VIDEO.ToByteArray(), 0, info, 16);
                Marshal.Copy(H264.ToByteArray(), 0, info + 16, 16);
                if (MFTEnumEx(CAT_ENCODER, 0x4 | 0x40, IntPtr.Zero, info, out arr, out count) < 0) return null; // HARDWARE | SORTANDFILTER
                for (int k = 0; k < count; k++)
                {
                    IntPtr a = Marshal.ReadIntPtr(arr, k * IntPtr.Size);
                    IntPtr obj;
                    if (found == null && ComVt.Fn<ActivateD>(a, 33)(a, ref IID_TRANSFORM, out obj) >= 0)
                    {
                        found = (IMFTransform)Marshal.GetObjectForIUnknown(obj);
                        Marshal.Release(obj);
                        activate = a; // kept: ShutdownObject on dispose
                        IntPtr s; int len;
                        if (ComVt.Fn<AllocStrD>(a, 13)(a, ref FRIENDLY_NAME, out s, out len) >= 0) { name = Marshal.PtrToStringUni(s, len); CoTaskMemFree(s); }
                        continue;
                    }
                    Marshal.Release(a);
                }
            }
            finally
            {
                if (arr != IntPtr.Zero) CoTaskMemFree(arr);
                Marshal.FreeHGlobal(info);
            }
            return found;
        }

        void ReadStreamInfo()
        {
            MFT_OUTPUT_STREAM_INFO info;
            mft.GetOutputStreamInfo(0, out info);
            providesSamples = (info.dwFlags & 0x100) != 0; // MFT_OUTPUT_STREAM_PROVIDES_SAMPLES
            if (!providesSamples && outBuf == null)
            {
                Check(MFCreateMemoryBuffer(Math.Max(info.cbSize, w * h * 2), out outBuf), "buffer");
                Check(MFCreateSample(out outSample), "sample");
                outSample.AddBuffer(outBuf);
            }
        }

        static void Set(ICodecAPI c, Guid key, object value)
        {
            try { c.SetValue(ref key, ref value); } catch { }
        }

        static void Check(int hr, string what)
        {
            if (hr < 0) throw new InvalidOperationException("Video-Encoder (" + what + "): 0x" + hr.ToString("X8"));
        }

        // BGRX → NV12 (BT.601 limited range, like every player expects), split over several cores.
        unsafe void Convert(IntPtr bgrx, IMFMediaBuffer buf)
        {
            IntPtr dst; int max, cur;
            Check(buf.Lock(out dst, out max, out cur), "lock");
            try
            {
                int pairs = h / 2, bands = Math.Max(1, Math.Min(4, Environment.ProcessorCount / 2));
                int per = (pairs + bands - 1) / bands;
                IntPtr src0 = bgrx, dst0 = dst;
                int W = w, H = h;
                System.Threading.Tasks.Parallel.For(0, bands, band =>
                {
                    byte* y = (byte*)dst0, uv = y + W * H;
                    uint* src = (uint*)src0;
                    int end = Math.Min(pairs, (band + 1) * per);
                    for (int pr = band * per; pr < end; pr++)
                    {
                        int row = pr * 2;
                        uint* s = src + row * W, s2 = s + W;
                        byte* yr = y + row * W, yr2 = yr + W, uvr = uv + pr * W;
                        for (int x = 0; x < W; x += 2)
                        {
                            uint p0 = s[x], p1 = s[x + 1], p2 = s2[x], p3 = s2[x + 1];
                            int b0 = (int)(p0 & 255), g0 = (int)((p0 >> 8) & 255), r0 = (int)((p0 >> 16) & 255);
                            int b1 = (int)(p1 & 255), g1 = (int)((p1 >> 8) & 255), r1 = (int)((p1 >> 16) & 255);
                            int b2 = (int)(p2 & 255), g2 = (int)((p2 >> 8) & 255), r2 = (int)((p2 >> 16) & 255);
                            int b3 = (int)(p3 & 255), g3 = (int)((p3 >> 8) & 255), r3 = (int)((p3 >> 16) & 255);
                            yr[x] = (byte)(((66 * r0 + 129 * g0 + 25 * b0 + 128) >> 8) + 16);
                            yr[x + 1] = (byte)(((66 * r1 + 129 * g1 + 25 * b1 + 128) >> 8) + 16);
                            yr2[x] = (byte)(((66 * r2 + 129 * g2 + 25 * b2 + 128) >> 8) + 16);
                            yr2[x + 1] = (byte)(((66 * r3 + 129 * g3 + 25 * b3 + 128) >> 8) + 16);
                            int b = (b0 + b1 + b2 + b3) >> 2, g = (g0 + g1 + g2 + g3) >> 2, r = (r0 + r1 + r2 + r3) >> 2;
                            uvr[x] = (byte)(((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128);
                            uvr[x + 1] = (byte)(((112 * r - 94 * g - 18 * b + 128) >> 8) + 128);
                        }
                    }
                });
            }
            finally { buf.Unlock(); }
            buf.SetCurrentLength(frameBytes);
        }

        // The next frame becomes a keyframe (clips need one at least every 2 s, even when frames were skipped).
        public void ForceKey()
        {
            var c = mft as ICodecAPI;
            if (c != null) Set(c, FORCE_KEY, (uint)1);
        }

        unsafe void CopyRgb(IntPtr bgrx, IMFMediaBuffer buf)
        {
            IntPtr dst; int max, cur;
            Check(buf.Lock(out dst, out max, out cur), "lock");
            try { Buffer.MemoryCopy((void*)bgrx, (void*)dst, max, frameBytes); }
            finally { buf.Unlock(); }
            buf.SetCurrentLength(frameBytes);
        }

        // Encode one frame; returns the H.264 access unit(s) as Annex-B bytes (start codes included), or null.
        public byte[] Encode(IntPtr bgrx, long time100ns, long dur100ns)
        {
            var list = EncodeAus(bgrx, time100ns, dur100ns);
            if (list.Count == 0) return null;
            if (list.Count == 1) return list[0].Data;
            var ms = new MemoryStream();
            foreach (var a in list) ms.Write(a.Data, 0, a.Data.Length);
            return ms.ToArray();
        }

        // Same, but each access unit with its own time stamp (for the clip recorder).
        public List<Au> EncodeAus(IntPtr bgrx, long time100ns, long dur100ns)
        {
            var list = new List<Au>();
            if (!asyncMode)
            {
                Convert(bgrx, inBuf);
                inSample.SetSampleTime(time100ns);
                inSample.SetSampleDuration(dur100ns);
                Check(mft.ProcessInput(0, inSample, 0), "Eingabe");
                while (ReadOutput(list)) { }
                return list;
            }

            // the GPU encoder may still hold the previous input, so every frame gets its own buffer
            IMFMediaBuffer buf;
            IMFSample sample;
            Check(MFCreateMemoryBuffer(frameBytes, out buf), "buffer");
            Check(MFCreateSample(out sample), "sample");
            try
            {
                sample.AddBuffer(buf);
                if (rgbIn) CopyRgb(bgrx, buf);
                else Convert(bgrx, buf);
                sample.SetSampleTime(time100ns);
                sample.SetSampleDuration(dur100ns);
                lock (L)
                {
                    while (need == 0 && pumpError == null)
                        if (!Monitor.Wait(L, 2000)) { hwBroken = true; throw new InvalidOperationException("Der Hardware-Encoder antwortet nicht"); }
                    if (pumpError != null) throw pumpError;
                    need--;
                    int before = ready.Count;
                    Check(mft.ProcessInput(0, sample, 0), "Eingabe");
                    // the GPU usually finishes within a few ms: wait briefly so the frame goes out right away
                    int until = Environment.TickCount + 30;
                    while (ready.Count == before && pumpError == null)
                    {
                        int left = until - Environment.TickCount;
                        if (left <= 0 || !Monitor.Wait(L, left)) break;
                    }
                    list.AddRange(ready);
                    ready.Clear();
                }
            }
            finally
            {
                Marshal.ReleaseComObject(sample);
                Marshal.ReleaseComObject(buf);
            }
            return list;
        }

        void Pump()
        {
            try
            {
                var getEvent = ComVt.Fn<GetEventD>(gen, 3);
                while (!closing)
                {
                    IntPtr ev;
                    int hr = getEvent(gen, 0, out ev);
                    if (hr < 0)
                    {
                        lock (L) { if (!closing) pumpError = new InvalidOperationException("Hardware-Encoder: 0x" + hr.ToString("X8")); Monitor.PulseAll(L); }
                        return;
                    }
                    int type;
                    ComVt.Fn<GetTypeD>(ev, 33)(ev, out type);
                    Marshal.Release(ev);
                    lock (L)
                    {
                        try
                        {
                            if (type == 601) need++;                   // METransformNeedInput
                            else if (type == 602) ReadOutput(ready);   // METransformHaveOutput
                        }
                        catch (Exception ex) { pumpError = ex; }
                        Monitor.PulseAll(L);
                    }
                }
            }
            catch (Exception ex) { lock (L) { pumpError = ex; Monitor.PulseAll(L); } }
        }

        // One ProcessOutput call; false when the encoder needs more input first.
        bool ReadOutput(List<Au> into)
        {
            int size = IntPtr.Size == 8 ? 32 : 16;
            IntPtr arr = Marshal.AllocHGlobal(size);
            IntPtr samplePtr = IntPtr.Zero;
            try
            {
                // MFT_OUTPUT_DATA_BUFFER { DWORD id; IMFSample* sample; DWORD status; IMFCollection* events; }
                for (int k = 0; k < size; k++) Marshal.WriteByte(arr, k, 0);
                if (!providesSamples)
                {
                    outBuf.SetCurrentLength(0);
                    samplePtr = Marshal.GetComInterfaceForObject(outSample, typeof(IMFSample));
                    Marshal.WriteIntPtr(arr, IntPtr.Size, samplePtr);
                }
                int status;
                int hr = mft.ProcessOutput(0, 1, arr, out status);
                IntPtr events = Marshal.ReadIntPtr(arr, IntPtr.Size * 3);
                if (events != IntPtr.Zero) Marshal.Release(events);
                if (hr == NEED_MORE_INPUT) return false;
                if (hr == STREAM_CHANGE)
                {
                    // the encoder settled on its final output format: accept it
                    IMFMediaType t;
                    Check(mft.GetOutputAvailableType(0, 0, out t), "Formatwechsel");
                    Check(mft.SetOutputType(0, t, 0), "Formatwechsel");
                    Marshal.ReleaseComObject(t);
                    seqHeader = null;
                    ReadStreamInfo();
                    return true;
                }
                Check(hr, "Ausgabe");
                IMFSample sample = outSample;
                IMFSample own = null;
                if (providesSamples)
                {
                    IntPtr p = Marshal.ReadIntPtr(arr, IntPtr.Size);
                    if (p == IntPtr.Zero) return true;
                    own = sample = (IMFSample)Marshal.GetObjectForIUnknown(p);
                    Marshal.Release(p);
                }
                IMFMediaBuffer buf = outBuf;
                if (own != null) own.ConvertToContiguousBuffer(out buf);
                long time;
                if (sample.GetSampleTime(out time) < 0) time = 0;
                IntPtr data; int max, cur;
                buf.Lock(out data, out max, out cur);
                byte[] b;
                try
                {
                    b = new byte[cur];
                    Marshal.Copy(data, b, 0, cur);
                }
                finally
                {
                    buf.Unlock();
                    if (own != null) { Marshal.ReleaseComObject(buf); Marshal.ReleaseComObject(own); }
                }
                if (b.Length > 0)
                {
                    bool key = IsKey(b);
                    if (key && !HasSps(b)) b = WithHeader(b);
                    into.Add(new Au { Time = time, Data = b, Key = key });
                }
                return true;
            }
            finally
            {
                if (samplePtr != IntPtr.Zero) Marshal.Release(samplePtr);
                Marshal.FreeHGlobal(arr);
            }
        }

        static int NalType(byte[] a, int i) { return a[i] & 0x1F; }

        public static IEnumerable<int> Nals(byte[] a)
        {
            for (int i = 0; i + 3 < a.Length; i++)
                if (a[i] == 0 && a[i + 1] == 0 && (a[i + 2] == 1 || (a[i + 2] == 0 && a[i + 3] == 1)))
                {
                    int start = a[i + 2] == 1 ? i + 3 : i + 4;
                    if (start < a.Length) yield return start;
                    i = start;
                }
        }

        static bool HasSps(byte[] a) { foreach (int n in Nals(a)) if (NalType(a, n) == 7) return true; return false; }
        static bool IsKey(byte[] a) { foreach (int n in Nals(a)) if (NalType(a, n) == 5) return true; return false; }

        // Some encoders keep SPS/PPS only in the media type; put them in front of keyframes so a player can start.
        byte[] WithHeader(byte[] au)
        {
            if (seqHeader == null)
            {
                IMFMediaType t;
                if (mft.GetOutputCurrentType(0, out t) >= 0)
                {
                    int size;
                    if (t.GetBlobSize(ref SEQ_HEADER, out size) >= 0 && size > 0)
                    {
                        var b = new byte[size];
                        int got;
                        if (t.GetBlob(ref SEQ_HEADER, b, size, out got) >= 0) seqHeader = b;
                    }
                    Marshal.ReleaseComObject(t);
                }
            }
            if (seqHeader == null) return au;
            var r = new byte[seqHeader.Length + au.Length];
            Buffer.BlockCopy(seqHeader, 0, r, 0, seqHeader.Length);
            Buffer.BlockCopy(au, 0, r, seqHeader.Length, au.Length);
            return r;
        }

        public void Dispose()
        {
            closing = true;
            if (mft != null)
            {
                try { mft.ProcessMessage(0x10000004, IntPtr.Zero); } catch { } // NOTIFY_END_OF_STREAM
                try { mft.ProcessMessage(0x10000001, IntPtr.Zero); } catch { } // NOTIFY_END_STREAMING
            }
            if (asyncMode && mft != null)
            {
                // shutting the encoder down ends the blocking event wait of the pump thread
                IntPtr unk = Marshal.GetIUnknownForObject(mft), sd;
                if (Marshal.QueryInterface(unk, ref IID_SHUTDOWN, out sd) >= 0) { try { ComVt.Fn<SimpleD>(sd, 3)(sd); } catch { } Marshal.Release(sd); }
                Marshal.Release(unk);
                if (pump != null) pump.Join(500);
            }
            ComVt.Rel(ref gen);
            foreach (object o in new object[] { inSample, outSample, inBuf, outBuf, mft })
                try { if (o != null) Marshal.ReleaseComObject(o); } catch { }
            if (activate != IntPtr.Zero)
            {
                try { ComVt.Fn<SimpleD>(activate, 34)(activate); } catch { } // IMFActivate::ShutdownObject
                ComVt.Rel(ref activate);
            }
        }
    }

    // Live video of one monitor: [4-byte length][2-byte duration ms][H.264 Annex-B access unit] …
    static class VideoStream
    {
        public static void Run(Stream s, string dev, int maxW, int fps, int bitrate)
        {
            fps = Math.Max(5, Math.Min(60, fps));
            bool ours = VirtualDisplay.IsOurs(dev);
            if (ours) VirtualDisplay.ViewerStart();
            Grabber g = null;
            H264Encoder enc = null;
            try
            {
                var mon = Monitors.Find(dev);
                if (mon == null) return;
                var size = Grabber.Fit(mon, maxW);
                g = new Grabber(mon, size.Width, size.Height);
                enc = H264Encoder.Open(size.Width, size.Height, fps, bitrate, true);
                Log.Write("video: " + size.Width + "x" + size.Height + "@" + fps + " · " + enc.Name + (g.UsesDxgi ? " · DXGI" : " · GDI"));
                long frameTicks = 10000000L / fps, t = 0;
                var clock = Stopwatch.StartNew();
                long lastSentMs = -1, lastLook = 0, next = 0;
                ulong lastPrint = 0;
                var head = new byte[6];
                while (!Program.Exiting)
                {
                    long now = clock.ElapsedMilliseconds;
                    if (now - lastLook > 1000)
                    {
                        lastLook = now;
                        var m = Monitors.Find(dev);
                        if (m == null) break; // monitor is gone
                        if (m.W != mon.W || m.H != mon.H) break; // size changed: the phone reconnects with the new size
                        if (m.X != mon.X || m.Y != mon.Y) { mon = m; g.Move(m); }
                    }
                    // DXGI says for free when nothing changed; GDI needs the pixel check
                    ulong print = g.Grab() ? g.Fingerprint() : lastPrint;
                    // Still picture: encode only now and then (keeps the stream alive, saves CPU).
                    bool changed = print != lastPrint || lastSentMs < 0;
                    if (changed || now - lastSentMs >= 500)
                    {
                        lastPrint = print;
                        byte[] au = enc.Encode(g.Bits, t, frameTicks);
                        t += frameTicks;
                        if (au != null)
                        {
                            int dur = lastSentMs < 0 ? 1000 / fps : (int)Math.Max(1, Math.Min(1000, now - lastSentMs));
                            head[0] = (byte)(au.Length >> 24); head[1] = (byte)(au.Length >> 16); head[2] = (byte)(au.Length >> 8); head[3] = (byte)au.Length;
                            head[4] = (byte)(dur >> 8); head[5] = (byte)dur;
                            s.Write(head, 0, 6);
                            s.Write(au, 0, au.Length);
                            s.Flush();
                            lastSentMs = now;
                        }
                    }
                    next += 1000 / fps;
                    long wait = next - clock.ElapsedMilliseconds;
                    if (wait > 0) Thread.Sleep((int)wait);
                    else if (wait < -200) next = clock.ElapsedMilliseconds; // fell behind: don't try to catch up
                }
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
            catch (Exception ex) { Log.Write("video: " + ex.Message); }
            finally
            {
                if (enc != null) enc.Dispose();
                if (g != null) g.Dispose();
                if (ours) VirtualDisplay.ViewerEnd();
            }
        }

        public static string Encoder; // name of the encoder the last probe used

        // Quick self-test so the phone knows up front whether video works on this PC.
        public static string Probe()
        {
            try
            {
                using (var e = H264Encoder.Open(640, 360, 30, 1000000, true))
                {
                    IntPtr buf = Marshal.AllocHGlobal(640 * 360 * 4);
                    try
                    {
                        for (int i = 0; i < 12; i++) if (e.Encode(buf, i * 333333L, 333333L) != null) { Encoder = e.Name; return null; }
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                }
                return "Der Video-Encoder liefert keine Bilder";
            }
            catch (Exception ex) { return ex.Message; }
        }
    }
}
