using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace PCRemote
{
    // The PC app window. WebView2 types live only in WebWindow, so a missing DLL/runtime fails inside Create()
    // and we fall back to Edge's app mode instead of crashing.
    static class Desktop
    {
        static Form win;
        static bool hintShown;

        public static string Url(string view)
        {
            return "http://localhost:" + Program.Cfg.Port + "/?pc=1" + (string.IsNullOrEmpty(view) ? "" : "#" + view);
        }

        public static void Show(string view)
        {
            try
            {
                if (win == null || win.IsDisposed) win = Create(view);
                else if (!string.IsNullOrEmpty(view)) Go(win, view);
                win.Show();
                if (win.WindowState == FormWindowState.Minimized) win.WindowState = Program.Cfg.WinMax ? FormWindowState.Maximized : FormWindowState.Normal;
                win.Activate();
                win.BringToFront();
            }
            catch (Exception ex)
            {
                Log.Write("window: " + ex);
                win = null;
                Fallback(view);
            }
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        static Form Create(string view) { return new WebWindow(Url(view)); }

        [MethodImpl(MethodImplOptions.NoInlining)]
        static void Go(Form f, string view) { ((WebWindow)f).Go(view); }

        public static void Fallback(string view)
        {
            string url = Url(view);
            string edge = null;
            foreach (var p in new[] {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\Microsoft\Edge\Application\msedge.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Microsoft\Edge\Application\msedge.exe" })
                if (File.Exists(p)) { edge = p; break; }
            try
            {
                if (edge != null)
                {
                    string data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"PCRemote\EdgeApp");
                    Process.Start(edge, "--app=\"" + url + "\" --user-data-dir=\"" + data + "\" --window-size=1200,800").Dispose();
                }
                else { var p = Process.Start(url); if (p != null) p.Dispose(); }
            }
            catch (Exception ex) { Log.Write("fallback window: " + ex.Message); }
        }

        public static void Hidden()
        {
            if (hintShown) return;
            hintShown = true;
            Program.Balloon("PC Remote läuft weiter", "Das Fenster ist nur ausgeblendet. Über das Symbol unten rechts öffnest du es wieder.");
        }

        public static void CloseForExit()
        {
            if (win != null && !win.IsDisposed) win.Close();
        }
    }

    class WebWindow : Form
    {
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int val, int size);

        readonly WebView2 view;
        string pendingView;
        bool ready;

        public WebWindow(string url)
        {
            var cfg = Program.Cfg;
            Text = "PC Remote";
            Icon = Logo.MakeIcon(48);
            BackColor = Color.FromArgb(8, 9, 13);
            float scale;
            using (var g = CreateGraphics()) scale = g.DpiX / 96f;
            MinimumSize = new Size((int)(760 * scale), (int)(520 * scale));
            var wa = Screen.PrimaryScreen.WorkingArea;
            if (cfg.WinW > 200 && cfg.WinH > 200 && IsOnScreen(new Rectangle(cfg.WinX, cfg.WinY, cfg.WinW, cfg.WinH)))
            {
                StartPosition = FormStartPosition.Manual;
                Bounds = new Rectangle(cfg.WinX, cfg.WinY, cfg.WinW, cfg.WinH);
            }
            else
            {
                StartPosition = FormStartPosition.CenterScreen;
                Size = new Size(Math.Min((int)(1240 * scale), wa.Width - 40), Math.Min((int)(820 * scale), wa.Height - 40));
            }
            if (cfg.WinMax) WindowState = FormWindowState.Maximized;

            view = new WebView2();
            view.Dock = DockStyle.Fill;
            view.DefaultBackgroundColor = Color.FromArgb(8, 9, 13);
            view.CreationProperties = new CoreWebView2CreationProperties {
                UserDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"PCRemote\WebView2") };
            view.CoreWebView2InitializationCompleted += OnReady;
            Controls.Add(view);
            view.Source = new Uri(url);

            FormClosing += (s, e) =>
            {
                SaveBounds();
                if (!Program.Exiting && e.CloseReason == CloseReason.UserClosing)
                {
                    e.Cancel = true;
                    Hide();
                    Desktop.Hidden();
                }
            };
            ResizeEnd += (s, e) => SaveBounds();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            int on = 1;
            try { if (DwmSetWindowAttribute(Handle, 20, ref on, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref on, 4); } catch { }
        }

        static bool IsOnScreen(Rectangle r)
        {
            foreach (var s in Screen.AllScreens) if (s.WorkingArea.IntersectsWith(r)) return true;
            return false;
        }

        void SaveBounds()
        {
            var cfg = Program.Cfg;
            cfg.WinMax = WindowState == FormWindowState.Maximized;
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            if (b.Width > 200 && b.Height > 200) { cfg.WinX = b.X; cfg.WinY = b.Y; cfg.WinW = b.Width; cfg.WinH = b.Height; }
            cfg.Save();
        }

        void OnReady(object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            if (!e.IsSuccess)
            {
                Log.Write("webview2 init: " + e.InitializationException);
                BeginInvoke(new Action(() => { Hide(); Desktop.Fallback(pendingView); Dispose(); }));
                return;
            }
            var core = view.CoreWebView2;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.IsZoomControlEnabled = false;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.IsPasswordAutosaveEnabled = false;
            core.Settings.IsGeneralAutofillEnabled = false;
            string origin = "http://localhost:" + Program.Cfg.Port + "/";
            // Links to other sites open in the normal browser, the window only ever shows PC Remote.
            core.NewWindowRequested += (s, a) => { a.Handled = true; OpenExternal(a.Uri); };
            core.NavigationStarting += (s, a) =>
            {
                if (a.Uri.StartsWith(origin, StringComparison.OrdinalIgnoreCase) || a.Uri.StartsWith("about:", StringComparison.OrdinalIgnoreCase)) return;
                a.Cancel = true;
                OpenExternal(a.Uri);
            };
            core.DocumentTitleChanged += (s, a) => { Text = string.IsNullOrEmpty(core.DocumentTitle) ? "PC Remote" : core.DocumentTitle; };
            ready = true;
            if (pendingView != null) Go(pendingView);
        }

        static void OpenExternal(string uri)
        {
            try { var p = Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); if (p != null) p.Dispose(); }
            catch (Exception ex) { Log.Write("open " + uri + ": " + ex.Message); }
        }

        public void Go(string viewName)
        {
            pendingView = viewName;
            if (!ready) return;
            pendingView = null;
            view.CoreWebView2.ExecuteScriptAsync("window.pcGo && window.pcGo(" + J.Ser(viewName) + ")");
        }
    }
}
