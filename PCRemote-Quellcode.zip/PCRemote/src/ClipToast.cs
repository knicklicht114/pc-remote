using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace PCRemote
{
    // "Clip gespeichert" on the PC – a small card top right like ShadowPlay or Medal: the clip's picture, game, length and
    // how it was saved; it slides in, stays a few seconds and fades out. It never takes the focus from the game and every
    // click goes right through it. Drawn with real transparency (soft corners and shadow), plus a short two-tone chime.
    sealed class ClipToast : Form
    {
        static ClipToast current;

        public static void Pop(byte[] thumbJpg, string game, double seconds, string why)
        {
            Program.OnUi(() =>
            {
                try
                {
                    if (current != null && !current.IsDisposed) current.Close();
                    current = new ClipToast(thumbJpg, game, seconds, why);
                    current.Begin();
                }
                catch (Exception ex)
                {
                    Log.Write("clip toast: " + ex.Message);
                    Program.Balloon("Clip gespeichert", game + " · " + Math.Round(seconds) + " s");
                }
            });
        }

        // ---------- sound ----------

        static System.Media.SoundPlayer chime;

        public static void Chime()
        {
            try
            {
                if (chime == null) { chime = new System.Media.SoundPlayer(new MemoryStream(MakeChime())); chime.Load(); }
                chime.Play();
            }
            catch { try { System.Media.SystemSounds.Asterisk.Play(); } catch { } }
        }

        // two soft bell notes going up (E6 → B6), each fading out by itself – no Windows "ding"
        static byte[] MakeChime()
        {
            int rate = 44100, n = (int)(rate * 0.45);
            var ms = new MemoryStream();
            var w = new BinaryWriter(ms);
            w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + n * 2); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
            w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(rate); w.Write(rate * 2); w.Write((short)2); w.Write((short)16);
            w.Write(Encoding.ASCII.GetBytes("data")); w.Write(n * 2);
            for (int i = 0; i < n; i++)
            {
                double t = i / (double)rate, t2 = t - 0.075;
                double a = (Math.Sin(2 * Math.PI * 1318.5 * t) + 0.25 * Math.Sin(2 * Math.PI * 2637 * t)) * Math.Exp(-t * 16);
                double b = t2 > 0 ? (Math.Sin(2 * Math.PI * 1975.5 * t2) + 0.2 * Math.Sin(2 * Math.PI * 3951 * t2)) * Math.Exp(-t2 * 9) : 0;
                double v = (a * 0.8 + b) * 0.22 * Math.Min(1.0, i / 90.0); // a tiny fade-in: no click at the start
                w.Write((short)(Math.Max(-1.0, Math.Min(1.0, v)) * 32767));
            }
            w.Flush();
            return ms.ToArray();
        }

        // ---------- the card ----------

        readonly Bitmap frame;
        readonly float scale;
        Point target;
        Timer timer;
        int t0;
        bool still;

        ClipToast(byte[] thumbJpg, string game, double seconds, string why)
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            TopMost = true;
            using (var g0 = Graphics.FromHwnd(IntPtr.Zero)) scale = Math.Max(1f, g0.DpiX / 96f);
            frame = Render(scale, thumbJpg, game, seconds, why);
            Size = frame.Size;
            // on the screen you're playing on, top right
            var wa = Screen.FromHandle(GetForegroundWindow()).WorkingArea;
            target = new Point(wa.Right - frame.Width - (int)(8 * scale), wa.Top + (int)(8 * scale));
            Location = new Point(target.X + (int)(48 * scale), target.Y);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                // layered (real transparency) · tool window (no taskbar/Alt+Tab) · never activated · topmost · clicks go through
                cp.ExStyle |= 0x00080000 | 0x00000080 | 0x08000000 | 0x00000008 | 0x00000020;
                return cp;
            }
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        void Begin()
        {
            var h = Handle; // create the window first, then give it its picture, then show it (no flash)
            Draw(0, Location);
            Show();
            t0 = Environment.TickCount;
            timer = new Timer { Interval = 15 };
            timer.Tick += (o, e) => Step();
            timer.Start();
        }

        void Step()
        {
            const int IN = 280, HOLD = 3800, OUT = 340;
            int t = Environment.TickCount - t0;
            if (t < IN)
            {
                float p = (float)t / IN, e = 1 - (1 - p) * (1 - p) * (1 - p); // slides in, slowing down
                Draw((byte)(255 * Math.Min(1f, p * 1.6f)), new Point((int)(target.X + (1 - e) * 48 * scale), target.Y));
            }
            else if (t < IN + HOLD)
            {
                if (!still) { still = true; Draw(255, target); timer.Interval = 100; }
            }
            else if (t < IN + HOLD + OUT)
            {
                timer.Interval = 15;
                float p = (float)(t - IN - HOLD) / OUT;
                Draw((byte)(255 * (1 - p)), new Point(target.X, (int)(target.Y - p * 10 * scale)));
            }
            else
            {
                timer.Stop();
                Close();
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (timer != null) timer.Dispose();
            frame.Dispose();
            if (current == this) current = null;
            base.OnFormClosed(e);
        }

        // "PCRemote.exe --toast-png file.png": only paints the card into a picture (to look at the design), no window
        public static void Preview(string file, byte[] thumbJpg)
        {
            using (var b = Render(1.5f, thumbJpg, "Fortnite", 30, "Stimme")) b.Save(file, ImageFormat.Png);
        }

        static Bitmap Render(float s, byte[] thumbJpg, string game, double seconds, string why)
        {
            int pad = (int)(18 * s), cw = (int)(380 * s), ch = (int)(96 * s);
            var bmp = new Bitmap(cw + 2 * pad, ch + 2 * pad, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                var card = new RectangleF(pad, pad, cw, ch);
                float r = 16 * s;

                // soft shadow: widening, very faint outlines a little below the card
                for (int i = 9; i >= 1; i--)
                {
                    var sr = new RectangleF(card.X - i * 1.6f * s, card.Y - i * 1.2f * s + 4 * s, card.Width + i * 3.2f * s, card.Height + i * 2.4f * s);
                    using (var sp = Round(sr, r + i * 1.6f * s))
                    using (var b = new SolidBrush(Color.FromArgb(10, 0, 0, 0)))
                        g.FillPath(b, sp);
                }

                // the card: dark like the app, a faint light edge, a red glow from the left (recording colour)
                using (var cp = Round(card, r))
                {
                    using (var b = new SolidBrush(Color.FromArgb(250, 20, 22, 29))) g.FillPath(b, cp);
                    using (var glow = new LinearGradientBrush(card, Color.FromArgb(70, 255, 92, 117), Color.FromArgb(0, 255, 92, 117), LinearGradientMode.Horizontal))
                    {
                        var blend = new Blend { Positions = new[] { 0f, .45f, 1f }, Factors = new[] { 0f, .85f, 1f } };
                        glow.Blend = blend;
                        g.FillPath(glow, cp);
                    }
                    using (var pen = new Pen(Color.FromArgb(38, 255, 255, 255), Math.Max(1f, s))) g.DrawPath(pen, cp);
                }

                // the clip's picture (16:9) with its length on it
                float th = ch - 22 * s, tw = th * 16 / 9;
                var tr = new RectangleF(card.X + 11 * s, card.Y + 11 * s, tw, th);
                using (var tp = Round(tr, 10 * s))
                {
                    Image pic = null;
                    try { if (thumbJpg != null) using (var mst = new MemoryStream(thumbJpg)) using (var tmp = Image.FromStream(mst)) pic = new Bitmap(tmp); } catch { pic = null; }
                    if (pic != null)
                    {
                        using (pic)
                        using (var scaled = new Bitmap((int)Math.Ceiling(tw), (int)Math.Ceiling(th), PixelFormat.Format32bppArgb))
                        {
                            using (var sg = Graphics.FromImage(scaled))
                            {
                                sg.InterpolationMode = InterpolationMode.HighQualityBicubic;
                                // cover: fill the box, cut what sticks out
                                float k = Math.Max(scaled.Width / (float)pic.Width, scaled.Height / (float)pic.Height);
                                float pw = pic.Width * k, ph = pic.Height * k;
                                sg.DrawImage(pic, (scaled.Width - pw) / 2, (scaled.Height - ph) / 2, pw, ph);
                            }
                            using (var tb = new TextureBrush(scaled))
                            {
                                tb.TranslateTransform(tr.X, tr.Y);
                                g.FillPath(tb, tp);
                            }
                        }
                    }
                    else
                        using (var b = new LinearGradientBrush(tr, Color.FromArgb(124, 92, 255), Color.FromArgb(34, 211, 238), 30f)) g.FillPath(b, tp);
                    using (var pen = new Pen(Color.FromArgb(50, 255, 255, 255), Math.Max(1f, s))) g.DrawPath(pen, tp);
                }
                string len = ((int)seconds / 60) + ":" + ((int)Math.Round(seconds) % 60).ToString("00");
                using (var f = new Font("Segoe UI Semibold", 10 * s, FontStyle.Regular, GraphicsUnit.Pixel))
                {
                    var sz = g.MeasureString(len, f);
                    var br = new RectangleF(tr.Right - sz.Width - 9 * s, tr.Bottom - sz.Height - 5 * s, sz.Width + 5 * s, sz.Height + 1 * s);
                    using (var bp = Round(br, 5 * s)) using (var b = new SolidBrush(Color.FromArgb(190, 0, 0, 0))) g.FillPath(b, bp);
                    g.DrawString(len, f, Brushes.White, br.X + 2.5f * s, br.Y + .5f * s);
                }

                // text: ✓ Clip gespeichert / game / how · where
                float x = tr.Right + 14 * s, right = card.Right - 40 * s;
                var circle = new RectangleF(x, card.Y + 17 * s, 18 * s, 18 * s);
                using (var b = new SolidBrush(Color.FromArgb(61, 220, 151))) g.FillEllipse(b, circle);
                using (var pen = new Pen(Color.FromArgb(8, 30, 20), 2.2f * s) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                    g.DrawLines(pen, new[] { new PointF(circle.X + 5 * s, circle.Y + 9.5f * s), new PointF(circle.X + 8 * s, circle.Y + 12.5f * s), new PointF(circle.X + 13.5f * s, circle.Y + 6 * s) });
                using (var fmt = new StringFormat(StringFormatFlags.NoWrap) { Trimming = StringTrimming.EllipsisCharacter })
                {
                    using (var f = new Font("Segoe UI Semibold", 15 * s, FontStyle.Regular, GraphicsUnit.Pixel))
                    using (var b = new SolidBrush(Color.FromArgb(242, 243, 247)))
                        g.DrawString("Clip gespeichert", f, b, new RectangleF(circle.Right + 7 * s, card.Y + 14 * s, right - circle.Right, 22 * s), fmt);
                    using (var f = new Font("Segoe UI", 13 * s, FontStyle.Regular, GraphicsUnit.Pixel))
                    using (var b = new SolidBrush(Color.FromArgb(205, 209, 220)))
                        g.DrawString(string.IsNullOrEmpty(game) ? "Desktop" : game, f, b, new RectangleF(x, card.Y + 40 * s, card.Right - 14 * s - x, 20 * s), fmt);

                    // how it was saved, as a small pill, then where it is
                    string how = why == "Stimme" ? "Per Stimme" : why == "hotkey" ? "Tastenkürzel" : "Vom Handy";
                    using (var f = new Font("Segoe UI Semibold", 10.5f * s, FontStyle.Regular, GraphicsUnit.Pixel))
                    {
                        var hs = g.MeasureString(how, f);
                        var pr = new RectangleF(x, card.Y + 64 * s, hs.Width + 10 * s, 18 * s);
                        using (var pp = Round(pr, 9 * s)) using (var b = new SolidBrush(Color.FromArgb(46, 34, 211, 238))) g.FillPath(b, pp);
                        using (var b = new SolidBrush(Color.FromArgb(125, 226, 245))) g.DrawString(how, f, b, pr.X + 5 * s, pr.Y + (pr.Height - hs.Height) / 2);
                        using (var f2 = new Font("Segoe UI", 11 * s, FontStyle.Regular, GraphicsUnit.Pixel))
                        using (var b = new SolidBrush(Color.FromArgb(130, 136, 154)))
                            g.DrawString("Videos › PC Remote Clips", f2, b, new RectangleF(pr.Right + 7 * s, pr.Y + 1 * s, card.Right - 14 * s - pr.Right - 7 * s, 18 * s), fmt);
                    }
                }

                // the logo, top right
                int ls = (int)(22 * s);
                using (var logo = Logo.Draw(ls, false)) g.DrawImage(logo, card.Right - ls - 12 * s, card.Y + 13 * s, ls, ls);
            }
            return bmp;
        }

        static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = Math.Min(rad * 2, Math.Min(r.Width, r.Height));
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        // ---------- real transparency: hand the finished picture to Windows ----------

        void Draw(byte alpha, Point pos)
        {
            IntPtr screen = GetDC(IntPtr.Zero), mem = CreateCompatibleDC(screen), hbmp = IntPtr.Zero, old = IntPtr.Zero;
            try
            {
                hbmp = frame.GetHbitmap(Color.FromArgb(0));
                old = SelectObject(mem, hbmp);
                var size = new SIZE { cx = frame.Width, cy = frame.Height };
                var src = new POINT { x = 0, y = 0 };
                var dst = new POINT { x = pos.X, y = pos.Y };
                var blend = new BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = alpha, AlphaFormat = 1 };
                UpdateLayeredWindow(Handle, screen, ref dst, ref size, mem, ref src, 0, ref blend, 2);
            }
            finally
            {
                if (old != IntPtr.Zero) SelectObject(mem, old);
                if (hbmp != IntPtr.Zero) DeleteObject(hbmp);
                DeleteDC(mem);
                ReleaseDC(IntPtr.Zero, screen);
            }
        }

        [StructLayout(LayoutKind.Sequential)] struct POINT { public int x, y; }
        [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; }
        [StructLayout(LayoutKind.Sequential, Pack = 1)] struct BLENDFUNCTION { public byte BlendOp, BlendFlags, SourceConstantAlpha, AlphaFormat; }
        [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize, IntPtr hdcSrc, ref POINT pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc, IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
    }
}
