using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace PCRemote
{
    class Api
    {
        readonly string webDir;
        readonly string layoutPath;
        readonly Dictionary<string, Fail> fails = new Dictionary<string, Fail>();

        class Fail { public int Count; public DateTime First; public DateTime BlockedUntil; }

        public Api()
        {
            webDir = Path.GetFullPath(Path.Combine(Program.BaseDir, "web")) + Path.DirectorySeparatorChar;
            layoutPath = Path.Combine(Program.DataDir, "layout.json");
        }

        // One message on the open line: touch/mouse input (no answer) or a button press with "_id", answered with its
        // result – plus "nop" to check the line is alive. Every answer also says when the newest clip was saved.
        static string WsMessage(string text)
        {
            var a = J.Obj(text);
            string id = J.Str(a, "_id");
            object result = null;
            string err = null;
            if (J.Str(a, "t", "") != "nop")
            {
                try { result = Actions.Run(a); }
                catch (Exception ex) { if (id == null) throw; err = ex.Message; }
            }
            if (id == null) return null;
            var d = new Dictionary<string, object> { { "_id", id }, { "ok", err == null }, { "clip", Clips.LastSavedAt.ToString() } };
            if (err != null) d["error"] = err; else if (result != null) d["r"] = result;
            return J.Ser(d);
        }

        // Every API answer carries the change counter, so a device that polls anyway needs no extra /api/ping.
        public Response Handle(Request r)
        {
            var res = Route(r);
            if (res != null && r.Path.StartsWith("/api/"))
            {
                res.Headers["X-Rev"] = System.Threading.Interlocked.Read(ref rev).ToString();
                res.Headers["X-Clip"] = Clips.LastSavedAt.ToString();
            }
            return res;
        }

        Response Route(Request r)
        {
            string p = r.Path;

            if (p == "/spotify/callback")
            {
                if (!r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                return Response.Html(SpotifyApi.Callback(r.Q("code"), r.Q("state"), r.Q("error")));
            }
            if (!p.StartsWith("/api/")) return Static(r);

            if (p == "/api/ping")
                return Response.Json(new Dictionary<string, object> { { "ok", true }, { "name", Environment.MachineName }, { "version", Program.Version }, { "web", WebVersion() }, { "central", Reporter.Central }, { "rev", System.Threading.Interlocked.Read(ref rev) } });

            if (p == "/api/connect")
            {
                if (!r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                return Response.Json(new Dictionary<string, object> {
                    { "pin", Program.Cfg.Pin }, { "port", Program.Cfg.Port },
                    { "name", Environment.MachineName }, { "urls", Net.LanUrls(Program.Cfg.Port) } });
            }

            string ip = r.Remote.ToString();
            if (IsBlocked(ip)) return Response.Error(429, "Zu viele falsche Versuche – bitte 5 Minuten warten");

            // Pairing without PIN: the phone asks, the PC owner allows it in PC Remote.
            if (p == "/api/pair/request")
            {
                if (r.Method != "POST") return Response.Error(405, "POST erwartet");
                var a = J.Obj(r.BodyText);
                return Response.Json(Devices.Request(J.Str(a, "name"), ip, r.Header("User-Agent")));
            }
            if (p == "/api/pair/status")
                return Response.Json(Devices.RequestStatus(r.Q("req"), r.Q("secret")));

            // A paired device sends its own key; the PIN is only needed to pair (or on the PC itself).
            string device = null;
            string token = r.Header("X-Token") ?? r.Q("token");
            if (!string.IsNullOrEmpty(token))
            {
                device = Devices.Check(token, ip);
                if (device == null)
                {
                    RegisterFail(ip);
                    return Response.Error(401, "Dieses Gerät ist nicht mehr verbunden");
                }
            }
            else
            {
                string pin = r.Header("X-Pin") ?? r.Q("pin");
                if (!PinOk(pin))
                {
                    if (!string.IsNullOrEmpty(pin)) RegisterFail(ip);
                    return Response.Error(401, "PIN falsch");
                }
            }

            switch (p)
            {
                case "/api/auth":
                    return Response.Json(new Dictionary<string, object> { { "ok", true }, { "name", Environment.MachineName }, { "version", Program.Version }, { "local", r.IsLocal }, { "device", device } });
                case "/api/pair":
                    {
                        if (r.Method != "POST") return Response.Error(405, "POST erwartet");
                        if (device != null) return Response.Json(new Dictionary<string, object> { { "ok", true }, { "id", device } });
                        var a = J.Obj(r.BodyText);
                        return Response.Json(Devices.PairWithPin(J.Str(a, "name"), ip, r.Header("User-Agent")));
                    }
                case "/api/devices":
                    if (r.Method == "POST")
                    {
                        var a = J.Obj(r.BodyText);
                        string cmd = J.Str(a, "cmd", ""), id = J.Str(a, "id");
                        switch (cmd)
                        {
                            case "rename": Devices.Rename(id, J.Str(a, "name")); break;
                            case "remove":
                                if (id == "*" && !r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                                Devices.Remove(id);
                                break;
                            case "allow":
                            case "deny":
                                if (!r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                                Devices.Answer(id, cmd == "allow");
                                break;
                            default: return Response.Error(400, "Unbekannt");
                        }
                    }
                    return Response.Json(Devices.List(device, r.IsLocal));
                case "/api/state":
                    {
                        var st = State(r.Q("stats") == "1", r.Q("vm") == "1", r.Q("discord") == "1");
                        if (r.Q("spotify") == "1" && SpotifyApi.Connected) Try(st, "spotify", SpotifyApi.StateCached);
                        return Response.Json(st);
                    }
                case "/api/mixer":
                    return Response.Json(Mixer(r.Q("vm") == "1"));
                case "/api/media":
                    {
                        var d = new Dictionary<string, object>();
                        Try(d, "sessions", () => Media.List());
                        Try(d, "volumes", Audio.AppStates);
                        if (r.Q("spotify") == "1" && SpotifyApi.Connected) Try(d, "spotify", SpotifyApi.StateCached);
                        else d["spotify"] = SpotifyApi.Status();
                        return Response.Json(d);
                    }
                case "/api/art":
                    {
                        string type;
                        byte[] img = null;
                        try { img = Media.Art(r.Q("id"), out type); } catch (Exception ex) { Log.Write("art: " + ex.Message); type = null; }
                        if (img == null) return Response.Error(404, "Kein Cover");
                        var res = Response.Bytes(img, type);
                        res.Headers["Cache-Control"] = "private, max-age=600";
                        return res;
                    }
                case "/api/spotify":
                    return Response.Json(SpotifyApi.Get(r.Q("what") ?? "status", r.Q("q")));
                case "/api/discord":
                    return Response.Json(Discord.State());
                case "/api/appinfo":
                    return Response.Json(AppInfo(r));
                case "/api/apps":
                    return Response.Json(Apps.ListForClient());
                case "/api/rescan":
                    Apps.ScanBlocking();
                    return Response.Json(Apps.ListForClient());
                case "/api/icon":
                    return Icon(r);
                // everything that has to look the same on every device lives here on the PC; each change bumps Rev,
                // devices see the new Rev in /api/ping and fetch the change right away
                case "/api/layout":
                    {
                        var res = JsonFile(r, layoutPath);
                        if (r.Method == "POST") return Changed();
                        return res;
                    }
                case "/api/addons":
                    if (r.Method == "POST") { Addons.Save(r.BodyText); return Changed(); }
                    return Response.RawJson(Addons.Raw());
                case "/api/ui":
                    return SharedUi(r);
                case "/api/action":
                    if (r.Method != "POST") return Response.Error(405, "POST erwartet");
                    return Response.Json(Actions.Run(J.Obj(r.BodyText)));
                case "/api/windows":
                    return Response.Json(new Dictionary<string, object> { { "windows", WindowList.List() }, { "monitors", Sys.Monitors() } });
                case "/api/screen":
                    return Response.Bytes(Sys.Screenshot(r.QInt("mon", 0), r.QInt("w", 1280), r.QInt("q", 60)), "image/jpeg");
                case "/api/display":
                    return Response.Json(VirtualDisplay.Status());
                case "/api/video":
                    {
                        // H.264 live video (much smoother and ~20× smaller than the picture stream)
                        string dev = r.Q("dev");
                        int w = r.QInt("w", 1920), fps = r.QInt("fps", 30), br = r.QInt("br", 6000000);
                        var res = new Response();
                        res.ContentType = "application/octet-stream";
                        res.Streamer = s => VideoStream.Run(s, dev, w, fps, Math.Max(500000, Math.Min(20000000, br)));
                        return res;
                    }
                case "/api/videoprobe":
                    {
                        string err = VideoStream.Probe();
                        return Response.Json(new Dictionary<string, object> { { "ok", err == null }, { "error", err } });
                    }
                case "/api/ws":
                    {
                        var res = new Response();
                        // "acts": this PC answers button presses on the open line – the app then sends them this way (faster)
                        res.Socket = (input, output) => WebSocketLink.Run(r, input, output, WsMessage, "{\"hello\":1,\"acts\":true}");
                        return res;
                    }
                case "/api/stream":
                    {
                        string dev = r.Q("dev");
                        int w = r.QInt("w", 1600), q = r.QInt("q", 60), fps = r.QInt("fps", 15);
                        var res = new Response();
                        res.ContentType = "multipart/x-mixed-replace; boundary=frame";
                        res.Streamer = s => ScreenStream.Run(s, dev, w, q, fps);
                        return res;
                    }
                case "/api/clipboard":
                    return Response.Json(new Dictionary<string, object> { { "text", Sys.GetClipboard() } });
                case "/api/clips":
                    if (r.Method == "POST") return Response.Json(Clips.Command(J.Obj(r.BodyText), r.IsLocal));
                    return Response.Json(Clips.Overview());
                case "/api/voice":
                    try
                    {
                        if (r.Method == "POST") return Response.Json(VoiceClip.Command(J.Obj(r.BodyText)));
                        return Response.Json(VoiceClip.Overview());
                    }
                    catch (InvalidOperationException ex) { return Response.Error(400, ex.Message); }
                case "/api/voice/audio":
                    {
                        byte[] wav = VoiceClip.Audio();
                        if (wav == null) return Response.Error(404, "Keine Sprachnachricht aufgenommen");
                        return Response.Bytes(wav, "audio/wav");
                    }
                case "/api/clipfile":
                    {
                        string name = r.Q("name");
                        return Response.FromFile(Clips.FileOf(name), "video/mp4", r.Header("Range"), r.Q("dl") == "1" ? name : null);
                    }
                case "/api/clipthumb":
                    {
                        byte[] jpg = Clips.ThumbOf(r.Q("name"));
                        if (jpg == null) return Response.Error(404, "Kein Vorschaubild");
                        var res = Response.Bytes(jpg, "image/jpeg");
                        res.Headers["Cache-Control"] = "private, max-age=86400";
                        return res;
                    }
                case "/api/info":
                    return Response.Json(Sys.Info());
                case "/api/update":
                    if (r.Method == "POST")
                    {
                        var a = J.Obj(r.BodyText);
                        switch (J.Str(a, "cmd", ""))
                        {
                            case "check": Update.Refresh(true); break;
                            case "install":
                                new System.Threading.Thread(() => { try { Update.Install(); } catch { } }) { IsBackground = true }.Start();
                                break;
                        }
                    }
                    else Update.Refresh(false);
                    return Response.Json(Update.Status());
                case "/api/logs":
                    if (!r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                    return Response.Json(new Dictionary<string, object> { { "logs", Log.Recent(r.Q("problems") == "1") } });
                case "/api/consent":
                    if (r.Method == "POST")
                    {
                        var a = J.Obj(r.BodyText);
                        Program.Cfg.ReportApps = J.Bool(a, "reportApps");
                        Program.Cfg.ReportAsked = true;
                        Program.Cfg.Save();
                        if (Program.Cfg.ReportApps) Apps.ScanAsync(); // report what's already there
                    }
                    return Response.Json(new Dictionary<string, object> { { "reportApps", Program.Cfg.ReportApps }, { "asked", Program.Cfg.ReportAsked } });
                case "/api/pc":
                    if (!r.IsLocal) return Response.Error(403, "Nur direkt am PC verfügbar");
                    return Response.Json(PcSettings(r));
            }
            return Response.Error(404, "Unbekannter Endpunkt");
        }

        static Dictionary<string, object> State(bool stats, bool vm, bool discord)
        {
            var d = new Dictionary<string, object>();
            Try(d, "master", Audio.MasterState);
            Try(d, "mic", Audio.MicState);
            Try(d, "apps", Audio.AppStates);
            Try(d, "np", NowPlaying);
            Try(d, "procs", Sys.ProcNames);
            if (stats) Try(d, "stats", Sys.Stats);
            if (vm) Try(d, "vm", Voicemeeter.State);
            if (discord) Try(d, "discord", Discord.State);
            return d;
        }

        static object NowPlaying()
        {
            try { return Media.NowPlaying(); }
            catch (Exception ex) { Log.Write("media: " + ex.Message); return Sys.NowPlaying(); }
        }

        static object Mixer(bool vm)
        {
            var d = new Dictionary<string, object>();
            Try(d, "master", Audio.MasterState);
            Try(d, "mic", Audio.MicState);
            Try(d, "sessions", Audio.MixerList);
            Try(d, "outputs", () => Audio.Devices(0));
            Try(d, "inputs", () => Audio.Devices(1));
            if (vm) Try(d, "vm", Voicemeeter.State);
            return d;
        }

        // Changes whenever a web file changes, so open phones can reload to the current UI.
        string webVer;
        long webVerAt;
        string WebVersion()
        {
            if (webVer != null && Environment.TickCount - webVerAt < 5000) return webVer;
            long h = 17;
            foreach (var f in new[] { "app.js", "style.css", "index.html" })
            {
                try { var fi = new FileInfo(Path.Combine(webDir, f)); if (fi.Exists) h = h * 31 + fi.LastWriteTimeUtc.Ticks + fi.Length; } catch { }
            }
            webVerAt = Environment.TickCount;
            return webVer = (Program.Version + "-" + (h & 0xffffff).ToString("x"));
        }

        static object AppInfo(Request r)
        {
            var procs = (r.Q("procs") ?? "").Split(',').Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            string parts = r.Q("parts") ?? "";
            var d = new Dictionary<string, object>();
            if (procs.Count > 0) Try(d, "app", () => AppCtl.Info(procs));
            if (parts.Contains("media")) Try(d, "media", () => Media.List());
            if (parts.Contains("discord")) Try(d, "discord", Discord.State);
            if (parts.Contains("spotify")) Try(d, "spotify", () => SpotifyApi.Connected ? SpotifyApi.StateCached() : SpotifyApi.Status());
            if (parts.Contains("vm")) Try(d, "vm", Voicemeeter.State);
            if (parts.Contains("stats")) Try(d, "stats", Sys.Stats);
            return d;
        }

        static object PcSettings(Request r)
        {
            if (r.Method == "POST")
            {
                var a = J.Obj(r.BodyText);
                switch (J.Str(a, "cmd", ""))
                {
                    case "newpin": Program.Cfg.NewPin(); break;
                    case "autostart": Program.SetAutostart(J.Bool(a, "on")); break;
                    case "folder": Process.Start("explorer.exe", "\"" + Program.BaseDir + "\"").Dispose(); break;
                    case "rescan": Apps.ScanAsync(); break;
                    case "quit": Program.Quit(); break;
                    // a Windows notification from the app (e.g. "new VIP request" for the owner)
                    case "notify": Program.Balloon(J.Str(a, "title", "PC Remote"), J.Str(a, "text", "")); break;
                    default: throw new ArgumentException("Unbekannt");
                }
            }
            return new Dictionary<string, object> {
                { "pin", Program.Cfg.Pin }, { "port", Program.Cfg.Port }, { "urls", Net.LanUrls(Program.Cfg.Port) },
                { "autostart", Program.IsAutostart() }, { "version", Program.Version }, { "dir", Program.BaseDir }, { "name", Environment.MachineName },
                { "update", Update.Status() } };
        }

        static void Try(Dictionary<string, object> d, string key, Func<object> f)
        {
            try { d[key] = f(); }
            catch (Exception ex) { d[key] = null; d[key + "Error"] = ex.Message; Log.Write("state " + key + ": " + ex.Message); }
        }

        Response Icon(Request r)
        {
            byte[] png = r.Q("id") != null ? Apps.IconById(r.Q("id")) : Apps.IconByProc(r.Q("proc"));
            if (png == null) return Response.Error(404, "kein Icon");
            var res = Response.Bytes(png, "image/png");
            res.Headers["Cache-Control"] = "private, max-age=86400";
            return res;
        }

        // ---------- live sync between PC and phones/tablets ----------

        static long rev = DateTime.UtcNow.Ticks / 10000; // a new value after every PC Remote start, too
        static long Bump() { return System.Threading.Interlocked.Increment(ref rev); }
        static Response Changed() { return Response.Json(new Dictionary<string, object> { { "ok", true }, { "rev", Bump() } }); }

        static readonly object uiLock = new object();
        // shared look: tile size, VIP colours/styles, background (incl. an own picture). POST merges keys, null removes one.
        Response SharedUi(Request r)
        {
            string path = Path.Combine(Program.DataDir, "ui.json");
            lock (uiLock)
            {
                Dictionary<string, object> cur;
                try { cur = J.Obj(Store.Read(path) ?? "{}"); } catch { cur = new Dictionary<string, object>(); }
                if (cur == null) cur = new Dictionary<string, object>();
                if (r.Method != "POST") return Response.Json(cur);
                var patch = J.Obj(r.BodyText);
                foreach (var kv in patch)
                {
                    if (kv.Key.Length > 40) continue;
                    if (kv.Value == null) cur.Remove(kv.Key); else cur[kv.Key] = kv.Value;
                }
                Store.Write(path, J.Ser(cur));
            }
            return Changed();
        }

        static Response JsonFile(Request r, string path)
        {
            if (r.Method == "POST")
            {
                string json = r.BodyText;
                J.Parse(json);
                Store.Write(path, json);
                return Response.Json(new Dictionary<string, object> { { "ok", true } });
            }
            string s = Store.Read(path);
            return Response.RawJson(string.IsNullOrWhiteSpace(s) ? "null" : s);
        }

        Response Static(Request r)
        {
            if (r.Method != "GET" && r.Method != "HEAD") return Response.Error(405, "Nur GET");

            var m = Regex.Match(r.Path, @"^/(?:logo-(\d+)|(apple-touch-icon))\.png$");
            if (m.Success)
            {
                int size = m.Groups[1].Success ? Math.Max(16, Math.Min(1024, int.Parse(m.Groups[1].Value))) : 180;
                var lr = Response.Bytes(Logo.Png(size, m.Groups[2].Success || size == 180), "image/png");
                lr.Headers["Cache-Control"] = "public, max-age=86400";
                return lr;
            }
            var sm = Regex.Match(r.Path, @"^/splash-(\d{3,4})x(\d{3,4})\.png$");
            if (sm.Success)
            {
                int w = Math.Max(320, Math.Min(3000, int.Parse(sm.Groups[1].Value))), h = Math.Max(320, Math.Min(3000, int.Parse(sm.Groups[2].Value)));
                var sr = Response.Bytes(Logo.Splash(w, h), "image/png");
                sr.Headers["Cache-Control"] = "public, max-age=86400";
                return sr;
            }

            string rel = r.Path == "/" ? "index.html" : r.Path.TrimStart('/');
            string full;
            try { full = Path.GetFullPath(Path.Combine(webDir, rel.Replace('/', Path.DirectorySeparatorChar))); }
            catch { return Response.Error(400, "Ungültiger Pfad"); }
            if (!full.StartsWith(webDir, StringComparison.OrdinalIgnoreCase) || !File.Exists(full))
                return Response.Error(404, "Nicht gefunden");

            // Files are kept in memory (plus a gzip copy); the browser revalidates with ETag and gets a 304 when nothing changed.
            var fi = new FileInfo(full);
            Cached c;
            lock (fileCache) fileCache.TryGetValue(full, out c);
            if (c == null || c.Time != fi.LastWriteTimeUtc || c.Length != fi.Length)
            {
                byte[] raw = File.ReadAllBytes(full);
                c = new Cached { Time = fi.LastWriteTimeUtc, Length = fi.Length, Raw = raw,
                    ETag = "\"" + fi.LastWriteTimeUtc.Ticks.ToString("x") + "-" + fi.Length.ToString("x") + "\"" };
                if (raw.Length > 1024 && Response.Compressible(Mime(full))) c.Gzip = Response.Gzip(raw, true);
                lock (fileCache) fileCache[full] = c;
            }
            string cache = rel.StartsWith("vendor/") ? "public, max-age=604800" : "no-cache";
            if (r.Header("If-None-Match") == c.ETag)
            {
                var nm = new Response { Status = 304 };
                nm.Headers["ETag"] = c.ETag;
                nm.Headers["Cache-Control"] = cache;
                return nm;
            }
            bool gz = c.Gzip != null && (r.Header("Accept-Encoding") ?? "").Contains("gzip");
            var res = Response.Bytes(gz ? c.Gzip : c.Raw, Mime(full));
            if (gz) res.Headers["Content-Encoding"] = "gzip";
            res.Headers["Vary"] = "Accept-Encoding";
            res.Headers["ETag"] = c.ETag;
            res.Headers["Cache-Control"] = cache;
            return res;
        }

        class Cached { public DateTime Time; public long Length; public byte[] Raw, Gzip; public string ETag; }
        static readonly Dictionary<string, Cached> fileCache = new Dictionary<string, Cached>(StringComparer.OrdinalIgnoreCase);

        static string Mime(string f)
        {
            switch (Path.GetExtension(f).ToLowerInvariant())
            {
                case ".html": return "text/html; charset=utf-8";
                case ".css": return "text/css; charset=utf-8";
                case ".js": return "application/javascript; charset=utf-8";
                case ".json": return "application/json; charset=utf-8";
                case ".webmanifest": return "application/manifest+json; charset=utf-8";
                case ".svg": return "image/svg+xml";
                case ".png": return "image/png";
                case ".ico": return "image/x-icon";
                case ".woff2": return "font/woff2";
                default: return "application/octet-stream";
            }
        }

        static bool PinOk(string pin)
        {
            string real = Program.Cfg.Pin;
            if (pin == null || pin.Length != real.Length) return false;
            int diff = 0;
            for (int i = 0; i < real.Length; i++) diff |= pin[i] ^ real[i];
            return diff == 0;
        }

        bool IsBlocked(string ip)
        {
            lock (fails)
            {
                Fail f;
                return fails.TryGetValue(ip, out f) && f.BlockedUntil > DateTime.UtcNow;
            }
        }

        void RegisterFail(string ip)
        {
            lock (fails)
            {
                Fail f;
                if (!fails.TryGetValue(ip, out f) || (DateTime.UtcNow - f.First).TotalMinutes > 10)
                {
                    f = new Fail { First = DateTime.UtcNow };
                    fails[ip] = f;
                }
                if (++f.Count >= 10) f.BlockedUntil = DateTime.UtcNow.AddMinutes(5);
                Log.Write("wrong pin from " + ip + " (" + f.Count + ")");
            }
        }
    }

    static class Actions
    {
        public static object Run(Dictionary<string, object> a)
        {
            string t = J.Str(a, "t", "");
            switch (t)
            {
                case "media":
                    {
                        string k = J.Str(a, "k", "playpause");
                        string src = J.Str(a, "src");
                        // With a source (spotify/chrome …) control exactly that app, without needing its window.
                        if (!string.IsNullOrEmpty(src) && (k == "playpause" || k == "next" || k == "prev" || k == "stop"))
                        {
                            Media.Do(src, k == "playpause" ? "toggle" : k, 0);
                            return Ok();
                        }
                        Input.Tap(Input.MediaVk(k));
                        return Ok();
                    }
                case "pointer":
                    ScreenStream.Pointer(a);
                    return Ok();
                case "clipsave":
                    return Clips.Save("button");
                case "display":
                    switch (J.Str(a, "cmd", ""))
                    {
                        case "add": return VirtualDisplay.Add(VirtualDisplay.ReadLayout(a));
                        case "remove": VirtualDisplay.RemoveAll(); return Msg("Zusätzlicher Bildschirm entfernt");
                        case "arrange": VirtualDisplay.Arrange(VirtualDisplay.ReadLayout(a)); return Ok();
                        case "install": return Msg(VirtualDisplay.Install((int)J.Num(a, "w"), (int)J.Num(a, "h")));
                        case "modes": return Msg(VirtualDisplay.SetModes((int)J.Num(a, "w"), (int)J.Num(a, "h")));
                    }
                    throw new ArgumentException("Unbekannt");
                case "mctl":
                    Media.Do(J.Str(a, "id"), J.Str(a, "cmd", "toggle"), J.Num(a, "value"));
                    return Ok();
                case "spotify":
                    return SpotifyApi.Do(a);
                case "discord":
                    return Discord.Do(J.Str(a, "cmd", "mute"));
                case "volume":
                    if (J.Has(a, "set")) Audio.SetMasterVolume((float)J.Num(a, "set"));
                    else Audio.StepMaster((float)(J.Num(a, "delta", 5) / 100.0));
                    return Ok();
                case "set":
                    Binds.Set(J.Str(a, "bind"), J.Num(a, "value"));
                    return Ok();
                case "toggle":
                    return new Dictionary<string, object> { { "ok", true }, { "value", Binds.Toggle(J.Str(a, "bind"), J.Str(a, "mode", "toggle")) } };
                case "key":
                    Input.Hotkey(J.Str(a, "keys", ""));
                    return Ok();
                case "appkey":
                    AppCtl.SendKeys(AppCtl.Procs(a), J.Str(a, "keys", ""), J.Bool(a, "back"));
                    return Ok();
                case "focus":
                    if (!WindowList.FocusProcs(AppCtl.Procs(a))) throw new InvalidOperationException("Kein offenes Fenster");
                    return Ok();
                case "appwin":
                    AppCtl.Windows(AppCtl.Procs(a), J.Str(a, "op", "min"));
                    return Ok();
                case "priority":
                    return Msg(AppCtl.SetPriority(AppCtl.Procs(a), J.Str(a, "level", "normal")));
                case "riot":
                    return Msg(AppCtl.Riot(J.Str(a, "product", "valorant"), J.Str(a, "patchline", "live")));
                case "text":
                    Input.Text(J.Str(a, "text", ""));
                    if (J.Bool(a, "enter")) Input.Hotkey("enter");
                    return Ok();
                case "mouse":
                    Input.Mouse(a);
                    return Ok();
                case "tap":
                    Sys.ClickAt(J.Num(a, "x"), J.Num(a, "y"), (int)J.Num(a, "mon"), J.Str(a, "button", "left"));
                    return Ok();
                case "launch":
                    Sys.Launch(J.Str(a, "target"), J.Str(a, "args"));
                    return Msg("Wird gestartet …");
                case "procrun":
                    {
                        // start the exe of a running program once more with arguments, e.g. Wallpaper Engine "-control pause"
                        string exe = Sys.ExeOfRunning(AppCtl.Procs(a));
                        if (exe == null) throw new InvalidOperationException("Das Programm läuft gerade nicht");
                        Sys.Launch(exe, J.Str(a, "args"));
                        return Ok();
                    }
                case "url":
                    Sys.Launch(J.Str(a, "url"), null);
                    return Msg("Wird geöffnet …");
                case "app":
                    return Apps.Do(J.Str(a, "id"), J.Str(a, "op", "smart"));
                case "kill":
                    Sys.Kill(AppCtl.Procs(a), J.Bool(a, "force"));
                    return Msg("Wird beendet");
                case "power":
                    return Msg(Sys.Power(J.Str(a, "cmd", ""), (int)J.Num(a, "delay")));
                case "cmd":
                    return Msg(Sys.RunCommand(J.Str(a, "cmd", "")));
                case "window":
                    WindowList.Do(J.Str(a, "h"), J.Str(a, "op", "focus"));
                    return Ok();
                case "device":
                    Audio.SetDefaultDevice(J.Str(a, "id"));
                    return Msg("Gerät gewechselt");
                case "clip":
                    Sys.SetClipboard(J.Str(a, "text", ""));
                    return Msg("In die PC-Zwischenablage kopiert");
                case "macro":
                    Macro.Start(J.Str(a, "script", ""));
                    return Msg("Makro läuft");
                case "vm":
                    Voicemeeter.Command(J.Str(a, "cmd", ""));
                    return Msg("Voicemeeter: erledigt");
            }
            throw new ArgumentException("Unbekannte Aktion: " + t);
        }

        static object Ok() { return new Dictionary<string, object> { { "ok", true } }; }
        static object Msg(string m) { return new Dictionary<string, object> { { "ok", true }, { "msg", m } }; }
    }

    static class Binds
    {
        public static void Set(string bind, double v)
        {
            if (string.IsNullOrEmpty(bind)) throw new ArgumentException("Kein Ziel angegeben");
            if (bind == "master") Audio.SetMasterVolume((float)v);
            else if (bind == "mic") Audio.SetMicVolume((float)v);
            else if (bind == "spotify") SpotifyApi.Do(new Dictionary<string, object> { { "cmd", "volume" }, { "value", v * 100 } });
            else if (bind.StartsWith("app:")) Audio.SetAppVolume(bind.Substring(4), (float)v);
            else if (bind.StartsWith("vm:")) Voicemeeter.Set(bind.Substring(3), (float)v);
            else throw new ArgumentException("Unbekanntes Ziel: " + bind);
        }

        public static double Toggle(string bind, string mode)
        {
            if (string.IsNullOrEmpty(bind)) throw new ArgumentException("Kein Ziel angegeben");
            bool? target = mode == "on" ? true : mode == "off" ? (bool?)false : null;
            if (bind == "master") return Audio.SetMasterMute(target) ? 1 : 0;
            if (bind == "mic") return Audio.SetMicMute(target) ? 1 : 0;
            if (bind.StartsWith("app:")) return Audio.SetAppMute(bind.Substring(4), target) ? 1 : 0;
            if (bind.StartsWith("vm:")) return Voicemeeter.Toggle(bind.Substring(3), target);
            if (bind.StartsWith("discord:")) return Discord.Toggle(bind.Substring(8), target) ? 1 : 0;
            throw new ArgumentException("Unbekanntes Ziel: " + bind);
        }
    }

    // Script lines: key ctrl+c | text hallo | wait 500 | launch notepad | url https://.. | media next
    //               toggle mic | mute [bind] | unmute [bind] | volume 40 | app <id> | kill <proc> | cmd <command> | click left
    //               discord mute | spotify next | spotify volume 40 | appkey <proc> <keys> | riot valorant
    static class Macro
    {
        public static void Start(string script)
        {
            string[] lines = (script ?? "").Replace("\r", "").Split('\n');
            var t = new Thread(() =>
            {
                foreach (string raw in lines)
                {
                    string l = raw.Trim();
                    if (l.Length == 0 || l.StartsWith("#") || l.StartsWith("//")) continue;
                    int sp = l.IndexOf(' ');
                    string cmd = (sp < 0 ? l : l.Substring(0, sp)).ToLowerInvariant();
                    string arg = sp < 0 ? "" : l.Substring(sp + 1).Trim();
                    try { Step(cmd, arg); }
                    catch (Exception ex) { Log.Write("macro '" + l + "': " + ex.Message); }
                    Thread.Sleep(40);
                }
            });
            t.IsBackground = true;
            t.Start();
        }

        static void Step(string cmd, string arg)
        {
            switch (cmd)
            {
                case "key": case "taste": case "hotkey": Input.Hotkey(arg); break;
                case "text": case "type": case "tippe": Input.Text(arg); break;
                case "wait": case "warte": case "sleep": Thread.Sleep(Math.Max(0, Math.Min(120000, int.Parse(arg)))); break;
                case "launch": case "start": case "open": Sys.Launch(arg, null); break;
                case "url": Sys.Launch(arg, null); break;
                case "media": Input.Tap(Input.MediaVk(arg)); break;
                case "toggle": Binds.Toggle(arg, "toggle"); break;
                case "mute": Binds.Toggle(arg.Length == 0 ? "master" : arg, "on"); break;
                case "unmute": Binds.Toggle(arg.Length == 0 ? "master" : arg, "off"); break;
                case "volume": Binds.Set("master", double.Parse(arg, CultureInfo.InvariantCulture) / 100.0); break;
                case "app": Apps.Do(arg, "smart"); break;
                case "kill": Sys.Kill(new List<string> { arg }, false); break;
                case "cmd": Sys.RunCommand(arg); break;
                case "discord": Discord.Do(arg.Length == 0 ? "mute" : arg); break;
                case "riot": AppCtl.Riot(arg.Length == 0 ? "valorant" : arg, "live"); break;
                case "spotify":
                    {
                        var parts = arg.Split(new[] { ' ' }, 2);
                        var a = new Dictionary<string, object> { { "cmd", parts[0] } };
                        if (parts.Length > 1) a["value"] = double.Parse(parts[1], CultureInfo.InvariantCulture);
                        SpotifyApi.Do(a);
                        break;
                    }
                case "appkey":
                    {
                        var parts = arg.Split(new[] { ' ' }, 2);
                        if (parts.Length < 2) throw new ArgumentException("appkey <prozess> <tasten>");
                        AppCtl.SendKeys(new List<string> { parts[0] }, parts[1], false);
                        break;
                    }
                case "click":
                    Input.Mouse(new Dictionary<string, object> { { "click", arg.Length == 0 ? "left" : arg } });
                    break;
                default: throw new ArgumentException("unbekannter Befehl " + cmd);
            }
        }
    }
}
