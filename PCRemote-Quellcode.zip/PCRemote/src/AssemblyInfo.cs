using System.Reflection;

// Name, description and version in the exe's file properties - programs without them look suspicious to virus scanners.
[assembly: AssemblyTitle("PC Remote")]
[assembly: AssemblyDescription("Steuere deinen PC vom Handy")]
[assembly: AssemblyCompany("PC Remote")]
[assembly: AssemblyProduct("PC Remote")]
[assembly: AssemblyCopyright("© 2026 PC Remote")]
[assembly: AssemblyVersion(PCRemote.Program.Version + ".0.0")]
[assembly: AssemblyFileVersion(PCRemote.Program.Version + ".0.0")]
