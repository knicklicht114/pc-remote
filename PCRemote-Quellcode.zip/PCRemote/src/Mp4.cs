using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PCRemote
{
    struct AacFrame { public long Time; public byte[] Data; } // time in 100 ns

    // Minimal MP4 writer for clips: H.264 video + AAC audio, index ("moov") in front so phones and browsers
    // can start playing right away. Samples are interleaved by time, one chunk per sample.
    static class Mp4
    {
        class Box
        {
            readonly MemoryStream ms = new MemoryStream();
            readonly Stack<long> open = new Stack<long>();
            public void Begin(string type) { open.Push(ms.Position); U32(0); Ascii(type); }
            public void Full(string type, int version, int flags) { Begin(type); U32((uint)((version << 24) | flags)); }
            public void End() { long s = open.Pop(), e = ms.Position; ms.Position = s; U32((uint)(e - s)); ms.Position = e; }
            public void U8(int v) { ms.WriteByte((byte)v); }
            public void U16(int v) { U8(v >> 8); U8(v); }
            public void U32(uint v) { U8((int)(v >> 24)); U8((int)(v >> 16)); U8((int)(v >> 8)); U8((int)v); }
            public void I32(int v) { U32(unchecked((uint)v)); }
            public void Zero(int n) { for (int i = 0; i < n; i++) ms.WriteByte(0); }
            public void Ascii(string s) { var b = Encoding.ASCII.GetBytes(s); ms.Write(b, 0, b.Length); }
            public void Bytes(byte[] b) { ms.Write(b, 0, b.Length); }
            public byte[] ToArray() { return ms.ToArray(); }
        }

        class Sample { public long Time; public byte[] Data; public bool Key, Audio; public uint Offset; }

        static readonly uint[] Matrix = { 0x10000, 0, 0, 0, 0x10000, 0, 0, 0, 0x40000000 };
        const int VideoScale = 90000;

        // Returns the clip length in seconds.
        public static double Write(string file, List<H264Encoder.Au> aus, int w, int h, int fps, List<AacFrame> aac, int rate, int channels)
        {
            // H.264 from the encoder is Annex-B (start codes); MP4 wants length-prefixed NAL units plus SPS/PPS in the header
            byte[] sps = null, pps = null;
            var vs = new List<Sample>();
            foreach (var au in aus)
            {
                var ms = new MemoryStream(au.Data.Length + 16);
                foreach (var nal in SplitNals(au.Data))
                {
                    int type = au.Data[nal.Offset] & 0x1F;
                    if (type == 7) { if (sps == null) sps = Slice(nal); continue; }
                    if (type == 8) { if (pps == null) pps = Slice(nal); continue; }
                    if (type == 9) continue; // access unit delimiter
                    ms.WriteByte((byte)(nal.Count >> 24)); ms.WriteByte((byte)(nal.Count >> 16)); ms.WriteByte((byte)(nal.Count >> 8)); ms.WriteByte((byte)nal.Count);
                    ms.Write(nal.Array, nal.Offset, nal.Count);
                }
                if (ms.Length > 0) vs.Add(new Sample { Time = au.Time, Data = ms.ToArray(), Key = au.Key });
            }
            if (vs.Count == 0 || sps == null || pps == null) throw new InvalidOperationException("Keine Videodaten im Puffer");

            long t0 = vs[0].Time;
            long frameDur = 10000000L / Math.Max(1, fps);
            var vDur = new long[vs.Count]; // in 90 kHz
            for (int i = 0; i < vs.Count; i++)
            {
                long d = i + 1 < vs.Count ? vs[i + 1].Time - vs[i].Time : frameDur;
                vDur[i] = Math.Max(1, d * VideoScale / 10000000L);
            }
            long videoTicks = vDur.Sum();
            long endTime = t0 + videoTicks * 10000000L / VideoScale;

            var aSamples = new List<Sample>();
            bool hasAudio = aac != null && rate > 0;
            if (hasAudio)
                foreach (var f in aac)
                    if (f.Time >= t0 && f.Time < endTime && f.Data != null && f.Data.Length > 0)
                        aSamples.Add(new Sample { Time = f.Time, Data = f.Data, Audio = true });
            hasAudio = aSamples.Count > 0;
            long audioDelayMs = hasAudio ? (aSamples[0].Time - t0) / 10000 : 0;

            // interleave by time
            var all = vs.Concat(aSamples).OrderBy(s => s.Time).ThenBy(s => s.Audio ? 1 : 0).ToList();
            long durMs = videoTicks * 1000 / VideoScale;

            var ftyp = new Box();
            ftyp.Begin("ftyp"); ftyp.Ascii("isom"); ftyp.U32(512); ftyp.Ascii("isomiso2avc1mp41"); ftyp.End();
            byte[] ftypBytes = ftyp.ToArray();

            // the index holds absolute file offsets: build it once to learn its size, then for real
            byte[] moov = null;
            for (int pass = 0; pass < 2; pass++)
            {
                long pos = ftypBytes.Length + (moov == null ? 0 : moov.Length) + 8;
                foreach (var s in all)
                {
                    if (pos > uint.MaxValue) throw new InvalidOperationException("Clip zu groß");
                    s.Offset = (uint)pos;
                    pos += s.Data.Length;
                }
                moov = Moov(vs, vDur, w, h, sps, pps, aSamples, rate, channels, durMs, audioDelayMs);
            }
            {
                long pos = ftypBytes.Length + moov.Length + 8;
                foreach (var s in all) { s.Offset = (uint)pos; pos += s.Data.Length; }
                moov = Moov(vs, vDur, w, h, sps, pps, aSamples, rate, channels, durMs, audioDelayMs);
            }

            long mdatSize = 8 + all.Sum(s => (long)s.Data.Length);
            string tmp = file + ".part";
            using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 20))
            {
                fs.Write(ftypBytes, 0, ftypBytes.Length);
                fs.Write(moov, 0, moov.Length);
                var head = new byte[] { (byte)(mdatSize >> 24), (byte)(mdatSize >> 16), (byte)(mdatSize >> 8), (byte)mdatSize, (byte)'m', (byte)'d', (byte)'a', (byte)'t' };
                fs.Write(head, 0, 8);
                foreach (var s in all) fs.Write(s.Data, 0, s.Data.Length);
            }
            File.Move(tmp, file);
            return durMs / 1000.0;
        }

        static byte[] Moov(List<Sample> vs, long[] vDur, int w, int h, byte[] sps, byte[] pps, List<Sample> aus, int rate, int channels, long durMs, long audioDelayMs)
        {
            var b = new Box();
            b.Begin("moov");

            b.Full("mvhd", 0, 0);
            b.U32(0); b.U32(0); b.U32(1000); b.U32((uint)durMs);
            b.U32(0x10000); b.U16(0x100); b.Zero(10);
            foreach (var m in Matrix) b.U32(m);
            b.Zero(24);
            b.U32(aus.Count > 0 ? 3u : 2u);
            b.End();

            // ----- video track -----
            b.Begin("trak");
            Tkhd(b, 1, durMs, 0, w, h);
            b.Begin("mdia");
            Mdhd(b, VideoScale, vDur.Sum());
            Hdlr(b, "vide", "Video");
            b.Begin("minf");
            b.Full("vmhd", 0, 1); b.U16(0); b.U16(0); b.U16(0); b.U16(0); b.End();
            Dinf(b);
            b.Begin("stbl");
            b.Full("stsd", 0, 0); b.U32(1);
            b.Begin("avc1");
            b.Zero(6); b.U16(1); b.U16(0); b.U16(0); b.Zero(12);
            b.U16(w); b.U16(h); b.U32(0x480000); b.U32(0x480000); b.U32(0); b.U16(1);
            b.Zero(32); b.U16(0x18); b.U16(0xFFFF);
            b.Begin("avcC");
            b.U8(1); b.U8(sps[1]); b.U8(sps[2]); b.U8(sps[3]); b.U8(0xFF);
            b.U8(0xE1); b.U16(sps.Length); b.Bytes(sps);
            b.U8(1); b.U16(pps.Length); b.Bytes(pps);
            b.End();
            b.End(); // avc1
            b.End(); // stsd
            Stts(b, vDur);
            var keys = new List<uint>();
            for (int i = 0; i < vs.Count; i++) if (vs[i].Key) keys.Add((uint)(i + 1));
            b.Full("stss", 0, 0); b.U32((uint)keys.Count); foreach (var k in keys) b.U32(k); b.End();
            Tables(b, vs);
            b.End(); b.End(); b.End(); b.End(); // stbl minf mdia trak

            // ----- audio track -----
            if (aus.Count > 0)
            {
                long aTicks = aus.Count * 1024L;
                long aMs = aTicks * 1000 / rate;
                b.Begin("trak");
                Tkhd(b, 2, audioDelayMs + aMs, 0x100, 0, 0);
                if (audioDelayMs > 0)
                {
                    // starts a little after the picture: an empty edit keeps both in step
                    b.Begin("edts");
                    b.Full("elst", 0, 0); b.U32(2);
                    b.U32((uint)audioDelayMs); b.I32(-1); b.U32(0x10000);
                    b.U32((uint)aMs); b.I32(0); b.U32(0x10000);
                    b.End(); b.End();
                }
                b.Begin("mdia");
                Mdhd(b, rate, aTicks);
                Hdlr(b, "soun", "Audio");
                b.Begin("minf");
                b.Full("smhd", 0, 0); b.U16(0); b.U16(0); b.End();
                Dinf(b);
                b.Begin("stbl");
                b.Full("stsd", 0, 0); b.U32(1);
                b.Begin("mp4a");
                b.Zero(6); b.U16(1); b.Zero(8);
                b.U16(channels); b.U16(16); b.U16(0); b.U16(0); b.U32((uint)rate << 16);
                byte[] asc = Asc(rate, channels);
                b.Full("esds", 0, 0);
                b.U8(0x03); b.U8(3 + 2 + 13 + 2 + asc.Length + 3); b.U16(2); b.U8(0);
                b.U8(0x04); b.U8(13 + 2 + asc.Length); b.U8(0x40); b.U8(0x15); b.U8(0); b.U16(0x1800); b.U32(160000); b.U32(160000);
                b.U8(0x05); b.U8(asc.Length); b.Bytes(asc);
                b.U8(0x06); b.U8(1); b.U8(2);
                b.End(); // esds
                b.End(); // mp4a
                b.End(); // stsd
                b.Full("stts", 0, 0); b.U32(1); b.U32((uint)aus.Count); b.U32(1024); b.End();
                Tables(b, aus);
                b.End(); b.End(); b.End(); b.End();
            }

            b.End(); // moov
            return b.ToArray();
        }

        static void Tkhd(Box b, int id, long durMs, int volume, int w, int h)
        {
            b.Full("tkhd", 0, 3);
            b.U32(0); b.U32(0); b.U32((uint)id); b.U32(0); b.U32((uint)durMs);
            b.Zero(8); b.U16(0); b.U16(0); b.U16(volume); b.U16(0);
            foreach (var m in Matrix) b.U32(m);
            b.U32((uint)w << 16); b.U32((uint)h << 16);
            b.End();
        }

        static void Mdhd(Box b, int scale, long dur)
        {
            b.Full("mdhd", 0, 0);
            b.U32(0); b.U32(0); b.U32((uint)scale); b.U32((uint)dur);
            b.U16(0x55C4); b.U16(0); // language "und"
            b.End();
        }

        static void Hdlr(Box b, string type, string name)
        {
            b.Full("hdlr", 0, 0);
            b.U32(0); b.Ascii(type); b.Zero(12); b.Ascii(name); b.U8(0);
            b.End();
        }

        static void Dinf(Box b)
        {
            b.Begin("dinf");
            b.Full("dref", 0, 0); b.U32(1);
            b.Full("url ", 0, 1); b.End();
            b.End(); b.End();
        }

        static void Stts(Box b, long[] durs)
        {
            var runs = new List<KeyValuePair<uint, uint>>();
            foreach (var d in durs)
            {
                if (runs.Count > 0 && runs[runs.Count - 1].Value == (uint)d) runs[runs.Count - 1] = new KeyValuePair<uint, uint>(runs[runs.Count - 1].Key + 1, (uint)d);
                else runs.Add(new KeyValuePair<uint, uint>(1, (uint)d));
            }
            b.Full("stts", 0, 0); b.U32((uint)runs.Count);
            foreach (var r in runs) { b.U32(r.Key); b.U32(r.Value); }
            b.End();
        }

        // sample-to-chunk (one sample per chunk), sizes and offsets
        static void Tables(Box b, List<Sample> s)
        {
            b.Full("stsc", 0, 0); b.U32(1); b.U32(1); b.U32(1); b.U32(1); b.End();
            b.Full("stsz", 0, 0); b.U32(0); b.U32((uint)s.Count); foreach (var x in s) b.U32((uint)x.Data.Length); b.End();
            b.Full("stco", 0, 0); b.U32((uint)s.Count); foreach (var x in s) b.U32(x.Offset); b.End();
        }

        // AudioSpecificConfig for AAC-LC
        static byte[] Asc(int rate, int channels)
        {
            int[] rates = { 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000 };
            int fi = Array.IndexOf(rates, rate);
            if (fi < 0) fi = 3;
            return new[] { (byte)((2 << 3) | (fi >> 1)), (byte)(((fi & 1) << 7) | (channels << 3)) };
        }

        static byte[] Slice(ArraySegment<byte> s) { var r = new byte[s.Count]; Buffer.BlockCopy(s.Array, s.Offset, r, 0, s.Count); return r; }

        static List<ArraySegment<byte>> SplitNals(byte[] a)
        {
            var res = new List<ArraySegment<byte>>();
            int start = -1, i = 0;
            while (i + 2 < a.Length)
            {
                if (a[i] == 0 && a[i + 1] == 0 && a[i + 2] == 1)
                {
                    if (start >= 0)
                    {
                        int end = i;
                        while (end > start && a[end - 1] == 0) end--; // trailing zero of a 4-byte start code
                        if (end > start) res.Add(new ArraySegment<byte>(a, start, end - start));
                    }
                    start = i + 3;
                    i += 3;
                }
                else i++;
            }
            if (start >= 0 && start < a.Length) res.Add(new ArraySegment<byte>(a, start, a.Length - start));
            return res;
        }

        // Length in seconds plus picture size, read from the index (works for MP4s from other programs too).
        public static double ReadInfo(string file, out int w, out int h)
        {
            w = h = 0;
            double dur = 0;
            using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                long pos = 0, len = fs.Length;
                while (pos + 8 <= len)
                {
                    fs.Position = pos;
                    var hd = new byte[16];
                    fs.Read(hd, 0, 16);
                    long size = Be32(hd, 0);
                    string type = Encoding.ASCII.GetString(hd, 4, 4);
                    int headLen = 8;
                    if (size == 1) { size = (Be32(hd, 8) << 32) | Be32(hd, 12); headLen = 16; }
                    else if (size == 0) size = len - pos;
                    if (size < headLen) break;
                    if (type == "moov")
                    {
                        if (size > 64 << 20) break;
                        var moov = new byte[size - headLen];
                        fs.Position = pos + headLen;
                        fs.Read(moov, 0, moov.Length);
                        int mv = Find(moov, "mvhd");
                        if (mv >= 0)
                        {
                            int v = moov[mv + 4];
                            long scale = v == 1 ? Be32(moov, mv + 24) : Be32(moov, mv + 16);
                            long d = v == 1 ? (Be32(moov, mv + 28) << 32 | Be32(moov, mv + 32)) : Be32(moov, mv + 20);
                            if (scale > 0) dur = d / (double)scale;
                        }
                        // first track with a picture size
                        for (int at = 0; (at = Find(moov, "tkhd", at)) >= 0; at += 4)
                        {
                            int v = moov[at + 4];
                            int off = at + (v == 1 ? 92 : 80); // width/height after times, matrix …
                            if (off + 8 > moov.Length) break;
                            int tw = (int)(Be32(moov, off) >> 16), th = (int)(Be32(moov, off + 4) >> 16);
                            if (tw > 0 && th > 0) { w = tw; h = th; break; }
                        }
                        break;
                    }
                    pos += size;
                }
            }
            return Math.Round(dur, 2);
        }

        static long Be32(byte[] b, int i) { return ((long)b[i] << 24) | ((long)b[i + 1] << 16) | ((long)b[i + 2] << 8) | b[i + 3]; }

        static int Find(byte[] b, string type, int from = 0)
        {
            byte c0 = (byte)type[0], c1 = (byte)type[1], c2 = (byte)type[2], c3 = (byte)type[3];
            for (int i = Math.Max(from, 4); i + 4 <= b.Length; i++)
                if (b[i] == c0 && b[i + 1] == c1 && b[i + 2] == c2 && b[i + 3] == c3) return i;
            return -1;
        }
    }
}
