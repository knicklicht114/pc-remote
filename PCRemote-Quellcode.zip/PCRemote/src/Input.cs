using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

namespace PCRemote
{
    // Keyboard and mouse injection via SendInput (scan codes included so games and hotkey hooks see the keys).
    static class Input
    {
        [StructLayout(LayoutKind.Sequential)]
        struct MOUSEINPUT { public int dx; public int dy; public int mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }

        [StructLayout(LayoutKind.Sequential)]
        struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }

        [StructLayout(LayoutKind.Explicit)]
        struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }

        [StructLayout(LayoutKind.Sequential)]
        struct INPUT { public uint type; public InputUnion u; }

        [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] inputs, int size);
        [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint mapType);

        const uint KEYEVENTF_EXTENDEDKEY = 0x1, KEYEVENTF_KEYUP = 0x2, KEYEVENTF_UNICODE = 0x4;
        const uint MOUSE_MOVE = 0x1, MOUSE_WHEEL = 0x800, MOUSE_HWHEEL = 0x1000;
        static readonly object L = new object();

        static void Send(params INPUT[] arr)
        {
            SendInput((uint)arr.Length, arr, Marshal.SizeOf(typeof(INPUT)));
        }

        static bool IsExtended(ushort vk)
        {
            return (vk >= 0x21 && vk <= 0x28) || vk == 0x2C || vk == 0x2D || vk == 0x2E || vk == 0x5B || vk == 0x5C ||
                   vk == 0x5D || vk == 0x6F || vk == 0x90 || vk == 0xA3 || vk == 0xA5 || (vk >= 0xA6 && vk <= 0xB7);
        }

        static INPUT Key(ushort vk, bool up)
        {
            var i = new INPUT();
            i.type = 1;
            i.u.ki.wVk = vk;
            i.u.ki.wScan = (ushort)MapVirtualKey(vk, 0);
            i.u.ki.dwFlags = (up ? KEYEVENTF_KEYUP : 0) | (IsExtended(vk) ? KEYEVENTF_EXTENDEDKEY : 0);
            return i;
        }

        public static void Tap(ushort vk)
        {
            lock (L)
            {
                Send(Key(vk, false));
                Thread.Sleep(25);
                Send(Key(vk, true));
            }
        }

        public static void Hotkey(string combo)
        {
            var vks = new List<ushort>();
            foreach (string part in (combo ?? "").Split('+'))
            {
                string p = part.Trim();
                if (p.Length > 0) vks.Add(Vk(p));
            }
            if (vks.Count == 0) throw new ArgumentException("Keine Taste angegeben");
            lock (L)
            {
                foreach (var vk in vks) { Send(Key(vk, false)); Thread.Sleep(15); }
                Thread.Sleep(45);
                for (int i = vks.Count - 1; i >= 0; i--) { Send(Key(vks[i], true)); Thread.Sleep(10); }
            }
        }

        public static void Text(string s)
        {
            if (string.IsNullOrEmpty(s)) return;
            lock (L)
            {
                foreach (char c in s.Replace("\r\n", "\n"))
                {
                    if (c == '\n') { Tap(0x0D); continue; }
                    if (c == '\t') { Tap(0x09); continue; }
                    if (c == '\b') { Tap(0x08); continue; }
                    var down = new INPUT();
                    down.type = 1;
                    down.u.ki.wScan = c;
                    down.u.ki.dwFlags = KEYEVENTF_UNICODE;
                    var up = down;
                    up.u.ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
                    Send(down, up);
                    Thread.Sleep(3);
                }
            }
        }

        static void SendMouse(int dx, int dy, int data, uint flags)
        {
            var i = new INPUT();
            i.type = 0;
            i.u.mi.dx = dx;
            i.u.mi.dy = dy;
            i.u.mi.mouseData = data;
            i.u.mi.dwFlags = flags;
            Send(i);
        }

        static void ButtonFlags(string btn, out uint down, out uint up)
        {
            switch ((btn ?? "left").ToLowerInvariant())
            {
                case "right": down = 0x08; up = 0x10; break;
                case "middle": down = 0x20; up = 0x40; break;
                default: down = 0x02; up = 0x04; break;
            }
        }

        public static void Click(string btn, bool dbl)
        {
            uint d, u;
            ButtonFlags(btn, out d, out u);
            lock (L)
            {
                SendMouse(0, 0, 0, d); Thread.Sleep(15); SendMouse(0, 0, 0, u);
                if (dbl) { Thread.Sleep(40); SendMouse(0, 0, 0, d); Thread.Sleep(15); SendMouse(0, 0, 0, u); }
            }
        }

        public static void Mouse(Dictionary<string, object> a)
        {
            int dx = (int)Math.Round(J.Num(a, "dx")), dy = (int)Math.Round(J.Num(a, "dy"));
            if (dx != 0 || dy != 0) SendMouse(dx, dy, 0, MOUSE_MOVE);
            int sy = (int)Math.Round(J.Num(a, "sy"));
            if (sy != 0) SendMouse(0, 0, sy, MOUSE_WHEEL);
            int sx = (int)Math.Round(J.Num(a, "sx"));
            if (sx != 0) SendMouse(0, 0, sx, MOUSE_HWHEEL);

            uint d, u;
            string down = J.Str(a, "down");
            if (down != null) { ButtonFlags(down, out d, out u); SendMouse(0, 0, 0, d); }
            string up = J.Str(a, "up");
            if (up != null) { ButtonFlags(up, out d, out u); SendMouse(0, 0, 0, u); }
            string click = J.Str(a, "click");
            if (click != null) Click(click, J.Bool(a, "double"));
        }

        public static ushort MediaVk(string k)
        {
            switch ((k ?? "").ToLowerInvariant())
            {
                case "next": return 0xB0;
                case "prev": case "previous": return 0xB1;
                case "stop": return 0xB2;
                case "volup": return 0xAF;
                case "voldown": return 0xAE;
                case "mute": return 0xAD;
                default: return 0xB3;
            }
        }

        public static ushort Vk(string name)
        {
            string k = name.Trim().ToLowerInvariant();
            if (k.Length == 1)
            {
                char c = k[0];
                if (c >= 'a' && c <= 'z') return (ushort)(c - 'a' + 0x41);
                if (c >= '0' && c <= '9') return (ushort)c;
                switch (c)
                {
                    case ',': return 0xBC;
                    case '.': return 0xBE;
                    case '-': return 0xBD;
                    case '#': return 0xBF;
                    case '<': return 0xE2;
                    case '^': return 0xDC;
                    case '`': return 0xC0;
                }
            }
            int n;
            if (k.Length >= 2 && k[0] == 'f' && int.TryParse(k.Substring(1), out n) && n >= 1 && n <= 24) return (ushort)(0x70 + n - 1);
            if (k.StartsWith("num") && k.Length == 4 && char.IsDigit(k[3])) return (ushort)(0x60 + (k[3] - '0'));
            if (k.StartsWith("vk:") || k.StartsWith("0x"))
            {
                string hex = k.StartsWith("vk:") ? k.Substring(3) : k;
                if (hex.StartsWith("0x")) hex = hex.Substring(2);
                return Convert.ToUInt16(hex, 16);
            }
            switch (k)
            {
                case "ctrl": case "control": case "strg": case "lctrl": return 0xA2;
                case "rctrl": return 0xA3;
                case "shift": case "umschalt": case "lshift": return 0xA0;
                case "rshift": return 0xA1;
                case "alt": case "lalt": return 0xA4;
                case "altgr": case "ralt": return 0xA5;
                case "win": case "windows": case "super": case "meta": case "cmd": return 0x5B;
                case "enter": case "return": case "eingabe": return 0x0D;
                case "esc": case "escape": return 0x1B;
                case "tab": return 0x09;
                case "space": case "leertaste": return 0x20;
                case "backspace": case "back": case "bksp": return 0x08;
                case "delete": case "del": case "entf": return 0x2E;
                case "insert": case "ins": case "einfg": return 0x2D;
                case "home": case "pos1": return 0x24;
                case "end": case "ende": return 0x23;
                case "pageup": case "pgup": case "bildauf": return 0x21;
                case "pagedown": case "pgdn": case "bildab": return 0x22;
                case "up": return 0x26;
                case "down": return 0x28;
                case "left": return 0x25;
                case "right": return 0x27;
                case "printscreen": case "print": case "prtsc": case "druck": return 0x2C;
                case "pause": return 0x13;
                case "capslock": case "caps": return 0x14;
                case "numlock": return 0x90;
                case "scrolllock": return 0x91;
                case "menu": case "apps": case "context": return 0x5D;
                case "volumeup": case "volup": return 0xAF;
                case "volumedown": case "voldown": return 0xAE;
                case "volumemute": case "mute": return 0xAD;
                case "playpause": case "play": return 0xB3;
                case "nexttrack": case "next": return 0xB0;
                case "prevtrack": case "prev": return 0xB1;
                case "mediastop": case "stop": return 0xB2;
                case "plus": return 0xBB;
                case "minus": return 0xBD;
                case "comma": return 0xBC;
                case "period": case "dot": return 0xBE;
                case "multiply": return 0x6A;
                case "add": return 0x6B;
                case "subtract": return 0x6D;
                case "divide": return 0x6F;
                case "decimal": return 0x6E;
            }
            throw new ArgumentException("Unbekannte Taste: " + name);
        }
    }
}
