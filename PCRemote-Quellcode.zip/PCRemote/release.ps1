# Builds everything for publishing:
#   dist\PCRemote-Setup.exe, dist\PCRemote-Portable.zip, dist\PCRemote-Quellcode.zip
#   and the folder for web hosting (default: ..\PCRemote-Online) with website, downloads and a clean copy of the app.
# Only a fixed list of program files is packed - your own data (PIN, paired phones, Spotify login, layout, log) never gets in.
# Works while PC Remote is running (builds into dist\, not over the running exe).
#
#   powershell -ExecutionPolicy Bypass -File release.ps1 [-Out <folder>] [-Publish]
#
# -Publish also puts it on GitHub: a release "vX.Y" with the downloads (the website's buttons always point to the
# newest release) and the website files for GitHub Pages. Uses tools\gh (GitHub CLI); the first time it asks you
# to log in once with a code in the browser.

param(
  [string]$Out = (Join-Path (Split-Path $PSScriptRoot -Parent) 'PCRemote-Online'),
  [string]$Repo = 'knicklicht114/pc-remote',  # website (GitHub Pages) + downloads (Releases); empty = plain web space
  [switch]$Publish
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root = $PSScriptRoot
$ver = [regex]::Match((Get-Content "$root\src\Program.cs" -Raw), 'Version = "([^"]+)"').Groups[1].Value
$FW = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319"
$WM = "$env:WINDIR\System32\WinMetadata"
$dist = Join-Path $root 'dist'
$stage = Join-Path $dist 'stage'
Write-Host "PC Remote $ver" -ForegroundColor Cyan

# ZipFile.CreateFromDirectory on .NET Framework writes "\" into entry names; the ZIP standard (and other OSes) want "/"
function Zip($dir, $zip) {
  if (Test-Path $zip) { Remove-Item $zip -Force }
  $base = (Resolve-Path $dir).Path.TrimEnd('\') + '\'
  $fs = [IO.File]::Open($zip, [IO.FileMode]::CreateNew)
  $za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
  try {
    foreach ($f in Get-ChildItem $dir -Recurse -File) {
      $name = $f.FullName.Substring($base.Length).Replace('\', '/')
      [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($za, $f.FullName, $name, [IO.Compression.CompressionLevel]::Optimal)
    }
  } finally { $za.Dispose(); $fs.Dispose() }
}
function Size($file) {
  $mb = (Get-Item $file).Length / 1MB
  if ($mb -lt 1) { return ('{0:0} KB' -f ((Get-Item $file).Length / 1KB)) }
  return ('{0:0.0} MB' -f $mb).Replace('.', ',')
}

if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }
New-Item -ItemType Directory -Force "$stage\web\vendor" | Out-Null

# 1) the program
Write-Host '1/5 Programm bauen'
& "$FW\csc.exe" /nologo /target:winexe /platform:x64 /optimize+ /unsafe "/out:$stage\PCRemote.exe" "/win32icon:$root\app.ico" `
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Web.Extensions.dll `
  "/r:$FW\System.Runtime.dll" "/r:$FW\WPF\UIAutomationClient.dll" "/r:$FW\WPF\UIAutomationTypes.dll" "/r:$FW\WPF\WindowsBase.dll" `
  "/r:$WM\Windows.Foundation.winmd" "/r:$WM\Windows.Media.winmd" "/r:$WM\Windows.Storage.winmd" `
  "/r:$root\lib\Microsoft.Web.WebView2.Core.dll" "/r:$root\lib\Microsoft.Web.WebView2.WinForms.dll" "$root\src\*.cs"
if ($LASTEXITCODE -ne 0) { throw 'Das Programm konnte nicht gebaut werden.' }

# 2) exactly these files belong to the program
Copy-Item "$root\lib\*.dll" $stage
Copy-Item "$root\app.ico" $stage
foreach ($f in 'index.html', 'manifest.json', 'app.js', 'style.css', 'vendor\jmuxer.min.js') { Copy-Item "$root\web\$f" "$stage\web\$f" }

# 3) installer with the program inside
Write-Host '2/5 Installer bauen'
Zip $stage "$dist\payload.zip"
[IO.File]::WriteAllText("$dist\version.txt", $ver)
# name, description and version in the setup's file properties
$fv = (($ver -split '\.') + @('0', '0', '0'))[0..3] -join '.'
[IO.File]::WriteAllText("$dist\SetupInfo.cs", @"
using System.Reflection;
[assembly: AssemblyTitle("PC Remote Setup")]
[assembly: AssemblyDescription("Installiert PC Remote")]
[assembly: AssemblyCompany("PC Remote")]
[assembly: AssemblyProduct("PC Remote")]
[assembly: AssemblyCopyright("(c) $(Get-Date -Format yyyy) PC Remote")]
[assembly: AssemblyVersion("$fv")]
[assembly: AssemblyFileVersion("$fv")]
"@)
& "$FW\csc.exe" /nologo /target:winexe /platform:anycpu /optimize+ "/out:$dist\PCRemote-Setup.exe" "/win32icon:$root\app.ico" `
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "/r:$FW\System.IO.Compression.dll" "/r:$FW\System.IO.Compression.FileSystem.dll" `
  "/resource:$dist\payload.zip,payload.zip" "/resource:$dist\version.txt,version.txt" "$root\installer\Setup.cs" "$dist\SetupInfo.cs"
if ($LASTEXITCODE -ne 0) { throw 'Der Installer konnte nicht gebaut werden.' }

# 4) portable zip and source zip
Write-Host '3/5 ZIP-Archive'
New-Item -ItemType Directory -Force "$dist\portable" | Out-Null
Copy-Item $stage "$dist\portable\PC Remote" -Recurse
Zip "$dist\portable" "$dist\PCRemote-Portable.zip"

$src = "$dist\source\PCRemote"
New-Item -ItemType Directory -Force "$src\web\vendor" | Out-Null
foreach ($d in 'src', 'installer', 'lib', 'website') { Copy-Item "$root\$d" "$src\$d" -Recurse }
foreach ($f in 'index.html', 'manifest.json', 'app.js', 'style.css', 'vendor\jmuxer.min.js') { Copy-Item "$root\web\$f" "$src\web\$f" }
foreach ($f in 'app.ico', 'build.bat', 'release.ps1') { Copy-Item "$root\$f" "$src\$f" }
Zip "$dist\source" "$dist\PCRemote-Quellcode.zip"

# 5) folder for web hosting - flat on purpose: many hosters' upload forms drop sub-folders,
#    so design and logos live inside the pages and the downloads sit right next to them.
Write-Host "4/5 Online-Ordner: $Out"
New-Item -ItemType Directory -Force $Out | Out-Null
foreach ($d in 'app', 'download', 'assets') { if (Test-Path "$Out\$d") { Remove-Item "$Out\$d" -Recurse -Force } }
Copy-Item "$dist\PCRemote-Setup.exe", "$dist\PCRemote-Portable.zip", "$dist\PCRemote-Quellcode.zip" $Out
# for Node.js hosts (game-server panels run "npm install" + "node index.js"); plain web space just ignores them
Copy-Item "$root\website\server\index.js", "$root\website\server\db.js" $Out
$semver = (($ver -split '\.') + @('0', '0'))[0..2] -join '.'
[IO.File]::WriteAllText("$Out\package.json", ([IO.File]::ReadAllText("$root\website\server\package.json") -replace '"version": "[^"]*"', ('"version": "' + $semver + '"')))

$logos = "$dist\logos"
New-Item -ItemType Directory -Force $logos | Out-Null
foreach ($s in 64, 256) { Start-Process "$stage\PCRemote.exe" -ArgumentList '--make-png', "`"$logos\logo-$s.png`"", $s -Wait }
$css = [IO.File]::ReadAllText("$root\website\style.css")
$logo64 = 'data:image/png;base64,' + [Convert]::ToBase64String([IO.File]::ReadAllBytes("$logos\logo-64.png"))
$logo256 = 'data:image/png;base64,' + [Convert]::ToBase64String([IO.File]::ReadAllBytes("$logos\logo-256.png"))
function Inline([string]$html) {
  $m = [regex]::Match($html, '<link rel="stylesheet" href="assets/style\.css[^"]*">')
  if ($m.Success) { $html = $html.Replace($m.Value, "<style>`n" + $css + "</style>") }
  return $html.Replace('assets/logo-64.png', $logo64).Replace('assets/logo-256.png', $logo256)
}
$utf8 = New-Object Text.UTF8Encoding $false

# Windows Defender checks every download before it goes online; the page only says "geprueft" if that really happened
$mp = "$env:ProgramFiles\Windows Defender\MpCmdRun.exe"
$scanned = $false
if (Test-Path $mp) {
  foreach ($f in "$dist\PCRemote-Setup.exe", "$dist\PCRemote-Portable.zip", "$dist\PCRemote-Quellcode.zip") {
    $o = & $mp -Scan -ScanType 3 -File $f -DisableRemediation | Out-String
    if ($o -notmatch 'found no threats') { Write-Host $o; throw "Windows Defender meldet etwas in $(Split-Path $f -Leaf) - nicht hochladen!" }
  }
  $scanned = $true
} else { Write-Host '  Windows Defender nicht gefunden - Download-Pruefung uebersprungen' -ForegroundColor Yellow }

$html = [IO.File]::ReadAllText("$root\website\index.html", [Text.Encoding]::UTF8).
  Replace('{{VERSION}}', $ver).Replace('{{SETUP_SIZE}}', (Size "$dist\PCRemote-Setup.exe")).
  Replace('{{PORTABLE_SIZE}}', (Size "$dist\PCRemote-Portable.zip")).Replace('{{SOURCE_SIZE}}', (Size "$dist\PCRemote-Quellcode.zip")).
  Replace('{{DATE}}', (Get-Date -Format 'dd.MM.yyyy')).Replace('{{YEAR}}', (Get-Date -Format 'yyyy'))
# downloads come from the newest GitHub release (a new version needs no new links); without a repo they sit next to the page
if ($Repo) {
  $html = $html.Replace('{{DL}}', "https://github.com/$Repo/releases/latest/download/").
    Replace('{{GITHUB_LINK}}', "<a href=`"https://github.com/$Repo`">GitHub</a>")
} else { $html = $html.Replace('{{DL}}', '').Replace('{{GITHUB_LINK}}', '') }
if (-not $scanned) { $html = [regex]::Replace($html, '(?s)\s*<div><svg class="i"><use href="#i-check"/></svg><span><b>Gepr.ft:</b>.*?</div>', '') }
[IO.File]::WriteAllText("$Out\index.html", (Inline $html), $utf8)
# legal pages are created once and then yours to edit - only their design link gets inlined, the text stays
foreach ($p in 'impressum.html', 'datenschutz.html') {
  if (-not (Test-Path "$Out\$p")) { Copy-Item "$root\website\$p" "$Out\$p" }
  [IO.File]::WriteAllText("$Out\$p", (Inline ([IO.File]::ReadAllText("$Out\$p", [Text.Encoding]::UTF8))), $utf8)
}

@"
PC Remote $ver - Dateien fuer das Webhosting
=============================================

ALLE Dateien aus diesem Ordner (ausser dieser LIESMICH.txt) direkt in das
Hauptverzeichnis deines Webspace hochladen - oft heisst es "htdocs",
"public_html" oder "www". Nicht den Ordner PCRemote-Online selbst hochladen,
sondern seinen Inhalt. Es gibt keine Unterordner mehr.

  index.html              Startseite (Design und Logo stecken mit drin)
  impressum.html          VOR DEM HOCHLADEN AUSFUELLEN (Name, Anschrift, E-Mail)
  datenschutz.html        VOR DEM HOCHLADEN PRUEFEN (Hosting-Anbieter eintragen)
  PCRemote-Setup.exe      Installer
  PCRemote-Portable.zip   Das Programm zum Entpacken (dasselbe wie im Installer)
  PCRemote-Quellcode.zip  Quellcode
  index.js, package.json  Nur fuer Node.js-Hosting (siehe unten)

NODE.JS-HOSTING (Panel mit Konsole, Ordner /home/container, z. B. Pterodactyl):
  Alle Dateien inklusive index.js und package.json hochladen und den Server
  starten. Startdatei ist index.js, Pakete braucht es keine. Die Seite ist dann
  unter der IP und dem Port erreichbar, die das Panel anzeigt.

Erlaubt dein Hoster keine .exe-Dateien, lass sie einfach weg: die Startseite
merkt das und bietet dann automatisch die ZIP-Datei an.

Kann dein Datei-Manager ZIP-Dateien entpacken, geht es noch einfacher:
dist\PCRemote-Website.zip hochladen und dort entpacken.

Neue Version: release.ps1 im PC-Remote-Ordner ausfuehren und die Dateien
erneut hochladen. Dein Text in Impressum und Datenschutz bleibt erhalten.

Enthalten sind nur Programmdateien - keine PIN, keine verbundenen Geraete,
keine Spotify-Anmeldung, kein Deck-Layout und kein Log.
"@ | Set-Content "$Out\LIESMICH.txt" -Encoding UTF8

New-Item -ItemType Directory -Force "$dist\website" | Out-Null
Get-ChildItem $Out -File | Where-Object Name -ne 'LIESMICH.txt' | Copy-Item -Destination "$dist\website"
Zip "$dist\website" "$dist\PCRemote-Website.zip"
# safety net: none of your own files may end up in the upload
Write-Host '5/5 Pruefen'
$private = 'config.json', 'devices.json', 'spotify.json', 'layout.json', 'addons.json', 'clips.json', 'pcremote.log', '*.bak', 'layout.before-display.json', '_h.html'
$found = foreach ($p in $private) { Get-ChildItem $Out, $dist -Recurse -Force -Filter $p -ErrorAction SilentlyContinue }
foreach ($z in Get-ChildItem $Out, $dist -Recurse -Filter *.zip) {
  $zz = [IO.Compression.ZipFile]::OpenRead($z.FullName)
  try { $found += $zz.Entries | Where-Object { $n = $_.Name; $private | Where-Object { $n -like $_ } } | ForEach-Object { "$($z.Name): $($_.FullName)" } } finally { $zz.Dispose() }
}
if ($found) { $found | ForEach-Object { Write-Host "  PRIVAT: $_" -ForegroundColor Red }; throw 'Persoenliche Dateien gefunden - nichts hochladen!' }

# 6) GitHub: release with the downloads + website for GitHub Pages
if ($Publish) {
  if (-not $Repo) { throw '-Publish braucht -Repo (z. B. name/pc-remote)' }
  Write-Host "6/6 GitHub: $Repo"
  $ErrorActionPreference = 'Continue' # gh writes progress to stderr; failures are checked via exit codes
  $gh = "$root\tools\gh\bin\gh.exe"
  if (-not (Test-Path $gh)) { $c = Get-Command gh -ErrorAction SilentlyContinue; if ($c) { $gh = $c.Source } else { throw 'GitHub CLI fehlt: tools\gh\bin\gh.exe' } }
  $env:GH_NO_UPDATE_NOTIFIER = '1'
  & $gh auth status *> $null
  if ($LASTEXITCODE -ne 0) {
    Write-Host '  Einmal bei GitHub anmelden: Code im Browser eingeben ...' -ForegroundColor Yellow
    & $gh auth login --web --hostname github.com --git-protocol https
    if ($LASTEXITCODE -ne 0) { throw 'GitHub-Anmeldung fehlgeschlagen' }
  }
  $owner = $Repo.Split('/')[0]; $name = $Repo.Split('/')[1]
  $pages = "$owner.github.io/$name"
  function Fill([string]$t) { return $t.Replace('{{VERSION}}', $ver).Replace('{{REPO}}', $Repo).Replace('{{PAGES}}', $pages) }

  # the version with its downloads
  $tag = "v$ver"
  $assets = "$dist\PCRemote-Setup.exe", "$dist\PCRemote-Portable.zip", "$dist\PCRemote-Quellcode.zip"
  [IO.File]::WriteAllText("$dist\release-notes.md", (Fill ([IO.File]::ReadAllText("$root\website\release-notes.md", [Text.Encoding]::UTF8))), $utf8)
  & $gh release view $tag --repo $Repo *> $null
  if ($LASTEXITCODE -eq 0) {
    & $gh release upload $tag $assets --repo $Repo --clobber
    & $gh release edit $tag --repo $Repo --notes-file "$dist\release-notes.md" --latest *> $null
    Write-Host "  Version $tag aktualisiert"
  } else {
    & $gh release create $tag $assets --repo $Repo --target main --title "PC Remote $ver" --notes-file "$dist\release-notes.md" --latest
    Write-Host "  Version $tag erstellt"
  }
  if ($LASTEXITCODE -ne 0) { throw "GitHub-Release $tag fehlgeschlagen" }

  # website files: only what changed. Impressum/Datenschutz only if missing - you edit those on GitHub.
  [IO.File]::WriteAllText("$dist\README.md", (Fill ([IO.File]::ReadAllText("$root\website\README.md", [Text.Encoding]::UTF8))), $utf8)
  [IO.File]::WriteAllText("$dist\.nojekyll", '', $utf8)
  $site = @(Get-ChildItem $Out -File | Where-Object { 'LIESMICH.txt', 'index.js', 'db.js', 'package.json', 'notify.json', 'notify-data.json' -notcontains $_.Name }) +
          @(Get-Item "$dist\README.md", "$root\website\screenshot.png") + @(Get-Item "$dist\.nojekyll" -Force)
  $sha1 = [Security.Cryptography.SHA1]::Create()
  foreach ($f in $site) {
    $bytes = [IO.File]::ReadAllBytes($f.FullName)
    $remote = $null
    $json = & $gh api "repos/$Repo/contents/$($f.Name)" 2> $null
    if ($LASTEXITCODE -eq 0) { $remote = $json | ConvertFrom-Json }
    if ($remote -and 'impressum.html', 'datenschutz.html' -contains $f.Name) { continue }
    # git's blob hash: same hash = same content, no upload needed
    $head = [Text.Encoding]::ASCII.GetBytes("blob $($bytes.Length)`0")
    $blob = (($sha1.ComputeHash([byte[]]($head + $bytes))) | ForEach-Object { $_.ToString('x2') }) -join ''
    if ($remote -and $remote.sha -eq $blob) { continue }
    $body = @{ message = "Website $ver`: $($f.Name)"; content = [Convert]::ToBase64String($bytes); branch = 'main' }
    if ($remote) { $body.sha = $remote.sha }
    [IO.File]::WriteAllText("$dist\put.json", ($body | ConvertTo-Json -Compress), $utf8)
    & $gh api -X PUT "repos/$Repo/contents/$($f.Name)" --input "$dist\put.json" > $null
    if ($LASTEXITCODE -ne 0) { throw "Hochladen von $($f.Name) fehlgeschlagen" }
    Write-Host "  hochgeladen: $($f.Name)"
  }
  Remove-Item "$dist\put.json" -ErrorAction SilentlyContinue
  $ErrorActionPreference = 'Stop'
  Write-Host "  Website: https://$pages/  (GitHub braucht ca. 1 Minute)" -ForegroundColor Cyan
}

Write-Host ''
Write-Host "Fertig. Setup: $(Size "$dist\PCRemote-Setup.exe") | Portable: $(Size "$dist\PCRemote-Portable.zip")" -ForegroundColor Green
Write-Host "Online-Ordner: $Out"
