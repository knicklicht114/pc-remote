// PC Remote website for Node.js hosts (e.g. Pterodactyl panels: "npm install", then "node index.js").
// No packages needed. Serves the pages and downloads in this folder - nothing else, not even itself -
// and writes a readable log to the console: every visit, every download (finished or cancelled), errors, stats.
'use strict';

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 8080);
// always all interfaces: in panel containers the public SERVER_IP isn't a local address (only the port is forwarded)
const HOST = '0.0.0.0';
const VERSION = (() => { try { return require('./package.json').version; } catch (e) { return '?'; } })();
// The website moved to GitHub Pages (HTTPS - Chrome blocked this plain-HTTP address). While this is set, every
// visit is sent there: "/" to the start page, an old download link straight to the same file. Empty = serve the files here.
const MOVED_TO = (process.env.MOVED_TO !== undefined ? process.env.MOVED_TO : 'https://knicklicht114.github.io/pc-remote/').replace(/\/?$/, '/');

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.exe': 'application/vnd.microsoft.portable-executable',
  '.zip': 'application/zip',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.css': 'text/css; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8'
};
const PRIVATE = new Set(['index.js', 'package.json', 'package-lock.json', 'liesmich.txt']);
const DOWNLOADS = ['PCRemote-Setup.exe', 'PCRemote-Portable.zip', 'PCRemote-Quellcode.zip'];

// ---------- log ----------

const COLOR = !process.env.NO_COLOR;
const paint = code => s => COLOR ? '\x1b[' + code + 'm' + s + '\x1b[0m' : String(s);
const c = { dim: paint('2'), bold: paint('1'), red: paint('31'), green: paint('32'), yellow: paint('33'), blue: paint('34'), magenta: paint('35'), cyan: paint('36') };

const two = n => String(n).padStart(2, '0');
function stamp() {
  const d = new Date();
  return c.dim(two(d.getDate()) + '.' + two(d.getMonth() + 1) + '. ' + two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds()));
}
const log = (icon, text) => console.log(stamp() + ' ' + icon + ' ' + text);

function size(b) {
  if (b >= 1048576) return (b / 1048576).toFixed(1).replace('.', ',') + ' MB';
  if (b >= 1024) return Math.round(b / 1024) + ' KB';
  return b + ' B';
}

// visitor address, shortened for privacy (last part hidden) - enough to tell visitors apart
function who(req) {
  let ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?').split(',')[0].trim().replace(/^::ffff:/, '');
  if (/^\d+\.\d+\.\d+\.\d+$/.test(ip)) ip = ip.replace(/\.\d+$/, '.x');
  else if (ip.includes(':')) ip = ip.split(':').slice(0, 3).join(':') + ':…';
  return ip;
}

// "Chrome · Windows" instead of the whole user agent
function agent(req) {
  const ua = String(req.headers['user-agent'] || '');
  if (!ua) return 'unbekannt';
  if (/bot|crawl|spider|slurp|curl|wget|python|scan/i.test(ua)) return 'Bot/Tool';
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\/|Opera/.test(ua) ? 'Opera' : /SamsungBrowser/.test(ua) ? 'Samsung Internet'
    : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone/iPad'
    : /Mac OS X/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '?';
  return browser + ' · ' + os;
}

const stats = { pages: 0, started: 0, finished: 0, cancelled: 0, notFound: 0, errors: 0, visitors: new Set() };

// ---------- server ----------

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({ 'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff' }, headers || {}));
  res.end(body);
}

function notFound(res) {
  send(res, 404, '<!doctype html><meta charset="utf-8"><title>Nicht gefunden</title>' +
    '<body style="font-family:system-ui;background:#08090d;color:#eef0f7;display:grid;place-items:center;height:100vh;margin:0">' +
    '<div style="text-align:center"><h1>404</h1><p>Diese Seite gibt es nicht.</p><a style="color:#22d3ee" href="/">Zur Startseite</a></div>');
}

// ---------- new-app notifications (opt-in, anonymous) ----------
// PC Remote installs may send names of unknown apps (only names, nothing personal, only if the user agreed).
// New ones are stored and the admin gets a WhatsApp via CallMeBot; the admin confirms them on the /admin page.

const DATA_FILE = path.join(ROOT, 'notify-data.json');
let DATA = (() => { try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { return null; } })()
  || { adminKey: crypto.randomBytes(12).toString('hex'), pending: {}, known: {}, ignored: {} };
if (!DATA.tokenSecret) DATA.tokenSecret = crypto.randomBytes(24).toString('hex'); // signs account login tokens
function saveData() { try { fs.writeFileSync(DATA_FILE, JSON.stringify(DATA, null, 2)); } catch (e) { log(c.red('!'), 'notify speichern: ' + e.message); } }
saveData();

// a stateless login token: username|role|expiry signed with the server secret, so it can be checked later without a session store
function makeToken(acc) {
  const payload = acc.username + '|' + acc.role + '|' + (Date.now() + 30 * 24 * 3600 * 1000);
  const sig = crypto.createHmac('sha256', DATA.tokenSecret).update(payload).digest('base64').replace(/[+/=]/g, m => ({ '+': '-', '/': '_', '=': '' }[m]));
  return Buffer.from(payload).toString('base64').replace(/=+$/, '') + '.' + sig;
}

// Settings can come from a notify.json file next to this server (easy to upload on a panel) or from env vars.
const CONF = (() => { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'notify.json'), 'utf8')); } catch (e) { return {}; } })();
const conf = (key, env) => CONF[key] || process.env[env] || '';
const PUBLIC = conf('public', 'PUBLIC_URL') || (process.env.SERVER_IP ? 'http://' + process.env.SERVER_IP + ':' + PORT : '');

// Accounts database (MySQL). Config in notify.json "db": {host,port,user,password,database} or env MYSQL_*.
let db = null;
try { db = require('./db.js'); } catch (e) { }
if (db) {
  db.configure(CONF.db || (process.env.MYSQL_HOST && { host: process.env.MYSQL_HOST, port: process.env.MYSQL_PORT, user: process.env.MYSQL_USER, password: process.env.MYSQL_PASSWORD, database: process.env.MYSQL_DATABASE }));
}

// Notifications go to whichever free channel is set up (any or several). Pick the easiest:
//   NOTIFY_DISCORD  = a Discord channel webhook URL (easiest - no account/token, pings the Discord app)
//   NOTIFY_TELEGRAM = "<bot-token>:<chat-id>" (Telegram bot)
//   NOTIFY_NTFY     = a topic name (ntfy.sh app) or a full https URL
//   NOTIFY_WHATSAPP = "<phone>:<callmebot-apikey>" (WhatsApp via CallMeBot, when it issues keys again)
const CHANNELS = [];
function addChannel(name, build) { try { const c = build(); if (c) CHANNELS.push(Object.assign({ name }, c)); } catch (e) { } }
addChannel('Discord', () => { const u = conf('discord', 'NOTIFY_DISCORD'); return u && { method: 'POST', url: u, json: t => ({ content: t }) }; });
addChannel('Telegram', () => {
  const v = conf('telegram', 'NOTIFY_TELEGRAM'); if (!v) return null;
  const i = v.indexOf(':'), token = v.slice(0, v.lastIndexOf(':')), chat = v.slice(v.lastIndexOf(':') + 1);
  return i > 0 && { method: 'POST', url: 'https://api.telegram.org/bot' + token + '/sendMessage', json: t => ({ chat_id: chat, text: t, disable_web_page_preview: false }) };
});
addChannel('ntfy', () => {
  const v = conf('ntfy', 'NOTIFY_NTFY'); if (!v) return null;
  const url = /^https?:\/\//.test(v) ? v : 'https://ntfy.sh/' + v;
  return { method: 'POST', url, text: t => t, extra: { Title: 'PC Remote', Tags: 'video_game', Click: PUBLIC ? PUBLIC + '/admin?key=' + DATA.adminKey : '' } };
});
addChannel('WhatsApp', () => {
  const v = conf('whatsapp', 'NOTIFY_WHATSAPP') || (process.env.CALLMEBOT_PHONE && process.env.CALLMEBOT_PHONE + ':' + process.env.CALLMEBOT_APIKEY);
  if (!v || v.indexOf(':') < 0) return null;
  const phone = v.slice(0, v.indexOf(':')).replace(/[^0-9]/g, ''), key = v.slice(v.indexOf(':') + 1);
  return phone && key && { method: 'GET', url: t => 'https://api.callmebot.com/whatsapp.php?phone=' + phone + '&apikey=' + encodeURIComponent(key) + '&text=' + encodeURIComponent(t) };
});

function postTo(ch, text, cb) {
  try {
    const target = typeof ch.url === 'function' ? ch.url(text) : ch.url;
    const u = new URL(target);
    const lib = u.protocol === 'http:' ? http : https;
    let body = null;
    const headers = {};
    if (ch.json) { body = JSON.stringify(ch.json(text)); headers['Content-Type'] = 'application/json'; }
    else if (ch.text) { body = ch.text(text); headers['Content-Type'] = 'text/plain; charset=utf-8'; }
    if (ch.extra) for (const k in ch.extra) { const val = ('' + ch.extra[k]).replace(/[\r\n]/g, ' '); if (val) headers[k] = val; }
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    const req = lib.request(u, { method: ch.method || 'GET', headers, timeout: 12000 }, r => {
      let out = ''; r.on('data', d => out += d); r.on('end', () => cb(r.statusCode >= 200 && r.statusCode < 300, r.statusCode + (out && r.statusCode >= 400 ? ' ' + out.slice(0, 120) : '')));
    });
    req.on('error', e => cb(false, e.message));
    req.on('timeout', () => { req.destroy(); cb(false, 'Zeitüberschreitung'); });
    if (body) req.write(body);
    req.end();
  } catch (e) { cb(false, e.message); }
}

// Sends to every configured channel; cb(true) if at least one worked.
function notify(text, cb) {
  if (!CHANNELS.length) { log(c.yellow('!'), 'Keine Benachrichtigung eingerichtet – nur im Log: ' + text); return cb && cb(false); }
  let left = CHANNELS.length, any = false;
  CHANNELS.forEach(ch => postTo(ch, text, (ok, info) => {
    if (ok) { any = true; log(c.green('✔'), 'Benachrichtigung über ' + ch.name + ' gesendet'); }
    else log(c.red('!'), ch.name + ' fehlgeschlagen: ' + info);
    if (--left === 0 && cb) cb(any);
  }));
}

const buckets = new Map();
function allow(ip) { const now = Date.now(); let b = buckets.get(ip); if (!b || now > b.reset) { b = { n: 0, reset: now + 600000 }; buckets.set(ip, b); } return ++b.n <= 40; }

function readBody(req, cb) { let b = ''; req.on('data', d => { b += d; if (b.length > 65536) req.destroy(); }); req.on('end', () => cb(b)); }
function apiJson(res, status, obj) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

function handleApi(req, res, p, from) {
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Key', 'Access-Control-Allow-Methods': 'GET, POST' }); return res.end(); }

  if (p === '/api/report' && req.method === 'POST') {
    if (!allow(from)) return apiJson(res, 429, { error: 'zu viele Meldungen' });
    return readBody(req, body => {
      let d; try { d = JSON.parse(body || '{}'); } catch (e) { return apiJson(res, 400, { error: 'ungültig' }); }
      const apps = [...new Set((Array.isArray(d.apps) ? d.apps : []).map(x => String(x || '').trim()).filter(x => x && x.length <= 60))].slice(0, 50);
      const now = Date.now(), fresh = [];
      for (const a of apps) {
        const k = a.toLowerCase();
        if (DATA.known[k] || DATA.ignored[k]) continue;
        if (!DATA.pending[k]) { DATA.pending[k] = { name: a, first: now, count: 0 }; fresh.push(a); }
        DATA.pending[k].count++; DATA.pending[k].last = now;
      }
      if (fresh.length) {
        saveData();
        const link = PUBLIC ? ' ' + PUBLIC + '/admin?key=' + DATA.adminKey : '';
        notify('PC Remote: neue App' + (fresh.length > 1 ? 's' : '') + ' gefunden – ' + fresh.join(', ') + '. Bestätigen:' + link,
          ok => log(c.magenta('✎'), 'Neue App gemeldet: ' + c.bold(fresh.join(', ')) + (ok ? '' : c.dim(' · keine Benachrichtigung')) + c.dim(' ← ' + from)));
      } else log(c.dim('·'), c.dim('App-Meldung ohne Neues ← ' + from));
      return apiJson(res, 200, { ok: true, new: fresh.length, pending: Object.keys(DATA.pending).length });
    });
  }

  // account login (public): username + password -> a signed token the PC can trust later
  if (p === '/api/login' && req.method === 'POST') {
    if (!allow(from)) return apiJson(res, 429, { error: 'zu viele Versuche' });
    if (!db || !db.ready()) return apiJson(res, 503, { error: 'Konten sind gerade nicht verfügbar' });
    return readBody(req, body => {
      let d; try { d = JSON.parse(body || '{}'); } catch (e) { return apiJson(res, 400, { error: 'ungültig' }); }
      db.login(d.username, d.password).then(acc => {
        if (!acc) { log(c.yellow('?'), 'Login falsch: ' + String(d.username || '').slice(0, 32) + c.dim(' ← ' + from)); return apiJson(res, 401, { error: 'Benutzername oder Passwort falsch' }); }
        log(c.green('✔'), 'Login: ' + acc.username + ' (' + acc.role + ')' + c.dim(' ← ' + from));
        apiJson(res, 200, { ok: true, username: acc.username, role: acc.role, token: makeToken(acc) });
      }).catch(e => apiJson(res, 500, { error: e.message }));
    });
  }

  // everything below is for the admin only
  const key = new URL(req.url, 'http://x').searchParams.get('key') || req.headers['x-admin-key'];
  if (key !== DATA.adminKey) return apiJson(res, 401, { error: 'Admin-Schlüssel falsch' });

  // ----- accounts (admin manages them) -----
  if (p === '/api/admin/accounts') {
    if (!db || !db.has()) return apiJson(res, 503, { error: 'Keine Datenbank verbunden', dbError: db ? db.error() : 'db-Modul fehlt' });
    if (req.method === 'GET') return db.listAccounts().then(rows => apiJson(res, 200, { accounts: rows, ready: db.ready() })).catch(e => apiJson(res, 500, { error: e.message }));
    return readBody(req, body => {
      let d; try { d = JSON.parse(body || '{}'); } catch (e) { return apiJson(res, 400, { error: 'ungültig' }); }
      let work;
      if (d.op === 'create') work = db.createAccount(d.username, d.password, d.role).then(a => ({ ok: true, account: a }));
      else if (d.op === 'delete') work = db.deleteAccount(d.username).then(() => ({ ok: true }));
      else if (d.op === 'password') work = db.setPassword(d.username, d.password).then(() => ({ ok: true }));
      else return apiJson(res, 400, { error: 'unbekannt' });
      work.then(r => { log(c.blue('✓'), 'Konto ' + d.op + ': ' + String(d.username || '').toLowerCase()); apiJson(res, 200, r); })
        .catch(e => apiJson(res, 400, { error: e.message }));
    });
  }
  if (p === '/api/admin/pending') return apiJson(res, 200, { pending: Object.values(DATA.pending).sort((a, b) => b.last - a.last), known: Object.keys(DATA.known).length, ignored: Object.keys(DATA.ignored).length });
  if (p === '/api/admin/resolve' && req.method === 'POST') return readBody(req, body => {
    let d; try { d = JSON.parse(body || '{}'); } catch (e) { return apiJson(res, 400, { error: 'ungültig' }); }
    const k = String(d.app || '').toLowerCase(), item = DATA.pending[k];
    if (!item) return apiJson(res, 404, { error: 'nicht gefunden' });
    delete DATA.pending[k];
    if (d.action === 'ignore') DATA.ignored[k] = { name: item.name }; else DATA.known[k] = { name: item.name, done: Date.now() };
    saveData();
    log(c.blue('✓'), (d.action === 'ignore' ? 'Ignoriert: ' : 'Bestätigt: ') + item.name);
    return apiJson(res, 200, { ok: true });
  });
  return apiJson(res, 404, { error: 'unbekannt' });
}

// Small page the WhatsApp link opens: pending apps with Confirm / Ignore. Same origin, so no CORS needed.
function adminPage(res) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PC Remote – Neue Apps</title>' +
    '<style>body{font-family:system-ui,Segoe UI,sans-serif;background:#08090d;color:#eef0f7;margin:0;padding:20px;max-width:620px;margin:auto}' +
    'h1{font-size:22px}.app{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:12px 14px;margin:10px 0}' +
    '.app b{flex:1;min-width:0}.app small{color:#9aa0b4;font-weight:400}button{border:0;border-radius:10px;padding:9px 14px;font-weight:700;cursor:pointer;font-size:14px}' +
    '.ok{background:linear-gradient(135deg,#7c5cff,#22d3ee);color:#fff}.no{background:#2a2d3a;color:#eef0f7}.muted{color:#9aa0b4}</style></head><body>' +
    '<h1>Neue Apps bestätigen</h1><p class="muted">Diese App-Namen haben Nutzer anonym gemeldet. „Bestätigen“ merkt sie vor (du baust danach das Addon), „Ignorieren“ blendet sie aus.</p>' +
    '<div id="list" class="muted">Lade …</div>' +
    '<script>var key=new URLSearchParams(location.search).get("key");' +
    'function load(){fetch("/api/admin/pending?key="+encodeURIComponent(key)).then(r=>r.json()).then(d=>{var l=document.getElementById("list");if(d.error){l.textContent=d.error;return;}' +
    'if(!d.pending.length){l.innerHTML="<p>Keine offenen Apps. "+d.known+" bestätigt.</p>";return;}' +
    'l.innerHTML=d.pending.map(function(a){return \'<div class=app><b>\'+a.name.replace(/[<>&]/g,"")+\' <small>(\'+a.count+"x)</small></b><button class=ok onclick=\\"res(\'"+encodeURIComponent(a.name)+"\',\'confirm\')\\">Bestätigen</button> <button class=no onclick=\\"res(\'"+encodeURIComponent(a.name)+"\',\'ignore\')\\">Ignorieren</button></div>";}).join("");});}' +
    'function res(app,action){fetch("/api/admin/resolve?key="+encodeURIComponent(key),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({app:decodeURIComponent(app),action:action})}).then(load);}' +
    'load();setInterval(load,15000);</script></body></html>');
}

const server = http.createServer((req, res) => {
  const t0 = Date.now(), from = who(req), ua = agent(req);
  let name = '?', kind = 'page';

  // backend (new-app reports + admin) works with any method and regardless of the website redirect
  let reqPath = '/';
  try { reqPath = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { }
  if (reqPath.indexOf('/api/') === 0) { kind = 'api'; return handleApi(req, res, reqPath, from); }
  if (reqPath === '/admin' || reqPath === '/admin/') { kind = 'admin'; return adminPage(res); }

  // one line per request when it's done; downloads get their own lines
  res.on('close', () => {
    const ms = Date.now() - t0, st = res.statusCode;
    if (kind === 'download' || kind === 'redirect' || kind === 'api' || kind === 'admin') return;
    if (st === 404) { stats.notFound++; log(c.yellow('?'), c.yellow('404') + ' ' + name + c.dim('  ← ' + from + ' · ' + ua)); return; }
    if (st >= 400) { log(c.red('!'), c.red(String(st)) + ' ' + name + c.dim('  ← ' + from)); return; }
    if (req.method === 'HEAD') return; // the page checks once whether the installer is there - not worth a line
    if (/\.html$/.test(name)) {
      stats.pages++;
      stats.visitors.add(from + ua);
      log(c.cyan('●'), 'Seite ' + c.bold(name === 'index.html' ? 'Startseite' : name) + c.dim('  ← ' + from + ' · ' + ua + ' · ' + ms + ' ms'));
    } else log(c.dim('·'), c.dim(st + ' ' + name + ' ← ' + from));
  });

  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Nur GET', { Allow: 'GET, HEAD' });

  try { name = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { return send(res, 400, 'Ungültige Adresse'); }
  if (name === '/' || name === '') name = '/index.html';
  name = name.replace(/^\/+/, '');

  if (MOVED_TO !== '/') {
    // known pages and downloads keep their name, everything else goes to the start page
    const known = /^(impressum|datenschutz)\.html$/i.test(name) || DOWNLOADS.includes(name);
    const target = MOVED_TO + (known ? name : '');
    kind = 'redirect';
    stats.visitors.add(from + ua);
    if (DOWNLOADS.includes(name)) stats.started++; else stats.pages++;
    log(c.blue('↪'), (DOWNLOADS.includes(name) ? 'Download ' : 'Seite ') + c.bold(name === 'index.html' ? 'Startseite' : name) + ' → ' + c.cyan(target) + c.dim('  ← ' + from + ' · ' + ua));
    // 302, not 301: browsers don't remember it forever, so this address can be used for something else later
    return send(res, 302, '<!doctype html><meta charset="utf-8"><title>PC Remote ist umgezogen</title><meta http-equiv="refresh" content="0;url=' + target + '">' +
      '<p>PC Remote ist umgezogen: <a href="' + target + '">' + target + '</a></p>', { Location: target, 'Cache-Control': 'no-store' });
  }

  // only plain files right here: no sub-folders, no hidden files, no server files, only known types
  const ext = path.extname(name).toLowerCase();
  if (name.includes('/') || name.includes('\\') || name.startsWith('.') || PRIVATE.has(name.toLowerCase()) || !TYPES[ext]) return notFound(res);
  const file = path.join(ROOT, name);

  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(res);
    const headers = {
      'Content-Type': TYPES[ext],
      'X-Content-Type-Options': 'nosniff',
      'Last-Modified': st.mtime.toUTCString(),
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
      'Accept-Ranges': 'bytes'
    };
    const isDownload = ext === '.exe' || ext === '.zip';
    if (isDownload) headers['Content-Disposition'] = 'attachment; filename="' + name + '"';

    // continue interrupted downloads (Range requests)
    let start = 0, end = st.size - 1, status = 200;
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (m && st.size > 0) {
      if (m[1] !== '') { start = Math.min(+m[1], st.size - 1); if (m[2] !== '') end = Math.min(+m[2], st.size - 1); }
      else if (m[2] !== '') start = Math.max(0, st.size - +m[2]);
      if (end < start) end = start;
      status = 206;
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + st.size;
    }
    const length = st.size === 0 ? 0 : end - start + 1;
    headers['Content-Length'] = length;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || st.size === 0) return res.end();

    if (isDownload) {
      kind = 'download';
      stats.started++;
      log(c.magenta('⬇'), 'Download ' + c.bold(name) + ' (' + size(st.size) + ')' + (status === 206 ? c.dim(' – fortgesetzt ab ' + size(start)) : '') + c.dim('  ← ' + from + ' · ' + ua));
    }
    let sent = 0;
    const stream = fs.createReadStream(file, { start, end });
    stream.on('data', d => { sent += d.length; });
    stream.on('error', e => { stats.errors++; log(c.red('!'), c.red('Lesefehler ') + name + ': ' + e.message); res.destroy(); });
    res.on('close', () => {
      if (!isDownload) return;
      const secs = Math.max(0.001, (Date.now() - t0) / 1000);
      if (res.writableFinished) {
        stats.finished++;
        log(c.green('✔'), 'Download fertig ' + c.bold(name) + c.dim('  ' + size(length) + ' in ' + secs.toFixed(1).replace('.', ',') + ' s (' + size(Math.round(length / secs)) + '/s) → ' + from));
      } else {
        stats.cancelled++;
        log(c.yellow('✖'), 'Download abgebrochen ' + c.bold(name) + c.dim('  nach ' + size(sent) + ' von ' + size(length) + ' → ' + from +
          ' (meist: der Browser hat die Datei blockiert oder der Besucher hat abgebrochen)'));
      }
    });
    stream.pipe(res);
  });
});

// ---------- start, stop, stats ----------

function banner() {
  const line = c.dim('─'.repeat(58));
  console.log(line);
  console.log(' ' + c.bold(c.cyan('PC Remote Website')) + c.dim('  v' + VERSION + ' · Node ' + process.version));
  console.log(line);
  const ip = process.env.SERVER_IP && process.env.SERVER_IP !== '0.0.0.0' ? process.env.SERVER_IP : null;
  console.log(' ' + c.green('✔') + ' Läuft auf Port ' + c.bold(PORT) + (ip ? '  →  ' + c.bold(c.cyan('http://' + ip + ':' + PORT)) : ''));
  if (MOVED_TO !== '/') {
    console.log(' ' + c.blue('↪') + ' Leitet alle Besucher weiter an ' + c.bold(c.cyan(MOVED_TO)));
    console.log(c.dim('   (die Website liegt jetzt dort – Dateien hier werden nicht mehr gebraucht)'));
    console.log(line);
    console.log(c.dim(' ↪ Weiterleitung   Σ Zusammenfassung alle 30 Minuten'));
    console.log(line);
    notifyBanner(line);
    return;
  }
  const page = fs.existsSync(path.join(ROOT, 'index.html'));
  console.log(' ' + (page ? c.green('✔') + ' Startseite index.html' : c.red('✖ index.html fehlt – bitte hochladen!')));
  for (const f of DOWNLOADS) {
    let st = null;
    try { st = fs.statSync(path.join(ROOT, f)); } catch (e) { }
    if (st) console.log(' ' + c.green('✔') + ' ' + f + c.dim(' (' + size(st.size) + ', vom ' + st.mtime.toLocaleDateString('de-DE') + ')'));
    else console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' fehlt') + (f.endsWith('.exe') ? c.dim(' – die Seite bietet dann die ZIP an') : ''));
  }
  for (const f of ['impressum.html', 'datenschutz.html']) {
    try { if (/\[(Vorname|deine E-Mail|Name des Hosting)/.test(fs.readFileSync(path.join(ROOT, f), 'utf8'))) console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' enthält noch Platzhalter in [eckigen Klammern]')); }
    catch (e) { console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' fehlt')); }
  }
  console.log(line);
  console.log(c.dim(' ● Seitenaufruf   ⬇ Download startet   ✔ fertig   ✖ abgebrochen   ? nicht gefunden'));
  console.log(line);
  notifyBanner(line);
}

// Shows the new-app notification setup (WhatsApp + admin link + key).
function notifyBanner(line) {
  console.log(' ' + c.bold('Neue-App-Meldungen'));
  console.log(' ' + (CHANNELS.length ? c.green('✔') + ' Benachrichtigung über ' + CHANNELS.map(ch => ch.name).join(', ')
    : c.yellow('!') + ' keine Benachrichtigung – eine Variable setzen: NOTIFY_DISCORD, NOTIFY_TELEGRAM, NOTIFY_NTFY oder NOTIFY_WHATSAPP'));
  console.log(' ' + c.cyan('→') + ' Bestätigen-Seite: ' + c.bold((PUBLIC || 'http://<IP>:' + PORT) + '/admin?key=' + DATA.adminKey));
  console.log(c.dim('   (Link geheim halten – wer ihn hat, sieht die gemeldeten App-Namen und verwaltet die Konten)'));
  console.log(line);
  console.log(' ' + c.bold('Konten (Datenbank)'));
  if (!db || !db.has()) console.log(' ' + c.yellow('!') + ' keine Datenbank – in notify.json "db": {host,port,user,password,database} eintragen' + (db && db.error() ? c.dim(' (' + db.error() + ')') : ''));
  else if (db.ready()) console.log(' ' + c.green('✔') + ' verbunden' + (dbCount != null ? ' · ' + dbCount + ' Konten' : ''));
  else console.log(' ' + c.yellow('…') + ' verbinde …' + (db.error() ? c.dim(' (' + db.error() + ')') : ''));
  console.log(line);
}
let dbCount = null;

function summary(label) {
  if (MOVED_TO !== '/') {
    log(c.blue('Σ'), c.bold(label) + '  ' + (stats.pages + stats.started) + ' Besuche weitergeleitet (' + stats.started + ' davon Downloads) · ' + stats.visitors.size + ' Besucher');
    return;
  }
  log(c.blue('Σ'), c.bold(label) + '  ' + stats.pages + ' Seitenaufrufe von ' + stats.visitors.size + ' Besuchern · ' +
    stats.finished + ' Downloads fertig' + (stats.cancelled ? ', ' + stats.cancelled + ' abgebrochen' : '') +
    (stats.notFound ? ' · ' + stats.notFound + '× nicht gefunden' : '') + (stats.errors ? ' · ' + c.red(stats.errors + ' Fehler') : ''));
}

let lastShown = '';
setInterval(() => {
  const key = [stats.pages, stats.started, stats.notFound, stats.errors].join();
  if (key !== lastShown && stats.pages + stats.started > 0) { lastShown = key; summary('Bisher'); }
}, 30 * 60 * 1000).unref();

server.on('error', e => {
  if (e.code === 'EADDRINUSE') log(c.red('✖'), c.red('Port ' + PORT + ' ist schon belegt') + ' – läuft der Server schon in einem zweiten Fenster? Im Panel einmal Stopp, dann Start.');
  else if (e.code === 'EACCES') log(c.red('✖'), c.red('Keine Berechtigung für Port ' + PORT) + ' – im Panel unter Netzwerk den zugewiesenen Port prüfen.');
  else log(c.red('✖'), c.red('Server konnte nicht starten: ') + e.message);
  process.exit(1);
});
server.listen(PORT, HOST, () => {
  banner();
  if (db && db.has()) db.init()
    .then(() => db.count())
    .then(n => { dbCount = n; log(c.green('✔'), 'Datenbank verbunden' + (n != null ? ' · ' + n + ' Konten' : '')); })
    .catch(e => log(c.red('!'), 'Datenbank: ' + e.message + ' – Konten sind aus, der Rest läuft weiter'));
});

// a broken request must never take the whole site down
process.on('uncaughtException', e => { stats.errors++; log(c.red('!'), c.red('Fehler: ') + (e && e.stack || e)); });

// panels stop servers with Ctrl+C / SIGTERM
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => {
  summary('Gestoppt');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1000).unref(); // open downloads must not block the stop
});
