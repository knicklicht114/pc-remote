// PC Remote website for Node.js hosts (e.g. Pterodactyl panels: "npm install", then "node index.js").
// No packages needed. Serves the pages and downloads in this folder - nothing else, not even itself -
// and writes a readable log to the console: every visit, every download (finished or cancelled), errors, stats.
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 8080);
// always all interfaces: in panel containers the public SERVER_IP isn't a local address (only the port is forwarded)
const HOST = '0.0.0.0';
const VERSION = (() => { try { return require('./package.json').version; } catch (e) { return '?'; } })();

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.exe': 'application/vnd.microsoft.portable-executable',
  '.zip': 'application/zip',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.css': 'text/css; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8'
};
const PRIVATE = new Set(['index.js', 'package.json', 'package-lock.json', 'liesmich.txt']);
const DOWNLOADS = ['PCRemote-Setup.exe', 'PCRemote-Portable.zip', 'PCRemote-Quellcode.zip'];

// ---------- log ----------

const COLOR = !process.env.NO_COLOR;
const paint = code => s => COLOR ? '\x1b[' + code + 'm' + s + '\x1b[0m' : String(s);
const c = { dim: paint('2'), bold: paint('1'), red: paint('31'), green: paint('32'), yellow: paint('33'), blue: paint('34'), magenta: paint('35'), cyan: paint('36') };

const two = n => String(n).padStart(2, '0');
function stamp() {
  const d = new Date();
  return c.dim(two(d.getDate()) + '.' + two(d.getMonth() + 1) + '. ' + two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds()));
}
const log = (icon, text) => console.log(stamp() + ' ' + icon + ' ' + text);

function size(b) {
  if (b >= 1048576) return (b / 1048576).toFixed(1).replace('.', ',') + ' MB';
  if (b >= 1024) return Math.round(b / 1024) + ' KB';
  return b + ' B';
}

// visitor address, shortened for privacy (last part hidden) - enough to tell visitors apart
function who(req) {
  let ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?').split(',')[0].trim().replace(/^::ffff:/, '');
  if (/^\d+\.\d+\.\d+\.\d+$/.test(ip)) ip = ip.replace(/\.\d+$/, '.x');
  else if (ip.includes(':')) ip = ip.split(':').slice(0, 3).join(':') + ':…';
  return ip;
}

// "Chrome · Windows" instead of the whole user agent
function agent(req) {
  const ua = String(req.headers['user-agent'] || '');
  if (!ua) return 'unbekannt';
  if (/bot|crawl|spider|slurp|curl|wget|python|scan/i.test(ua)) return 'Bot/Tool';
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\/|Opera/.test(ua) ? 'Opera' : /SamsungBrowser/.test(ua) ? 'Samsung Internet'
    : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone/iPad'
    : /Mac OS X/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '?';
  return browser + ' · ' + os;
}

const stats = { pages: 0, started: 0, finished: 0, cancelled: 0, notFound: 0, errors: 0, visitors: new Set() };

// ---------- server ----------

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({ 'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff' }, headers || {}));
  res.end(body);
}

function notFound(res) {
  send(res, 404, '<!doctype html><meta charset="utf-8"><title>Nicht gefunden</title>' +
    '<body style="font-family:system-ui;background:#08090d;color:#eef0f7;display:grid;place-items:center;height:100vh;margin:0">' +
    '<div style="text-align:center"><h1>404</h1><p>Diese Seite gibt es nicht.</p><a style="color:#22d3ee" href="/">Zur Startseite</a></div>');
}

const server = http.createServer((req, res) => {
  const t0 = Date.now(), from = who(req), ua = agent(req);
  let name = '?', kind = 'page';

  // one line per request when it's done; downloads get their own lines
  res.on('close', () => {
    const ms = Date.now() - t0, st = res.statusCode;
    if (kind === 'download') return;
    if (st === 404) { stats.notFound++; log(c.yellow('?'), c.yellow('404') + ' ' + name + c.dim('  ← ' + from + ' · ' + ua)); return; }
    if (st >= 400) { log(c.red('!'), c.red(String(st)) + ' ' + name + c.dim('  ← ' + from)); return; }
    if (req.method === 'HEAD') return; // the page checks once whether the installer is there - not worth a line
    if (/\.html$/.test(name)) {
      stats.pages++;
      stats.visitors.add(from + ua);
      log(c.cyan('●'), 'Seite ' + c.bold(name === 'index.html' ? 'Startseite' : name) + c.dim('  ← ' + from + ' · ' + ua + ' · ' + ms + ' ms'));
    } else log(c.dim('·'), c.dim(st + ' ' + name + ' ← ' + from));
  });

  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Nur GET', { Allow: 'GET, HEAD' });

  try { name = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { return send(res, 400, 'Ungültige Adresse'); }
  if (name === '/' || name === '') name = '/index.html';
  name = name.replace(/^\/+/, '');

  // only plain files right here: no sub-folders, no hidden files, no server files, only known types
  const ext = path.extname(name).toLowerCase();
  if (name.includes('/') || name.includes('\\') || name.startsWith('.') || PRIVATE.has(name.toLowerCase()) || !TYPES[ext]) return notFound(res);
  const file = path.join(ROOT, name);

  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(res);
    const headers = {
      'Content-Type': TYPES[ext],
      'X-Content-Type-Options': 'nosniff',
      'Last-Modified': st.mtime.toUTCString(),
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
      'Accept-Ranges': 'bytes'
    };
    const isDownload = ext === '.exe' || ext === '.zip';
    if (isDownload) headers['Content-Disposition'] = 'attachment; filename="' + name + '"';

    // continue interrupted downloads (Range requests)
    let start = 0, end = st.size - 1, status = 200;
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (m && st.size > 0) {
      if (m[1] !== '') { start = Math.min(+m[1], st.size - 1); if (m[2] !== '') end = Math.min(+m[2], st.size - 1); }
      else if (m[2] !== '') start = Math.max(0, st.size - +m[2]);
      if (end < start) end = start;
      status = 206;
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + st.size;
    }
    const length = st.size === 0 ? 0 : end - start + 1;
    headers['Content-Length'] = length;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || st.size === 0) return res.end();

    if (isDownload) {
      kind = 'download';
      stats.started++;
      log(c.magenta('⬇'), 'Download ' + c.bold(name) + ' (' + size(st.size) + ')' + (status === 206 ? c.dim(' – fortgesetzt ab ' + size(start)) : '') + c.dim('  ← ' + from + ' · ' + ua));
    }
    let sent = 0;
    const stream = fs.createReadStream(file, { start, end });
    stream.on('data', d => { sent += d.length; });
    stream.on('error', e => { stats.errors++; log(c.red('!'), c.red('Lesefehler ') + name + ': ' + e.message); res.destroy(); });
    res.on('close', () => {
      if (!isDownload) return;
      const secs = Math.max(0.001, (Date.now() - t0) / 1000);
      if (res.writableFinished) {
        stats.finished++;
        log(c.green('✔'), 'Download fertig ' + c.bold(name) + c.dim('  ' + size(length) + ' in ' + secs.toFixed(1).replace('.', ',') + ' s (' + size(Math.round(length / secs)) + '/s) → ' + from));
      } else {
        stats.cancelled++;
        log(c.yellow('✖'), 'Download abgebrochen ' + c.bold(name) + c.dim('  nach ' + size(sent) + ' von ' + size(length) + ' → ' + from +
          ' (meist: der Browser hat die Datei blockiert oder der Besucher hat abgebrochen)'));
      }
    });
    stream.pipe(res);
  });
});

// ---------- start, stop, stats ----------

function banner() {
  const line = c.dim('─'.repeat(58));
  console.log(line);
  console.log(' ' + c.bold(c.cyan('PC Remote Website')) + c.dim('  v' + VERSION + ' · Node ' + process.version));
  console.log(line);
  const ip = process.env.SERVER_IP && process.env.SERVER_IP !== '0.0.0.0' ? process.env.SERVER_IP : null;
  console.log(' ' + c.green('✔') + ' Läuft auf Port ' + c.bold(PORT) + (ip ? '  →  ' + c.bold(c.cyan('http://' + ip + ':' + PORT)) : ''));
  const page = fs.existsSync(path.join(ROOT, 'index.html'));
  console.log(' ' + (page ? c.green('✔') + ' Startseite index.html' : c.red('✖ index.html fehlt – bitte hochladen!')));
  for (const f of DOWNLOADS) {
    let st = null;
    try { st = fs.statSync(path.join(ROOT, f)); } catch (e) { }
    if (st) console.log(' ' + c.green('✔') + ' ' + f + c.dim(' (' + size(st.size) + ', vom ' + st.mtime.toLocaleDateString('de-DE') + ')'));
    else console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' fehlt') + (f.endsWith('.exe') ? c.dim(' – die Seite bietet dann die ZIP an') : ''));
  }
  for (const f of ['impressum.html', 'datenschutz.html']) {
    try { if (/\[(Vorname|deine E-Mail|Name des Hosting)/.test(fs.readFileSync(path.join(ROOT, f), 'utf8'))) console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' enthält noch Platzhalter in [eckigen Klammern]')); }
    catch (e) { console.log(' ' + c.yellow('!') + ' ' + f + c.yellow(' fehlt')); }
  }
  console.log(line);
  console.log(c.dim(' ● Seitenaufruf   ⬇ Download startet   ✔ fertig   ✖ abgebrochen   ? nicht gefunden'));
  console.log(line);
}

function summary(label) {
  log(c.blue('Σ'), c.bold(label) + '  ' + stats.pages + ' Seitenaufrufe von ' + stats.visitors.size + ' Besuchern · ' +
    stats.finished + ' Downloads fertig' + (stats.cancelled ? ', ' + stats.cancelled + ' abgebrochen' : '') +
    (stats.notFound ? ' · ' + stats.notFound + '× nicht gefunden' : '') + (stats.errors ? ' · ' + c.red(stats.errors + ' Fehler') : ''));
}

let lastShown = '';
setInterval(() => {
  const key = [stats.pages, stats.started, stats.notFound, stats.errors].join();
  if (key !== lastShown && stats.pages + stats.started > 0) { lastShown = key; summary('Bisher'); }
}, 30 * 60 * 1000).unref();

server.on('error', e => {
  if (e.code === 'EADDRINUSE') log(c.red('✖'), c.red('Port ' + PORT + ' ist schon belegt') + ' – läuft der Server schon in einem zweiten Fenster? Im Panel einmal Stopp, dann Start.');
  else if (e.code === 'EACCES') log(c.red('✖'), c.red('Keine Berechtigung für Port ' + PORT) + ' – im Panel unter Netzwerk den zugewiesenen Port prüfen.');
  else log(c.red('✖'), c.red('Server konnte nicht starten: ') + e.message);
  process.exit(1);
});
server.listen(PORT, HOST, banner);

// a broken request must never take the whole site down
process.on('uncaughtException', e => { stats.errors++; log(c.red('!'), c.red('Fehler: ') + (e && e.stack || e)); });

// panels stop servers with Ctrl+C / SIGTERM
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => {
  summary('Gestoppt');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1000).unref(); // open downloads must not block the stop
});
