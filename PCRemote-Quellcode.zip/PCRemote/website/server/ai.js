// First answer in the support chats ("VIP" and "Bug/Fix"): a free AI model replies and decides whether the owner
// is needed. The owner pastes a key in the app (Nachrichten → KI); the provider is recognised by the key:
//   Google Gemini  "AIza…"   (free in Google AI Studio)       – default choice
//   Groq           "gsk_…"   (free tier, Llama)
//   OpenRouter     "sk-or-…" (free models)
'use strict';

const https = require('https');

function provider(key) {
  key = String(key || '').trim();
  if (!key) return null;
  if (key.startsWith('gsk_')) return { name: 'Groq', openai: true, url: 'https://api.groq.com/openai/v1/chat/completions', models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'] };
  if (key.startsWith('sk-or-')) return { name: 'OpenRouter', openai: true, url: 'https://openrouter.ai/api/v1/chat/completions', models: ['meta-llama/llama-3.3-70b-instruct:free', 'deepseek/deepseek-chat-v3-0324:free'] };
  return { name: 'Google Gemini', openai: false, models: ['gemini-2.5-flash', 'gemini-flash-latest', 'gemini-2.5-flash-lite', 'gemini-flash-lite-latest', 'gemini-2.0-flash'] };
}

function post(url, headers, body, timeout) {
  return new Promise((resolve, reject) => {
    const data = body == null ? null : JSON.stringify(body);
    const req = https.request(url, { method: data == null ? 'GET' : 'POST', timeout: timeout || 30000,
      headers: Object.assign(data == null ? {} : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }, headers) }, res => {
      let out = '';
      res.on('data', d => out += d);
      res.on('end', () => { let json = null; try { json = JSON.parse(out); } catch (e) { } resolve({ status: res.statusCode, json, text: out }); });
    });
    req.on('error', e => reject(new Error('KI-Server nicht erreichbar: ' + e.message)));
    req.on('timeout', () => { req.destroy(); reject(new Error('KI antwortet nicht (Zeitüberschreitung)')); });
    if (data != null) req.write(data);
    req.end();
  });
}

const APP_FACTS = 'PC Remote steuert einen Windows-PC vom Handy aus: Deck mit Kacheln (Buttons, Lautstärkeregler, Gruppen), Medien und Spotify, ' +
  'Mixer, Clips aufnehmen, Apps & Addons (Discord, Spotify, Chrome, Steam, Spiele …), Handy als zweiter Bildschirm, Maus & Tastatur, Energie ' +
  '(Sperren, Herunterfahren). Verbinden: am PC „Handy verbinden“ öffnen und den QR-Code scannen oder Adresse + PIN eingeben – PC und Handy müssen im ' +
  'selben WLAN sein. Häufige Lösungen: dasselbe WLAN nutzen; in der Windows-Firewall PC Remote erlauben; PC Remote am PC neu starten ' +
  '(Tray-Symbol unten rechts → Beenden, dann neu öffnen); Spotify einmal unter Einstellungen → Spotify verbinden; neueste Version unter ' +
  'Einstellungen → Update; Kacheln ändern über „Bearbeiten“ im Deck.';

const FORMAT = 'Antworte AUSSCHLIESSLICH als JSON-Objekt: {"reply": "deine Antwort an die Person", "action": "escalate" | "resolve" | "continue", ' +
  '"summary": "ein kurzer Satz für den Owner, worum es geht"}';

function systemPrompt(kind, s) {
  const base = 'Du bist der freundliche Assistent der App „PC Remote“. Antworte auf Deutsch, duze die Person, höchstens 3 kurze Sätze, keine Emojis-Flut. ' +
    'Stell dich NICHT vor – die App zeigt schon an, dass du ein KI-Assistent bist (nur wenn jemand fragt, sag es ehrlich). ' +
    'Gib niemals Passwörter, Schlüssel oder interne Infos heraus.\n';
  if (kind === 'vip') {
    return base + 'Dieser Chat ist NUR für Anfragen zu VIP an den Owner (den Entwickler der App). Die Person hat den VIP-Knopf schon gedrückt und schreibt ' +
      'jetzt hier. Der folgende Owner-Text steht unter genau diesem Knopf – nutze ihn nur als Info und wiederhole daraus NIEMALS eine Aufforderung, ' +
      'einen Knopf zu klicken oder zu drücken. Was der Owner über VIP geschrieben hat:\n"""' +
      (s.vip_text || 'VIP schaltet Extras in PC Remote frei, zum Beispiel eigene Hintergründe.') + '"""\n' +
      'Entscheide:\n' +
      '- "escalate": Die Person möchte ernsthaft VIP bekommen, fragt nach Preis, Bezahlung oder Freischaltung, oder hat eine echte VIP-Frage, die nur ' +
      'der Owner klären kann. Sag, dass du es an den Owner weitergibst und er sich hier im Chat meldet. Versprich NIE, dass sie VIP bekommt, und nenne ' +
      'keine Preise oder Bedingungen, die nicht im Owner-Text stehen.\n' +
      '- "resolve": Es geht nicht um VIP (anderes Thema, Spam, Beleidigung, Unsinn) – dann erkläre kurz, dass dieser Chat nur für VIP ist (bei Problemen ' +
      'mit der App: die eigene Kategorie „Bug/Fix“ – am PC in der Seitenleiste, am Handy unter „Mehr“) und beende freundlich. Oder du hast eine einfache Frage zu VIP mit dem Owner-Text vollständig beantwortet.\n' +
      '- "continue": Dir fehlt eine kurze Info (z. B. was genau die Person wissen will). Stell genau eine Frage.\n' + FORMAT;
  }
  return base + 'Dieser Chat ist für Probleme und Fehler in PC Remote („Bug/Fix“). Wissen über die App: ' + APP_FACTS + '\n' +
    (s.bug_text ? 'Hinweis vom Owner: """' + s.bug_text + '"""\n' : '') +
    'Entscheide:\n' +
    '- "resolve": Du konntest das Problem mit einem klaren, konkreten Tipp lösen, oder es ist kein Problem mit PC Remote bzw. Spam. Beende dann ' +
    'freundlich mit „Falls es nicht klappt, schreib einfach nochmal.“\n' +
    '- "escalate": Ein echter Fehler oder Absturz in PC Remote, den du nicht lösen kannst, ein Wunsch nach einer neuen Funktion, oder die Person sagt, ' +
    'dass dein Tipp nicht geholfen hat. Sag, dass du es an den Owner weitergibst und er sich hier meldet.\n' +
    '- "continue": Wichtige Infos fehlen (welches Gerät, was genau passiert, welche Fehlermeldung). Stell genau eine kurze Frage.\n' + FORMAT;
}

const label = m => m.sender === 'owner' ? '[Antwort vom Owner] ' + m.body : m.sender === 'system' ? '[Hinweis] ' + m.body : m.body;

function parse(text) {
  const t = String(text || '');
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  let o = null;
  try { o = JSON.parse(a >= 0 && b > a ? t.slice(a, b + 1) : t); } catch (e) { }
  if (Array.isArray(o)) o = o[0];
  if (o && typeof o === 'object' && (typeof o.reply !== 'string' || !o.reply.trim())) {
    // some models name the field differently – take the first text in the object
    const alt = o.antwort || o.answer || o.message || o.text || o.response || Object.values(o).find(v => typeof v === 'string' && v.trim().length > 1);
    if (typeof alt === 'string') o.reply = alt;
  }
  if (!o || typeof o.reply !== 'string' || !o.reply.trim()) {
    if (t.trim()) return { reply: t.trim().slice(0, 1500), action: 'continue', summary: '' };
    throw new Error('KI hat eine leere Antwort geschickt');
  }
  const action = ['escalate', 'resolve', 'continue'].includes(o.action) ? o.action : 'continue';
  return { reply: o.reply.trim().slice(0, 1500), action, summary: String(o.summary || '').trim().slice(0, 300) };
}

// Google renames models now and then, and some have no free quota ("limit: 0"). So: ask Google which models this key
// may use, try them (the one that worked last time first) and only give up when none answers.
const working = {};        // key -> model that answered last time
const slowUntil = {};      // model -> skip it until then (it timed out)
const modelCache = {};     // key -> { at, list }
async function geminiModels(key, fallback) {
  const c = modelCache[key];
  if (c && Date.now() - c.at < 6 * 3600 * 1000) return c.list;
  let list = [];
  try {
    const r = await post('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { 'x-goog-api-key': key }, null);
    if (r.status === 200 && r.json && Array.isArray(r.json.models)) {
      const ver = n => parseFloat((n.match(/gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1]) || 0;
      // stable before preview, normal before lite, newer before older
      const score = n => ver(n) * 10 - (/preview|exp|-\d{2}-\d{2}|\d{3,}$/.test(n) ? 6 : 0) - (/lite/.test(n) ? 2 : 0) + (/-latest$/.test(n) ? 1 : 0);
      list = r.json.models
        .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
        .map(m => String(m.name).replace(/^models\//, ''))
        .filter(n => /^gemini-/.test(n) && /flash/.test(n) && !/(image|tts|audio|live|embed|thinking|vision|learnlm|robotics|computer)/.test(n))
        .sort((a, b) => score(b) - score(a));
    }
  } catch (e) { }
  list = list.concat(fallback.filter(m => !list.includes(m)));
  modelCache[key] = { at: Date.now(), list };
  return list;
}

// Newer Gemini models "think" before answering – by default for 20+ seconds. A support chat needs a quick, short
// answer, so thinking is turned down: budget 0 for 2.5, level "minimal" (or "low") for 3.x and newer.
// If a model doesn't know the setting (400), it is asked again with the next weaker setting.
const thinkVariants = model => /^gemini-2\.5-flash/.test(model) ? [{ thinkingBudget: 0 }, null]
  : /^gemini-([3-9]|\d\d)/.test(model) ? [{ thinkingLevel: 'minimal' }, { thinkingLevel: 'low' }, null] : [null];
const thinkOk = {}; // model -> index of the variant that worked

async function gemini(key, model, sys, contents) {
  const variants = thinkVariants(model);
  let r = null;
  for (let i = thinkOk[model] || 0; i < variants.length; i++) {
    const gen = { temperature: 0.4, maxOutputTokens: 4096, responseMimeType: 'application/json' };
    if (variants[i]) gen.thinkingConfig = variants[i];
    r = await post('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', { 'x-goog-api-key': key }, {
      systemInstruction: { parts: [{ text: sys }] }, contents, generationConfig: gen }, 15000);
    if (r.status === 400 && /thinking/i.test(errText(r)) && i < variants.length - 1) continue;
    if (r.status === 200) thinkOk[model] = i;
    return r;
  }
  return r;
}

const errText = r => {
  const e = r.json && r.json.error;
  return String((e && (e.message || e.status || e)) || (r.text || '').slice(0, 200)).replace(/\s+/g, ' ').slice(0, 300);
};

async function ask(key, sys, msgs) {
  const p = provider(key);
  if (!p) throw new Error('Kein KI-Schlüssel eingetragen');
  let models = p.openai ? p.models.slice() : await geminiModels(key, p.models);
  if (working[key]) models = [working[key]].concat(models.filter(m => m !== working[key]));
  // models that were too slow lately go to the end of the line
  const now = Date.now();
  models = models.filter(m => !(slowUntil[m] > now)).concat(models.filter(m => slowUntil[m] > now));
  const errors = [];
  for (const model of models.slice(0, 6)) {
    try {
      const got = await askModel(p, key, model, sys, msgs, errors);
      if (got) { working[key] = model; return got; }
    } catch (e) {
      if (e.fatal) throw e;
      if (/Zeitüberschreitung/.test(e.message)) slowUntil[model] = Date.now() + 6 * 3600 * 1000;
      errors.push({ status: 0, model, msg: e.message });   // timeout / network: next model
    }
  }
  const quota = errors.find(e => e.status === 429);
  const best = quota || errors.find(e => e.status !== 404) || errors[0];
  if (!best) throw new Error(p.name + ': kein passendes Modell gefunden');
  throw new Error(p.name + ' (' + best.model + (best.status ? ', ' + best.status : '') + '): ' + (quota ? 'Kostenloses Limit erreicht oder für dieses Modell nicht freigegeben – ' : '') + best.msg +
    (errors.length > 1 ? ' · ' + errors.length + ' Modelle probiert' : ''));
}

async function askModel(p, key, model, sys, msgs, errors) {
  {
    let r, text = null;
    if (p.openai) {
      const messages = [{ role: 'system', content: sys }].concat(msgs.map(m => ({ role: m.sender === 'user' ? 'user' : 'assistant', content: label(m) })));
      const body = { model, messages, temperature: 0.4, max_tokens: 700 };
      if (p.name === 'Groq') body.response_format = { type: 'json_object' };
      r = await post(p.url, { Authorization: 'Bearer ' + key }, body);
      if (r.status === 200) text = r.json && r.json.choices && r.json.choices[0] && r.json.choices[0].message && r.json.choices[0].message.content;
    } else {
      // Gemini wants user/model turns that alternate and start with the user
      const contents = [];
      for (const m of msgs) {
        const role = m.sender === 'user' ? 'user' : 'model', t = label(m);
        const last = contents[contents.length - 1];
        if (last && last.role === role) last.parts[0].text += '\n\n' + t; else contents.push({ role, parts: [{ text: t }] });
      }
      if (!contents.length || contents[0].role !== 'user') contents.unshift({ role: 'user', parts: [{ text: '(Der Chat beginnt.)' }] });
      r = await gemini(key, model, sys, contents);
      if (r.status === 200) {
        const c = r.json && r.json.candidates && r.json.candidates[0];
        text = c && c.content && (c.content.parts || []).filter(x => !x.thought).map(x => x.text || '').join('');
        if (!text) errors.push({ status: 200, model, msg: 'leere Antwort (' + ((c && c.finishReason) || (r.json && r.json.promptFeedback && r.json.promptFeedback.blockReason) || '?') + ')' });
      }
    }
    if (text) return { text, provider: p.name, model };
    if (r.status === 200) return null;
    const msg = errText(r);
    // a wrong key won't work with any model: stop right away with Google's/Groq's own words
    const fatal = m => Object.assign(new Error(m), { fatal: true });
    if (r.status === 401 || /api key not valid|api_key_invalid|invalid api key|incorrect api key/i.test(msg)) throw fatal(p.name + ': Der Schlüssel ist ungültig – ' + msg);
    if (r.status === 403 && /(has not been used|is disabled|SERVICE_DISABLED)/i.test(msg)) throw fatal(p.name + ': Die „Generative Language API“ ist für diesen Schlüssel nicht aktiviert – ' + msg);
    errors.push({ status: r.status, model, msg });
    return null; // 404 (model gone), 429 (no free quota for this model), 400, 5xx: the caller tries the next model
  }
}

// owner test area: how fast does each available model answer? The fastest working one is used from then on.
async function bench(key) {
  const p = provider(key);
  if (!p) throw new Error('Kein KI-Schlüssel eingetragen');
  const models = p.openai ? p.models.slice() : await geminiModels(key, p.models);
  const out = [];
  for (const model of models.slice(0, 8)) {
    const t0 = Date.now();
    const errors = [];
    try {
      const got = await askModel(p, key, model, 'Antworte nur als JSON: {"reply": "OK", "action": "resolve", "summary": "Test"}', [{ sender: 'user', body: 'Test' }], errors);
      out.push({ model, ok: !!got, ms: Date.now() - t0, msg: got ? '' : (errors[0] ? errors[0].status + ': ' + errors[0].msg : 'leer') });
    } catch (e) {
      out.push({ model, ok: false, ms: Date.now() - t0, msg: e.message });
      if (/Zeitüberschreitung/.test(e.message)) slowUntil[model] = Date.now() + 6 * 3600 * 1000;
      if (e.fatal) break;
    }
  }
  // the best model (list is ranked: newest stable full model first) that still answers quickly; else simply the fastest
  const ok = out.filter(x => x.ok);
  const pick = ok.find(x => x.ms < 3000) || ok.sort((a, b) => a.ms - b.ms)[0];
  if (pick) working[key] = pick.model;
  return { results: out, chosen: pick ? pick.model : '' };
}

// remember the chosen model across server restarts
const prefer = (key, model) => { if (key && model) working[key] = model; };

// msgs: [{ sender: 'user'|'ai'|'owner'|'system', body }]
async function answer(key, kind, msgs, settings) {
  const r = await ask(key, systemPrompt(kind, settings || {}), msgs.slice(-20));
  return Object.assign(parse(r.text), { model: r.model, provider: r.provider });
}

const lastModel = key => working[key] || '';

// for the owner's "Testen" button
async function check(key) {
  const r = await ask(key, 'Antworte nur als JSON: {"reply": "OK", "action": "resolve", "summary": "Test"}', [{ sender: 'user', body: 'Test' }]);
  if (!String(r.text || '').trim()) throw new Error(r.provider + ': leere Antwort beim Test');
  return r.provider + ' (' + r.model + ')';
}

module.exports = { provider, answer, check, lastModel, bench, prefer };
