// Accounts in MySQL. The admin creates accounts; later they can log in instead of using the PIN.
// Passwords are stored only as a scrypt hash. Works on the panel (npm installs mysql2); locally it degrades gracefully.
'use strict';

const crypto = require('crypto');
let mysql = null;
try { mysql = require('mysql2/promise'); } catch (e) { /* installed by npm on the panel; absent locally */ }

let pool = null, ready = false, lastError = 'nicht eingerichtet';

// cfg: { host, port, user, password, database }  (e.g. from notify.json "db": {...})
function configure(cfg) {
  const c = cfg || {};
  if (!mysql) { lastError = 'mysql2 fehlt – npm install nötig'; return; }
  if (!c.host || !c.user || !c.database) { lastError = 'keine Zugangsdaten (host/user/database)'; return; }
  try {
    pool = mysql.createPool({
      host: c.host, port: Number(c.port) || 3306, user: c.user, password: c.password || '', database: c.database,
      waitForConnections: true, connectionLimit: 4, charset: 'utf8mb4', connectTimeout: 10000
    });
    lastError = null;
  } catch (e) { lastError = e.message; }
}

async function init() {
  if (!pool) return false;
  await pool.query(
    'CREATE TABLE IF NOT EXISTS accounts (' +
    ' id INT AUTO_INCREMENT PRIMARY KEY,' +
    ' username VARCHAR(64) NOT NULL UNIQUE,' +
    ' pass VARCHAR(255) NOT NULL,' +
    ' role VARCHAR(32) NOT NULL DEFAULT "user",' +
    ' created BIGINT, last_login BIGINT' +
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  ready = true; lastError = null;
  return true;
}

// ----- password hashing (scrypt, built into Node) -----
function hash(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(pw), salt, 32);
  return 'scrypt$' + salt.toString('hex') + '$' + h.toString('hex');
}
function verifyHash(pw, stored) {
  try {
    const parts = String(stored).split('$');
    if (parts[0] !== 'scrypt') return false;
    const h = crypto.scryptSync(String(pw), Buffer.from(parts[1], 'hex'), 32);
    const want = Buffer.from(parts[2], 'hex');
    return want.length === h.length && crypto.timingSafeEqual(want, h);
  } catch (e) { return false; }
}

const cleanUser = u => String(u || '').trim().toLowerCase();

async function createAccount(username, password, role) {
  const u = cleanUser(username);
  if (!/^[a-z0-9._-]{3,32}$/.test(u)) throw new Error('Benutzername: 3–32 Zeichen, nur a–z, 0–9, . _ -');
  if (String(password || '').length < 6) throw new Error('Passwort: mindestens 6 Zeichen');
  try {
    await pool.query('INSERT INTO accounts (username, pass, role, created) VALUES (?,?,?,?)',
      [u, hash(password), role === 'admin' ? 'admin' : 'user', Date.now()]);
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new Error('Diesen Benutzernamen gibt es schon');
    throw e;
  }
  return { username: u, role: role === 'admin' ? 'admin' : 'user' };
}

async function listAccounts() {
  const [rows] = await pool.query('SELECT username, role, created, last_login FROM accounts ORDER BY created DESC');
  return rows;
}

async function deleteAccount(username) {
  const [r] = await pool.query('DELETE FROM accounts WHERE username=?', [cleanUser(username)]);
  if (!r.affectedRows) throw new Error('Konto nicht gefunden');
}

async function setPassword(username, password) {
  if (String(password || '').length < 6) throw new Error('Passwort: mindestens 6 Zeichen');
  const [r] = await pool.query('UPDATE accounts SET pass=? WHERE username=?', [hash(password), cleanUser(username)]);
  if (!r.affectedRows) throw new Error('Konto nicht gefunden');
}

async function login(username, password) {
  const [rows] = await pool.query('SELECT username, pass, role FROM accounts WHERE username=?', [cleanUser(username)]);
  if (!rows.length || !verifyHash(password, rows[0].pass)) return null;
  pool.query('UPDATE accounts SET last_login=? WHERE username=?', [Date.now(), rows[0].username]).catch(() => {});
  return { username: rows[0].username, role: rows[0].role };
}

async function count() {
  try { const [r] = await pool.query('SELECT COUNT(*) n FROM accounts'); return r[0].n; } catch (e) { return null; }
}

module.exports = {
  configure, init, hash, verifyHash,
  has: () => !!pool, ready: () => ready, error: () => lastError,
  createAccount, listAccounts, deleteAccount, setPassword, login, count
};
