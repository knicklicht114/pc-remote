// Accounts in MySQL. The admin creates accounts; later they can log in instead of using the PIN.
// Passwords are stored only as a scrypt hash. Works on the panel (npm installs mysql2); locally it degrades gracefully.
'use strict';

const crypto = require('crypto');
let mysql = null;
try { mysql = require('mysql2/promise'); } catch (e) { /* installed by npm on the panel; absent locally */ }

let pool = null, ready = false, lastError = 'nicht eingerichtet';

// cfg: { host, port, user, password, database }  (e.g. from notify.json "db": {...})
function configure(cfg) {
  const c = cfg || {};
  if (!mysql) { lastError = 'mysql2 fehlt – npm install nötig'; return; }
  if (!c.host || !c.user || !c.database) { lastError = 'keine Zugangsdaten (host/user/database)'; return; }
  try {
    pool = mysql.createPool({
      host: c.host, port: Number(c.port) || 3306, user: c.user, password: c.password || '', database: c.database,
      waitForConnections: true, connectionLimit: 4, charset: 'utf8mb4', connectTimeout: 10000
    });
    lastError = null;
  } catch (e) { lastError = e.message; }
}

async function init() {
  if (!pool) return false;
  await pool.query(
    'CREATE TABLE IF NOT EXISTS accounts (' +
    ' id INT AUTO_INCREMENT PRIMARY KEY,' +
    ' username VARCHAR(64) NOT NULL UNIQUE,' +
    ' pass VARCHAR(255) NOT NULL,' +
    ' role VARCHAR(32) NOT NULL DEFAULT "user",' +
    ' created BIGINT, last_login BIGINT' +
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  // one row per signed-in device; last_seen is refreshed by the app every minute while it is open
  await pool.query(
    'CREATE TABLE IF NOT EXISTS sessions (' +
    ' id CHAR(32) PRIMARY KEY,' +
    ' username VARCHAR(64) NOT NULL,' +
    ' device VARCHAR(80) NOT NULL DEFAULT "",' +
    ' platform VARCHAR(60) NOT NULL DEFAULT "",' +
    ' created BIGINT, last_seen BIGINT,' +
    ' INDEX (username)' +
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  // support chats: "VIP" requests and "Bug/Fix" reports. The AI answers first; status "owner" = waiting for the owner.
  await pool.query(
    'CREATE TABLE IF NOT EXISTS chats (' +
    ' id INT AUTO_INCREMENT PRIMARY KEY,' +
    ' username VARCHAR(64) NOT NULL,' +
    ' kind VARCHAR(16) NOT NULL,' +
    ' status VARCHAR(16) NOT NULL DEFAULT "ai",' +
    ' title VARCHAR(160) NOT NULL DEFAULT "",' +
    ' summary VARCHAR(400) NOT NULL DEFAULT "",' +
    ' created BIGINT, updated BIGINT, owner_seen BIGINT NOT NULL DEFAULT 0, user_seen BIGINT NOT NULL DEFAULT 0,' +
    ' INDEX (username), INDEX (status)' +
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  await pool.query(
    'CREATE TABLE IF NOT EXISTS chat_msgs (' +
    ' id INT AUTO_INCREMENT PRIMARY KEY,' +
    ' chat_id INT NOT NULL,' +
    ' sender VARCHAR(16) NOT NULL,' +
    ' body TEXT NOT NULL,' +
    ' created BIGINT,' +
    ' INDEX (chat_id)' +
    ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  await pool.query('CREATE TABLE IF NOT EXISTS settings (k VARCHAR(64) PRIMARY KEY, v TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  await cleanup();
  ready = true; lastError = null;
  return true;
}

// sign-ins expire after 30 days (same as the token), so old devices don't count forever
const SESSION_DAYS = 30;
const ONLINE_MS = 3 * 60 * 1000;
async function cleanup() {
  try { await pool.query('DELETE FROM sessions WHERE last_seen < ?', [Date.now() - SESSION_DAYS * 86400000]); } catch (e) { }
  // chats the AI closed (not about VIP / solved) disappear after 3 days
  try {
    const old = Date.now() - 3 * 86400000;
    await pool.query('DELETE m FROM chat_msgs m JOIN chats c ON c.id = m.chat_id WHERE c.status = "closed" AND c.updated < ?', [old]);
    await pool.query('DELETE FROM chats WHERE status = "closed" AND updated < ?', [old]);
  } catch (e) { }
}

// ----- password hashing (scrypt, built into Node) -----
function hash(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(pw), salt, 32);
  return 'scrypt$' + salt.toString('hex') + '$' + h.toString('hex');
}
function verifyHash(pw, stored) {
  try {
    const parts = String(stored).split('$');
    if (parts[0] !== 'scrypt') return false;
    const h = crypto.scryptSync(String(pw), Buffer.from(parts[1], 'hex'), 32);
    const want = Buffer.from(parts[2], 'hex');
    return want.length === h.length && crypto.timingSafeEqual(want, h);
  } catch (e) { return false; }
}

const cleanUser = u => String(u || '').trim().toLowerCase();

// roles: owner (runs everything) > admin (manages accounts) > vip > user
const ROLES = ['user', 'vip', 'admin', 'owner'];
const cleanRole = r => ROLES.includes(r) ? r : 'user';

async function createAccount(username, password, role) {
  const u = cleanUser(username);
  if (!/^[a-z0-9._-]{3,32}$/.test(u)) throw new Error('Benutzername: 3–32 Zeichen, nur a–z, 0–9, . _ -');
  if (String(password || '').length < 6) throw new Error('Passwort: mindestens 6 Zeichen');
  const r = cleanRole(role);
  try {
    await pool.query('INSERT INTO accounts (username, pass, role, created) VALUES (?,?,?,?)', [u, hash(password), r, Date.now()]);
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new Error('Diesen Benutzernamen gibt es schon');
    throw e;
  }
  return { username: u, role: r };
}

// self sign-up from the app: a normal user – except the very first account, which becomes the owner
async function register(username, password) {
  const [[o]] = await pool.query('SELECT COUNT(*) AS n FROM accounts WHERE role = "owner"');
  return createAccount(username, password, Number(o.n) ? 'user' : 'owner');
}

async function getRole(username) {
  const [rows] = await pool.query('SELECT role FROM accounts WHERE username=?', [cleanUser(username)]);
  return rows.length ? rows[0].role : null;
}

async function setRole(username, role) {
  const r = cleanRole(role);
  const [res] = await pool.query('UPDATE accounts SET role=? WHERE username=?', [r, cleanUser(username)]);
  if (!res.affectedRows) throw new Error('Konto nicht gefunden');
  return r;
}

// ----- settings (texts the owner writes in the app) -----
async function getSettings() {
  const [rows] = await pool.query('SELECT k, v FROM settings');
  const out = {};
  rows.forEach(r => { out[r.k] = r.v; });
  return out;
}
async function setSetting(k, v) {
  await pool.query('INSERT INTO settings (k, v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)', [String(k).slice(0, 64), String(v == null ? '' : v).slice(0, 4000)]);
}

// ----- support chats -----
const clipText = (s, n) => String(s || '').replace(/\r/g, '').trim().slice(0, n);

async function createChat(username, kind, title) {
  const now = Date.now();
  const [r] = await pool.query('INSERT INTO chats (username, kind, status, title, created, updated, user_seen) VALUES (?,?,?,?,?,?,?)',
    [cleanUser(username), kind === 'bug' ? 'bug' : 'vip', 'ai', clipText(title, 160), now, now, now]);
  return r.insertId;
}
async function addMsg(chatId, sender, body) {
  const now = Date.now();
  await pool.query('INSERT INTO chat_msgs (chat_id, sender, body, created) VALUES (?,?,?,?)', [chatId, sender, clipText(body, 4000), now]);
  await pool.query('UPDATE chats SET updated=? WHERE id=?', [now, chatId]);
  return now;
}
async function getChat(id) {
  const [[c]] = await pool.query('SELECT * FROM chats WHERE id=?', [Number(id) || 0]);
  if (!c) return null;
  const [msgs] = await pool.query('SELECT id, sender, body, created FROM chat_msgs WHERE chat_id=? ORDER BY id', [c.id]);
  return Object.assign(numChat(c), { msgs: msgs.map(m => Object.assign({}, m, { created: Number(m.created) })) });
}
const numChat = c => Object.assign({}, c, { created: Number(c.created), updated: Number(c.updated), owner_seen: Number(c.owner_seen), user_seen: Number(c.user_seen) });
async function setChat(id, fields) {
  const keys = Object.keys(fields).filter(k => ['status', 'summary', 'owner_seen', 'user_seen', 'title'].includes(k));
  if (!keys.length) return;
  await pool.query('UPDATE chats SET ' + keys.map(k => k + '=?').join(', ') + ' WHERE id=?', keys.map(k => fields[k]).concat([Number(id)]));
}
// a user's own chats, newest first, with the last message
async function userChats(username, kind) {
  const [rows] = await pool.query(
    'SELECT c.*, (SELECT body FROM chat_msgs m WHERE m.chat_id = c.id ORDER BY m.id DESC LIMIT 1) AS last, ' +
    ' (SELECT sender FROM chat_msgs m WHERE m.chat_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_sender ' +
    'FROM chats c WHERE c.username=? AND (? = "" OR c.kind = ?) ORDER BY c.updated DESC LIMIT 50', [cleanUser(username), kind || '', kind || '']);
  return rows.map(numChat);
}
// the owner's inbox: everything the AI passed on (and, on request, all chats)
async function inbox(all) {
  const [rows] = await pool.query(
    'SELECT c.*, (SELECT body FROM chat_msgs m WHERE m.chat_id = c.id ORDER BY m.id DESC LIMIT 1) AS last, ' +
    ' (SELECT sender FROM chat_msgs m WHERE m.chat_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_sender, a.role ' +
    'FROM chats c LEFT JOIN accounts a ON a.username = c.username ' + (all ? '' : 'WHERE c.status = "owner" ') + 'ORDER BY c.updated DESC LIMIT 200');
  return rows.map(numChat);
}
// the owner clears chats: one, all finished ones, or everything
async function deleteChat(id) {
  await pool.query('DELETE FROM chat_msgs WHERE chat_id=?', [Number(id) || 0]);
  const [r] = await pool.query('DELETE FROM chats WHERE id=?', [Number(id) || 0]);
  return r.affectedRows;
}
async function deleteAllChats(onlyClosed) {
  if (onlyClosed) {
    await pool.query('DELETE m FROM chat_msgs m JOIN chats c ON c.id = m.chat_id WHERE c.status = "closed"');
    const [r] = await pool.query('DELETE FROM chats WHERE status = "closed"');
    return r.affectedRows;
  }
  await pool.query('DELETE FROM chat_msgs');
  const [r] = await pool.query('DELETE FROM chats');
  return r.affectedRows;
}

async function unreadForOwner() {
  const [[r]] = await pool.query('SELECT COUNT(*) AS n FROM chats WHERE status = "owner" AND updated > owner_seen');
  return Number(r.n);
}

// accounts with how many devices are signed in and how many of them are online right now
async function listAccounts() {
  const [rows] = await pool.query(
    'SELECT a.username, a.role, a.created, a.last_login, COUNT(s.id) AS devices, ' +
    ' COALESCE(SUM(s.last_seen > ?), 0) AS online, MAX(s.last_seen) AS last_seen ' +
    'FROM accounts a LEFT JOIN sessions s ON s.username = a.username ' +
    'GROUP BY a.id, a.username, a.role, a.created, a.last_login ORDER BY a.created DESC', [Date.now() - ONLINE_MS]);
  return rows.map(r => Object.assign({}, r, { devices: Number(r.devices) || 0, online: Number(r.online) || 0, last_seen: r.last_seen == null ? null : Number(r.last_seen) }));
}

async function deleteAccount(username) {
  const u = cleanUser(username);
  const [r] = await pool.query('DELETE FROM accounts WHERE username=?', [u]);
  if (!r.affectedRows) throw new Error('Konto nicht gefunden');
  await pool.query('DELETE FROM sessions WHERE username=?', [u]);
  await pool.query('DELETE m FROM chat_msgs m JOIN chats c ON c.id = m.chat_id WHERE c.username=?', [u]);
  await pool.query('DELETE FROM chats WHERE username=?', [u]);
}

// a new password signs the account out everywhere
async function setPassword(username, password) {
  if (String(password || '').length < 6) throw new Error('Passwort: mindestens 6 Zeichen');
  const u = cleanUser(username);
  const [r] = await pool.query('UPDATE accounts SET pass=? WHERE username=?', [hash(password), u]);
  if (!r.affectedRows) throw new Error('Konto nicht gefunden');
  const [s] = await pool.query('DELETE FROM sessions WHERE username=?', [u]);
  return s.affectedRows;
}

// ----- signed-in devices -----
const clip = (s, n) => String(s || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, n);

async function createSession(username, device, platform) {
  const id = crypto.randomBytes(16).toString('hex'), now = Date.now();
  await pool.query('INSERT INTO sessions (id, username, device, platform, created, last_seen) VALUES (?,?,?,?,?,?)',
    [id, cleanUser(username), clip(device, 80) || 'Gerät', clip(platform, 60), now, now]);
  return id;
}

// true while the session exists (false = it was signed out, e.g. by the admin)
async function touchSession(id, username) {
  const [r] = await pool.query('UPDATE sessions SET last_seen=? WHERE id=? AND username=?', [Date.now(), String(id), cleanUser(username)]);
  return r.affectedRows > 0;
}

async function endSession(id) {
  const [r] = await pool.query('DELETE FROM sessions WHERE id=?', [String(id)]);
  return r.affectedRows > 0;
}

async function endAllSessions(username) {
  const [r] = await pool.query('DELETE FROM sessions WHERE username=?', [cleanUser(username)]);
  return r.affectedRows;
}

async function listSessions(username) {
  const now = Date.now();
  const [rows] = username
    ? await pool.query('SELECT id, username, device, platform, created, last_seen FROM sessions WHERE username=? ORDER BY last_seen DESC', [cleanUser(username)])
    : await pool.query('SELECT id, username, device, platform, created, last_seen FROM sessions ORDER BY last_seen DESC LIMIT 500');
  return rows.map(r => Object.assign({}, r, { created: Number(r.created), last_seen: Number(r.last_seen), online: now - Number(r.last_seen) < ONLINE_MS }));
}

async function stats() {
  const [[a]] = await pool.query('SELECT COUNT(*) AS n FROM accounts');
  const [[s]] = await pool.query('SELECT COUNT(*) AS devices, COALESCE(SUM(last_seen > ?), 0) AS online, COUNT(DISTINCT username) AS users FROM sessions', [Date.now() - ONLINE_MS]);
  return { accounts: Number(a.n), devices: Number(s.devices), online: Number(s.online), signedInAccounts: Number(s.users) };
}

async function login(username, password) {
  const [rows] = await pool.query('SELECT username, pass, role FROM accounts WHERE username=?', [cleanUser(username)]);
  if (!rows.length || !verifyHash(password, rows[0].pass)) return null;
  pool.query('UPDATE accounts SET last_login=? WHERE username=?', [Date.now(), rows[0].username]).catch(() => {});
  return { username: rows[0].username, role: rows[0].role };
}

async function count() {
  try { const [r] = await pool.query('SELECT COUNT(*) n FROM accounts'); return r[0].n; } catch (e) { return null; }
}

module.exports = {
  configure, init, cleanup, hash, verifyHash, SESSION_DAYS,
  has: () => !!pool, ready: () => ready, error: () => lastError,
  createAccount, listAccounts, deleteAccount, setPassword, login, count,
  createSession, touchSession, endSession, endAllSessions, listSessions, stats,
  ROLES, register, getRole, setRole, getSettings, setSetting,
  createChat, addMsg, getChat, setChat, userChats, inbox, unreadForOwner, deleteChat, deleteAllChats
};
