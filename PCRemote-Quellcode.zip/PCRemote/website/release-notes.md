## PC Remote {{VERSION}}

### Neu in {{VERSION}}
- **Automatische Updates** – PC Remote merkt neue Versionen und aktualisiert sich auf Knopfdruck (Einstellungen → Update). Das Handy lädt die neue Oberfläche von selbst nach.
- **Spotify ohne laufendes Lied** – die Wiedergabe-Kachel zeigt auch den zuletzt gespielten Titel; Play setzt fort, startet auf dem besten Gerät oder öffnet Spotify – egal ob pausiert, geschlossen oder auf einem anderen Gerät.
- **Lautstärke als Regler-Kachel** – hochkant, klein oder breit; Lauter/Leiser-Buttons lassen sich in einen Regler umwandeln.
- **Protokoll in der App** – Einstellungen → Dieser PC → Protokoll, mit „Nur Probleme".
- **Mithelfen (freiwillig)** – optional anonym unbekannte App-Namen senden, damit mehr Spiele und Programme unterstützt werden.

### Schon in 2.1
- Clips wie bei ShadowPlay & Medal (Grafikkarten-Encoder), Deck frei gestalten, aufgeräumter Medien-Player, schnelleres Laden, Installer mit Autostart.

### Downloads
| Datei | |
|---|---|
| **PCRemote-Setup.exe** | Installer – empfohlen |
| PCRemote-Portable.zip | entpacken und `PCRemote.exe` starten, nichts wird installiert |
| PCRemote-Quellcode.zip | Quellcode |

Windows 10 und 11 (64-Bit). Warnt Windows beim Start („Der Computer wurde durch Windows geschützt"): „Weitere Informationen" → „Trotzdem ausführen" – das Programm ist noch nicht kostenpflichtig signiert.
