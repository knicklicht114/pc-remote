## PC Remote {{VERSION}}

### Neu in {{VERSION}}
- **Clips per Stimme** – einen Satz einmal aufnehmen (Einstellungen → Clips per Stimme). Sagst du ihn am PC, wird ein Clip gespeichert – auch mitten im Spiel. Die Erkennung läuft offline in Windows.
- **Neuer Lautstärkeregler** – eine große Leiste wie im Kontrollzentrum: antippen springt, ziehen regelt fein, auch auf dem iPhone. Senkrechte Regler: doppelt tippen = stumm.
- **iPad und Handy quer** – Navigation als Leiste links, Kacheln und Symbole passen sich jedem Bildschirm automatisch an.
- **Als App auf den Home-Bildschirm** – mit Anleitung für iPhone, iPad und Android, eigenem Startbild und automatischem Wiederverbinden.
- **20 neue Addons** – OBS, Streamlabs, Teams, Zoom, TeamSpeak, WhatsApp, PowerPoint (Präsentations-Fernbedienung), Word, Excel, VLC, Wallpaper Engine, AMD, Minecraft, Firefox, Opera GX, Brave, Apple Music, Amazon Music, Deezer, TIDAL. Fehlt ein Tastenkürzel, trägst du es beim Antippen direkt ein.
- **Clips** – nach Spiel filtern, nach Tagen sortiert, „Neu“-Markierung, und jedes Gerät zeigt sofort „Clip gespeichert“.
- **Schneller** – Schalter reagieren sofort, weniger Abfragen, kein Warten auf Schriften beim Start.
- **Alles synchron** – Deck, Gruppen, Addons und Look sind auf allen Geräten sofort gleich.
- **App-Kacheln** – antippen öffnet, gedrückt halten schließt die App.
- **Ordnung** – deine persönlichen Daten liegen jetzt im Ordner `data` neben dem Programm (wird beim ersten Start automatisch umgezogen).

### Downloads
| Datei | |
|---|---|
| **PCRemote-Setup.exe** | Installer – empfohlen |
| PCRemote-Portable.zip | entpacken und `PCRemote.exe` starten, nichts wird installiert |
| PCRemote-Quellcode.zip | Quellcode |

Windows 10 und 11 (64-Bit). Warnt Windows beim Start („Der Computer wurde durch Windows geschützt"): „Weitere Informationen" → „Trotzdem ausführen" – das Programm ist noch nicht kostenpflichtig signiert.

Hast du schon Version 2.2 installiert? Lade 1.2.0 einmal hier herunter und installiere sie darüber – deine Einstellungen bleiben erhalten.
