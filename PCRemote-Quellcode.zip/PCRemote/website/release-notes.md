## PC Remote {{VERSION}}

### Neu
- **Clips wie bei ShadowPlay & Medal** – läuft ab dem Start im Hintergrund. **Alt+Shift+C** (auch im Spiel), der Deck-Button oder das Tray-Menü speichern die letzten 30 Sekunden mit Ton. Nutzt den Encoder der Grafikkarte (NVIDIA NVENC, Intel Quick Sync, AMD AMF).
- **Lautstärke-Regler als Kachel** – hochkant, in einem Feld oder breit. Lauter/Leiser-Buttons lassen sich mit einem Klick in einen Regler umwandeln.
- **Deck frei gestalten** – Kacheln aufs Raster ziehen, Größe ziehen, bis zu 8 Spalten, Kachelgröße pro Gerät, Rückgängig.
- **Medien** – aufgeräumter Player mit Cover-Hintergrund, Spotify-Lautstärke, Playlists und Suche.
- **Schneller** – Bildschirmaufnahme über DXGI und Hardware-Encoder, die App lädt etwa 3,5× schneller.
- **Installer** – mit Startmenü, Autostart und Deinstallation über die Windows-Einstellungen.

### Downloads
| Datei | |
|---|---|
| **PCRemote-Setup.exe** | Installer – empfohlen |
| PCRemote-Portable.zip | entpacken und `PCRemote.exe` starten, nichts wird installiert |
| PCRemote-Quellcode.zip | Quellcode |

Windows 10 und 11 (64-Bit). Warnt Windows beim Start („Der Computer wurde durch Windows geschützt“): „Weitere Informationen“ → „Trotzdem ausführen“ – das Programm ist noch nicht kostenpflichtig signiert.
