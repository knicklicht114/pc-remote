(function () {
  'use strict';

  // ---------- helpers ----------

  const $ = (s, r) => (r || document).querySelector(s);
  const enc = encodeURIComponent;
  const PC = /[?&]pc=1/.test(location.search);

  const LS = {
    get(k, d) { try { const v = localStorage.getItem('pcr.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('pcr.' + k, JSON.stringify(v)); } catch (e) { } },
    del(k) { try { localStorage.removeItem('pcr.' + k); } catch (e) { } }
  };

  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k === 'value') n.value = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(Infinity)) {
      if (c == null || c === false) continue;
      n.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return n;
  }

  const uid = () => Math.random().toString(36).slice(2, 10);
  const clone = o => JSON.parse(JSON.stringify(o));
  const getPath = (o, p) => p.split('.').reduce((x, k) => (x == null ? x : x[k]), o);

  function fmtTime(s) {
    s = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(sec).padStart(2, '0');
  }

  const ICONS = {
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
    next: '<path d="M5 5l10 7-10 7z"/><path d="M19 5v14"/>',
    prev: '<path d="M19 5L9 12l10 7z"/><path d="M5 5v14"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    shuffle: '<path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
    repeat: '<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
    repeat1: '<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/>',
    volume: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>',
    voldown: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>',
    mute: '<path d="M11 5L6 9H2v6h4l5 4z"/><path d="M22 9l-6 6M16 9l6 6"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/>',
    micoff: '<path d="M2 2l20 20"/><path d="M15 9.3V5a3 3 0 0 0-5.7-1.3"/><path d="M9 9v3a3 3 0 0 0 4.9 2.3"/><path d="M19 10a7 7 0 0 1-1.1 3.8M5 10a7 7 0 0 0 11.4 5.4M12 17v5M8 22h8"/>',
    headphones: '<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3zM3 19a2 2 0 0 0 2 2h1v-6H3z"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    restart: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
    keyboard: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 13h.01M18 13h.01M10 13h4M7 16h10"/>',
    mouse: '<rect x="6" y="2" width="12" height="20" rx="6"/><path d="M12 6v4"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    gamepad: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01"/><path d="M17.3 5H6.7a4 4 0 0 0-4 3.6L2 15a3 3 0 0 0 5.3 2l1.4-1.6a2 2 0 0 1 1.5-.7h3.6a2 2 0 0 1 1.5.7l1.4 1.6A3 3 0 0 0 22 15l-.7-6.4A4 4 0 0 0 17.3 5z"/>',
    more: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    terminal: '<path d="M4 17l6-5-6-5M12 19h8"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
    zap: '<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>',
    type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
    refresh: '<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/>',
    window: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>',
    minimize: '<path d="M5 18h14"/>',
    maximize: '<rect x="4" y="4" width="16" height="16" rx="2"/>',
    left: '<path d="M15 18l-6-6 6-6"/>',
    right: '<path d="M9 18l6-6-6-6"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    down: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
    back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    camera: '<path d="M14.5 4h-5L7.5 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3.5z"/><circle cx="12" cy="13" r="3.5"/>',
    video: '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M22 8l-6 4 6 4z"/>',
    share: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4M12 13V7M9 10l3-3 3 3"/>',
    waves: '<path d="M2 12h2M6 8v8M10 5v14M14 8v8M18 10v4M22 12h0"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.4 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.8 2z"/>',
    phoneoff: '<path d="M10.7 13.3a16 16 0 0 0 3.4 2.6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.7 2v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3 4.2 2 2 0 0 1 5 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.4 2.1L9 9.9"/><path d="M22 2L2 22"/>',
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    star: '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
    home: '<path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
    folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    record: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',
    wifi: '<path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M2 9a15 15 0 0 1 20 0M12 20h.01"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    puzzle: '<path d="M4 7h4a2 2 0 1 1 4 0h4v4a2 2 0 1 1 0 4v4H4v-4a2 2 0 1 0 0-4z"/>',
    qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM21 14v.01M14 21h.01M17 21h4v-4"/>',
    zoomin: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>',
    zoomout: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',
    fullscreen: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    store: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/>',
    code: '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12"/>',
    gauge: '<path d="M12 14l4-4"/><path d="M3.3 19a10 10 0 1 1 17.4 0"/>',
    rocket: '<path d="M4.5 16.5c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2.1-.1-2.9a2.2 2.2 0 0 0-2.9-.1z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.9A12.9 12.9 0 0 1 22 2c0 2.7-.8 7.5-6 11a22.4 22.4 0 0 1-4 2z"/><path d="M9 12H4s.6-3 2-4c1.6-1.1 5 0 5 0M12 15v5s3-.6 4-2c1.1-1.6 0-5 0-5"/>',
    devices: '<rect x="2" y="4" width="14" height="10" rx="2"/><rect x="17" y="8" width="5" height="12" rx="1"/><path d="M6 18h6"/>',
    resize: '<path d="M21 15v6h-6M21 21l-7-7M3 9V3h6M3 3l7 7"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-4"/>'
  };
  const PICK_ICONS = ['zap', 'play', 'next', 'prev', 'volume', 'mute', 'mic', 'micoff', 'headphones', 'music', 'heart', 'gamepad', 'keyboard', 'mouse',
    'monitor', 'window', 'camera', 'video', 'record', 'scissors', 'share', 'message', 'phone', 'phoneoff', 'globe', 'terminal', 'code', 'type', 'copy',
    'clipboard', 'folder', 'save', 'home', 'star', 'bell', 'sun', 'moon', 'lock', 'power', 'restart', 'logout', 'refresh', 'sliders', 'cpu', 'gauge',
    'rocket', 'wifi', 'users', 'store', 'download', 'search', 'x'];
  const COLORS = ['violet', 'cyan', 'pink', 'orange', 'yellow', 'green', 'red', 'slate'];

  const svg = name => '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || ICONS.zap) + '</svg>';
  function ic(name, cls) {
    const s = document.createElement('span');
    s.className = 'ic' + (cls ? ' ' + cls : '');
    s.innerHTML = svg(name);
    return s;
  }
  function setIc(node, name, cls) { node.innerHTML = ''; node.append(ic(name, cls)); }
  const tic = (name, color) => el('span', { class: 't-ic c-' + (color || 'violet') }, ic(name));

  function buzz(ms) {
    if (S.haptics && navigator.vibrate) try { navigator.vibrate(ms || 8); } catch (e) { }
  }

  function toast(msg, kind) {
    const box = $('#toasts');
    while (box.children.length > 2) box.firstChild.remove();
    const t = el('div', { class: 'toast ' + (kind || '') }, msg);
    box.append(t);
    setTimeout(() => t.classList.add('out'), kind === 'err' ? 4200 : 2400);
    setTimeout(() => t.remove(), kind === 'err' ? 4600 : 2800);
  }

  function flash(n) { n.classList.remove('fire'); void n.offsetWidth; n.classList.add('fire'); }

  // Tap + long-press on one element; cancels when the finger moves (so scrolling never triggers it).
  function press(node, o) {
    let timer = null, fired = false, down = false, sx = 0, sy = 0;
    if (!node.matches('button,a,input')) { node.tabIndex = 0; node.setAttribute('role', 'button'); }
    const cancel = () => { down = false; clearTimeout(timer); node.classList.remove('pressed'); };
    node.addEventListener('pointerdown', e => {
      if (e.button) return;
      down = true; fired = false; sx = e.clientX; sy = e.clientY;
      node.classList.add('pressed');
      if (o.long) timer = setTimeout(() => { fired = true; cancel(); buzz(20); o.long(); }, 480);
    });
    node.addEventListener('pointermove', e => { if (down && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
    node.addEventListener('pointerup', () => { if (!down) return; const ok = !fired; cancel(); if (ok && o.tap) o.tap(); });
    node.addEventListener('pointercancel', cancel);
    node.addEventListener('pointerleave', cancel);
    node.addEventListener('contextmenu', e => { e.preventDefault(); if (o.long && PC) o.long(); });
    node.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && o.tap) { e.preventDefault(); o.tap(); } });
  }

  // Range input that throttles sends and ignores server updates while the user is touching it.
  function makeRange(o, onSend, onLive) {
    const r = el('input', { type: 'range', class: 'range', min: o.min, max: o.max, step: o.step });
    let dragging = false, lastSend = 0, timer = null, pending = null, touched = 0;
    const paint = () => {
      const min = +r.min, max = +r.max;
      r.style.setProperty('--p', (max > min ? (r.value - min) / (max - min) * 100 : 0) + '%');
    };
    const send = () => { timer = null; if (pending == null) return; const v = pending; pending = null; lastSend = Date.now(); onSend(v); };
    r.addEventListener('input', () => {
      paint();
      pending = +r.value;
      if (onLive) onLive(+r.value);
      const wait = (o.throttle || 70) - (Date.now() - lastSend);
      if (wait <= 0) send(); else if (!timer) timer = setTimeout(send, wait);
    });
    const end = () => { dragging = false; touched = Date.now(); };
    r.addEventListener('pointerdown', () => { dragging = true; });
    r.addEventListener('pointerup', end);
    r.addEventListener('pointercancel', end);
    r.addEventListener('change', end);
    r.busy = () => dragging || Date.now() - touched < 1500;
    r.setValue = v => {
      if (r.busy() || v == null) return;
      r.value = v;
      paint();
    };
    r.setMax = m => { if (+r.max !== m) { r.max = m; paint(); } };
    paint();
    return r;
  }

  function sw(checked, onChange) {
    const i = el('input', { type: 'checkbox' });
    i.checked = !!checked;
    i.addEventListener('change', () => onChange(i.checked));
    return el('span', { class: 'sw' }, i, el('i'));
  }

  // Segmented tabs; returns the element. items: [[key, label]]
  function segTabs(items, cur, onPick, cls) {
    const seg = el('div', { class: 'seg' + (cls ? ' ' + cls : '') });
    items.forEach(([k, l]) => seg.append(el('button', { class: k === cur ? 'on' : '', 'data-k': k, onclick: () => {
      [...seg.children].forEach(c => c.classList.toggle('on', c.dataset.k === k));
      onPick(k);
    } }, l)));
    return seg;
  }

  const heading = (title, action) => el('div', { class: 'section-title' }, el('span', { class: 'grow' }, title), action || null);

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    const ta = el('textarea', { style: 'position:fixed;opacity:0;top:0' });
    ta.value = text;
    document.body.append(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { }
    ta.remove();
    return ok ? Promise.resolve() : Promise.reject();
  }

  // ---------- state + api ----------

  const S = {
    pin: LS.get('pin', null),
    token: PC ? null : LS.get('token', null), // this device's own key (the PC app itself just uses the PIN)
    name: '',
    local: false,
    layout: null,
    pageIdx: LS.get('deckPage', 0),
    apps: [],
    st: {},
    vm: null,
    sp: { connected: false },
    editing: false,
    haptics: LS.get('haptics', true),
    deckCell: LS.get('deckCell', PC ? 100 : 200), // largest tile size in px on this device (200 = as wide as the screen allows)
    online: true
  };

  class ApiError extends Error { constructor(m, s) { super(m); this.status = s; } }

  // for <img>/<video>/WebSocket addresses, which cannot send headers
  const authQ = () => S.token ? 'token=' + enc(S.token) : 'pin=' + enc(S.pin || '');

  // A readable name for this device, e.g. "Android-Handy (Chrome)"; can be renamed later.
  function deviceName() {
    const ua = navigator.userAgent;
    const os = /Android/i.test(ua) ? (/Mobile/i.test(ua) ? 'Android-Handy' : 'Android-Tablet') : /iPhone/i.test(ua) ? 'iPhone' : /iPad/i.test(ua) ? 'iPad'
      : /Windows/i.test(ua) ? 'Windows-PC' : /Mac OS/i.test(ua) ? 'Mac' : /Linux/i.test(ua) ? 'Linux' : 'Gerät';
    const m = /Android [\d.]+; ([^;)]+)\)/.exec(ua);
    const model = m && m[1].trim().length > 2 ? ' ' + m[1].trim() : '';
    const br = /SamsungBrowser/i.test(ua) ? 'Samsung Internet' : /EdgA?\//i.test(ua) ? 'Edge' : /Firefox|FxiOS/i.test(ua) ? 'Firefox' : /OPR\//i.test(ua) ? 'Opera'
      : /Chrome|CriOS/i.test(ua) ? 'Chrome' : /Safari/i.test(ua) ? 'Safari' : 'Browser';
    return os + model + ' (' + br + ')';
  }

  function saveToken(t) {
    S.token = t;
    LS.set('token', t);
    S.pin = null;
    LS.del('pin');
  }

  // Trade the PIN (typed or from the QR code) for this device's own key, once.
  async function pairWithPin(pin) {
    const r = await fetch('/api/pair', { method: 'POST', headers: { 'X-Pin': pin, 'Content-Type': 'application/json' }, body: JSON.stringify({ name: deviceName() }), cache: 'no-store' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.token) throw new ApiError(d.error || 'Fehler ' + r.status, r.status);
    saveToken(d.token);
  }

  async function api(path, body) {
    const opt = { headers: S.token ? { 'X-Token': S.token } : { 'X-Pin': S.pin || '' }, cache: 'no-store' };
    if (body !== undefined) {
      opt.method = 'POST';
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    let res;
    try { res = await fetch(path, opt); }
    catch (e) { setOnline(false); throw new ApiError('PC nicht erreichbar', 0); }
    setOnline(true);
    let data = null;
    try { data = await res.json(); } catch (e) { }
    if (!res.ok) {
      if (res.status === 401 && (S.pin || S.token)) logout(S.token ? 'Dieses Gerät wurde am PC entfernt – bitte neu verbinden.' : 'Die PIN stimmt nicht mehr – bitte neu eingeben.');
      throw new ApiError((data && data.error) || ('Fehler ' + res.status), res.status);
    }
    return data;
  }

  function prepare(a) {
    a = Object.assign({}, a);
    if (a.t === 'kill' && typeof a.procs === 'string') a.procs = a.procs.split(',').map(s => s.trim()).filter(Boolean);
    if (a.t === 'power') a.delay = +a.delay || 0;
    return a;
  }

  async function act(a, opts) {
    opts = opts || {};
    if (a.t === 'display' && a.mode) { quickDisplay(a.mode); return { ok: true }; } // handled on the phone itself
    buzz();
    try {
      const r = await api('/api/action', prepare(a));
      if (r && r.msg && !opts.quiet) toast(r.msg);
      pollSoon();
      return r || { ok: true };
    } catch (e) {
      if (e.status !== 401) toast(e.message, 'err');
      return null;
    }
  }

  function setOnline(v) {
    if (S.online === v) return;
    S.online = v;
    document.body.classList.toggle('offline', !v);
    document.querySelectorAll('.status-text').forEach(s => { s.textContent = v ? 'Verbunden' : 'Getrennt – versuche erneut …'; });
  }

  const isLocal = () => ['localhost', '127.0.0.1', '[::1]', '::1'].includes(location.hostname);

  function appById(id) { return S.apps.find(a => a.id === id); }
  function appByProc(p) { return S.apps.find(a => a.procs.includes(p)); }
  function nameForProc(p) {
    if (p === 'system') return 'Systemklänge';
    const a = appByProc(p);
    return a ? a.name : p.charAt(0).toUpperCase() + p.slice(1);
  }

  function appIcon(o, name) {
    const box = el('span', { class: 'appic' });
    if (o.proc === 'system') { box.classList.add('sys'); box.append(ic('bell')); return box; }
    if (!o.id && !o.proc) { box.classList.add('letter'); box.textContent = (name || '?').trim().charAt(0).toUpperCase(); return box; }
    const src = '/api/icon?' + (o.id ? 'id=' + enc(o.id) : 'proc=' + enc(o.proc)) + '&' + authQ();
    const img = el('img', { src, alt: '', loading: 'lazy', draggable: 'false' });
    img.onerror = () => {
      box.innerHTML = '';
      box.classList.add('letter');
      box.textContent = (name || '?').trim().charAt(0).toUpperCase();
    };
    box.append(img);
    return box;
  }

  function procSet(d) {
    if (!d || !d.procs) return null;
    if (!d._ps) d._ps = new Set(d.procs);
    return d._ps;
  }
  function isRunning(a, d) {
    const ps = procSet(d);
    return !!(a && ps && a.procs.some(p => ps.has(p)));
  }

  // ---------- binds (volume / mute targets) ----------

  const PCT = { min: 0, max: 100, step: 1, toServer: v => v / 100, fromServer: v => Math.round(v * 100), fmt: v => Math.round(v * 100) + ' %' };
  const DB = { min: -60, max: 12, step: 0.5, toServer: v => v, fromServer: v => v, fmt: v => (v > 0 ? '+' : '') + (+v).toFixed(1) + ' dB' };

  function vmParse(p) {
    const m = /^(Strip|Bus)\[(\d)\]\.(\w+)$/.exec(p || '');
    return m ? { kind: m[1], i: +m[2], prop: m[3], base: m[1] + '[' + m[2] + ']' } : null;
  }
  function vmName(m) {
    if (!m) return 'Voicemeeter';
    const vm = S.vm;
    if (m.kind === 'Strip') {
      const s = vm && vm.strips && vm.strips[m.i];
      return s ? s.label : 'Eingang ' + (m.i + 1);
    }
    const b = vm && vm.buses && vm.buses[m.i];
    return 'Bus ' + (b ? b.name : m.i + 1);
  }
  function vmParam(d, p) {
    const vm = d && d.vm;
    if (!vm || !vm.ok || !vm.params || !(p in vm.params)) return null;
    return vm.params[p];
  }

  function bindInfo(bind) {
    bind = bind || 'master';
    if (bind === 'master') return Object.assign({ label: 'Lautstärke', icon: 'volume', offIcon: 'mute', read: d => d && d.master, muteBind: 'master' }, PCT);
    if (bind === 'mic') return Object.assign({ label: 'Mikrofon', icon: 'mic', offIcon: 'micoff', read: d => d && d.mic, muteBind: 'mic' }, PCT);
    if (bind === 'spotify') return Object.assign({
      label: 'Spotify', icon: 'music', offIcon: 'music', proc: 'spotify', muteBind: null, idle: 'Spotify nicht aktiv',
      read: d => d && d.spotify && d.spotify.device && d.spotify.device.volume != null ? { v: d.spotify.device.volume / 100, m: false } : null
    }, PCT);
    if (bind.startsWith('app:')) {
      const p = bind.slice(4);
      return Object.assign({ label: nameForProc(p), proc: p, icon: 'volume', offIcon: 'mute', read: d => d && d.apps && d.apps[p], muteBind: bind, idle: 'Kein Ton aktiv' }, PCT);
    }
    if (bind.startsWith('vm:')) {
      const p = bind.slice(3), m = vmParse(p);
      const label = vmName(m) + (m && m.prop !== 'Gain' && m.prop !== 'Mute' ? ' → ' + m.prop : '');
      const muteP = m ? m.base + '.Mute' : p;
      return Object.assign({
        label, icon: 'sliders', offIcon: 'mute', muteBind: 'vm:' + muteP, idle: 'Voicemeeter nicht verbunden', vm: true,
        read: d => { const v = vmParam(d, p); return v == null ? null : { v, m: vmParam(d, muteP) > 0.5 }; }
      }, DB);
    }
    return Object.assign({ label: bind, icon: 'volume', read: () => null }, PCT);
  }

  // What a toggle shows: "alert" = active means muted, otherwise active means routed/on.
  function toggleInfo(bind) {
    bind = bind || 'mic';
    if (bind === 'master') return { label: 'Ton', on: 'volume', off: 'mute', alert: true, read: d => d && d.master ? d.master.m : null };
    if (bind === 'mic') return { label: 'Mikrofon', on: 'mic', off: 'micoff', alert: true, read: d => d && d.mic ? d.mic.m : null };
    if (bind.startsWith('discord:')) {
      const k = bind.slice(8);
      return {
        label: k === 'deaf' ? 'Discord Ton' : 'Discord Mikro', on: k === 'deaf' ? 'headphones' : 'mic', off: k === 'deaf' ? 'mute' : 'micoff', alert: true,
        read: d => d && d.discord && d.discord.ok && typeof d.discord[k] === 'boolean' ? d.discord[k] : null
      };
    }
    if (bind.startsWith('app:')) {
      const p = bind.slice(4);
      return { label: nameForProc(p), on: 'volume', off: 'mute', alert: true, proc: p, read: d => d && d.apps && d.apps[p] ? d.apps[p].m : null };
    }
    if (bind.startsWith('vm:')) {
      const p = bind.slice(3), m = vmParse(p);
      const mute = m && m.prop === 'Mute';
      return {
        label: vmName(m) + (mute ? '' : ' → ' + (m ? m.prop : p)), on: mute ? 'volume' : 'headphones', off: mute ? 'mute' : 'headphones', alert: mute,
        read: d => { const v = vmParam(d, p); return v == null ? null : v > 0.5; }
      };
    }
    return { label: bind, on: 'zap', off: 'zap', read: () => null };
  }

  // ---------- actions ----------

  const MEDIA_KEYS = [['playpause', 'Play / Pause'], ['next', 'Nächster Titel'], ['prev', 'Vorheriger Titel'], ['stop', 'Stopp'],
    ['volup', 'Lauter'], ['voldown', 'Leiser'], ['mute', 'Ton aus / an']];
  const MEDIA_SRC = [['', 'Was gerade läuft'], ['spotify', 'Nur Spotify'], ['chrome', 'Nur Chrome'], ['msedge', 'Nur Edge'], ['firefox', 'Nur Firefox']];
  const POWER = [['lock', 'Sperren'], ['monitoroff', 'Monitor aus'], ['sleep', 'Energiesparen'], ['hibernate', 'Ruhezustand'],
    ['restart', 'Neu starten'], ['shutdown', 'Herunterfahren'], ['logoff', 'Abmelden'], ['cancel', 'Herunterfahren abbrechen']];
  const POWER_ICON = { lock: 'lock', monitoroff: 'monitor', sleep: 'moon', hibernate: 'moon', restart: 'restart', shutdown: 'power', logoff: 'logout', cancel: 'x' };
  const SPOTIFY_CMDS = [['toggle', 'Play / Pause'], ['next', 'Nächster Song'], ['prev', 'Vorheriger Song'], ['like', 'Song liken / entliken'],
    ['volup', 'Lauter (in Spotify)'], ['voldown', 'Leiser (in Spotify)'], ['shuffle', 'Shuffle an / aus'], ['repeat', 'Wiederholen umschalten']];
  const SPOTIFY_ICON = { toggle: 'play', next: 'next', prev: 'prev', like: 'heart', volup: 'volume', voldown: 'voldown', shuffle: 'shuffle', repeat: 'repeat' };
  const DISCORD_CMDS = [['mute', 'Mikro stumm'], ['deaf', 'Ton aus (Deafen)'], ['disconnect', 'Auflegen'], ['camera', 'Kamera an / aus'],
    ['screen', 'Bildschirm teilen'], ['noise', 'Rauschunterdrückung'], ['soundboard', 'Soundboard']];
  const DISCORD_ICON = { mute: 'micoff', deaf: 'headphones', disconnect: 'phoneoff', camera: 'video', screen: 'share', noise: 'waves', soundboard: 'music' };
  const MACRO_HELP = 'Eine Zeile pro Schritt:\nkey ctrl+shift+m · text Hallo · wait 500 · launch notepad · url https://… · media next · mute mic · unmute mic · toggle mic · volume 40 · app <app-id> · kill <prozess> · cmd <befehl> · click left · discord mute · spotify next · spotify volume 40 · appkey chrome ctrl+t · riot valorant';
  const optLabel = (list, v, def) => (list.find(x => x[0] === v) || [0, def])[1];

  const ACTS = {
    media: { name: 'Medientaste', icon: 'play', fields: [['k', 'Taste', 'select', MEDIA_KEYS], ['src', 'Für welche App?', 'select', MEDIA_SRC]], label: a => optLabel(MEDIA_KEYS, a.k, 'Medien'), iconFor: a => ({ next: 'next', prev: 'prev', stop: 'stop', volup: 'volume', voldown: 'voldown', mute: 'mute' })[a.k] || 'play' },
    key: { name: 'Tastenkürzel (global)', icon: 'keyboard', fields: [['keys', 'Tasten', 'keys']], label: a => prettyKeys(a.keys) || 'Tastenkürzel' },
    appkey: { name: 'Taste an eine bestimmte App', icon: 'keyboard', fields: [['id', 'App', 'appsel'], ['keys', 'Tasten', 'keys'], ['back', 'Danach zurück zum vorherigen Fenster', 'check']], hint: 'Die App wird kurz nach vorne geholt und bekommt die Tasten – auch wenn gerade ein anderes Fenster aktiv ist.', label: a => prettyKeys(a.keys) || 'Taste' },
    spotify: { name: 'Spotify', icon: 'music', fields: [['cmd', 'Befehl', 'select', SPOTIFY_CMDS]], label: a => optLabel(SPOTIFY_CMDS, a.cmd, 'Spotify').replace(' (in Spotify)', ''), iconFor: a => SPOTIFY_ICON[a.cmd] || 'music' },
    discord: { name: 'Discord', icon: 'message', fields: [['cmd', 'Befehl', 'select', DISCORD_CMDS]], label: a => optLabel(DISCORD_CMDS, a.cmd, 'Discord'), iconFor: a => DISCORD_ICON[a.cmd] || 'message' },
    text: { name: 'Text tippen', icon: 'type', fields: [['text', 'Text', 'area'], ['enter', 'Danach Enter drücken', 'check']], label: a => (a.text || 'Text').slice(0, 24) },
    url: { name: 'Webseite / Link öffnen', icon: 'globe', fields: [['url', 'Adresse', 'text', 'https://… oder steam://…']], label: a => (a.url || 'Webseite').replace(/^https?:\/\/(www\.)?/, '').split('/')[0] },
    launch: { name: 'Programm / Datei öffnen', icon: 'folder', fields: [['target', 'Pfad, Programm oder Link', 'text', 'z. B. notepad oder C:\\Spiele\\spiel.exe'], ['args', 'Argumente (optional)', 'text']], label: a => (a.target || 'Öffnen').split(/[\\/]/).pop().replace(/\.exe$/i, '') },
    riot: { name: 'Riot-Spiel starten', icon: 'gamepad', fields: [['product', 'Spiel', 'select', [['valorant', 'VALORANT'], ['league_of_legends', 'League of Legends']]]], label: a => a.product === 'league_of_legends' ? 'LoL starten' : 'VALORANT starten' },
    cmd: { name: 'Konsolenbefehl', icon: 'terminal', fields: [['cmd', 'Befehl (cmd.exe)', 'text', 'z. B. ipconfig /flushdns']], label: a => a.cmd || 'Befehl' },
    macro: { name: 'Makro (mehrere Schritte)', icon: 'zap', fields: [['script', 'Schritte', 'area', 'discord mute\nkey win+d\nwait 300\nspotify next']], hint: MACRO_HELP, label: () => 'Makro' },
    power: { name: 'Energie', icon: 'power', fields: [['cmd', 'Aktion', 'select', POWER], ['delay', 'Verzögerung in Sekunden (nur Herunterfahren/Neustart)', 'number']], label: a => optLabel(POWER, a.cmd, 'Energie'), iconFor: a => POWER_ICON[a.cmd] || 'power' },
    kill: { name: 'Programm beenden', icon: 'x', fields: [['procs', 'Prozessname(n), mit Komma getrennt', 'text', 'z. B. discord']], label: a => (a.procs || 'Beenden') + ' beenden' },
    device: { name: 'Audiogerät wechseln', icon: 'headphones', fields: [['id', 'Gerät', 'device']], label: a => a.devName || 'Audiogerät' },
    clipsave: { name: 'Clip speichern', icon: 'scissors', fields: [], hint: 'Speichert die letzten Sekunden als Video – die Aufnahme läuft ab dem Start von PC Remote im Hintergrund.', label: () => 'Clip speichern' },
    vm: { name: 'Voicemeeter', icon: 'sliders', fields: [['cmd', 'Befehl', 'select', [['show', 'Fenster anzeigen'], ['restart', 'Audio-Engine neu starten']]]], label: a => a.cmd === 'restart' ? 'VM Neustart' : 'Voicemeeter' },
    display: { name: 'Handy als Bildschirm', icon: 'devices', fields: [['mode', 'Was soll passieren?', 'select', [['extend', 'Handy wird zusätzlicher Bildschirm'], ['mirror1', 'Bildschirm 1 aufs Handy spiegeln'], ['mirror2', 'Bildschirm 2 aufs Handy spiegeln'], ['mirror3', 'Bildschirm 3 aufs Handy spiegeln']]]],
      hint: 'Ein Tipp genügt: Das Handy zeigt den Bildschirm im Vollbild, Tippen = Klicken, Ziehen = Fenster ziehen.', label: a => a.mode === 'extend' || !a.mode ? 'Als Bildschirm' : 'Bildschirm ' + a.mode.slice(-1) }
  };
  const HIDDEN_ACTS = { app: 1, mctl: 1, focus: 1, appwin: 1, priority: 1, toggle: 1, set: 1, window: 1, clip: 1, volume: 1, tap: 1, mouse: 1 };

  const KEY_NAMES = { ctrl: 'Strg', control: 'Strg', shift: 'Shift', alt: 'Alt', win: 'Win', enter: 'Enter', esc: 'Esc', space: 'Leertaste', tab: 'Tab',
    backspace: '⌫', delete: 'Entf', del: 'Entf', up: '↑', down: '↓', left: '←', right: '→', printscreen: 'Druck', plus: '+', minus: '−' };
  function prettyKeys(k) {
    return (k || '').split(' ').map(chord => chord.split('+').map(s => s.trim()).filter(Boolean)
      .map(s => KEY_NAMES[s.toLowerCase()] || (s.length === 1 ? s.toUpperCase() : s.charAt(0).toUpperCase() + s.slice(1))).join(' + ')).join(', ');
  }
  const actLabel = a => (ACTS[a.t] && ACTS[a.t].label(a)) || 'Aktion';
  const actIcon = a => { const d = ACTS[a.t]; return d ? (d.iconFor ? d.iconFor(a) : d.icon) : 'zap'; };

  // ---------- sheets ----------

  const sheets = [];
  function sheet(title, body, opts) {
    opts = opts || {};
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      wrap.classList.remove('open');
      setTimeout(() => wrap.remove(), 260);
      const i = sheets.indexOf(close);
      if (i >= 0) sheets.splice(i, 1);
      if (opts.onClose) opts.onClose();
    };
    const head = el('div', { class: 'sheet-head' }, el('h2', null, title),
      el('button', { class: 'icon-btn', 'aria-label': 'Schließen', onclick: close }, ic('x')));
    const panel = el('div', { class: 'sheet' + (opts.wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true' }, el('div', { class: 'sheet-grip' }), head, body);
    const wrap = el('div', { class: 'sheet-wrap' }, el('div', { class: 'sheet-back', onclick: close }), panel);
    $('#sheets').append(wrap);
    requestAnimationFrame(() => requestAnimationFrame(() => wrap.classList.add('open')));
    sheets.push(close);
    return close;
  }
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && sheets.length) sheets[sheets.length - 1](); });

  function confirmSheet(title, text, okLabel, danger) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (done) return; done = true; resolve(v); close(); };
      const body = el('div', null,
        text ? el('p', { class: 'muted', style: 'margin:0 0 18px' }, text) : null,
        el('div', { class: 'sheet-actions' },
          el('button', { class: 'btn', onclick: () => finish(false) }, 'Abbrechen'),
          el('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => finish(true) }, okLabel || 'OK')));
      const close = sheet(title, body, { onClose: () => finish(false) });
    });
  }

  function pickList(items) {
    return el('div', { class: 'pick-list' }, items.map(it =>
      el('button', { class: 'pick-item' + (it.on ? ' on' : ''), onclick: it.onclick }, it.icon, el('div', null, el('b', null, it.title), it.sub ? el('small', null, it.sub) : null), it.trail || null)));
  }

  // ---------- polling ----------

  let current = null, pollTimer = null, pollGen = 0, soonTimer = null;

  function startPoll() {
    clearTimeout(pollTimer);
    const gen = ++pollGen;
    const loop = async () => {
      if (gen !== pollGen) return;
      const v = current;
      const p = v && v.poll && v.poll();
      if (p && !document.hidden) {
        try {
          const d = await api(p.path);
          if (gen === pollGen && v.update) v.update(d);
        } catch (e) { }
      }
      if (gen === pollGen) pollTimer = setTimeout(loop, (p && p.ms) || 2000);
    };
    loop();
  }
  function stopPoll() { pollGen++; clearTimeout(pollTimer); }
  function pollSoon() { clearTimeout(soonTimer); soonTimer = setTimeout(() => { if (current) startPoll(); }, 250); }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && current) startPoll(); });

  // ---------- addon store (settings, on/off, custom buttons; saved on the PC) ----------

  const AD = { settings: {}, disabled: [], buttons: {} };

  async function loadAddons() {
    try {
      const d = await api('/api/addons');
      if (d && typeof d === 'object') {
        AD.settings = d.settings || {};
        AD.disabled = d.disabled || [];
        AD.buttons = d.buttons || {};
      }
    } catch (e) { }
  }

  let adTimer = null;
  function saveAddons() {
    clearTimeout(adTimer);
    adTimer = setTimeout(() => {
      api('/api/addons', { settings: AD.settings, disabled: AD.disabled, buttons: AD.buttons })
        .catch(e => toast('Addon-Einstellungen nicht gespeichert: ' + e.message, 'err'));
    }, 300);
  }

  const addonOn = id => !AD.disabled.includes(id);
  function setAddonOn(id, on) {
    AD.disabled = AD.disabled.filter(x => x !== id);
    if (!on) AD.disabled.push(id);
    saveAddons();
  }
  function setting(addon, key) {
    const s = AD.settings[addon.id] || {};
    if (s[key] != null && s[key] !== '') return s[key];
    const def = (addon.settings || []).find(x => x.key === key);
    return def && def.def != null ? def.def : '';
  }

  // ---------- addon definitions ----------

  const K = (label, keys, icon) => ({ label, icon, a: { t: 'appkey', keys } });   // keys into this app's window
  const G = (label, keys, icon) => ({ label, icon, a: { t: 'key', keys } });      // global hotkey
  const U = (label, url, icon) => ({ label, icon, a: { t: 'url', url } });
  const KS = (label, key, icon) => ({ label, icon, setting: key });                // hotkey from this addon's settings

  const GAME = {
    type: 'buttons', title: 'Beim Zocken', items: [
      { label: 'Discord Mikro', icon: 'micoff', a: { t: 'discord', cmd: 'mute' }, state: 'discord.mute', deck: { type: 'toggle', bind: 'discord:mute', color: 'violet' } },
      { label: 'Discord Ton', icon: 'headphones', a: { t: 'discord', cmd: 'deaf' }, state: 'discord.deaf', deck: { type: 'toggle', bind: 'discord:deaf', color: 'violet' } },
      { label: 'Clip speichern', icon: 'scissors', a: { t: 'clipsave' } },
      { label: 'Clip (Medal)', icon: 'scissors', ref: ['medal', 'clipKey'] },
      { label: 'Replay (NVIDIA)', icon: 'record', ref: ['nvidia', 'replayKey'] },
      G('Screenshot', 'win+alt+printscreen', 'camera'),
      G('Aufnahme (Game Bar)', 'win+alt+r', 'video'),
      G('Game Bar', 'win+g', 'gamepad'),
      { label: 'Nächster Song', icon: 'next', a: { t: 'media', k: 'next', src: 'spotify' } }
    ]
  };

  function browserAddon(id, name, procs, rx, exe) {
    return {
      id, name, icon: 'globe', color: 'cyan', match: { procs, name: rx }, parts: ['media'],
      desc: 'Seiten öffnen, Tabs, Navigation, Zoom, Vollbild und YouTube-Steuerung',
      sections: [
        { type: 'player', title: 'Wiedergabe im Browser' },
        { type: 'openurl', exe },
        { type: 'buttons', title: 'Tabs & Navigation', items: [K('Neuer Tab', 'ctrl+t', 'plus'), K('Tab schließen', 'ctrl+w', 'x'), K('Nächster Tab', 'ctrl+tab', 'right'),
          K('Vorheriger Tab', 'ctrl+shift+tab', 'left'), K('Tab zurückholen', 'ctrl+shift+t', 'restart'), K('Neu laden', 'f5', 'refresh'), K('Zurück', 'alt+left', 'back'),
          K('Vor', 'alt+right', 'right'), K('Neues Fenster', 'ctrl+n', 'window'), K('Inkognito', 'ctrl+shift+n', 'lock'), K('Downloads', 'ctrl+j', 'download'), K('Verlauf', 'ctrl+h', 'list')] },
        { type: 'buttons', title: 'Ansicht', items: [K('Vollbild', 'f11', 'fullscreen'), K('Zoom +', 'ctrl+plus', 'zoomin'), K('Zoom −', 'ctrl+minus', 'zoomout'), K('Zoom 100 %', 'ctrl+0', 'search'),
          K('Ganz nach oben', 'home', 'up'), K('Ganz nach unten', 'end', 'down'), K('Seite hoch', 'pageup', 'up'), K('Seite runter', 'pagedown', 'down')] },
        { type: 'buttons', title: 'YouTube', items: [K('Play / Pause', 'k', 'play'), K('−10 s', 'j', 'prev'), K('+10 s', 'l', 'next'), K('Vollbild', 'f', 'fullscreen'),
          K('Ton aus', 'm', 'mute'), K('Untertitel', 'c', 'type'), K('Kinomodus', 't', 'monitor'), K('Nächstes Video', 'shift+n', 'next'), K('Schneller', 'shift+.', 'up'),
          K('Langsamer', 'shift+,', 'down'), K('Miniplayer', 'i', 'window')] }
      ]
    };
  }

  const ADDONS = [
    {
      id: 'spotify', name: 'Spotify', icon: 'music', color: 'green', match: { procs: ['spotify'], name: /^spotify/i }, parts: ['media', 'spotify'],
      desc: 'Lautstärke direkt in Spotify, Lieblingssongs, Playlists, Suche, Warteschlange, Geräte, Spulen, Shuffle',
      sections: [
        { type: 'player' },
        { type: 'buttons', title: 'Schnellzugriff', items: [
          { label: 'Song liken', icon: 'heart', a: { t: 'spotify', cmd: 'like' }, needs: 'spotify' },
          { label: 'Lauter', icon: 'volume', a: { t: 'spotify', cmd: 'volup' }, needs: 'spotify' },
          { label: 'Leiser', icon: 'voldown', a: { t: 'spotify', cmd: 'voldown' }, needs: 'spotify' },
          { label: 'Shuffle', icon: 'shuffle', a: { t: 'spotify', cmd: 'shuffle' }, needs: 'spotify' },
          { label: 'Wiederholen', icon: 'repeat', a: { t: 'spotify', cmd: 'repeat' }, needs: 'spotify' },
          U('Lieblingssongs', 'spotify:collection:tracks', 'heart'),
          K('Suchen', 'ctrl+l', 'search'),
          K('Zurück', 'alt+left', 'back')] },
        { type: 'spotify' }
      ]
    },
    {
      id: 'discord', name: 'Discord', icon: 'message', color: 'violet', match: { procs: ['discord'], name: /^discord$/i }, parts: ['discord'],
      desc: 'Mikro stumm, Ton aus, Auflegen, Kamera, Bildschirm teilen – direkt in Discord mit Live-Status',
      settings: [
        { key: 'muteKey', label: 'Ersatz-Kürzel: Mikro stumm', type: 'keys', hint: 'Nur nötig, wenn das Discord-Fenster ganz geschlossen ist. In Discord unter Einstellungen → Tastenbelegung dasselbe Kürzel festlegen.' },
        { key: 'deafKey', label: 'Ersatz-Kürzel: Ton aus', type: 'keys' },
        { key: 'disconnectKey', label: 'Ersatz-Kürzel: Auflegen', type: 'keys' }
      ],
      sections: [
        { type: 'discord' },
        { type: 'buttons', title: 'In Discord', items: [K('Schnellwechsler', 'ctrl+k', 'search'), K('Anruf annehmen', 'ctrl+enter', 'phone'), K('Anruf ablehnen', 'esc', 'phoneoff'),
          K('Nächster ungelesener Kanal', 'alt+shift+down', 'down'), K('Kanal gelesen', 'esc', 'check'), K('Server gelesen', 'shift+esc', 'check'),
          K('Einstellungen', 'ctrl+,', 'settings'), K('Nach oben', 'pageup', 'up')] }
      ]
    },
    browserAddon('chrome', 'Google Chrome', ['chrome'], /chrome/i, 'chrome'),
    browserAddon('edge', 'Microsoft Edge', ['msedge'], /microsoft edge/i, 'msedge'),
    {
      id: 'steam', name: 'Steam', icon: 'gamepad', color: 'slate', match: { procs: ['steam'], name: /^steam$/i },
      desc: 'Bibliothek, Shop, Freunde, Downloads, Big Picture, Online-Status und alle Steam-Spiele',
      sections: [
        { type: 'games', source: 'steam', title: 'Steam-Spiele' },
        { type: 'buttons', title: 'Steam öffnen', items: [U('Bibliothek', 'steam://nav/games', 'grid'), U('Shop', 'steam://store', 'store'), U('Freunde', 'steam://open/friends', 'users'),
          U('Downloads', 'steam://open/downloads', 'download'), U('Big Picture', 'steam://open/bigpicture', 'monitor'), U('Screenshots', 'steam://open/screenshots', 'camera'),
          U('Einstellungen', 'steam://open/settings', 'settings'), U('Konsole', 'steam://open/console', 'terminal')] },
        { type: 'buttons', title: 'Online-Status', items: [U('Online', 'steam://friends/status/online', 'check'), U('Abwesend', 'steam://friends/status/away', 'moon'),
          U('Unsichtbar', 'steam://friends/status/invisible', 'lock'), U('Offline', 'steam://friends/status/offline', 'x'),
          Object.assign(U('Steam beenden', 'steam://exit', 'power'), { confirm: true, color: 'red' })] }
      ]
    },
    {
      id: 'epic', name: 'Epic Games', icon: 'gamepad', color: 'slate', match: { procs: ['epicgameslauncher'], name: /epic games launcher/i },
      desc: 'Launcher, Shop und alle Epic-Spiele direkt starten',
      sections: [
        { type: 'games', source: 'epic', title: 'Epic-Spiele' },
        { type: 'buttons', title: 'Epic Games', items: [U('Shop', 'com.epicgames.launcher://store', 'store')] }
      ]
    },
    {
      id: 'riot', name: 'Riot Client', icon: 'gamepad', color: 'red', match: { procs: ['riot client', 'riotclientservices'], name: /^riot client$/i },
      desc: 'VALORANT und League of Legends direkt starten, ohne den Client anzuklicken',
      sections: [{ type: 'buttons', title: 'Spiele starten', items: [
        { label: 'VALORANT', icon: 'play', a: { t: 'riot', product: 'valorant' } },
        { label: 'League of Legends', icon: 'play', a: { t: 'riot', product: 'league_of_legends' } }] }]
    },
    {
      id: 'valorant', name: 'VALORANT', icon: 'gamepad', color: 'red', game: true, match: { procs: ['valorant-win64-shipping', 'valorant'], name: /^valorant$/i },
      launch: { t: 'riot', product: 'valorant' }, desc: 'Direkt über Riot starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'fortnite', name: 'Fortnite', icon: 'gamepad', color: 'violet', game: true, match: { procs: ['fortniteclient-win64-shipping', 'fortnitelauncher'], name: /^fortnite$/i },
      desc: 'Starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'battlefield', name: 'Battlefield', icon: 'gamepad', color: 'orange', game: true, match: { procs: ['bf6'], name: /battlefield/i },
      desc: 'Starten, Spiel-Shortcuts, Priorität, Lautstärke', sections: [GAME]
    },
    {
      id: 'roblox', name: 'Roblox', icon: 'gamepad', color: 'cyan', game: true, match: { procs: ['robloxplayerbeta'], name: /^roblox player$/i },
      desc: 'Starten, Roblox Studio, Website, Spiel-Shortcuts',
      sections: [GAME, { type: 'buttons', title: 'Roblox', items: [U('Roblox im Browser', 'https://www.roblox.com/home', 'globe'),
        { label: 'Roblox Studio', icon: 'code', a: { t: 'app', id: 'roblox-studio', op: 'smart' } }] }]
    },
    {
      id: 'medal', name: 'Medal', icon: 'scissors', color: 'orange', match: { procs: ['medal'], name: /^medal$/i },
      desc: 'Clips speichern und Aufnahmen starten – per Knopfdruck vom Handy',
      settings: [
        { key: 'clipKey', label: 'Clip speichern', type: 'keys', def: 'f8', hint: 'Standard in Medal ist F8. Hast du es in Medal geändert, hier dasselbe eintragen.' },
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: '' },
        { key: 'screenshotKey', label: 'Screenshot', type: 'keys', def: '' }
      ],
      sections: [{ type: 'buttons', title: 'Medal', items: [KS('Clip speichern', 'clipKey', 'scissors'), KS('Aufnahme an / aus', 'recordKey', 'record'), KS('Screenshot', 'screenshotKey', 'camera')] }]
    },
    {
      id: 'nvidia', name: 'NVIDIA', icon: 'cpu', color: 'green', match: { procs: ['nvidia app', 'nvidia overlay'], name: /^nvidia app$/i }, parts: ['stats'],
      desc: 'Grafikkarte live (Last, Temperatur, Strom, Lüfter, Takt), Instant Replay, Aufnahme, Overlay',
      settings: [
        { key: 'replayKey', label: 'Instant Replay speichern', type: 'keys', def: 'alt+f10' },
        { key: 'recordKey', label: 'Aufnahme starten / stoppen', type: 'keys', def: 'alt+f9' },
        { key: 'replayToggleKey', label: 'Instant Replay an / aus', type: 'keys', def: 'alt+shift+f10' },
        { key: 'screenshotKey', label: 'Screenshot', type: 'keys', def: 'alt+f1' },
        { key: 'overlayKey', label: 'Overlay öffnen', type: 'keys', def: 'alt+z' },
        { key: 'statsKey', label: 'Leistungs-Overlay', type: 'keys', def: 'alt+r' }
      ],
      sections: [{ type: 'gpu' }, { type: 'buttons', title: 'Aufnahme & Overlay', items: [KS('Replay speichern', 'replayKey', 'scissors'), KS('Aufnahme an / aus', 'recordKey', 'record'),
        KS('Instant Replay an / aus', 'replayToggleKey', 'restart'), KS('Screenshot', 'screenshotKey', 'camera'), KS('Overlay', 'overlayKey', 'window'), KS('Leistungs-Overlay', 'statsKey', 'gauge')] }]
    },
    {
      id: 'voicemeeter', name: 'Voicemeeter', icon: 'sliders', color: 'cyan', parts: ['vm'],
      match: { procs: ['voicemeeter', 'voicemeeter_x64', 'voicemeeterpro', 'voicemeeterpro_x64', 'voicemeeter8', 'voicemeeter8x64'], name: /^voicemeeter/i },
      desc: 'Alle Eingänge und Busse: Gain, Stumm, Routing A1–B3, Audio-Engine neu starten',
      sections: [{ type: 'vm' }, { type: 'buttons', title: 'Voicemeeter', items: [{ label: 'Fenster zeigen', icon: 'window', a: { t: 'vm', cmd: 'show' } }, { label: 'Audio-Engine neu starten', icon: 'restart', a: { t: 'vm', cmd: 'restart' } }] }]
    },
    {
      id: 'vscode', name: 'VS Code', icon: 'code', color: 'cyan', match: { procs: ['code'], name: /visual studio code/i },
      desc: 'Speichern, Terminal, Befehlspalette, Debuggen, Formatieren und mehr',
      sections: [
        { type: 'buttons', title: 'Dateien', items: [K('Speichern', 'ctrl+s', 'save'), K('Alle speichern', 'ctrl+k s', 'save'), K('Datei öffnen', 'ctrl+p', 'folder'), K('Rückgängig', 'ctrl+z', 'back')] },
        { type: 'buttons', title: 'Ansicht', items: [K('Befehlspalette', 'ctrl+shift+p', 'search'), K('Terminal', 'ctrl+`', 'terminal'), K('Seitenleiste', 'ctrl+b', 'window'),
          K('In Dateien suchen', 'ctrl+shift+f', 'search'), K('Git', 'ctrl+shift+g', 'code')] },
        { type: 'buttons', title: 'Code', items: [K('Formatieren', 'shift+alt+f', 'type'), K('Kommentar', 'ctrl+#', 'code'), K('Zeile hoch', 'alt+up', 'up'), K('Zeile runter', 'alt+down', 'down'),
          K('Debuggen', 'f5', 'play'), K('Stoppen', 'shift+f5', 'stop')] }]
    }
  ];
  const GAME_ADDON = { id: 'game', name: 'Spiel', icon: 'gamepad', color: 'violet', game: true, sections: [GAME], generic: true };

  function matches(ad, app) {
    const m = ad.match || {};
    if (m.name && m.name.test(app.name)) return true;
    return (m.procs || []).some(p => app.procs.includes(p));
  }
  function addonFor(app) {
    const ad = ADDONS.find(x => matches(x, app));
    if (ad) return addonOn(ad.id) ? ad : null;
    return app.kind === 'game' && addonOn('game') ? GAME_ADDON : null;
  }
  const appForAddon = ad => S.apps.find(a => matches(ad, a));
  function addonRunning(ad, d) {
    const ps = procSet(d);
    return !!(ps && ((ad.match && ad.match.procs) || []).some(p => ps.has(p))) || isRunning(appForAddon(ad), d);
  }

  // ---------- deck layout (pages of tiles) ----------

  function defaultLayout() {
    const P = (name, tiles) => ({ id: uid(), name, tiles: tiles.map(t => Object.assign({ id: uid() }, t)) });
    const has = rx => S.apps.some(a => rx.test(a.name));
    const start = [
      { type: 'np' },
      { type: 'slider', bind: 'master' },
      { type: 'toggle', bind: 'mic', w: 2, color: 'violet' },
      { type: 'toggle', bind: 'master', w: 2, color: 'cyan' }
    ];
    if (has(/^discord$/i)) start.push({ type: 'toggle', bind: 'discord:mute', w: 2, color: 'violet' }, { type: 'toggle', bind: 'discord:deaf', w: 2, color: 'violet' });
    start.push({ type: 'stats' });

    const prefer = ['discord', 'spotify', 'valorant', 'fortnite', 'roblox player', 'league of legends', 'minecraft', 'battlefield', 'counter-strike',
      'steam', 'obs studio', 'medal', 'google chrome', 'voicemeeter', 'epic games', 'riot client'];
    const picked = [];
    for (const w of prefer) {
      const a = S.apps.find(x => x.name.toLowerCase().includes(w) && !picked.includes(x));
      if (a) picked.push(a);
      if (picked.length >= 12) break;
    }
    for (const a of S.apps) {
      if (picked.length >= 12) break;
      if (a.kind === 'game' && !picked.includes(a)) picked.push(a);
    }

    const actions = [
      { type: 'action', label: 'Sperren', icon: 'lock', color: 'slate', a: { t: 'power', cmd: 'lock' } },
      { type: 'action', label: 'Monitor aus', icon: 'monitor', color: 'slate', a: { t: 'power', cmd: 'monitoroff' } },
      { type: 'action', label: 'Desktop', icon: 'home', color: 'cyan', a: { t: 'key', keys: 'win+d' } },
      { type: 'action', label: 'Screen\u00adshot', icon: 'camera', color: 'pink', a: { t: 'key', keys: 'win+shift+s' } },
      { type: 'action', label: 'Task-Manager', icon: 'gauge', color: 'slate', a: { t: 'key', keys: 'ctrl+shift+esc' } },
      { type: 'action', label: 'Game Bar', icon: 'gamepad', color: 'violet', a: { t: 'key', keys: 'win+g' } }
    ];
    if (has(/^spotify/i)) actions.push(
      { type: 'action', label: 'Spotify Play/Pause', icon: 'play', color: 'green', a: { t: 'media', k: 'playpause', src: 'spotify' } },
      { type: 'action', label: 'Nächster Song', icon: 'next', color: 'green', a: { t: 'media', k: 'next', src: 'spotify' } });

    const layout = { v: 2, pages: [P('Start', start), P('Apps', picked.map(a => ({ type: 'app', app: a.id, name: a.name }))), P('Aktionen', actions)] };
    layout.pages.forEach(normalize);
    return layout;
  }

  // Older layouts were one flat list of tiles.
  function migrateLayout(l) {
    if (!l || typeof l !== 'object') return null;
    if (Array.isArray(l.pages) && l.pages.length) return l;
    if (Array.isArray(l.tiles)) return { v: 2, custom: l.custom, pages: [{ id: uid(), name: 'Start', tiles: l.tiles }] };
    return null;
  }

  function curPageIdx() {
    const n = S.layout.pages.length;
    S.pageIdx = Math.max(0, Math.min(n - 1, S.pageIdx || 0));
    return S.pageIdx;
  }
  const curPage = () => S.layout.pages[curPageIdx()];
  function findTile(id) {
    for (const p of S.layout.pages) {
      const i = p.tiles.findIndex(t => t.id === id);
      if (i >= 0) return { page: p, i };
    }
    return null;
  }

  // ---------- grid: every tile has a fixed spot {x, y, w, h} on its page (gaps allowed, same on phone and PC) ----------

  const pageCols = p => Math.max(3, Math.min(8, p.cols || 4));
  const FULL_ROW = { np: 1, slider: 1, stats: 1 };
  const MIN_W = { np: 2, stats: 3 };
  function defSize(t, cols) {
    if (FULL_ROW[t.type]) return { w: cols, h: 1 };
    return { w: Math.min(t.w === 4 ? cols : (t.w || 1), cols), h: 1 };
  }
  const hit = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  const pageRows = p => p.tiles.reduce((m, o) => o.pos ? Math.max(m, o.pos.y + o.pos.h) : m, 0);

  function fits(p, r, skip) {
    if (r.x < 0 || r.y < 0 || r.x + r.w > pageCols(p)) return false;
    return !p.tiles.some(o => o !== skip && o.pos && hit(o.pos, r));
  }

  // Nearest free spot to (x, y): same row first, then below.
  function freeSpot(p, w, h, x, y, skip) {
    const cols = pageCols(p);
    w = Math.min(w, cols);
    let best = null;
    for (let yy = 0; yy <= pageRows(p) + h; yy++)
      for (let xx = 0; xx + w <= cols; xx++) {
        const r = { x: xx, y: yy, w, h };
        if (!fits(p, r, skip)) continue;
        const d = Math.abs(yy - y) * 10 + Math.abs(xx - x) + (yy < y ? 5 : 0);
        if (!best || d < best.d) best = { d, r };
      }
    return best.r;
  }

  // Gives every tile a valid spot. Tiles without one (older layouts) are placed one after another, like before.
  function normalize(p) {
    const cols = p.cols = pageCols(p);
    let cx = 0, cy = 0;
    const done = [];
    for (const t of p.tiles) {
      const s = defSize(t, cols);
      if (t.pos && t.pos.w > 0) {
        const w = Math.max(1, Math.min(cols, Math.round(t.pos.w))), h = Math.max(1, Math.min(4, Math.round(t.pos.h || 1)));
        const r = { x: Math.max(0, Math.min(cols - w, Math.round(t.pos.x) || 0)), y: Math.max(0, Math.round(t.pos.y) || 0), w, h };
        if (!done.some(o => hit(o.pos, r))) { t.pos = r; done.push(t); continue; }
        s.w = w; s.h = h;
      }
      let x = cx, y = cy, r;
      while (true) {
        if (x + s.w > cols) { x = 0; y++; }
        const c = { x, y, w: s.w, h: s.h };
        if (!done.some(o => hit(o.pos, c))) { r = c; break; }
        x++;
      }
      t.pos = r;
      done.push(t);
      cx = r.x + r.w; cy = r.y;
    }
  }

  // Put a tile on spot r: a same-sized tile there swaps places, anything else moves to the nearest free spot.
  function placeAt(p, t, r) {
    const old = t.pos;
    t.pos = r;
    const covered = p.tiles.filter(o => o !== t && o.pos && hit(o.pos, r));
    if (covered.length === 1 && old && old.w === r.w && old.h === r.h && covered[0].pos.w === r.w && covered[0].pos.h === r.h) {
      covered[0].pos = { x: old.x, y: old.y, w: old.w, h: old.h };
      return;
    }
    for (const o of covered) {
      const from = o.pos;
      o.pos = null;
      o.pos = freeSpot(p, from.w, from.h, from.x, from.y, o);
    }
  }

  // Tidy up: close all gaps, keeping the reading order.
  function packPage(p) {
    p.tiles.sort((a, b) => a.pos.y - b.pos.y || a.pos.x - b.pos.x);
    const sizes = p.tiles.map(t => ({ w: t.pos.w, h: t.pos.h }));
    p.tiles.forEach(t => { t.pos = null; });
    p.tiles.forEach((t, i) => { t.pos = freeSpot(p, sizes[i].w, sizes[i].h, 0, 0, t); });
  }

  function moveToPage(t, idx) {
    const loc = findTile(t.id), dest = S.layout.pages[idx];
    if (!loc || !dest || loc.page === dest) return;
    loc.page.tiles.splice(loc.i, 1);
    const w = Math.min(t.pos.w, pageCols(dest)), h = t.pos.h;
    t.pos = null;
    t.pos = freeSpot(dest, w, h, 0, Math.max(0, pageRows(dest) - 1), t);
    dest.tiles.push(t);
    toast('Auf die Seite „' + dest.name + '“ verschoben');
  }

  // Undo for layout changes while editing.
  const undoStack = [];
  function remember() {
    undoStack.push(JSON.stringify(S.layout.pages));
    if (undoStack.length > 40) undoStack.shift();
    paintUndo();
  }
  function undoLast() {
    const s = undoStack.pop();
    if (!s) return;
    S.layout.pages = JSON.parse(s);
    saveLayout();
    Deck.draw();
    paintUndo();
    toast('Rückgängig gemacht');
  }
  function paintUndo() {
    document.querySelectorAll('.undo-btn').forEach(b => {
      b.style.display = S.editing && current === Deck ? '' : 'none';
      b.disabled = !undoStack.length;
    });
  }

  let saveTimer = null;
  function saveLayout() {
    S.layout.custom = true;
    LS.set('layout', S.layout);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      api('/api/layout', S.layout).catch(e => toast('Layout nicht gespeichert: ' + e.message, 'err'));
    }, 400);
  }

  async function loadLayout() {
    try { S.layout = migrateLayout(await api('/api/layout')); }
    catch (e) { S.layout = migrateLayout(LS.get('layout', null)); }
    if (!S.layout) S.layout = defaultLayout();
    S.layout.pages.forEach(normalize);
  }

  async function loadApps() {
    try { S.apps = await api('/api/apps') || []; } catch (e) { }
  }

  let addAt = null; // set when an empty grid cell was tapped: the new tile goes exactly there
  function addTile(t, pageIdx) {
    remember();
    t.id = uid();
    const p = S.layout.pages[pageIdx == null ? curPageIdx() : pageIdx];
    const s = defSize(t, pageCols(p));
    const want = addAt || { x: 0, y: Math.max(0, pageRows(p) - 1) };
    addAt = null;
    const r = { x: Math.min(want.x, pageCols(p) - s.w), y: want.y, w: s.w, h: s.h };
    t.pos = fits(p, r) ? r : freeSpot(p, s.w, s.h, want.x, want.y);
    p.tiles.push(t);
    saveLayout();
    if (current === Deck) Deck.draw();
  }

  // Put something on the deck; asks for the page when there are several.
  function toDeck(t, label) {
    const ps = S.layout.pages;
    const put = i => { addTile(t, i); toast('„' + label + '“ liegt jetzt auf der Seite „' + ps[i].name + '“'); };
    if (ps.length === 1) return put(0);
    const close = sheet('Auf welche Deck-Seite?', pickList(ps.map((p, i) => ({
      icon: tic('grid', 'violet'), title: p.name, sub: p.tiles.length + ' Kacheln', onclick: () => { close(); put(i); }
    }))));
  }

  // ---------- tiles ----------

  function artUrl(s) {
    if (!s) return null;
    if (s.image) return s.image;
    return s.art ? '/api/art?id=' + enc(s.id) + '&k=' + s.art + '&' + authQ() : null;
  }

  const TILES = {
    np: {
      name: 'Wiedergabe', w: 4,
      build(n, t, live) {
        const title = el('div', { class: 'np-title' }, 'Nichts läuft');
        const sub = el('div', { class: 'np-sub' }, '');
        const img = el('img', { alt: '' });
        const art = el('div', { class: 'np-art' }, ic('music'), img);
        const pp = el('button', { class: 'np-btn big', 'aria-label': 'Play/Pause' }, ic('play', 'fill'));
        const prev = el('button', { class: 'np-btn', 'aria-label': 'Zurück' }, ic('prev', 'fill'));
        const next = el('button', { class: 'np-btn', 'aria-label': 'Weiter' }, ic('next', 'fill'));
        let np = null;
        const ctl = cmd => np && np.id ? act({ t: 'mctl', id: np.id, cmd }, { quiet: 1 }) : act({ t: 'media', k: cmd === 'toggle' ? 'playpause' : cmd }, { quiet: 1 });
        if (live) {
          prev.onclick = () => ctl('prev');
          pp.onclick = () => ctl('toggle');
          next.onclick = () => ctl('next');
          press(art, { tap: () => show('media') });
        }
        n.append(art, el('div', { class: 'np-meta' }, title, sub), el('div', { class: 'np-ctl' }, prev, pp, next));
        let playing = null, lastArt = null;
        img.onerror = () => { img.style.display = 'none'; };
        img.onload = () => { img.style.display = ''; };
        return d => {
          np = d && d.np;
          title.textContent = np ? (np.title || np.app) : 'Nichts läuft';
          sub.textContent = !np ? 'Spotify oder YouTube starten' : np.title ? [np.artist, np.app].filter(Boolean).join(' · ') : np.playing === false ? 'Pausiert' : np.app;
          const p = !!(np && np.playing === true);
          if (p !== playing) { playing = p; setIc(pp, p ? 'pause' : 'play', 'fill'); }
          const u = artUrl(np);
          if (u !== lastArt) { lastArt = u; if (u) img.src = u; else img.style.display = 'none'; }
        };
      }
    },

    slider: {
      name: 'Lautstärkeregler', w: 4,
      build(n, t, live) {
        const b = bindInfo(t.bind);
        // narrow or upright tiles become a fader: swipe up/down on the tile, like a mixer channel
        if (!t.pos || t.pos.w < 2 * t.pos.h) return faderTile(n, t, live, b);
        const mute = el('button', { class: 'sl-mute', 'aria-label': 'Stumm' }, b.proc ? appIcon({ proc: b.proc }, b.label) : ic(b.icon));
        const val = el('div', { class: 'sl-val' }, '–');
        const range = makeRange(b, v => act(t.bind === 'spotify' ? { t: 'spotify', cmd: 'volume', value: v } : { t: 'set', bind: t.bind, value: b.toServer(v) }, { quiet: 1 }),
          v => { val.textContent = b.fmt(b.toServer(v)); });
        if (!live) range.disabled = true;
        if (live && b.muteBind) mute.onclick = () => act({ t: 'toggle', bind: b.muteBind }, { quiet: 1 });
        n.append(el('div', { class: 'sl-head' }, mute, el('div', { class: 'sl-name' }, t.label || b.label), val), range);
        let wasMuted = null;
        return d => {
          const s = b.read(d);
          n.classList.toggle('idle', !s);
          if (!s) { val.textContent = (t.pos && t.pos.w >= 3 && b.idle) || '–'; return; } // short tiles: the name needs the room
          range.setValue(b.fromServer(s.v));
          if (!range.busy()) val.textContent = b.fmt(s.v);
          n.classList.toggle('muted-state', !!s.m);
          if (!b.proc && wasMuted !== !!s.m) { wasMuted = !!s.m; setIc(mute, s.m ? b.offIcon : b.icon); }
        };
      }
    },

    toggle: {
      name: 'Stummschalter', w: 1, sq: true,
      build(n, t, live) {
        const info = toggleInfo(t.bind);
        const icBox = el('div', { class: 't-ic' }, ic(info.on));
        const state = el('div', { class: 't-sub' }, '…');
        n.append(icBox, el('div', null, el('div', { class: 't-label' }, t.label || info.label), state));
        if (live) press(n, { tap: () => { flash(n); act({ t: 'toggle', bind: t.bind }, { quiet: 1 }); } });
        let last;
        return d => {
          const v = info.read(d);
          n.classList.toggle('idle', v == null);
          n.classList.toggle('alert', !!(info.alert && v));
          n.classList.toggle('on', !!(!info.alert && v));
          state.textContent = v == null ? (t.bind && t.bind.startsWith('app:') ? 'Kein Ton aktiv' : t.bind && t.bind.startsWith('discord:') ? 'Discord zu' : '–') : info.alert ? (v ? 'Stumm' : 'An') : (v ? 'An' : 'Aus');
          const iconName = info.alert ? (v ? info.off : info.on) : info.on;
          if (iconName !== last) { last = iconName; setIc(icBox, iconName); }
        };
      }
    },

    app: {
      name: 'App / Spiel', w: 1, sq: true,
      build(n, t, live) {
        const a = appById(t.app);
        const name = t.label || (a && a.name) || t.name || t.app;
        n.append(el('span', { class: 'run-dot' }), appIcon({ id: t.app }, name), el('div', { class: 't-label' }, name));
        if (live) press(n, {
          tap: () => {
            const app = appById(t.app);
            if (!app) return toast('App nicht gefunden – unter „Apps“ neu scannen', 'err');
            const ad = addonFor(app);
            act(t.op === 'smart' || !t.op ? (ad && ad.launch && !isRunning(app, S.st) ? ad.launch : { t: 'app', id: t.app, op: 'smart' }) : { t: 'app', id: t.app, op: t.op });
          },
          long: () => { const app = appById(t.app); if (app) openApp({ app }); }
        });
        return d => n.classList.toggle('running', isRunning(appById(t.app), d));
      }
    },

    action: {
      name: 'Aktion', w: 1, sq: true,
      build(n, t, live) {
        n.append(el('div', { class: 't-ic' }, ic(t.icon || actIcon(t.a || {}))), el('div', { class: 't-label' }, t.label || actLabel(t.a || {})));
        if (live) press(n, {
          tap: async () => {
            if (t.confirm && !await confirmSheet((t.label || actLabel(t.a)) + '?', 'Wirklich ausführen?', 'Ausführen', true)) return;
            flash(n);
            act(t.a);
          }
        });
        return null;
      }
    },

    stats: {
      name: 'Systemwerte', w: 4,
      build(n) {
        const mk = label => {
          const b = el('b', null, '–'), bar = el('i'), sm = el('small', null, '');
          const box = el('div', { class: 'bar' }, bar);
          n.append(el('div', { class: 'meter' }, el('div', { class: 'meter-top' }, label, b), box, sm));
          return (pct, extra) => {
            b.textContent = pct == null ? '–' : Math.round(pct) + '%';
            bar.style.width = (pct || 0) + '%';
            box.classList.toggle('hot', pct > 85);
            sm.textContent = extra || '';
          };
        };
        const cpu = mk('CPU'), ram = mk('RAM'), gpu = mk('GPU');
        return d => {
          const s = d && d.stats;
          if (!s) return;
          cpu(s.cpu, 'Laufzeit ' + uptime(s.uptime));
          ram(s.ram && s.ram.pct, s.ram ? s.ram.used + ' / ' + s.ram.total + ' GB' : '');
          if (s.gpu) gpu(s.gpu.util, s.gpu.temp + ' °C · ' + Math.round(s.gpu.memUsed / 1024 * 10) / 10 + ' GB');
          else gpu(null, 'nur NVIDIA');
        };
      }
    }
  };

  // Volume as a fader that fits into one cell or stands upright: the fill shows the level,
  // dragging up/down anywhere on the tile changes it (relative, so a tap never jumps), the symbol mutes.
  function faderTile(n, t, live, b) {
    const fill = el('div', { class: 'fd-fill' });
    const val = el('div', { class: 'fd-val' }, '–');
    const mute = el('button', { class: 'fd-mute', 'aria-label': 'Stumm' }, b.proc ? appIcon({ proc: b.proc }, b.label) : ic(b.icon));
    n.classList.add('fader');
    n.append(fill, el('div', { class: 'fd-top' }, mute, val), el('div', { class: 'fd-name' }, t.label || b.label));
    const span = b.max - b.min;
    let cur = null, held = 0, pending = null, timer = null, last = 0, wasMuted = null;
    const paint = v => {
      fill.style.height = Math.max(0, Math.min(100, (v - b.min) / span * 100)) + '%';
      val.textContent = b.fmt(b.toServer(v));
    };
    const send = () => {
      timer = null;
      if (pending == null) return;
      const v = pending;
      pending = null;
      last = Date.now();
      act(t.bind === 'spotify' ? { t: 'spotify', cmd: 'volume', value: v } : { t: 'set', bind: t.bind, value: b.toServer(v) }, { quiet: 1 });
    };
    const setVal = v => {
      v = Math.max(b.min, Math.min(b.max, Math.round(v / b.step) * b.step));
      if (v === cur) return;
      cur = v;
      held = Date.now();
      paint(v);
      pending = v;
      const wait = (t.bind === 'spotify' ? 300 : 70) - (Date.now() - last);
      if (wait <= 0) send(); else if (!timer) timer = setTimeout(send, wait);
    };
    if (live) {
      if (b.muteBind) mute.onclick = e => { e.stopPropagation(); act({ t: 'toggle', bind: b.muteBind }, { quiet: 1 }); };
      n.addEventListener('pointerdown', e => {
        if (e.button || cur == null || e.target.closest('.fd-mute')) return;
        const y0 = e.clientY, v0 = cur, scale = Math.max(n.clientHeight, 170); // whole range ≈ one tile height (at least 170 px)
        n.classList.add('dragging');
        try { n.setPointerCapture(e.pointerId); } catch (x) { }
        const move = ev => setVal(v0 + (y0 - ev.clientY) / scale * span);
        const end = () => {
          n.classList.remove('dragging');
          n.removeEventListener('pointermove', move);
          n.removeEventListener('pointerup', end);
          n.removeEventListener('pointercancel', end);
          held = Date.now();
        };
        n.addEventListener('pointermove', move);
        n.addEventListener('pointerup', end);
        n.addEventListener('pointercancel', end);
      });
      n.addEventListener('wheel', e => { if (cur == null) return; e.preventDefault(); setVal(cur + (e.deltaY < 0 ? 1 : -1) * span / 25); }, { passive: false });
    }
    return d => {
      const s = b.read(d);
      n.classList.toggle('idle', !s);
      if (!s) { val.textContent = '–'; return; }
      n.classList.toggle('muted-state', !!s.m);
      if (!b.proc && wasMuted !== !!s.m) { wasMuted = !!s.m; setIc(mute, s.m ? b.offIcon : b.icon); }
      if (n.classList.contains('dragging') || Date.now() - held < 1500) return; // don't jump back while the finger is (or just was) on it
      cur = b.fromServer(s.v);
      paint(cur);
    };
  }

  function uptime(s) {
    if (s == null) return '';
    const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
    return (d ? d + ' T ' : '') + (d || h ? h + ' h ' : '') + m + ' min';
  }

  const gridArea = r => 'grid-column:' + (r.x + 1) + ' / span ' + r.w + ';grid-row:' + (r.y + 1) + ' / span ' + r.h;

  function renderTile(t, ups, page) {
    const kind = TILES[t.type];
    if (!kind) return null;
    const r = t.pos;
    const n = el('div', { class: 'tile t-' + t.type + ' w' + (r.w >= 3 ? 4 : r.w) + (r.h >= 2 ? ' tall' : '') + ' c-' + (t.color || 'violet'), style: gridArea(r) });
    const upd = kind.build(n, t, !S.editing);
    if (upd) ups.push(upd);
    if (S.editing) {
      n.append(el('span', { class: 'edit-badge' }, ic('edit')), el('span', { class: 'rs-handle', title: 'Ziehen = Größe ändern' }, ic('resize')));
      dragTile(n, t, page);
    }
    return n;
  }

  // Edit mode: drag a tile to any cell (on phones: hold briefly, then drag), drag the corner to resize,
  // drop it on a page name to move it there, tap it to edit.
  function dragTile(n, t, page) {
    const cols = pageCols(page);
    let active = false;
    n.addEventListener('touchmove', e => { if (active) e.preventDefault(); }, { passive: false });
    n.addEventListener('contextmenu', e => e.preventDefault());
    n.addEventListener('pointerdown', e => {
      if (e.button) return;
      const resize = !!e.target.closest('.rs-handle');
      const touch = e.pointerType === 'touch';
      const grid = n.parentNode, marker = grid.querySelector('.drop-marker');
      const gr = grid.getBoundingClientRect(), gap = parseFloat(getComputedStyle(grid).columnGap) || 10;
      const pitch = (gr.width - gap * (cols - 1)) / cols + gap;
      const rect = n.getBoundingClientRect(), sx = e.clientX, sy = e.clientY, scroll0 = window.scrollY;
      let moving = false, armed = !touch || resize, target = null, ghost = null, chip = null, scrollT = null, lastY = sy;
      active = false;
      // a quick swipe on a phone still scrolls the page; holding still for a moment picks the tile up
      const armT = armed ? null : setTimeout(() => { armed = true; active = true; buzz(15); n.classList.add('lifted'); }, 260);
      try { n.setPointerCapture(e.pointerId); } catch (x) { }

      const mark = r => {
        const busy = page.tiles.some(o => o !== t && o.pos && hit(o.pos, r));
        marker.setAttribute('style', gridArea(r));
        marker.className = 'drop-marker on' + (busy ? ' push' : '');
      };
      const scrollLoop = () => {
        clearInterval(scrollT);
        scrollT = setInterval(() => {
          if (lastY < 90) window.scrollBy(0, -12);
          else if (lastY > window.innerHeight - 110) window.scrollBy(0, 12);
        }, 16);
      };
      const move = ev => {
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        lastY = ev.clientY;
        if (!armed) { if (Math.hypot(dx, dy) > 8) { clearTimeout(armT); finish(null, true); } return; }
        if (!moving) {
          if (Math.hypot(dx, dy) < 6) return;
          moving = true;
          active = true;
          n.classList.add('drag-src');
          if (!resize) {
            ghost = n.cloneNode(true);
            ghost.className += ' drag-ghost';
            ghost.setAttribute('style', 'left:' + rect.left + 'px;top:' + rect.top + 'px;width:' + rect.width + 'px;height:' + rect.height + 'px');
            document.body.append(ghost);
            scrollLoop();
          }
        }
        const gridTop = gr.top - (window.scrollY - scroll0);
        if (resize) {
          const w = Math.max(MIN_W[t.type] || 1, Math.min(cols - t.pos.x, Math.round((rect.width + dx + gap) / pitch)));
          const h = Math.max(1, Math.min(4, Math.round((rect.height + dy + gap) / pitch)));
          target = { x: t.pos.x, y: t.pos.y, w, h };
          n.setAttribute('style', gridArea(target));
          mark(target);
          return;
        }
        ghost.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(1.04)';
        const under = document.elementFromPoint(ev.clientX, ev.clientY);
        const c = under && under.closest('.page-chip[data-page]');
        if (chip && chip !== c) chip.classList.remove('drop');
        chip = c && +c.dataset.page !== curPageIdx() ? c : null;
        if (chip) { chip.classList.add('drop'); marker.className = 'drop-marker'; target = null; return; }
        const gx = Math.round((rect.left + dx - gr.left) / pitch), gy = Math.round((rect.top + dy - gridTop) / pitch);
        target = { x: Math.max(0, Math.min(cols - t.pos.w, gx)), y: Math.max(0, gy), w: t.pos.w, h: t.pos.h };
        mark(target);
      };
      const finish = (ev, cancelled) => {
        n.removeEventListener('pointermove', move);
        n.removeEventListener('pointerup', up);
        n.removeEventListener('pointercancel', cancel);
        clearTimeout(armT);
        clearInterval(scrollT);
        active = false;
        n.classList.remove('lifted', 'drag-src');
        if (ghost) ghost.remove();
        if (chip) chip.classList.remove('drop');
        if (marker) marker.className = 'drop-marker';
        if (cancelled) { if (resize) n.setAttribute('style', gridArea(t.pos)); return; }
        if (!moving) { if (!resize) editTile(t); return; }
        if (!chip && !target) return;
        remember();
        if (chip) moveToPage(t, +chip.dataset.page);
        else placeAt(page, t, target);
        saveLayout();
        Deck.draw();
      };
      const up = ev => finish(ev, false);
      const cancel = ev => finish(ev, true);
      n.addEventListener('pointermove', move);
      n.addEventListener('pointerup', up);
      n.addEventListener('pointercancel', cancel);
    });
  }

  // ---------- deck ----------

  const Deck = {
    title: 'Deck',
    poll() {
      const tiles = curPage().tiles;
      const q = ['stats=' + (tiles.some(t => t.type === 'stats') ? 1 : 0)];
      if (tiles.some(t => (t.bind || '').startsWith('vm:'))) q.push('vm=1');
      if (tiles.some(t => (t.bind || '').startsWith('discord:'))) q.push('discord=1');
      if (tiles.some(t => t.bind === 'spotify')) q.push('spotify=1');
      return { path: '/api/state?' + q.join('&'), ms: 1500 };
    },
    render(root) { this.root = root; this.draw(); },
    draw() {
      const root = this.root;
      if (!root) return;
      root.innerHTML = '';
      this.ups = [];
      const ps = S.layout.pages, idx = curPageIdx(), page = ps[idx];

      if (ps.length > 1 || S.editing) {
        const bar = el('div', { class: 'page-bar' });
        ps.forEach((p, i) => bar.append(el('button', {
          class: 'page-chip' + (i === idx ? ' on' : ''), 'data-page': i,
          onclick: () => (S.editing && i === idx ? pageSheet(i) : setDeckPage(i))
        }, p.name, S.editing && i === idx ? ic('edit') : null)));
        if (S.editing) bar.append(el('button', { class: 'page-chip add', onclick: () => pageSheet(-1) }, ic('plus'), 'Seite'));
        root.append(bar);
        requestAnimationFrame(() => { const on = bar.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest', inline: 'center' }); });
      }

      const cols = pageCols(page);
      if (S.editing) root.append(deckTools(page, cols));
      const grid = el('div', { class: 'deck' + (S.editing ? ' editing' : '') });
      const wrap = el('div', { class: 'deck-wrap', style: '--cols:' + cols }, grid);
      this.wrap = wrap;
      this.cols = cols;
      for (const t of page.tiles) {
        const n = renderTile(t, this.ups, page);
        if (n) grid.append(n);
      }
      if (S.editing) {
        // every free cell (plus one extra row) is a "+": a new tile goes exactly there
        const rows = pageRows(page) + 1;
        for (let y = 0; y < rows; y++)
          for (let x = 0; x < cols; x++) {
            if (!fits(page, { x, y, w: 1, h: 1 })) continue;
            const slot = el('div', { class: 'slot', style: gridArea({ x, y, w: 1, h: 1 }), 'aria-label': 'Neue Kachel hier' }, ic('plus'));
            press(slot, { tap: () => { addAt = { x, y }; addTileSheet(); } });
            grid.append(slot);
          }
        grid.append(el('div', { class: 'drop-marker' }));
      }
      swipePages(grid);
      root.append(wrap);
      sizeDeck(wrap, cols);
      if (!page.tiles.length && !S.editing)
        root.append(el('div', { class: 'empty' }, 'Diese Seite ist noch leer. ', el('a', { href: '#', onclick: e => { e.preventDefault(); setEditing(true); } }, 'Kacheln hinzufügen')));
      if (S.editing)
        root.append(el('div', { class: 'edit-help' },
          el('div', null, ic('mouse'), el('span', null, el('b', null, 'Verschieben: '), PC ? 'Kachel mit der Maus ziehen' : 'Kachel kurz festhalten, dann ziehen')),
          el('div', null, ic('resize'), el('span', null, el('b', null, 'Größe: '), 'die Ecke unten rechts ziehen')),
          el('div', null, ic('plus'), el('span', null, el('b', null, 'Neu: '), 'ein freies Feld antippen')),
          el('div', null, ic('grid'), el('span', null, el('b', null, 'Andere Seite: '), 'Kachel auf den Seitennamen oben ziehen')),
          el('div', null, ic('edit'), el('span', null, el('b', null, 'Ändern: '), 'Kachel antippen · aktive Seite antippen = Name, Spalten, Aufräumen'))));
      else if (ps.length > 1)
        root.append(el('div', { class: 'page-dots' }, ps.map((p, i) => el('i', { class: i === idx ? 'on' : '' }))));
      this.update(S.st);
    },
    update(d) {
      if (!d) return;
      S.st = d;
      if (d.vm && d.vm.ok) {
        const first = !S.vm;
        S.vm = d.vm;
        if (first) return this.draw(); // labels of Voicemeeter tiles come from this data
      }
      for (const u of this.ups) try { u(d); } catch (e) { }
    }
  };

  // ---------- deck size (per device) ----------

  const DECK_GAP = 10;
  const sizeName = v => v <= 60 ? 'Sehr klein' : v <= 80 ? 'Klein' : v <= 108 ? 'Mittel' : v <= 148 ? 'Groß' : v < 200 ? 'Sehr groß' : 'Maximal';

  // The deck is never wider than "columns × tile size"; small tiles get a compact look (tiny ones: symbol only).
  function sizeDeck(wrap, cols) {
    wrap.style.maxWidth = (cols * S.deckCell + (cols - 1) * DECK_GAP) + 'px';
    const w = wrap.clientWidth, grid = wrap.firstChild;
    if (!w || !grid) return;
    const col = (w - (cols - 1) * DECK_GAP) / cols;
    grid.classList.toggle('compact', col < 84);
    grid.classList.toggle('tiny', col < 62);
  }
  window.addEventListener('resize', () => { if (current === Deck && Deck.wrap && Deck.wrap.isConnected) sizeDeck(Deck.wrap, Deck.cols); });

  function deckSizeControl() {
    const val = el('b', { class: 'dt-val' }, sizeName(S.deckCell));
    const apply = v => {
      S.deckCell = v;
      val.textContent = sizeName(v);
      if (Deck.wrap && Deck.wrap.isConnected) sizeDeck(Deck.wrap, Deck.cols);
    };
    const range = makeRange({ min: 48, max: 200, step: 4, throttle: 250 }, v => LS.set('deckCell', v), apply);
    range.setValue(S.deckCell);
    const step = d => () => {
      range.value = Math.max(48, Math.min(200, +range.value + d));
      range.dispatchEvent(new Event('input'));
      range.dispatchEvent(new Event('change'));
    };
    return el('div', { class: 'dt-size' },
      el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Kleiner', onclick: step(-12) }, ic('zoomout')),
      el('div', { class: 'grow' }, range),
      el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Größer', onclick: step(12) }, ic('zoomin')),
      val);
  }

  // Edit mode: size (this device) and columns (this page) right above the grid.
  function deckTools(page, cols) {
    return el('div', { class: 'card deck-tools' },
      el('div', { class: 'dt-block' }, el('span', { class: 'field-label' }, 'Kachelgröße', el('small', null, ' · nur auf diesem ' + (PC ? 'PC' : 'Gerät'))), deckSizeControl()),
      el('div', { class: 'dt-block' }, el('span', { class: 'field-label' }, 'Spalten', el('small', null, ' · diese Seite')),
        segTabs([3, 4, 5, 6, 7, 8].map(c => [String(c), String(c)]), String(cols), k => {
          remember();
          page.cols = +k;
          normalize(page);
          saveLayout();
          Deck.draw();
        })));
  }

  function setDeckPage(i) {
    S.pageIdx = i;
    LS.set('deckPage', i);
    Deck.draw();
    if (current === Deck) startPoll();
  }

  function swipePages(node) {
    let sx = null, sy = 0;
    node.addEventListener('touchstart', e => {
      sx = e.touches.length === 1 && !e.target.closest('input') ? e.touches[0].clientX : null;
      if (sx != null) sy = e.touches[0].clientY;
    }, { passive: true });
    node.addEventListener('touchend', e => {
      if (sx == null || S.editing) return;
      const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      sx = null;
      if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
      const i = curPageIdx() + (dx < 0 ? 1 : -1);
      if (i >= 0 && i < S.layout.pages.length) setDeckPage(i);
    }, { passive: true });
  }

  function pageSheet(i) {
    const isNew = i < 0;
    const ps = S.layout.pages;
    const p = isNew ? { id: uid(), name: '', tiles: [] } : ps[i];
    const name = el('input', { class: 'in', placeholder: 'z. B. Gaming, Musik, Stream', value: p.name, autocomplete: 'off' });
    const move = dir => {
      const j = i + dir;
      if (j < 0 || j >= ps.length) return;
      [ps[i], ps[j]] = [ps[j], ps[i]];
      saveLayout();
      close();
      setDeckPage(j);
    };
    let cols = pageCols(p);
    const save = () => {
      remember();
      p.name = name.value.trim() || 'Seite ' + (isNew ? ps.length + 1 : i + 1);
      if (cols !== pageCols(p)) { p.cols = cols; normalize(p); }
      if (isNew) ps.push(p);
      saveLayout();
      close();
      setDeckPage(isNew ? ps.length - 1 : i);
    };
    name.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
    const body = el('div', { class: 'form' },
      field('Name der Seite', name),
      field('Spalten', segTabs([3, 4, 5, 6, 7, 8].map(c => [String(c), String(c)]), String(cols), k => { cols = +k; }),
        'Mehr Spalten = mehr Kacheln pro Zeile. Gilt auf Handy und PC gleich – wie groß die Kacheln sind, stellst du pro Gerät im Bearbeiten-Modus ein.'),
      isNew || !p.tiles.length ? null : field('Lücken', el('button', { class: 'btn small', onclick: () => {
        remember();
        packPage(p);
        saveLayout();
        close();
        Deck.draw();
        toast('Aufgeräumt – alle Lücken geschlossen');
      } }, ic('grid'), 'Aufräumen: Kacheln nach oben rücken')),
      isNew || ps.length < 2 ? null : field('Reihenfolge', el('div', { class: 'row' },
        el('button', { class: 'btn small grow', onclick: () => move(-1) }, ic('left'), 'Nach links'),
        el('button', { class: 'btn small grow', onclick: () => move(1) }, 'Nach rechts', ic('right')))),
      el('div', { class: 'sheet-actions' },
        isNew || ps.length < 2 ? null : el('button', { class: 'btn danger', onclick: async () => {
          if (!await confirmSheet('Seite „' + p.name + '“ löschen?', p.tiles.length ? 'Die ' + p.tiles.length + ' Kacheln darauf werden mitgelöscht.' : null, 'Löschen', true)) return;
          ps.splice(i, 1);
          saveLayout();
          close();
          setDeckPage(Math.max(0, i - 1));
        } }, ic('trash')),
        el('button', { class: 'btn primary', onclick: save }, ic('check'), isNew ? 'Seite anlegen' : 'Speichern')));
    const close = sheet(isNew ? 'Neue Deck-Seite' : 'Seite bearbeiten', body);
    if (isNew) setTimeout(() => name.focus(), 300);
  }

  function setEditing(v) {
    S.editing = v;
    document.querySelectorAll('.edit-btn').forEach(b => {
      b.classList.toggle('on', v);
      b.innerHTML = '';
      b.append(ic(v ? 'check' : 'edit'), el('span', null, v ? 'Fertig' : 'Bearbeiten'));
    });
    if (current === Deck) Deck.draw();
    paintUndo();
  }

  // ---------- media player (Windows sessions + Spotify) ----------

  function spotifySession(sp) {
    if (!sp || !sp.connected || !sp.active || !sp.track) return null;
    const t = sp.track;
    return {
      id: 'spotify-api', proc: 'spotify', app: 'Spotify' + (sp.device ? ' · ' + sp.device.name : ''), title: t.name, artist: t.artists, album: t.album,
      status: sp.playing ? 'playing' : 'paused', pos: sp.progress, dur: t.dur, shuffle: sp.shuffle,
      repeat: sp.repeat === 'context' ? 'list' : sp.repeat === 'track' ? 'track' : 'none', image: t.image,
      canPlay: true, canPause: true, canNext: true, canPrev: true, canSeek: true, canShuffle: true, canRepeat: true
    };
  }

  function makePlayer() {
    const img = el('img', { alt: '' });
    const art = el('div', { class: 'pl-art' }, ic('music'), img);
    const bg = el('div', { class: 'pl-bg' });
    img.onerror = () => { img.style.display = 'none'; bg.classList.remove('on'); };
    img.onload = () => { img.style.display = ''; bg.style.backgroundImage = 'url("' + img.src.replace(/"/g, '%22') + '")'; bg.classList.add('on'); };
    const app = el('div', { class: 'pl-app' }, '');
    const title = el('div', { class: 'pl-title' }, 'Nichts läuft');
    const sub = el('div', { class: 'pl-sub' }, '');
    const tPos = el('span', null, '0:00'), tDur = el('span', null, '0:00');
    let cur = null, sp = null, base = 0, baseAt = 0, playing = false, lastArt = null;
    const useSp = () => !!(sp && sp.connected && sp.active && cur && cur.proc === 'spotify');
    const control = (cmd, value) => {
      // nothing playing: prev/play/next still work as the keyboard's media keys (e.g. to resume Spotify)
      if (!cur) return act({ t: 'media', k: cmd === 'toggle' ? 'playpause' : cmd }, { quiet: 1 });
      if (useSp()) {
        const a = { t: 'spotify', cmd };
        if (cmd === 'seek') a.value = value;
        if (cmd === 'shuffle') a.value = !cur.shuffle;
        act(a, { quiet: 1 });
      } else act({ t: 'mctl', id: cur.id, cmd, value }, { quiet: 1 });
    };
    const seek = makeRange({ min: 0, max: 100, step: 1, throttle: 400 }, v => { base = v; baseAt = Date.now(); control('seek', v); }, v => { tPos.textContent = fmtTime(v); });
    const btn = (icon, label, fn, cls) => el('button', { class: 'pl-btn ' + (cls || ''), 'aria-label': label, onclick: fn }, ic(icon, cls === 'big' ? 'fill' : ''));
    const bShuf = btn('shuffle', 'Shuffle', () => control('shuffle', cur && cur.shuffle ? 0 : 1), 'pl-side');
    const bPrev = btn('prev', 'Zurück', () => control('prev'));
    const bPlay = btn('play', 'Play/Pause', () => { if (cur) { playing = !playing; setIc(bPlay, playing ? 'pause' : 'play', 'fill'); } control('toggle'); }, 'big');
    const bNext = btn('next', 'Weiter', () => control('next'));
    const bRep = btn('repeat', 'Wiederholen', () => {
      if (useSp()) return control('repeat');
      const r = cur && cur.repeat;
      control('repeat', r === 'none' ? 2 : r === 'list' ? 1 : 0);
    }, 'pl-side');
    setIc(bPrev, 'prev', 'fill'); setIc(bNext, 'next', 'fill');
    const like = el('button', { class: 'icon-btn like', 'aria-label': 'Liken', onclick: () => { like.classList.toggle('on'); act({ t: 'spotify', cmd: 'like', value: like.classList.contains('on') }); } }, ic('heart'));
    const volLabel = el('span', { class: 'v' }, '');
    const vol = makeRange({ min: 0, max: 100, step: 1, throttle: 250 }, v => {
      if (useSp()) act({ t: 'spotify', cmd: 'volume', value: v }, { quiet: 1 });
      else if (cur) act({ t: 'set', bind: 'app:' + cur.proc, value: v / 100 }, { quiet: 1 });
    }, v => { volLabel.textContent = v + ' %'; });
    const volName = el('span', null, 'Lautstärke');
    const volStep = d => () => {
      vol.value = Math.max(0, Math.min(100, +vol.value + d));
      vol.dispatchEvent(new Event('input'));
      vol.dispatchEvent(new Event('change'));
    };
    const volRow = el('div', { class: 'pl-vol' },
      el('button', { class: 'icon-btn', 'aria-label': 'Leiser', onclick: volStep(-5) }, ic('voldown')),
      el('div', { class: 'grow' }, el('div', { class: 'mix-name' }, volName, volLabel), vol),
      el('button', { class: 'icon-btn', 'aria-label': 'Lauter', onclick: volStep(5) }, ic('volume')));
    const devBtn = el('button', { class: 'chip pl-dev', onclick: () => spotifyDevices() }, ic('devices'), el('span', { class: 't' }, ''));
    const openBtn = el('button', { class: 'chip', onclick: () => cur && cur.proc && act({ t: 'focus', procs: cur.proc }, { quiet: 1 }) }, ic('window'), el('span', { class: 't' }, 'Am PC zeigen'));
    const node = el('div', { class: 'player card' },
      bg, art,
      el('div', { class: 'pl-main' },
        el('div', { class: 'pl-head' }, el('div', { class: 'grow' }, app, title, sub), like),
        el('div', { class: 'pl-seek' }, seek, el('div', { class: 'pl-times' }, tPos, tDur)),
        el('div', { class: 'pl-ctl' }, bShuf, bPrev, bPlay, bNext, bRep),
        volRow, el('div', { class: 'pl-foot' }, devBtn, openBtn)));
    const timer = setInterval(() => {
      if (!cur || !playing || seek.busy()) return;
      const p = Math.min(cur.dur || 0, base + (Date.now() - baseAt) / 1000);
      seek.setValue(p);
      tPos.textContent = fmtTime(p);
    }, 500);

    return {
      node,
      set(s, spState, volumes) {
        sp = spState;
        if (s && s.proc === 'spotify' && sp && sp.connected && sp.active && sp.track) {
          const o = spotifySession(sp);
          s = Object.assign({}, s, { title: o.title, artist: o.artist, album: o.album, status: o.status, pos: o.pos, dur: o.dur, shuffle: o.shuffle, repeat: o.repeat, image: o.image });
        }
        cur = s;
        node.classList.toggle('empty-pl', !s);
        if (!s) {
          title.textContent = 'Gerade läuft nichts';
          sub.textContent = 'Play drückt die Medientaste am PC – oder starte Musik in Spotify, YouTube …';
          app.textContent = '';
          playing = false;
          setIc(bPlay, 'play', 'fill');
          img.style.display = 'none';
          bg.classList.remove('on');
          lastArt = null;
          volRow.style.display = 'none';
          devBtn.style.display = 'none';
          openBtn.style.display = 'none';
          like.style.display = 'none';
          tPos.textContent = tDur.textContent = '0:00';
          seek.setValue(0);
          return;
        }
        openBtn.style.display = s.proc && s.id !== 'spotify-api' ? '' : 'none';
        app.textContent = s.app || '';
        title.textContent = s.title || s.app || '';
        sub.textContent = [s.artist, s.album].filter(Boolean).join(' · ');
        const p = s.status === 'playing';
        if (p !== playing) { playing = p; setIc(bPlay, p ? 'pause' : 'play', 'fill'); }
        base = s.pos || 0;
        baseAt = Date.now();
        seek.setMax(Math.max(1, Math.round(s.dur || 0)));
        seek.setValue(base);
        seek.disabled = !s.canSeek;
        if (!seek.busy()) tPos.textContent = fmtTime(base);
        tDur.textContent = fmtTime(s.dur);
        bShuf.style.visibility = s.canShuffle || useSp() ? '' : 'hidden';
        bRep.style.visibility = s.canRepeat || useSp() ? '' : 'hidden';
        bShuf.classList.toggle('on', !!s.shuffle);
        bRep.classList.toggle('on', s.repeat === 'list' || s.repeat === 'track');
        setIc(bRep, s.repeat === 'track' ? 'repeat1' : 'repeat');
        bNext.disabled = !s.canNext;
        bPrev.disabled = !s.canPrev;
        const u = artUrl(s);
        if (u !== lastArt) { lastArt = u; if (u) img.src = u; else { img.style.display = 'none'; bg.classList.remove('on'); } }

        // volume: inside Spotify when connected, otherwise the app's Windows volume
        let v = null;
        if (useSp() && sp.device && sp.device.canVolume !== false) { v = sp.device.volume; volName.textContent = 'Spotify-Lautstärke'; }
        else if (volumes && volumes[s.proc]) { v = Math.round(volumes[s.proc].v * 100); volName.textContent = 'Windows-Lautstärke'; }
        volRow.style.display = v == null ? 'none' : '';
        if (v != null) { vol.setValue(v); if (!vol.busy()) volLabel.textContent = v + ' %'; }
        const showLike = useSp() && typeof sp.liked === 'boolean';
        like.style.display = showLike ? '' : 'none';
        if (showLike) like.classList.toggle('on', sp.liked);
        devBtn.style.display = useSp() && sp.device ? '' : 'none';
        if (useSp() && sp.device) devBtn.lastChild.textContent = sp.device.name;
      },
      destroy() { clearInterval(timer); }
    };
  }

  // ---------- spotify ----------

  async function spotifyDevices() {
    const list = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade Geräte …'));
    const close = sheet('Wiedergabe auf …', list);
    try {
      const devs = await api('/api/spotify?what=devices');
      list.innerHTML = '';
      if (!devs.length) list.append(el('div', { class: 'empty' }, 'Keine Spotify-Geräte gefunden. Öffne Spotify auf dem Gerät.'));
      devs.forEach(d => list.append(el('button', { class: 'pick-item' + (d.active ? ' on' : ''), onclick: () => { close(); act({ t: 'spotify', cmd: 'transfer', device: d.id }); } },
        tic(d.type === 'Smartphone' ? 'phone' : d.type === 'Speaker' ? 'volume' : 'monitor', d.active ? 'green' : 'slate'),
        el('div', null, el('b', null, d.name), el('small', null, d.type + (d.active ? ' · spielt gerade' : ''))))));
    } catch (e) { list.innerHTML = ''; list.append(el('div', { class: 'empty' }, e.message)); }
  }

  function spotifySetup(after) {
    const body = el('div', { class: 'form' }, el('div', { class: 'hint' }, 'Lade …'));
    let watch = null;
    const close = sheet('Spotify verbinden', body, { onClose: () => { clearInterval(watch); if (after) after(); } });
    api('/api/spotify?what=status').then(st => {
      body.innerHTML = '';
      if (st.connected) {
        body.append(
          el('div', { class: 'connected-box' }, tic('check', 'green'), el('div', null, el('b', null, 'Verbunden'), el('small', null, 'Angemeldet als ' + (st.user || '?')))),
          el('p', { class: 'hint' }, 'Spotify-Lautstärke, Lieblingssongs, Playlists, Suche, Warteschlange und Geräte sind aktiv.'),
          el('button', { class: 'btn danger', onclick: async () => { await act({ t: 'spotify', cmd: 'logout' }); S.sp = { connected: false }; close(); } }, ic('logout'), 'Spotify trennen'));
        return;
      }
      const cid = el('input', { class: 'in', placeholder: 'Client ID (32 Zeichen)', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', value: st.clientId || '' });
      const redirect = st.redirect;
      const copyBtn = el('button', { class: 'btn small', type: 'button', onclick: () => copyText(redirect).then(() => toast('Kopiert'), () => toast('Bitte von Hand markieren', 'err')) }, ic('copy'), 'Kopieren');
      const dash = 'https://developer.spotify.com/dashboard';
      body.append(
        el('p', { class: 'muted', style: 'margin:0' }, 'Einmalig, dauert etwa 2 Minuten. Danach steuerst du Spotify von innen: Lautstärke in Spotify, Liken, Playlists, Suche, Warteschlange, Geräte wechseln.'),
        el('ol', { class: 'steps small' },
          el('li', null, el('span', null, 'Öffne das Spotify-Dashboard und melde dich an: ',
            el('a', { href: dash, target: '_blank', rel: 'noopener' }, 'developer.spotify.com/dashboard'),
            S.local ? null : el('button', { class: 'btn small', type: 'button', style: 'margin-left:6px', onclick: () => act({ t: 'url', url: dash }) }, ic('external'), 'Am PC öffnen'))),
          el('li', null, el('span', null, 'Auf „Create app“ tippen. Name z. B. „PC Remote“, Beschreibung egal. Bei „Which API/SDKs“ ', el('b', null, 'Web API'), ' anhaken.')),
          el('li', null, el('span', null, 'Bei „Redirect URIs“ genau diese Adresse eintragen und „Add“ drücken:',
            el('div', { class: 'copy-row' }, el('code', null, redirect), copyBtn))),
          el('li', null, el('span', null, 'Speichern, dann in den App-Einstellungen die ', el('b', null, 'Client ID'), ' kopieren und hier einfügen:'))),
        cid,
        el('button', { class: 'btn primary', onclick: async () => {
          const v = cid.value.trim();
          if (v.length < 20) return toast('Bitte die Client ID einfügen', 'err');
          const r = await act({ t: 'spotify', cmd: 'login', clientId: v });
          if (!r) return;
          body.append(el('p', { class: 'hint', style: 'text-align:center' }, 'Warte auf die Bestätigung im Browser am PC …'));
          clearInterval(watch);
          let n = 0;
          watch = setInterval(async () => {
            if (++n > 90) return clearInterval(watch);
            try {
              const s = await api('/api/spotify?what=status');
              if (s.connected) { clearInterval(watch); S.sp = { connected: true }; toast('Spotify verbunden ✓'); close(); }
            } catch (e) { }
          }, 2000);
        } }, ic('music'), 'Mit Spotify verbinden'),
        el('p', { class: 'hint' }, 'Die Anmeldung öffnet sich im Browser am PC (Spotify erlaubt die Rückleitung nur dorthin). Es wird nur ein Anmelde-Schlüssel auf deinem PC gespeichert – kein Passwort.'));
    }).catch(e => { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); });
  }

  function spotifyPromo() {
    return el('div', { class: 'card promo' }, tic('music', 'green'),
      el('div', { class: 'grow' }, el('b', null, 'Spotify richtig steuern'),
        el('small', null, 'Lautstärke in Spotify, Liken, Playlists, Suche, Warteschlange, Geräte wechseln')),
      el('button', { class: 'btn small primary', onclick: () => spotifySetup() }, 'Einrichten'));
  }

  // Lists: queue, playlists, search, recently played
  function spotifyBrowser() {
    const tabs = [['playlists', 'Playlists'], ['search', 'Suche'], ['queue', 'Warteschlange'], ['recent', 'Zuletzt']];
    let cur = LS.get('spTab', 'playlists');
    const body = el('div', { class: 'sp-body' });
    const seg = segTabs(tabs, cur, k => { cur = k; LS.set('spTab', k); load(); });
    const row = (it, opts) => {
      const img = it.image ? el('img', { src: it.image, alt: '', loading: 'lazy' }) : tic(it.kind === 'liked' ? 'heart' : it.kind === 'artist' ? 'users' : 'music', it.kind === 'liked' ? 'violet' : 'green');
      const n = el('div', { class: 'sp-row' }, el('span', { class: 'sp-img' + (it.kind === 'artist' ? ' round' : '') }, img),
        el('div', { class: 'grow' }, el('b', null, it.name), el('small', null, opts.sub || '')),
        opts.queue ? el('button', { class: 'icon-btn', 'aria-label': 'Zur Warteschlange', onclick: e => { e.stopPropagation(); act({ t: 'spotify', cmd: 'queue', uri: it.uri }); } }, ic('list')) : null);
      if (opts.play) press(n, { tap: opts.play, long: opts.queue ? () => act({ t: 'spotify', cmd: 'queue', uri: it.uri }) : null });
      return n;
    };
    const play = (uri, context) => () => act({ t: 'spotify', cmd: 'playUri', uri, context }, { quiet: 1 });
    let searchInput = null, searchTimer = null, lastQ = '';
    async function load() {
      body.innerHTML = '';
      if (cur === 'search') {
        searchInput = el('input', { class: 'in', type: 'search', placeholder: 'Songs, Künstler, Alben, Playlists …', value: lastQ });
        const res = el('div');
        searchInput.addEventListener('input', () => {
          clearTimeout(searchTimer);
          lastQ = searchInput.value;
          searchTimer = setTimeout(() => doSearch(res), 350);
        });
        body.append(el('div', { class: 'search', style: 'margin-bottom:10px' }, ic('search'), searchInput), res);
        if (lastQ) doSearch(res);
        setTimeout(() => searchInput.focus(), 50);
        return;
      }
      body.append(el('div', { class: 'hint', style: 'padding:10px 0' }, 'Lade …'));
      try {
        const d = await api('/api/spotify?what=' + cur);
        body.innerHTML = '';
        if (cur === 'queue') {
          if (d.current) body.append(heading('Läuft gerade'), row(d.current, { sub: d.current.artists }));
          body.append(heading('Als Nächstes'));
          if (!d.queue.length) body.append(el('div', { class: 'empty' }, 'Die Warteschlange ist leer.'));
          d.queue.forEach(t => body.append(row(t, { sub: t.artists })));
        } else if (cur === 'playlists') {
          if (!d.length) body.append(el('div', { class: 'empty' }, 'Keine Playlists gefunden.'));
          d.forEach(p => body.append(row(p, { sub: p.kind === 'liked' ? 'Deine Lieblingssongs' : (p.count ? p.count + ' Songs' : '') + (p.owner ? ' · ' + p.owner : ''), play: play(p.uri) })));
        } else if (cur === 'recent') {
          if (!d.length) body.append(el('div', { class: 'empty' }, 'Noch nichts gehört.'));
          d.forEach(t => body.append(row(t, { sub: t.artists, play: play(t.uri), queue: true })));
        }
      } catch (e) { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); }
    }
    async function doSearch(res) {
      const q = (searchInput && searchInput.value || '').trim();
      if (!q) { res.innerHTML = ''; return; }
      try {
        const d = await api('/api/spotify?what=search&q=' + enc(q));
        if (q !== (searchInput.value || '').trim()) return;
        res.innerHTML = '';
        const group = (title, items, map) => { if (!items || !items.length) return; res.append(heading(title)); items.forEach(x => res.append(map(x))); };
        group('Songs', d.tracks, t => row(t, { sub: t.artists + (t.album ? ' · ' + t.album : ''), play: play(t.uri), queue: true }));
        group('Künstler', d.artists, a => row(a, { sub: 'Künstler', play: play(a.uri) }));
        group('Alben', d.albums, a => row(a, { sub: a.artists, play: play(a.uri) }));
        group('Playlists', d.playlists, p => row(p, { sub: p.owner, play: play(p.uri) }));
        if (!res.children.length) res.append(el('div', { class: 'empty' }, 'Nichts gefunden.'));
      } catch (e) { res.innerHTML = ''; res.append(el('div', { class: 'empty' }, e.message)); }
    }
    load();
    return el('div', { class: 'card sp-browser' }, el('div', { class: 'card-h' }, el('h3', null, 'Deine Musik'),
      el('div', { class: 'row' }, el('button', { class: 'icon-btn', 'aria-label': 'Geräte', onclick: spotifyDevices }, ic('devices')),
        el('button', { class: 'icon-btn', 'aria-label': 'Neu laden', onclick: load }, ic('refresh')))), seg, body);
  }

  // ---------- media view ----------

  const MediaView = {
    title: 'Medien',
    poll: () => ({ path: '/api/media?spotify=1', ms: 1000 }),
    render(root) {
      this.sel = LS.get('mediaSel', null);
      this.chips = el('div', { class: 'chips src-chips' });
      this.player = makePlayer();
      this.extra = el('div');
      this.chipKey = null;
      this.spMode = null;
      root.append(this.chips, el('div', { class: 'media-wrap' }, el('div', { class: 'media-grid' }, el('div', { class: 'pl-holder' }, this.player.node), this.extra)));
    },
    update(d) {
      const sp = d.spotify || { connected: false };
      S.sp = sp;
      let list = (d.sessions || []).slice();
      if (sp.connected && sp.active && !list.some(s => s.proc === 'spotify')) list.unshift(spotifySession(sp));
      list = list.filter(Boolean);
      const key = list.map(s => s.id + s.app).join('|');
      if (key !== this.chipKey) {
        this.chipKey = key;
        this.chips.innerHTML = '';
        if (list.length > 1) list.forEach(s => this.chips.append(el('button', { class: 'chip', 'data-id': s.id, onclick: () => { this.sel = s.id; LS.set('mediaSel', s.id); this.update(this.last); } },
          s.proc && s.id !== 'spotify-api' ? appIcon({ proc: s.proc }, s.app) : ic('music'), el('span', { class: 't' }, s.app))));
      }
      const s = list.find(x => x.id === this.sel) || list[0] || null;
      [...this.chips.children].forEach(c => c.classList.toggle('on', !!s && c.dataset.id === s.id));
      this.last = d;
      this.player.set(s, sp, d.volumes);
      const mode = sp.connected ? 'browser' : 'promo';
      if (mode !== this.spMode) {
        this.spMode = mode;
        this.extra.innerHTML = '';
        this.extra.append(mode === 'browser' ? spotifyBrowser() : spotifyPromo());
      }
    },
    destroy() { if (this.player) this.player.destroy(); }
  };

  // ---------- clips (instant replay) ----------

  const CLIP_LEN = [[15, '15 s'], [30, '30 s'], [60, '1 Min.'], [120, '2 Min.']];
  const CLIP_QUALITY = [['mid', 'Gut'], ['high', 'Hoch'], ['max', 'Sehr hoch']];
  const CLIP_RES = [['native', 'Original'], ['1080', '1080p'], ['720', '720p']];
  const fmtSize = b => b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB';
  const clipUrl = (name, extra) => '/api/clipfile?name=' + enc(name) + '&' + authQ() + (extra || '');
  const clipTitle = n => n.replace(/\.mp4$/i, '');

  async function saveClip() {
    buzz();
    try {
      const r = await api('/api/clips', { cmd: 'save' });
      toast(r.msg || 'Clip gespeichert');
      if (current === ClipsView) pollSoon();
    } catch (e) { toast(e.message, 'err'); }
  }

  const ClipsView = {
    title: 'Clips',
    poll: () => ({ path: '/api/clips', ms: 2000 }),
    render(root) {
      this.key = this.listKey = null;
      this.head = el('div', null, el('div', { class: 'empty' }, 'Lade …'));
      this.count = el('small', { class: 'muted' }, '');
      this.list = el('div', { class: 'clip-grid' });
      root.append(this.head, el('div', { class: 'clip-list-head' }, el('h3', null, 'Gespeicherte Clips'), this.count), this.list);
    },
    update(d) {
      this.d = d;
      const s = d.settings, st = d.status;
      const key = JSON.stringify([s, st.state, st.error, st.encoder, st.capture, st.w, st.h, st.audio, st.hotkeyOk, d.folder, d.monitors]);
      if (key !== this.key) { this.key = key; this.drawHead(d); }
      if (this.bufEl) this.bufEl.textContent = st.state === 'on' ? 'Aufnahme läuft · ' + Math.min(st.buffered, s.seconds) + ' von ' + s.seconds + ' s im Puffer' : st.state === 'error' ? 'Aufnahme gestört' : 'Startet …';
      const lk = JSON.stringify(d.clips.map(c => [c.name, c.size, c.thumb]));
      if (lk !== this.listKey) { this.listKey = lk; this.drawList(d); }
    },
    set(patch) {
      api('/api/clips', Object.assign({ cmd: 'settings' }, patch))
        .then(d => { this.key = null; this.update(d); })
        .catch(e => toast(e.message, 'err'));
    },
    drawHead(d) {
      const s = d.settings, st = d.status, box = this.head;
      box.innerHTML = '';
      this.bufEl = null;
      const hk = s.hotkey ? prettyKeys(s.hotkey) : '';
      if (!s.enabled) {
        box.append(el('div', { class: 'card clip-hero off' },
          el('div', { class: 'clip-hero-ic' }, ic('video')),
          el('h2', null, 'Clip-Aufnahme pausiert'),
          el('p', { class: 'muted' }, 'Normalerweise merkt sich PC Remote ab dem Start ständig die letzten ' + s.seconds + ' Sekunden deines Bildschirms – mit Ton. Gerade ist das ausgeschaltet.'),
          el('button', { class: 'btn primary block', onclick: () => this.set({ enabled: true }) }, ic('record'), 'Wieder aufnehmen'),
          el('p', { class: 'hint' }, 'Gespeichert wird nur auf deinem PC (Videos → PC Remote Clips).')));
      } else {
        const ok = st.state === 'on';
        this.bufEl = el('b', null, '');
        const tech = [st.encoder ? (/nvidia/i.test(st.encoder) ? 'NVIDIA NVENC' : /intel/i.test(st.encoder) ? 'Intel Quick Sync' : /amd|amf/i.test(st.encoder) ? 'AMD AMF' : /software/i.test(st.encoder) ? 'Software-Encoder' : st.encoder) : null,
          st.w ? st.w + '×' + st.h : null, s.fps + ' FPS', st.audio ? 'mit Ton' : 'ohne Ton'].filter(Boolean).join(' · ');
        box.append(el('div', { class: 'card clip-hero' + (ok ? ' live' : '') },
          el('div', { class: 'clip-status' }, el('i', { class: 'rec-dot' }), el('div', { class: 'grow' }, this.bufEl, el('small', null, st.state === 'error' ? st.error : tech))),
          el('button', { class: 'btn primary block clip-save', disabled: !ok, onclick: saveClip }, ic('scissors'), 'Clip speichern'),
          el('p', { class: 'hint', style: 'text-align:center;margin:10px 0 0' }, hk
            ? (st.hotkeyOk ? 'Am PC – auch mitten im Spiel: ' : 'Das Kürzel ' + hk + ' benutzt schon ein anderes Programm – bitte unten ein anderes wählen. ')
            : 'Kein Tastenkürzel am PC eingestellt.', st.hotkeyOk && hk ? el('kbd', null, hk) : null)));
      }

      // settings
      const sel = el('select', { class: 'in' }, el('option', { value: '' }, 'Hauptbildschirm'), d.monitors.map(m => el('option', { value: m.dev }, m.name)));
      sel.value = s.monitor || '';
      sel.onchange = () => this.set({ monitor: sel.value });
      const hkIn = el('input', { class: 'in', value: s.hotkey || '', placeholder: 'z. B. alt+shift+c', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const seg = (key, items) => segTabs(items.map(([v, l]) => [String(v), l]), String(s[key]), k => this.set({ [key]: isNaN(+k) ? k : +k }));
      box.append(el('div', { class: 'card form clip-settings' },
        el('div', { class: 'card-h' }, el('h3', null, 'Aufnahme'), el('small', null, 'Änderungen starten den Puffer neu')),
        el('label', { class: 'check' }, el('span', null, 'Ab dem Start im Hintergrund aufnehmen (empfohlen)'), sw(s.enabled, v => this.set({ enabled: v }))),
        field('Länge eines Clips', seg('seconds', CLIP_LEN)),
        el('div', { class: 'size-row' }, field('Bildrate', seg('fps', [[30, '30 FPS'], [60, '60 FPS']])), field('Qualität', seg('quality', CLIP_QUALITY))),
        el('div', { class: 'size-row' }, field('Auflösung', seg('res', CLIP_RES)), field('Bildschirm', sel)),
        el('label', { class: 'check' }, el('span', null, 'Ton aufnehmen (was du hörst)'), sw(s.audio, v => this.set({ audio: v }))),
        el('label', { class: 'check' }, el('span', null, 'Ton am PC beim Speichern'), sw(s.sound, v => this.set({ sound: v }))),
        field('Tastenkürzel am PC', el('div', { class: 'row' }, el('div', { class: 'grow' }, hkIn),
          el('button', { class: 'btn small', onclick: () => this.set({ hotkey: hkIn.value.trim().toLowerCase() }) }, ic('check'), 'Übernehmen')),
          'Funktioniert überall, auch im Spiel. Tasten mit + verbinden, z. B. alt+shift+c, ctrl+f9 oder f8. Leer lassen = aus.'),
        field('Speicherort', el('div', null, el('div', { class: 'mono clip-folder' }, d.folder),
          el('div', { class: 'row wrap', style: 'margin-top:8px' },
            el('button', { class: 'btn small', onclick: () => api('/api/clips', { cmd: 'folder' }).then(r => toast(r.msg)).catch(e => toast(e.message, 'err')) }, ic('folder'), 'Ordner am PC öffnen'),
            S.local ? el('button', { class: 'btn small', onclick: () => api('/api/clips', { cmd: 'choosefolder' }).then(r => { this.key = null; this.update(r); }).catch(e => toast(e.message, 'err')) }, ic('edit'), 'Ändern') : null)))));
    },
    drawList(d) {
      const list = this.list;
      list.innerHTML = '';
      this.count.textContent = d.clips.length ? d.clips.length + (d.clips.length === 1 ? ' Clip · ' : ' Clips · ') + fmtSize(d.total) : '';
      if (!d.clips.length) {
        list.append(el('div', { class: 'empty clip-empty' }, ic('scissors'), el('div', null, 'Noch keine Clips.'),
          el('small', null, d.settings.enabled ? 'Tippe auf „Clip speichern“' + (d.settings.hotkey ? ' oder drücke am PC ' + prettyKeys(d.settings.hotkey) : '') + '.' : 'Die Aufnahme ist pausiert – oben fortsetzen.')));
        return;
      }
      for (const c of d.clips) {
        const img = c.thumb ? el('img', { src: '/api/clipthumb?name=' + enc(c.name) + '&' + authQ(), alt: '', loading: 'lazy' }) : null;
        list.append(el('button', { class: 'clip-card', onclick: () => openClip(c, () => { this.listKey = null; pollSoon(); }) },
          el('div', { class: 'clip-thumb' }, img || ic('video'), c.dur ? el('span', { class: 'clip-dur' }, fmtTime(c.dur)) : null, el('span', { class: 'clip-play' }, ic('play', 'fill'))),
          el('div', { class: 'clip-meta' }, el('b', null, clipTitle(c.name)), el('small', null, ago(c.time) + ' · ' + fmtSize(c.size) + (c.h ? ' · ' + c.h + 'p' : '')))));
      }
    }
  };

  // Player with download, rename, delete.
  function openClip(c, changed) {
    const video = el('video', { class: 'clip-video', src: clipUrl(c.name), controls: true, playsinline: true, preload: 'metadata', autoplay: true });
    const title = el('div', { class: 'clip-sheet-title' }, clipTitle(c.name));
    const run = (body, ok) => api('/api/clips', body).then(r => { if (r && r.msg) toast(r.msg); if (ok) ok(r); }).catch(e => toast(e.message, 'err'));
    const body = el('div', { class: 'clip-sheet' }, video, title,
      el('small', { class: 'muted' }, ago(c.time) + ' · ' + fmtSize(c.size) + (c.w ? ' · ' + c.w + '×' + c.h : '') + (c.dur ? ' · ' + fmtTime(c.dur) : '')),
      el('div', { class: 'clip-actions' },
        el('a', { class: 'btn primary', href: clipUrl(c.name, '&dl=1'), download: c.name }, ic('download'), PC ? 'Speichern unter …' : 'Aufs Handy laden'),
        el('button', { class: 'btn', onclick: () => run({ cmd: 'play', name: c.name }) }, ic('monitor'), 'Am PC abspielen'),
        el('button', { class: 'btn', onclick: () => run({ cmd: 'folder', name: c.name }) }, ic('folder'), 'Im Ordner zeigen'),
        el('button', { class: 'btn', onclick: () => renameClip(c, n => { c.name = n; title.textContent = clipTitle(n); changed(); }) }, ic('edit'), 'Umbenennen'),
        el('button', { class: 'btn danger', onclick: async () => {
          if (!await confirmSheet('Clip löschen?', '„' + clipTitle(c.name) + '“ wird endgültig vom PC gelöscht.', 'Löschen', true)) return;
          run({ cmd: 'delete', name: c.name }, () => { toast('Gelöscht'); close(); changed(); });
        } }, ic('trash'), 'Löschen')));
    const close = sheet('Clip', body, { wide: true, onClose: () => { video.pause(); video.removeAttribute('src'); video.load(); } });
  }

  function renameClip(c, done) {
    const inp = el('input', { class: 'in', value: clipTitle(c.name), autocomplete: 'off' });
    const go = () => api('/api/clips', { cmd: 'rename', name: c.name, to: inp.value.trim() })
      .then(r => { close(); toast('Umbenannt'); done(r.name); }).catch(e => toast(e.message, 'err'));
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    const close = sheet('Clip umbenennen', el('div', { class: 'form' }, inp,
      el('div', { class: 'sheet-actions' }, el('button', { class: 'btn', onclick: () => close() }, 'Abbrechen'), el('button', { class: 'btn primary', onclick: go }, ic('check'), 'Umbenennen'))));
    setTimeout(() => { inp.focus(); inp.select(); }, 300);
  }

  // ---------- mixer + voicemeeter ----------

  function mixRow(o) {
    const iconBox = o.proc ? appIcon({ proc: o.proc }, o.name) : el('span', { class: 'appic sys' }, ic(o.icon));
    const v = el('span', { class: 'v' }, '–');
    const sc = o.scale || PCT;
    const range = makeRange(sc, x => act({ t: 'set', bind: o.bind, value: sc.toServer(x) }, { quiet: 1 }), x => { v.textContent = sc.fmt(sc.toServer(x)); });
    const mute = el('button', { class: 'icon-btn', 'aria-label': 'Stumm', onclick: () => act({ t: 'toggle', bind: o.muteBind || o.bind }, { quiet: 1 }) }, ic(o.icon === 'mic' ? 'mic' : 'volume'));
    const peak = el('i');
    const mid = el('div', { class: 'mix-mid' }, el('div', { class: 'mix-name' }, el('span', null, o.name), v), range, o.peak ? el('div', { class: 'peak' }, peak) : null);
    const row = el('div', { class: 'mix-row' }, iconBox, mid, mute);
    let lastM = null;
    row.set = s => {
      if (!s) { v.textContent = '–'; return; }
      range.setValue(sc.fromServer(s.v));
      if (!range.busy()) v.textContent = sc.fmt(s.v);
      if (lastM !== !!s.m) {
        lastM = !!s.m;
        row.classList.toggle('muted-state', lastM);
        mute.classList.toggle('alert', lastM);
        setIc(mute, lastM ? (o.icon === 'mic' ? 'micoff' : 'mute') : (o.icon === 'mic' ? 'mic' : 'volume'));
      }
      if (o.peak) peak.style.width = Math.min(100, (s.peak || 0) * 100) + '%';
    };
    return row;
  }

  function vmPanel() {
    const box = el('div');
    let key = null, ups = [];
    const strip = (base, label, buses) => {
      const v = el('span', { class: 'v' }, '');
      const range = makeRange(DB, x => act({ t: 'set', bind: 'vm:' + base + '.Gain', value: x }, { quiet: 1 }), x => { v.textContent = DB.fmt(x); });
      const mute = el('button', { class: 'vm-bus mute', onclick: () => act({ t: 'toggle', bind: 'vm:' + base + '.Mute' }, { quiet: 1 }) }, 'Mute');
      const chips = buses.map(name => {
        const c = el('button', { class: 'vm-bus', onclick: () => act({ t: 'toggle', bind: 'vm:' + base + '.' + name }, { quiet: 1 }) }, name);
        c.param = base + '.' + name;
        return c;
      });
      const n = el('div', { class: 'vm-strip' }, el('div', { class: 'mix-name' }, el('span', null, label), v), range, el('div', { class: 'vm-buses' }, mute, chips));
      ups.push(p => {
        const g = p[base + '.Gain'];
        range.setValue(g);
        if (!range.busy()) v.textContent = DB.fmt(g);
        const m = p[base + '.Mute'] > 0.5;
        mute.classList.toggle('on', m);
        n.classList.toggle('muted-state', m);
        chips.forEach(c => c.classList.toggle('on', p[c.param] > 0.5));
      });
      return n;
    };
    return {
      node: box,
      update(vm) {
        if (!vm || !vm.ok) {
          if (key !== 'off') {
            key = 'off';
            box.innerHTML = '';
            box.append(el('div', { class: 'empty' }, 'Voicemeeter ist nicht verbunden (nicht installiert oder nicht gestartet).'));
          }
          return;
        }
        S.vm = vm;
        const k = vm.type + JSON.stringify(vm.strips.map(s => s.label));
        if (k !== key) {
          key = k;
          box.innerHTML = '';
          ups = [];
          const strips = el('div', { class: 'card' });
          for (const s of vm.strips) strips.append(strip('Strip[' + s.i + ']', s.label, vm.buses.map(x => x.name)));
          const buses = el('div', { class: 'card' });
          for (const b of vm.buses) buses.append(strip('Bus[' + b.i + ']', 'Bus ' + b.name, []));
          box.append(
            heading('Eingänge', el('div', { class: 'row' },
              el('button', { class: 'btn small', onclick: () => act({ t: 'vm', cmd: 'show' }) }, ic('window'), 'Öffnen'),
              el('button', { class: 'btn small', onclick: () => act({ t: 'vm', cmd: 'restart' }) }, ic('restart'), 'Engine'))),
            strips, heading('Ausgänge (Busse)'), buses);
        }
        for (const u of ups) u(vm.params);
      }
    };
  }

  const Mixer = {
    title: 'Mixer',
    poll: () => ({ path: '/api/mixer?vm=1', ms: 900 }),
    render(root) {
      this.master = mixRow({ name: 'Lautsprecher', icon: 'volume', bind: 'master' });
      this.mic = mixRow({ name: 'Mikrofon', icon: 'mic', bind: 'mic' });
      this.sessBox = el('div');
      this.outBox = el('div', { class: 'dev-list' });
      this.inBox = el('div', { class: 'dev-list' });
      this.vm = vmPanel();
      this.sessKey = this.outKey = this.inKey = null;
      const tab = LS.get('mixTab', 'vol');
      this.panes = {
        vol: el('div', null, el('div', { class: 'card' }, this.master, this.mic), heading('Apps'), el('div', { class: 'card' }, this.sessBox)),
        dev: el('div', null, heading('Ausgabe (Lautsprecher / Headset)'), el('div', { class: 'card' }, this.outBox), heading('Eingabe (Mikrofon)'), el('div', { class: 'card' }, this.inBox)),
        vm: this.vm.node
      };
      const pick = k => { LS.set('mixTab', k); Object.keys(this.panes).forEach(p => { this.panes[p].style.display = p === k ? '' : 'none'; }); };
      this.seg = segTabs([['vol', 'Lautstärke'], ['dev', 'Geräte'], ['vm', 'Voicemeeter']], tab, pick, 'top-seg');
      this.seg.lastChild.style.display = 'none';
      root.append(this.seg, this.panes.vol, this.panes.dev, this.panes.vm);
      pick(tab === 'vm' ? 'vol' : tab);
      this.wantVm = tab === 'vm';
    },
    update(d) {
      this.master.set(d.master);
      this.mic.set(d.mic);
      const sess = d.sessions || [];
      const key = sess.map(s => s.key).join('|');
      if (key !== this.sessKey) {
        this.sessKey = key;
        this.rows = {};
        this.sessBox.innerHTML = '';
        if (!sess.length) this.sessBox.append(el('div', { class: 'empty' }, 'Gerade spielt keine App Ton ab.'));
        for (const s of sess) {
          const r = mixRow({ name: s.name, proc: s.key, bind: 'app:' + s.key, peak: true });
          this.rows[s.key] = r;
          this.sessBox.append(r);
        }
      }
      for (const s of sess) this.rows[s.key].set(s);
      this.devices(d.outputs, 'outBox', 'outKey', 'headphones');
      this.devices(d.inputs, 'inBox', 'inKey', 'mic');
      const vmOk = !!(d.vm && d.vm.ok);
      this.seg.lastChild.style.display = vmOk ? '' : 'none';
      if (vmOk && this.wantVm) { this.wantVm = false; this.seg.lastChild.click(); }
      this.vm.update(d.vm);
    },
    devices(list, box, keyName, icon) {
      list = list || [];
      const key = JSON.stringify(list);
      if (key === this[keyName]) return;
      this[keyName] = key;
      const b = this[box];
      b.innerHTML = '';
      if (!list.length) b.append(el('div', { class: 'hint' }, 'Keine Geräte gefunden'));
      for (const dev of list)
        b.append(el('button', { class: 'dev-row' + (dev.def ? ' on' : ''), onclick: () => !dev.def && act({ t: 'device', id: dev.id }) },
          ic(icon), el('span', { class: 'grow' }, dev.name), dev.def ? el('span', { class: 'dev-badge' }, ic('check'), 'Aktiv') : null));
    }
  };

  // ---------- apps & addons ----------

  function resolveAction(item, ctx) {
    if (item.setting) {
      const keys = setting(ctx.addon, item.setting);
      return keys ? { t: 'key', keys } : null;
    }
    if (item.ref) {
      const ad = ADDONS.find(x => x.id === item.ref[0]);
      const keys = ad && setting(ad, item.ref[1]);
      return keys ? { t: 'key', keys } : null;
    }
    const a = clone(item.a);
    if (a.t === 'appkey' && !a.id && !a.procs) {
      if (ctx.app) a.id = ctx.app.id;
      else a.procs = ctx.procs.join(',');
    }
    return a;
  }

  function deckTileFor(item, ctx) {
    if (item.deck) return Object.assign({}, item.deck);
    const a = resolveAction(item, ctx);
    if (!a) return null;
    return { type: 'action', label: item.label, icon: item.icon || actIcon(a), color: item.color || (ctx.addon && ctx.addon.color) || 'violet', a, confirm: item.confirm };
  }

  function buttonMenu(item, ctx, extra) {
    const items = [{ icon: tic('grid', 'violet'), title: 'Aufs Deck legen', sub: 'Als Kachel auf der Startseite', onclick: () => {
      close();
      const t = deckTileFor(item, ctx);
      if (!t) return toast('Erst das Kürzel in den Einstellungen eintragen', 'err');
      toDeck(t, item.label);
    } }];
    (extra || []).forEach(x => items.push(Object.assign({}, x, { onclick: () => { close(); x.onclick(); } })));
    const close = sheet(item.label, pickList(items));
  }

  function addonButton(item, ctx, extra) {
    const b = el('button', { class: 'abtn c-' + (item.color || (ctx.addon && ctx.addon.color) || 'violet') },
      el('span', { class: 't-ic' }, ic(item.icon || (item.a ? actIcon(item.a) : 'zap'))), el('span', { class: 'abtn-l' }, item.label));
    press(b, {
      tap: async () => {
        const a = resolveAction(item, ctx);
        if (!a) return toast('Dafür fehlt noch das Tastenkürzel – unter „Einstellungen“ eintragen', 'err');
        if (item.confirm && !await confirmSheet(item.label + '?', null, 'Ausführen', true)) return;
        flash(b);
        act(a);
      },
      long: () => buttonMenu(item, ctx, extra)
    });
    if (item.state) ctx.ups.push(d => b.classList.toggle('alert', getPath(d, item.state) === true));
    return b;
  }

  const SECTIONS = {
    buttons(ctx, sec) {
      const items = sec.items.filter(i => i.needs !== 'spotify' || S.sp.connected);
      if (!items.length) return null;
      return [heading(sec.title || 'Funktionen'), el('div', { class: 'abtn-grid' }, items.map(i => addonButton(i, ctx)))];
    },

    player(ctx, sec) {
      const p = makePlayer();
      ctx.destroy.push(() => p.destroy());
      ctx.ups.push(d => {
        if (d.spotify) S.sp = d.spotify;
        const list = (d.media || []).filter(s => ctx.procs.includes(s.proc));
        let s = list.find(x => x.status === 'playing') || list[0] || null;
        if (!s && ctx.procs.includes('spotify')) s = spotifySession(d.spotify);
        p.set(s, d.spotify, d.app && d.app.audio && s ? { [s.proc]: d.app.audio } : null);
      });
      return [heading(sec.title || 'Wiedergabe'), p.node];
    },

    spotify(ctx) {
      const box = el('div');
      let mode = null;
      ctx.ups.push(d => {
        const sp = d.spotify || { connected: false };
        const m = sp.connected ? 'on' : 'off';
        if (m === mode) return;
        mode = m;
        box.innerHTML = '';
        box.append(sp.connected ? spotifyBrowser() : spotifyPromo());
      });
      return [heading('Bibliothek'), box];
    },

    discord(ctx) {
      const big = (key, label, icon, offIcon) => {
        const state = el('small', null, '…');
        const icBox = el('span', { class: 't-ic' }, ic(icon));
        const b = el('button', { class: 'dbig' }, icBox, el('span', null, el('b', null, label), state));
        press(b, {
          tap: () => { flash(b); act({ t: 'discord', cmd: key }, { quiet: 1 }); },
          long: () => buttonMenu({ label: 'Discord ' + label, deck: { type: 'toggle', bind: 'discord:' + key, color: 'violet' } }, ctx)
        });
        let last = null;
        ctx.ups.push(d => {
          const v = d.discord && d.discord[key];
          b.classList.toggle('alert', v === true);
          state.textContent = v === true ? 'Stumm' : v === false ? 'An' : '–';
          const want = v ? offIcon : icon;
          if (want !== last) { last = want; setIc(icBox, want); }
        });
        return b;
      };
      const extras = [['disconnect', 'Auflegen', 'phoneoff', 'red'], ['camera', 'Kamera', 'video', 'cyan'], ['screen', 'Bildschirm', 'share', 'cyan'],
        ['noise', 'Rauschunterdr.', 'waves', 'violet'], ['soundboard', 'Soundboard', 'music', 'pink'], ['activity', 'Aktivität', 'rocket', 'orange']]
        .map(([k, l, i, c]) => { const b = addonButton({ label: l, icon: i, color: c, a: { t: 'discord', cmd: k } }, ctx); b.dataset.key = k; return b; });
      const grid = el('div', { class: 'abtn-grid', style: 'margin-top:10px' }, extras);
      const hint = el('p', { class: 'hint' }, '');
      ctx.ups.push(d => {
        const dc = d.discord || {};
        const has = dc.controls || [];
        extras.forEach(b => { b.style.display = has.includes(b.dataset.key) ? '' : 'none'; });
        grid.style.display = extras.some(b => b.style.display === '') ? '' : 'none';
        hint.textContent = !dc.running ? 'Discord läuft nicht.' : !dc.ok ? 'Discord-Fenster nicht erreichbar – öffne Discord einmal (minimiert reicht). Bis dahin werden die Ersatz-Kürzel aus den Einstellungen benutzt.'
          : dc.voice ? 'Du bist in einem Sprachkanal.' : 'Nicht im Sprachkanal – Auflegen, Kamera und Bildschirm erscheinen, sobald du drin bist.';
      });
      return [heading('Sprache'), el('div', { class: 'dbig-row' }, big('mute', 'Mikrofon', 'mic', 'micoff'), big('deaf', 'Ton', 'headphones', 'mute')), grid, hint];
    },

    volume(ctx) {
      const v = el('span', { class: 'v' }, '');
      let proc = null;
      const range = makeRange(PCT, x => proc && act({ t: 'set', bind: 'app:' + proc, value: x / 100 }, { quiet: 1 }), x => { v.textContent = x + ' %'; });
      const mute = el('button', { class: 'icon-btn', 'aria-label': 'Stumm', onclick: () => proc && act({ t: 'toggle', bind: 'app:' + proc }, { quiet: 1 }) }, ic('volume'));
      const row = el('div', { class: 'mix-row' }, el('span', { class: 'appic sys' }, ic('volume')), el('div', { class: 'mix-mid' }, el('div', { class: 'mix-name' }, el('span', null, 'Lautstärke in Windows'), v), range), mute);
      const none = el('div', { class: 'hint' }, 'Spielt gerade keinen Ton.');
      const card = el('div', { class: 'card' }, row, none);
      ctx.ups.push(d => {
        const a = d.app && d.app.audio;
        proc = d.app && d.app.audioProc;
        row.style.display = a ? '' : 'none';
        none.style.display = a ? 'none' : '';
        if (!a) return;
        range.setValue(Math.round(a.v * 100));
        if (!range.busy()) v.textContent = Math.round(a.v * 100) + ' %';
        row.classList.toggle('muted-state', a.m);
        mute.classList.toggle('alert', a.m);
      });
      return [heading('Ton'), card];
    },

    vm(ctx) {
      const p = vmPanel();
      ctx.ups.push(d => p.update(d.vm));
      return [p.node];
    },

    gpu(ctx) {
      const cells = {};
      const cell = (k, label) => { cells[k] = el('div', { class: 'big-num' }, '–'); return el('div', { class: 'card' }, el('div', { class: 'hint' }, label), cells[k]); };
      const grid = el('div', { class: 'stat-grid three' }, cell('util', 'Auslastung'), cell('temp', 'Temperatur'), cell('mem', 'Grafikspeicher'), cell('power', 'Strom'), cell('fan', 'Lüfter'), cell('clock', 'Takt'));
      const name = el('div', { class: 'hint', style: 'margin:-4px 2px 10px' }, '');
      ctx.ups.push(d => {
        const g = d.stats && d.stats.gpu;
        if (!g) { name.textContent = 'Keine NVIDIA-Grafikkarte gefunden (nvidia-smi fehlt).'; return; }
        name.textContent = g.name + (g.driver ? ' · Treiber ' + g.driver : '');
        cells.util.textContent = Math.round(g.util) + ' %';
        cells.temp.textContent = Math.round(g.temp) + ' °C';
        cells.mem.textContent = (g.memUsed / 1024).toFixed(1) + ' / ' + (g.memTotal / 1024).toFixed(0) + ' GB';
        cells.power.textContent = g.power ? Math.round(g.power) + ' W' : '–';
        cells.fan.textContent = g.fan != null ? Math.round(g.fan) + ' %' : '–';
        cells.clock.textContent = g.clock ? Math.round(g.clock) + ' MHz' : '–';
      });
      return [heading('Grafikkarte live'), name, grid];
    },

    games(ctx, sec) {
      const games = S.apps.filter(a => a.source === sec.source);
      if (!games.length) return null;
      const grid = el('div', { class: 'app-grid' }, games.map(a => {
        const c = el('div', { class: 'app-card' }, el('span', { class: 'run-dot' }), appIcon({ id: a.id }, a.name), el('div', { class: 'n' }, a.name));
        press(c, { tap: () => act({ t: 'app', id: a.id, op: 'smart' }), long: () => openApp({ app: a }) });
        ctx.ups.push(() => c.classList.toggle('running', isRunning(a, S.st)));
        return c;
      }));
      return [heading(sec.title || 'Spiele'), grid, el('p', { class: 'hint' }, 'Antippen startet das Spiel, lange drücken öffnet seine Seite.')];
    },

    openurl(ctx, sec) {
      const inp = el('input', { class: 'in', type: 'url', placeholder: 'Adresse oder Suchbegriff', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const go = url => {
        url = (url || inp.value).trim();
        if (!url) return;
        if (!/^[a-z]+:\/\//i.test(url)) url = /^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(url) ? 'https://' + url : 'https://www.google.com/search?q=' + enc(url);
        act({ t: 'launch', target: sec.exe, args: url });
        inp.value = '';
      };
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      const sites = [['YouTube', 'https://www.youtube.com'], ['Twitch', 'https://www.twitch.tv'], ['Google', 'https://www.google.com'], ['Netflix', 'https://www.netflix.com'], ['ChatGPT', 'https://chatgpt.com'], ['Gmail', 'https://mail.google.com']];
      return [heading('Seite öffnen'),
        el('div', { class: 'card' }, el('div', { class: 'row' }, el('div', { class: 'grow' }, inp), el('button', { class: 'btn primary', onclick: () => go() }, 'Öffnen')),
          el('div', { class: 'chips', style: 'margin-top:10px' }, sites.map(([l, u]) => el('button', { class: 'chip', onclick: () => go(u) }, l))))];
    },

    custom(ctx) {
      const grid = el('div', { class: 'abtn-grid' });
      const draw = () => {
        grid.innerHTML = '';
        const list = AD.buttons[ctx.key] || [];
        list.forEach(t => grid.append(addonButton({ label: t.label || actLabel(t.a), icon: t.icon || actIcon(t.a), color: t.color, a: t.a, confirm: t.confirm }, ctx, [
          { icon: tic('edit', 'cyan'), title: 'Bearbeiten', onclick: () => editTile(t, false, customTarget(ctx, draw)) },
          { icon: tic('trash', 'red'), title: 'Löschen', onclick: async () => {
            if (!await confirmSheet('Button löschen?', null, 'Löschen', true)) return;
            AD.buttons[ctx.key] = (AD.buttons[ctx.key] || []).filter(x => x.id !== t.id);
            saveAddons();
            draw();
          } }])));
        const add = el('button', { class: 'abtn add' }, el('span', { class: 't-ic' }, ic('plus')), el('span', { class: 'abtn-l' }, 'Neuer Button'));
        press(add, { tap: () => {
          const a = { t: 'appkey', keys: '' };
          if (ctx.app) a.id = ctx.app.id; else a.procs = ctx.procs.join(',');
          editTile({ id: uid(), type: 'action', color: (ctx.addon && ctx.addon.color) || 'violet', a }, true, customTarget(ctx, draw));
        } });
        grid.append(add);
      };
      draw();
      return [el('p', { class: 'hint', style: 'margin:0 2px 12px' }, 'Deine eigenen Tastenkürzel, Texte, Makros oder Links für ' + ctx.name + '. Lange drücken = bearbeiten oder aufs Deck legen.'), grid];
    },

    process(ctx) {
      const prio = [['below', 'Niedrig'], ['normal', 'Normal'], ['above', 'Höher'], ['high', 'Hoch']];
      const seg = segTabs(prio, null, k => act({ t: 'priority', procs: ctx.procs, level: k }));
      const winBox = el('div');
      const info = el('dl', { class: 'kv' });
      let winKey = null;
      ctx.ups.push(d => {
        const a = d.app;
        if (!a) return;
        [...seg.children].forEach(b => b.classList.toggle('on', b.dataset.k === a.priority));
        info.innerHTML = '';
        const row = (k, v) => [el('dt', null, k), el('dd', null, v)];
        if (a.running) info.append(...[row('Prozesse', a.count), row('Arbeitsspeicher', a.ram + ' MB'), row('CPU', a.cpu == null ? '…' : a.cpu + ' %'),
          row('Läuft seit', a.since == null ? '–' : uptime(a.since))].flat());
        else info.append(...row('Status', 'Läuft gerade nicht'));
        const key = JSON.stringify(a.windows);
        if (key === winKey) return;
        winKey = key;
        winBox.innerHTML = '';
        (a.windows || []).forEach(w => {
          const op = o => e => { e.stopPropagation(); act({ t: 'window', h: w.h, op: o }, { quiet: 1 }); };
          const r = el('div', { class: 'win-row' + (w.fg ? ' fg' : '') }, el('span', { class: 'appic sys' }, ic('window')),
            el('div', { class: 'win-main' }, el('b', null, w.title), el('small', null, w.min ? 'minimiert' : w.fg ? 'im Vordergrund' : 'antippen = nach vorne')),
            el('div', { class: 'win-acts' },
              el('button', { class: 'icon-btn', 'aria-label': 'Minimieren', onclick: op('min') }, ic('minimize')),
              el('button', { class: 'icon-btn', 'aria-label': 'Maximieren', onclick: op('max') }, ic('maximize')),
              el('button', { class: 'icon-btn alert', 'aria-label': 'Schließen', onclick: op('close') }, ic('x'))));
          press(r.querySelector('.win-main'), { tap: () => act({ t: 'window', h: w.h, op: 'focus' }, { quiet: 1 }) });
          winBox.append(r);
        });
        if (!(a.windows || []).length) winBox.append(el('div', { class: 'hint' }, a.running ? 'Kein sichtbares Fenster.' : 'Läuft nicht.'));
      });
      const appOp = op => ctx.app ? act({ t: 'app', id: ctx.app.id, op }) : act({ t: 'kill', procs: ctx.procs, force: op === 'forcekill' });
      return [
        heading('Leistung'),
        el('div', { class: 'card' }, info,
          el('div', { class: 'field', style: 'margin-top:14px' }, el('span', { class: 'field-label' }, 'Priorität – „Hoch“ gibt dem Programm mehr CPU-Leistung'), seg)),
        heading('Fenster'),
        el('div', { class: 'card' },
          el('div', { class: 'row wrap' },
            el('button', { class: 'btn small', onclick: () => act({ t: 'appwin', procs: ctx.procs, op: 'min' }) }, ic('minimize'), 'Alle minimieren'),
            el('button', { class: 'btn small', onclick: () => act({ t: 'appwin', procs: ctx.procs, op: 'max' }) }, ic('maximize'), 'Maximieren')),
          el('div', { style: 'margin-top:8px' }, winBox)),
        heading('Neu starten & Beenden'),
        el('div', { class: 'card row wrap' },
          ctx.app ? el('button', { class: 'btn small', onclick: () => act({ t: 'app', id: ctx.app.id, op: 'restart' }) }, ic('restart'), 'Neu starten') : null,
          el('button', { class: 'btn small danger', onclick: async () => { if (await confirmSheet('Sofort beenden?', 'Das Programm wird hart beendet – nicht gespeicherte Daten gehen verloren.', 'Sofort beenden', true)) appOp('forcekill'); } }, ic('x'), 'Sofort beenden'))];
    },

    settings(ctx) {
      const ad = ctx.addon;
      if (!ad || ad.generic) return null;
      const box = el('div', { class: 'card form' },
        el('label', { class: 'check' }, el('span', null, el('b', null, ad.name + '-Addon aktiv'), el('small', { class: 'hint', style: 'display:block' }, ad.desc)),
          sw(addonOn(ad.id), v => { setAddonOn(ad.id, v); toast(v ? 'Addon aktiviert' : 'Addon ausgeschaltet'); ctx.reload(); })));
      for (const f of ad.settings || []) {
        const cur = (AD.settings[ad.id] || {})[f.key];
        const inp = el('input', { class: 'in', placeholder: f.def ? 'Standard: ' + prettyKeys(f.def) : 'nicht belegt', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', value: cur || '' });
        inp.addEventListener('change', () => {
          AD.settings[ad.id] = Object.assign({}, AD.settings[ad.id], { [f.key]: inp.value.trim() });
          saveAddons();
          toast('Gespeichert');
        });
        box.append(field(f.label, inp, f.hint || (f.type === 'keys' ? 'z. B. alt+f10 oder ctrl+shift+m' : null)));
      }
      if (ad.id === 'spotify') box.append(el('button', { class: 'btn small', onclick: () => spotifySetup(() => ctx.reload()) }, ic('music'), S.sp.connected ? 'Spotify-Verbindung' : 'Spotify verbinden'));
      return [box];
    }
  };

  function customTarget(ctx, redraw) {
    return {
      title: 'Eigener Button',
      save(t) {
        const list = AD.buttons[ctx.key] = AD.buttons[ctx.key] || [];
        const i = list.findIndex(x => x.id === t.id);
        if (i >= 0) list[i] = t; else list.push(t);
        saveAddons();
        redraw();
      }
    };
  }

  function buildPage(target, reload) {
    const app = target.app || (target.addon ? appForAddon(target.addon) : null);
    let addon = target.addon || (app ? addonFor(app) : null);
    if (addon && !addon.generic && !addonOn(addon.id)) addon = app ? addonFor(app) : null;
    const procs = [...new Set([...(app ? app.procs : []), ...((addon && addon.match && addon.match.procs) || [])].map(p => p.toLowerCase()))];
    const name = app ? app.name : addon ? addon.name : 'App';
    const ctx = { app, addon, procs, name, key: addon && !addon.generic ? addon.id : 'app:' + (app ? app.id : name), ups: [], destroy: [], reload };
    const parts = new Set((addon && addon.parts) || []);
    if (addon && addon.sections.includes(GAME)) parts.add('discord');
    if (procs.includes('spotify')) parts.add('spotify');

    const root = el('div', { class: 'app-page' });

    // hero: icon, status, start/front/stop
    const status = el('div', { class: 'hero-status' }, '…');
    const start = el('button', { class: 'btn primary', onclick: () => {
      if (addon && addon.launch) act(addon.launch);
      else if (app) act({ t: 'app', id: app.id, op: 'launch' });
      else toast('Für diese App ist kein Start bekannt', 'err');
    } }, ic('play', 'fill'), 'Starten');
    const front = el('button', { class: 'btn', onclick: () => app ? act({ t: 'app', id: app.id, op: 'focus' }) : act({ t: 'focus', procs }) }, ic('window'), 'Nach vorne');
    const stop = el('button', { class: 'btn danger', onclick: async () => {
      if (!await confirmSheet(name + ' beenden?', 'Nicht gespeicherte Daten können verloren gehen.', 'Beenden', true)) return;
      app ? act({ t: 'app', id: app.id, op: 'kill' }) : act({ t: 'kill', procs });
    } }, ic('x'), 'Beenden');
    const icon = app ? appIcon({ id: app.id }, name) : procs[0] ? appIcon({ proc: procs[0] }, name) : tic(addon.icon, addon.color);
    const about = addon && !addon.generic ? addon.desc : addon ? 'Spiel – mit Discord-, Clip- und Screenshot-Knöpfen' : 'App – Start, Fenster, Ton und eigene Buttons';
    root.append(el('div', { class: 'app-hero card' + (addon ? ' c-' + addon.color : '') },
      el('div', { class: 'row' }, icon, el('div', { class: 'grow' }, status, el('small', { class: 'hero-about' }, about))),
      el('div', { class: 'hero-btns' }, start, front, stop)));
    ctx.ups.push(d => {
      const a = d.app;
      if (!a) return;
      status.textContent = a.running ? 'Läuft' + (a.cpu != null ? ' · ' + a.cpu + ' % CPU' : '') + ' · ' + a.ram + ' MB' : 'Läuft gerade nicht';
      status.classList.toggle('running-text', a.running);
      stop.style.display = a.running ? '' : 'none';
      front.style.display = a.running ? '' : 'none';
      start.style.display = a.running ? 'none' : '';
    });

    // panes behind tabs, so a page never turns into one endless list
    const flat = x => [].concat(x || []).filter(Boolean);
    const control = [];
    if (addon) for (const sec of addon.sections) control.push(...flat(SECTIONS[sec.type](ctx, sec)));
    if (!addon && app) {
      const off = ADDONS.find(x => matches(x, app));
      if (off) control.push(el('div', { class: 'card promo' }, tic(off.icon, off.color), el('div', { class: 'grow' }, el('b', null, off.name + '-Addon ist aus'), el('small', null, off.desc)),
        el('button', { class: 'btn small primary', onclick: () => { setAddonOn(off.id, true); reload(); } }, 'Einschalten')));
    }
    const program = [];
    if (!(addon && addon.sections.some(s => s.type === 'vm'))) program.push(...flat(SECTIONS.volume(ctx)));
    if (procs.length) program.push(...flat(SECTIONS.process(ctx)));
    const settings = flat(SECTIONS.settings(ctx));

    const panes = [];
    if (control.length) panes.push(['control', 'Steuerung', control]);
    panes.push(['mine', 'Buttons', flat(SECTIONS.custom(ctx))]);
    panes.push(['program', 'Programm', program]);
    if (settings.length) panes.push(['settings', 'Optionen', settings]);

    const paneEls = {};
    const saved = LS.get('pane.' + ctx.key, panes[0][0]);
    const first = panes.some(p => p[0] === saved) ? saved : panes[0][0];
    const pick = k => { LS.set('pane.' + ctx.key, k); Object.keys(paneEls).forEach(p => { paneEls[p].style.display = p === k ? '' : 'none'; }); };
    root.append(segTabs(panes.map(p => [p[0], p[1]]), first, pick, 'page-tabs'));
    for (const [k, , nodes] of panes) {
      paneEls[k] = el('div', { class: 'pane' }, nodes);
      root.append(paneEls[k]);
    }
    pick(first);

    const q = 'procs=' + enc(procs.join(',')) + '&parts=' + [...parts].join(',');
    return {
      node: root, name,
      poll: () => ({ path: '/api/appinfo?' + q, ms: 1500 }),
      update(d) {
        if (d.spotify) S.sp = d.spotify;
        for (const u of ctx.ups) try { u(d); } catch (e) { console.error(e); }
      },
      destroy() { ctx.destroy.forEach(f => f()); }
    };
  }

  function appPage(target) {
    const view = { title: '' };
    view.render = root => {
      view.page = buildPage(target, () => view.reload());
      view.title = view.page.name;
      root.append(view.page.node);
    };
    view.poll = () => view.page.poll();
    view.update = d => view.page.update(d);
    view.destroy = () => { if (view.page) view.page.destroy(); };
    view.reload = () => {
      view.destroy();
      view.el.innerHTML = '';
      view.render(view.el);
      if (current === view) mount();
    };
    return view;
  }

  function openApp(target) {
    if (NAV.tab !== 'apps') show('apps');
    push(appPage(target));
  }

  const KIND_GROUPS = [['game', 'Spiele'], ['app', 'Apps'], ['launcher', 'Launcher']];

  const AppsView = {
    title: 'Apps',
    filter: 'all', q: '',
    poll() { return { path: '/api/state' + (addonOn('discord') ? '?discord=1' : ''), ms: 2500 }; },
    render(root) {
      this.root = root;
      const search = el('input', { class: 'in', type: 'search', placeholder: 'App oder Spiel suchen …', value: this.q });
      search.addEventListener('input', () => { this.q = search.value; this.drawApps(); });
      const rescan = el('button', { class: 'icon-btn', 'aria-label': 'Apps neu suchen', title: 'Apps neu suchen', onclick: async () => {
        rescan.disabled = true;
        toast('Suche Apps & Spiele …');
        try { S.apps = await api('/api/rescan') || []; toast(S.apps.length + ' Apps gefunden'); this.drawApps(); }
        catch (e) { toast(e.message, 'err'); }
        rescan.disabled = false;
      } }, ic('refresh'));
      const manage = el('button', { class: 'icon-btn', 'aria-label': 'Addons verwalten', title: 'Addons verwalten', onclick: addonManager }, ic('puzzle'));
      const seg = segTabs([['all', 'Alle'], ['game', 'Spiele'], ['app', 'Apps'], ['running', 'Läuft']], this.filter, k => { this.filter = k; this.drawApps(); });
      this.stripBox = el('div', { class: 'run-box' });
      this.list = el('div');
      root.append(
        el('div', { class: 'app-tools' }, el('div', { class: 'row' }, el('div', { class: 'search grow' }, ic('search'), search), manage, rescan), seg),
        this.stripBox, this.list,
        el('p', { class: 'hint', style: 'text-align:center;margin-top:18px' }, 'Antippen öffnet alle Funktionen der App · lange drücken startet sie direkt · ', ic('puzzle', 'inline'), ' = Addon mit Extra-Funktionen'));
      this.stripKey = null;
      this.drawApps();
      this.drawStrip(S.st);
    },
    card(a) {
      const ad = addonFor(a);
      const c = el('div', { class: 'app-card' + (ad && !ad.generic ? ' has-addon c-' + ad.color : '') }, el('span', { class: 'run-dot' }), appIcon({ id: a.id }, a.name), el('div', { class: 'n' }, a.name),
        ad && !ad.generic ? el('span', { class: 'addon-badge', title: 'Addon' }, ic('puzzle')) : null);
      press(c, { tap: () => openApp({ app: a }), long: () => act(ad && ad.launch ? ad.launch : { t: 'app', id: a.id, op: 'smart' }) });
      c.app = a;
      this.appCards.push(c);
      return c;
    },
    drawApps() {
      const q = this.q.trim().toLowerCase();
      const list = S.apps.filter(a => (this.filter === 'all' || (this.filter === 'running' ? isRunning(a, S.st) : this.filter === 'app' ? a.kind !== 'game' : a.kind === this.filter)) &&
        (!q || a.name.toLowerCase().includes(q)));
      this.list.innerHTML = '';
      this.appCards = [];
      if (!list.length) {
        this.list.append(el('div', { class: 'empty' }, S.apps.length ? (this.filter === 'running' ? 'Gerade läuft keine der Apps.' : 'Nichts gefunden.') : 'Apps werden noch gesucht … tippe gleich auf ↻.'));
        return;
      }
      if (this.filter === 'all' && !q) {
        for (const [k, l] of KIND_GROUPS) {
          const items = list.filter(a => a.kind === k);
          if (!items.length) continue;
          this.list.append(heading(l, el('span', { class: 'count' }, items.length)), el('div', { class: 'app-grid' }, items.map(a => this.card(a))));
        }
      } else this.list.append(el('div', { class: 'app-grid', style: 'margin-top:14px' }, list.map(a => this.card(a))));
      this.update(S.st, true);
    },
    // "running now" strip with live status for Spotify/Discord
    drawStrip(d) {
      const run = S.apps.filter(a => isRunning(a, d));
      const key = run.map(a => a.id).join('|');
      if (key !== this.stripKey) {
        this.stripKey = key;
        this.stripBox.innerHTML = '';
        this.stripItems = [];
        if (run.length && this.filter !== 'running') {
          const strip = el('div', { class: 'run-strip' });
          for (const a of run) {
            const sub = el('small', null, 'Läuft');
            const c = el('div', { class: 'run-item' }, appIcon({ id: a.id }, a.name), el('div', { class: 'grow' }, el('b', null, a.name), sub));
            press(c, { tap: () => openApp({ app: a }) });
            c.upd = dd => {
              let txt = 'Läuft';
              if (/^spotify/i.test(a.name) && dd.np && dd.np.proc === 'spotify' && dd.np.title) txt = (dd.np.playing ? '▶ ' : '❚❚ ') + dd.np.title;
              if (/^discord$/i.test(a.name) && dd.discord && dd.discord.ok) txt = dd.discord.deaf ? 'Ton aus' : dd.discord.mute ? 'Mikro stumm' : 'Mikro an';
              sub.textContent = txt;
            };
            this.stripItems.push(c);
            strip.append(c);
          }
          this.stripBox.append(heading('Läuft gerade', el('span', { class: 'count' }, run.length)), strip);
        }
      }
      (this.stripItems || []).forEach(c => c.upd(d || {}));
    },
    update(d, quiet) {
      if (!d) return;
      if (!quiet) S.st = d;
      for (const c of this.appCards || []) c.classList.toggle('running', isRunning(c.app, d));
      if (this.stripBox) this.drawStrip(d);
    }
  };

  function addonManager() {
    const list = el('div', { class: 'pick-list' });
    const all = ADDONS.concat([Object.assign({}, GAME_ADDON, { name: 'Spiele (allgemein)', desc: 'Für alle anderen Spiele: Discord stumm, Clips, Screenshots, Priorität, Lautstärke', match: {} })]);
    const installed = [], missing = [];
    for (const ad of all) {
      const app = ad.match && ad.match.name ? appForAddon(ad) : null;
      const found = ad.id === 'game' ? S.apps.some(a => a.kind === 'game') : !!app || addonRunning(ad, S.st);
      const row = el('div', { class: 'pick-item manager-row' + (found ? '' : ' dim') },
        app ? appIcon({ id: app.id }, ad.name) : tic(ad.icon, ad.color),
        el('div', null, el('b', null, ad.name), el('small', null, ad.desc)),
        sw(addonOn(ad.id), v => { setAddonOn(ad.id, v); if (current === AppsView) AppsView.drawApps(); }));
      if (found && ad.id !== 'game') press(row.children[1], { tap: () => { close(); openApp(app ? { app, addon: ad } : { addon: ad }); } });
      (found ? installed : missing).push(row);
    }
    list.append(heading('Auf diesem PC', el('span', { class: 'count' }, installed.length)), ...installed);
    if (missing.length) list.append(heading('Nicht installiert', el('span', { class: 'count' }, missing.length)), ...missing);
    const close = sheet('Addons verwalten', el('div', null,
      el('p', { class: 'muted', style: 'margin:0 0 4px' }, 'Addons geben einer App Extra-Funktionen. Schalter = an/aus, Antippen = App-Seite mit Einstellungen und eigenen Buttons.'), list), { wide: true });
  }

  // ---------- mouse & keyboard ----------

  const MouseView = {
    title: 'Maus & Tastatur',
    render(root) {
      const sens = LS.get('sens', 1.6);
      const M = { dx: 0, dy: 0, sx: 0, sy: 0, busy: false, extra: [], sens };
      this.release = Live.use();
      const nextAction = () => {
        const dx = Math.trunc(M.dx), dy = Math.trunc(M.dy), sx = Math.trunc(M.sx), sy = Math.trunc(M.sy);
        const extra = M.extra.shift();
        if (!dx && !dy && !sx && !sy && !extra) return null;
        M.dx -= dx; M.dy -= dy; M.sx -= sx; M.sy -= sy;
        return Object.assign({ t: 'mouse' }, dx ? { dx } : null, dy ? { dy } : null, sx ? { sx } : null, sy ? { sy } : null, extra);
      };
      const flush = () => {
        if (M.busy) return;
        // open line: send right away; otherwise one request at a time
        if (Live.ok) { let a; while ((a = nextAction())) Live.send(a); return; }
        const a = nextAction();
        if (!a) return;
        M.busy = true;
        api('/api/action', a).catch(() => { }).then(() => { M.busy = false; flush(); });
      };
      const queue = extra => { M.extra.push(extra); flush(); };

      const pad = el('div', { class: 'pad' }, el('div', { class: 'pad-hint' }, '1 Finger: bewegen · Tippen: Klick · 2 Finger: scrollen · 2-Finger-Tipp: Rechtsklick'));
      const pts = new Map();
      let maxPts = 0, startT = 0, moved = 0;
      pad.addEventListener('pointerdown', e => {
        e.preventDefault();
        try { pad.setPointerCapture(e.pointerId); } catch (x) { }
        if (!pts.size) { startT = performance.now(); moved = 0; maxPts = 0; }
        pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
        maxPts = Math.max(maxPts, pts.size);
        pad.classList.add('active');
      });
      pad.addEventListener('pointermove', e => {
        const p = pts.get(e.pointerId);
        if (!p) return;
        const dx = e.clientX - p.x, dy = e.clientY - p.y;
        p.x = e.clientX; p.y = e.clientY;
        moved += Math.abs(dx) + Math.abs(dy);
        if (pts.size === 1 && maxPts === 1) {
          const acc = 1 + Math.min(2.2, Math.hypot(dx, dy) / 14);
          M.dx += dx * M.sens * acc;
          M.dy += dy * M.sens * acc;
        } else if (pts.size >= 2) {
          M.sy += dy / pts.size * 4;
          M.sx -= dx / pts.size * 4;
        }
        flush();
      });
      const up = e => {
        if (!pts.has(e.pointerId)) return;
        pts.delete(e.pointerId);
        if (pts.size) return;
        pad.classList.remove('active');
        if (performance.now() - startT < 260 && moved < 14 * maxPts) { buzz(); queue({ click: maxPts >= 2 ? 'right' : 'left' }); }
      };
      pad.addEventListener('pointerup', up);
      pad.addEventListener('pointercancel', up);
      pad.addEventListener('contextmenu', e => e.preventDefault());

      // Hold a button while moving on the pad to drag, just like a laptop touchpad.
      const mbtn = (b, label) => {
        const n = el('button', null, label);
        n.addEventListener('pointerdown', e => { e.preventDefault(); buzz(); n.classList.add('down'); queue({ down: b }); });
        const rel = () => { if (!n.classList.contains('down')) return; n.classList.remove('down'); queue({ up: b }); };
        n.addEventListener('pointerup', rel);
        n.addEventListener('pointercancel', rel);
        n.addEventListener('pointerleave', rel);
        n.addEventListener('contextmenu', e => e.preventDefault());
        return n;
      };

      const sensR = makeRange({ min: 0.6, max: 4, step: 0.1 }, v => { M.sens = v; LS.set('sens', v); });
      sensR.value = sens;
      sensR.dispatchEvent(new Event('input'));

      let chain = Promise.resolve();
      const kq = a => { chain = chain.then(() => api('/api/action', a).catch(e => toast(e.message, 'err'))); };
      const live = el('input', { class: 'in', placeholder: 'Hier tippen – geht sofort an den PC', autocomplete: 'off', autocorrect: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'send' });
      let last = '', composing = false;
      live.addEventListener('compositionstart', () => { composing = true; });
      live.addEventListener('compositionend', () => { composing = false; });
      live.addEventListener('input', () => {
        const v = live.value;
        let i = 0;
        while (i < last.length && i < v.length && last[i] === v[i]) i++;
        const del = last.length - i, ins = v.slice(i);
        last = v;
        for (let k = 0; k < del; k++) kq({ t: 'key', keys: 'backspace' });
        if (ins) kq({ t: 'text', text: ins });
        if (!composing && v.length > 80) { live.value = ''; last = ''; }
      });
      live.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); kq({ t: 'key', keys: 'enter' }); live.value = ''; last = ''; }
      });
      live.addEventListener('blur', () => { live.value = ''; last = ''; });

      const KEYS = [['Esc', 'esc'], ['Tab', 'tab'], ['⌫', 'backspace'], ['Enter', 'enter'],
        ['Entf', 'delete'], ['↑', 'up'], ['Leer', 'space'], ['Win', 'win'],
        ['←', 'left'], ['↓', 'down'], ['→', 'right'], ['Alt+Tab', 'alt+tab'],
        ['Strg+C', 'ctrl+c'], ['Strg+V', 'ctrl+v'], ['Strg+Z', 'ctrl+z'], ['Strg+A', 'ctrl+a'],
        ['Desktop', 'win+d'], ['Snip', 'win+shift+s'], ['Alt+F4', 'alt+f4'], ['Task-Mgr', 'ctrl+shift+esc'],
        ['F5', 'f5'], ['F11', 'f11'], ['Pos1', 'home'], ['Ende', 'end']];
      const keys = el('div', { class: 'keys' }, KEYS.map(([l, k]) => el('button', { onclick: () => { buzz(); kq({ t: 'key', keys: k }); } }, l)));
      const combo = el('input', { class: 'in', placeholder: 'Eigene Kombination, z. B. ctrl+shift+m', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const sendCombo = () => { if (combo.value.trim()) { buzz(); kq({ t: 'key', keys: combo.value.trim() }); } };
      combo.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); sendCombo(); } });

      const mousePane = el('div', null, pad, el('div', { class: 'pad-btns' }, mbtn('left', 'Links'), mbtn('middle', 'Mitte'), mbtn('right', 'Rechts')),
        el('div', { class: 'sens' }, el('span', null, 'Tempo'), sensR));
      const keyPane = el('div', null, el('div', { class: 'card' }, live, el('div', { style: 'height:12px' }), keys, el('div', { style: 'height:12px' }),
        el('div', { class: 'row' }, el('div', { class: 'grow' }, combo), el('button', { class: 'btn', onclick: sendCombo }, 'Senden'))));
      const pick = k => { LS.set('mouseTab', k); mousePane.style.display = k === 'mouse' ? '' : 'none'; keyPane.style.display = k === 'keys' ? '' : 'none'; };
      const tab = LS.get('mouseTab', 'mouse');
      root.append(segTabs([['mouse', 'Touchpad'], ['keys', 'Tastatur']], tab, pick, 'top-seg'), mousePane, keyPane);
      pick(tab);
    },
    destroy() { if (this.release) { this.release(); this.release = null; } }
  };

  // ---------- system, power, screen, windows, tools ----------

  const SysSub = {
    title: 'System & Leistung',
    poll: () => ({ path: '/api/state?stats=1', ms: 2000 }),
    render(root) {
      const grid = el('div', { class: 'stat-grid' });
      root.append(grid);
      const stat = label => {
        const num = el('div', { class: 'big-num' }, '–'), bar = el('i'), sm = el('small', { class: 'hint' }, '');
        const box = el('div', { class: 'bar' }, bar);
        grid.append(el('div', { class: 'card' }, el('div', { class: 'hint' }, label), num, box, sm));
        return (pct, txt, sub) => {
          num.innerHTML = '';
          num.style.fontSize = txt != null && txt.length > 4 ? '20px' : '';
          num.append(txt != null ? txt : pct == null ? '–' : Math.round(pct) + '', pct != null && txt == null ? el('small', null, ' %') : '');
          bar.style.width = (pct || 0) + '%';
          box.classList.toggle('hot', pct > 85);
          sm.textContent = sub || '';
        };
      };
      this.cpu = stat('CPU'); this.ram = stat('Arbeitsspeicher'); this.gpu = stat('Grafikkarte'); this.up = stat('Laufzeit');

      this.info = el('dl', { class: 'kv' });
      this.drives = el('div');
      root.append(heading('Dieser PC'), el('div', { class: 'card' }, this.info, this.drives));
      api('/api/info').then(i => {
        const row = (k, v) => [el('dt', null, k), el('dd', null, v)];
        this.info.append(...[row('Name', i.name), row('Benutzer', i.user), row('System', i.os), row('PC Remote', 'Version ' + i.version), row('Adresse', i.urls.join('\n'))].flat());
        for (const d of i.drives) {
          const used = d.total - d.free, pct = d.total ? used / d.total * 100 : 0;
          this.drives.append(el('div', { style: 'margin-top:14px' },
            el('div', { class: 'meter-top' }, 'Laufwerk ' + d.name, el('span', null, d.free + ' GB frei von ' + d.total + ' GB')),
            el('div', { class: 'bar' + (pct > 90 ? ' hot' : '') }, el('i', { style: 'width:' + pct + '%' }))));
        }
      }).catch(() => { });
    },
    update(d) {
      const s = d && d.stats;
      if (!s) return;
      this.cpu(s.cpu);
      this.ram(s.ram && s.ram.pct, null, s.ram ? s.ram.used + ' von ' + s.ram.total + ' GB' : '');
      if (s.gpu) this.gpu(s.gpu.util, null, s.gpu.name + ' · ' + s.gpu.temp + ' °C' + (s.gpu.power ? ' · ' + Math.round(s.gpu.power) + ' W' : ''));
      else this.gpu(null, '–', 'Nur NVIDIA-Grafikkarten');
      this.up(null, uptime(s.uptime), 'seit dem letzten Start');
    }
  };

  const PowerSub = {
    title: 'Energie',
    render(root) {
      const pw = (cmd, label, sub, icon, color, opts) => {
        const b = el('button', { class: 'pick-item power-item', onclick: () => power(cmd, label, opts) }, tic(icon, color), el('div', null, el('b', null, label), el('small', null, sub)));
        return b;
      };
      root.append(
        heading('Sofort'),
        el('div', { class: 'pick-list' },
          pw('lock', 'Sperren', 'Sperrbildschirm, alles läuft weiter', 'lock', 'slate'),
          pw('monitoroff', 'Monitor aus', 'Bildschirm aus, PC läuft weiter', 'monitor', 'slate')),
        heading('Schlafen'),
        el('div', { class: 'pick-list' },
          pw('sleep', 'Energiesparen', 'Schnell wieder da, braucht etwas Strom', 'moon', 'violet', { confirm: 1 }),
          pw('hibernate', 'Ruhezustand', 'Speichert alles und schaltet ab', 'moon', 'violet', { confirm: 1 })),
        heading('Aus & Neustart'),
        el('div', { class: 'pick-list' },
          pw('restart', 'Neu starten', 'Jetzt oder mit Timer', 'restart', 'red', { delay: 1 }),
          pw('shutdown', 'Herunterfahren', 'Jetzt oder mit Timer', 'power', 'red', { delay: 1 }),
          pw('logoff', 'Abmelden', 'Windows-Benutzer abmelden', 'logout', 'orange', { confirm: 1 }),
          pw('cancel', 'Timer abbrechen', 'Geplantes Herunterfahren / Neustarten stoppen', 'x', 'green')));
    }
  };

  async function power(cmd, label, opts) {
    opts = opts || {};
    if (opts.delay) {
      const choices = [[0, 'Jetzt'], [60, 'In 1 Minute'], [300, 'In 5 Minuten'], [900, 'In 15 Minuten'], [1800, 'In 30 Minuten'], [3600, 'In 1 Stunde'], [7200, 'In 2 Stunden']];
      const close = sheet(label, el('div', null,
        el('p', { class: 'muted', style: 'margin:0 0 14px' }, 'Wann? Ein geplanter Vorgang lässt sich mit „Timer abbrechen“ stoppen.'),
        pickList(choices.map(([s, l]) => ({ icon: tic(cmd === 'restart' ? 'restart' : 'power', s ? 'slate' : 'red'), title: l, onclick: () => { close(); act({ t: 'power', cmd, delay: s }); } })))));
      return;
    }
    if (opts.confirm && !await confirmSheet(label + '?', null, label, true)) return;
    act({ t: 'power', cmd });
  }

  const ScreenSub = {
    title: 'Bildschirm',
    render(root) {
      this.mon = LS.get('mon', 0);
      this.mode = 'left';
      this.live = false;
      this.alive = true;
      const monBox = el('div', { class: 'chips', style: 'margin-bottom:12px' });
      this.img = el('img', { alt: 'Bildschirm' });
      this.loading = el('div', { class: 'loading' }, 'Lade Bildschirm …');
      this.wrap = el('div', { class: 'screen-wrap' }, this.img, this.loading);
      const liveBtn = el('button', { class: 'btn small', onclick: () => { this.live = !this.live; liveBtn.classList.toggle('primary', this.live); liveBtn.lastChild.textContent = this.live ? 'Live an' : 'Live'; if (this.live) this.load(); } }, ic('record'), 'Live');
      const modes = [['left', 'Klick'], ['right', 'Rechts'], ['double', 'Doppel'], ['move', 'Nur zeigen']];
      root.append(monBox, this.wrap,
        el('div', { class: 'row', style: 'margin:12px 0' }, el('button', { class: 'btn small', onclick: () => this.load() }, ic('refresh'), 'Neu laden'), liveBtn),
        el('div', { class: 'hint', style: 'margin-bottom:8px' }, 'Tippe ins Bild, um dort zu klicken:'), segTabs(modes, this.mode, m => { this.mode = m; }));

      this.img.addEventListener('load', () => {
        this.loading.style.display = 'none';
        if (this.live && this.alive) this.timer = setTimeout(() => this.load(), 350);
      });
      this.img.addEventListener('error', () => { this.loading.textContent = 'Bildschirm konnte nicht geladen werden'; this.loading.style.display = ''; });
      this.img.addEventListener('click', e => {
        const r = this.img.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        const mark = el('span', { class: 'tap-mark', style: 'left:' + (x * 100) + '%;top:' + (y * 100) + '%' });
        this.wrap.append(mark);
        setTimeout(() => mark.remove(), 520);
        act({ t: 'tap', x, y, mon: this.mon, button: this.mode }, { quiet: 1 }).then(() => { if (!this.live) setTimeout(() => this.load(), 450); });
      });

      api('/api/windows').then(d => {
        const mons = d.monitors || [];
        if (mons.length < 2) return;
        mons.forEach(m => monBox.append(el('button', {
          class: 'chip' + (m.i === this.mon ? ' on' : ''),
          onclick: e => { this.mon = m.i; LS.set('mon', m.i); [...monBox.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); this.load(); }
        }, ic('monitor'), 'Monitor ' + (m.i + 1) + (m.primary ? ' (Haupt)' : ''))));
      }).catch(() => { });
      this.load();
    },
    load() {
      clearTimeout(this.timer);
      if (!this.alive) return;
      const w = Math.min(1920, Math.round((this.wrap.clientWidth || 400) * (window.devicePixelRatio || 1)));
      this.img.src = '/api/screen?' + authQ() + '&mon=' + this.mon + '&w=' + w + '&q=' + (this.live ? 50 : 70) + '&t=' + Date.now();
    },
    destroy() { this.alive = false; this.live = false; clearTimeout(this.timer); }
  };

  const WinSub = {
    title: 'Fenster',
    poll: () => ({ path: '/api/windows', ms: 3000 }),
    render(root) {
      this.box = el('div', { class: 'card' }, el('div', { class: 'empty' }, 'Lade Fenster …'));
      this.key = null;
      root.append(el('p', { class: 'hint', style: 'margin:0 2px 12px' }, 'Antippen holt das Fenster nach vorne.'), this.box);
    },
    update(d) {
      const wins = d.windows || [];
      const key = JSON.stringify(wins);
      if (key === this.key) return;
      this.key = key;
      this.box.innerHTML = '';
      if (!wins.length) this.box.append(el('div', { class: 'empty' }, 'Keine offenen Fenster.'));
      for (const w of wins) {
        const op = o => e => { e.stopPropagation(); act({ t: 'window', h: w.h, op: o }, { quiet: 1 }); };
        const row = el('div', { class: 'win-row' + (w.fg ? ' fg' : '') }, appIcon({ proc: w.proc }, w.app),
          el('div', { class: 'win-main' }, el('b', null, w.title), el('small', null, w.app + (w.min ? ' · minimiert' : w.fg ? ' · im Vordergrund' : ''))),
          el('div', { class: 'win-acts' },
            el('button', { class: 'icon-btn', 'aria-label': 'Minimieren', onclick: op('min') }, ic('minimize')),
            el('button', { class: 'icon-btn', 'aria-label': 'Maximieren', onclick: op('max') }, ic('maximize')),
            el('button', { class: 'icon-btn alert', 'aria-label': 'Schließen', onclick: op('close') }, ic('x'))));
        press(row.querySelector('.win-main'), { tap: () => act({ t: 'window', h: w.h, op: 'focus' }, { quiet: 1 }) });
        this.box.append(row);
      }
    }
  };

  const ToolsSub = {
    title: 'Zwischenablage & Befehle',
    render(root) {
      const clipIn = el('textarea', { class: 'in', placeholder: 'Text, der in die Zwischenablage des PCs soll …', style: 'min-height:80px;font-family:inherit;font-size:15px' });
      const clipOut = el('pre', { class: 'out', style: 'display:none' });
      const fromPc = el('button', { class: 'btn small', onclick: async () => {
        try {
          const r = await api('/api/clipboard');
          clipOut.style.display = '';
          clipOut.textContent = r.text || '(leer oder kein Text)';
          if (r.text) copyText(r.text).then(() => toast('Auch aufs Handy kopiert'), () => { });
        } catch (e) { toast(e.message, 'err'); }
      } }, ic('clipboard'), 'Vom PC holen');
      root.append(heading('Zwischenablage'),
        el('div', { class: 'card' }, clipIn,
          el('div', { class: 'row wrap', style: 'margin-top:10px' },
            el('button', { class: 'btn small primary', onclick: () => { if (clipIn.value) act({ t: 'clip', text: clipIn.value }); } }, ic('copy'), 'An PC senden'),
            el('button', { class: 'btn small', onclick: () => { if (clipIn.value) act({ t: 'text', text: clipIn.value }, { quiet: 1 }); } }, ic('type'), 'Am PC tippen'),
            fromPc),
          clipOut));

      const cmdIn = el('input', { class: 'in', placeholder: 'z. B. ipconfig', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      const out = el('pre', { class: 'out', style: 'display:none' });
      const run = async () => {
        if (!cmdIn.value.trim()) return;
        out.style.display = '';
        out.textContent = '…';
        const r = await act({ t: 'cmd', cmd: cmdIn.value }, { quiet: 1 });
        out.textContent = r ? r.msg : 'Fehlgeschlagen';
      };
      cmdIn.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); run(); } });
      root.append(heading('Befehl ausführen'),
        el('div', { class: 'card' }, el('div', { class: 'row' }, el('div', { class: 'grow' }, cmdIn), el('button', { class: 'btn', onclick: run }, ic('terminal'))), out));
    }
  };

  // Settings: addons, Spotify, PC options (only directly on the PC), phone options
  const SettingsView = {
    title: 'Einstellungen',
    render(root) {
      root.append(heading('Addons'),
        el('div', { class: 'pick-list' },
          menuRow('puzzle', 'violet', 'Addons verwalten', 'Ein-/ausschalten, Einstellungen, eigene Buttons', addonManager),
          menuRow('music', 'green', 'Spotify', S.sp.connected ? 'Verbunden' : 'Einrichten für Lautstärke in Spotify, Like, Playlists …', () => spotifySetup())));
      root.append(heading('Verbundene Geräte'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Diese Geräte verbinden sich von selbst wieder – ohne Scannen und ohne PIN. Entfernte Geräte müssen neu verbunden werden.'),
        devicesPanel());
      const pcBox = el('div');
      root.append(pcBox);
      if (S.local) {
        api('/api/pc').then(pc => {
          const pinEl = el('div', { class: 'pin-big' }, pc.pin);
          pcBox.append(heading('Dieser PC'),
            el('div', { class: 'card form' },
              el('label', { class: 'check' }, el('span', null, 'Mit Windows starten (unsichtbar im Tray)'), sw(pc.autostart, v => api('/api/pc', { cmd: 'autostart', on: v }).then(() => toast(v ? 'Startet mit Windows' : 'Autostart aus')).catch(e => toast(e.message, 'err')))),
              field('PIN fürs Handy', el('div', { class: 'row' }, el('div', { class: 'grow' }, pinEl),
                el('button', { class: 'btn small', onclick: async () => {
                  if (!await confirmSheet('Neue PIN erzeugen?', 'Alle verbundenen Handys müssen sich danach mit der neuen PIN neu anmelden.', 'Neue PIN', true)) return;
                  const r = await api('/api/pc', { cmd: 'newpin' });
                  S.pin = r.pin; LS.set('pin', r.pin); pinEl.textContent = r.pin; toast('Neue PIN: ' + r.pin);
                } }, ic('refresh'), 'Neue PIN'))),
              field('Adressen im WLAN', el('div', null, pc.urls.map(u => el('div', { class: 'mono' }, u)))),
              el('div', { class: 'row wrap' },
                el('button', { class: 'btn small', onclick: () => show('connect') }, ic('qr'), 'Handy verbinden'),
                el('button', { class: 'btn small', onclick: () => api('/api/pc', { cmd: 'folder' }) }, ic('folder'), 'Programmordner'),
                el('button', { class: 'btn small', onclick: () => { api('/api/pc', { cmd: 'rescan' }); toast('Apps werden neu gesucht …'); } }, ic('refresh'), 'Apps neu scannen'),
                el('button', { class: 'btn small danger', onclick: async () => { if (await confirmSheet('PC Remote beenden?', 'Das Handy kann den PC dann nicht mehr steuern, bis du PC Remote wieder startest.', 'Beenden', true)) api('/api/pc', { cmd: 'quit' }).catch(() => { }); } }, ic('power'), 'PC Remote beenden')),
              el('p', { class: 'hint' }, 'Version ' + pc.version + ' · ' + pc.dir)));
        }).catch(() => { });
      }
      root.append(...[heading(PC ? 'Bedienung' : 'Dieses Handy'),
        el('div', { class: 'card form' },
          field('Kachelgröße im Deck (nur ' + (PC ? 'dieser PC' : 'dieses Gerät') + ')', deckSizeControl()),
          PC ? null : el('label', { class: 'check' }, el('span', null, 'Vibration beim Tippen'), sw(S.haptics, v => { S.haptics = v; LS.set('haptics', v); })),
          el('div', { class: 'row wrap' },
            el('button', { class: 'btn small', onclick: async () => {
              if (!await confirmSheet('Deck zurücksetzen?', 'Alle Deck-Seiten und Kacheln werden durch die Standard-Seiten ersetzt.', 'Zurücksetzen', true)) return;
              S.layout = defaultLayout();
              S.pageIdx = 0;
              saveLayout();
              toast('Deck zurückgesetzt');
            } }, ic('refresh'), 'Deck zurücksetzen'),
            PC ? null : el('button', { class: 'btn small danger', onclick: async () => {
              if (!await confirmSheet('Dieses Gerät abmelden?', 'Es wird vom PC entfernt und muss danach neu verbunden werden.', 'Abmelden', true)) return;
              if (S.deviceId) await api('/api/devices', { cmd: 'remove', id: S.deviceId }).catch(() => { });
              logout();
            } }, ic('logout'), 'Abmelden'))),
        PC ? null : el('p', { class: 'hint', style: 'text-align:center' }, 'Tipp: Im Browser-Menü „Zum Startbildschirm hinzufügen“ – dann startet PC Remote wie eine App.')].filter(Boolean));
    }
  };

  function ago(ms) {
    const s = Math.max(0, (Date.now() - ms) / 1000);
    if (s < 60) return 'gerade eben';
    if (s < 3600) return 'vor ' + Math.round(s / 60) + ' Min.';
    if (s < 86400) return 'vor ' + Math.round(s / 3600) + ' Std.';
    const d = Math.round(s / 86400);
    return 'vor ' + d + (d === 1 ? ' Tag' : ' Tagen');
  }
  const devIcon = name => /iphone|handy|android-handy/i.test(name) ? 'phone' : /tablet|ipad/i.test(name) ? 'devices' : 'monitor';

  async function answerPair(p, allow) {
    try {
      await api('/api/devices', { cmd: allow ? 'allow' : 'deny', id: p.id });
      toast(allow ? '„' + p.name + '“ ist jetzt verbunden' : 'Abgelehnt');
    } catch (e) { toast(e.message, 'err'); }
  }

  // Paired devices: who is connected, rename, remove; on the PC also open "allow?" requests.
  function devicesPanel() {
    const box = el('div', { class: 'pick-list' }, el('div', { class: 'hint' }, 'Lade …'));
    let key = null;
    const load = async () => {
      let d;
      try { d = await api('/api/devices'); }
      catch (e) { box.innerHTML = ''; box.append(el('div', { class: 'hint' }, e.message)); return; }
      const k = JSON.stringify([d.pending, d.devices.map(x => [x.id, x.name, x.online, Math.round(x.seen / 60000), x.ip])]);
      if (k === key) return;
      key = k;
      box.innerHTML = '';
      (d.pending || []).forEach(p => box.append(el('div', { class: 'pick-item dev-pending' }, tic('phone', 'orange'),
        el('div', null, el('b', null, p.name), el('small', null, 'möchte sich verbinden · Code ' + p.code + ' · ' + p.ip)),
        el('div', { class: 'row' },
          el('button', { class: 'btn small primary', onclick: async () => { await answerPair(p, true); key = null; load(); } }, 'Erlauben'),
          el('button', { class: 'btn small', onclick: async () => { await answerPair(p, false); key = null; load(); } }, 'Ablehnen')))));
      if (!d.devices.length) box.append(el('div', { class: 'empty' }, 'Noch kein Gerät verbunden.'));
      d.devices.forEach(dv => {
        const rename = el('button', { class: 'icon-btn', 'aria-label': 'Umbenennen', onclick: () => {
          const inp = el('input', { class: 'in', value: dv.name, maxlength: '40', autocomplete: 'off' });
          const save = async () => {
            try { await api('/api/devices', { cmd: 'rename', id: dv.id, name: inp.value }); close(); key = null; load(); }
            catch (e) { toast(e.message, 'err'); }
          };
          inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
          const close = sheet('Gerät umbenennen', el('div', { class: 'form' }, field('Name', inp, 'z. B. „Mein Handy“ oder „Tablet Wohnzimmer“'),
            el('button', { class: 'btn primary', onclick: save }, ic('check'), 'Speichern')));
          setTimeout(() => inp.select(), 300);
        } }, ic('edit'));
        const remove = el('button', { class: 'icon-btn alert', 'aria-label': 'Entfernen', onclick: async () => {
          if (!await confirmSheet('„' + dv.name + '“ entfernen?', dv.me ? 'Dieses Gerät wird abgemeldet und muss neu verbunden werden.' : 'Das Gerät kann den PC dann nicht mehr steuern, bis es neu verbunden wird.', 'Entfernen', true)) return;
          try {
            await api('/api/devices', { cmd: 'remove', id: dv.id });
            if (dv.me) return logout('Dieses Gerät wurde getrennt.');
            toast('Gerät entfernt');
            key = null;
            load();
          } catch (e) { toast(e.message, 'err'); }
        } }, ic('trash'));
        box.append(el('div', { class: 'pick-item dev-item' + (dv.me ? ' on' : '') }, tic(devIcon(dv.name), dv.online ? 'green' : 'slate'),
          el('div', null, el('b', null, dv.name, dv.me ? el('span', { class: 'me-badge' }, 'dieses Gerät') : null),
            el('small', null, (dv.online ? 'Gerade verbunden' : 'Zuletzt ' + ago(dv.seen)) + (dv.ip ? ' · ' + dv.ip : ''))),
          el('div', { class: 'row' }, rename, remove)));
      });
    };
    load();
    const timer = setInterval(() => { if (box.isConnected) load(); else clearInterval(timer); }, 4000);
    return box;
  }

  // PC app: show "allow this device?" as soon as a phone asks.
  let pairWatch = null;
  const pairShown = {};
  function watchPairing() {
    clearInterval(pairWatch);
    pairWatch = setInterval(async () => {
      let d;
      try { d = await api('/api/devices'); } catch (e) { return; }
      const ids = (d.pending || []).map(p => p.id);
      Object.keys(pairShown).forEach(id => { if (!ids.includes(id)) { pairShown[id](); delete pairShown[id]; } });
      (d.pending || []).forEach(p => {
        if (pairShown[p.id]) return;
        const close = sheet('Gerät verbinden?', el('div', null,
          el('div', { class: 'connected-box' }, tic(devIcon(p.name), 'orange'), el('div', null, el('b', null, p.name), el('small', null, 'Adresse ' + p.ip))),
          el('div', { class: 'hint', style: 'margin-top:16px' }, 'Steht auf dem Gerät derselbe Code?'),
          el('div', { class: 'ask-code' }, p.code),
          el('div', { class: 'sheet-actions' },
            el('button', { class: 'btn', onclick: () => { close(); answerPair(p, false); } }, 'Ablehnen'),
            el('button', { class: 'btn primary', onclick: () => { close(); answerPair(p, true); } }, ic('check'), 'Erlauben'))),
          { onClose: () => { pairShown[p.id] = () => { }; } });
        pairShown[p.id] = close;
      });
    }, 2000);
  }

  function menuRow(icon, color, title, sub, onclick) {
    return el('button', { class: 'pick-item menu-row', onclick }, tic(icon, color), el('div', null, el('b', null, title), el('small', null, sub)), ic('right', 'chev'));
  }

  // Phone "Mehr": a clear menu instead of a row of tabs; each entry opens its own page.
  const More = {
    title: 'Mehr',
    render(root) {
      const group = (title, rows) => [heading(title), el('div', { class: 'pick-list' }, rows)];
      root.append(
        ...group('Steuern', [
          menuRow('devices', 'cyan', 'Handy als Bildschirm', 'Als zusätzlicher Bildschirm nutzen oder einen Bildschirm spiegeln', () => push(DisplayView)),
          menuRow('mouse', 'violet', 'Maus & Tastatur', 'Touchpad, live tippen, Tastenkürzel', () => push(MouseView)),
          menuRow('monitor', 'cyan', 'Bildschirm', 'Live-Bild vom PC – ins Bild tippen = klicken', () => push(ScreenSub)),
          menuRow('window', 'cyan', 'Fenster', 'Offene Fenster wechseln, minimieren, schließen', () => push(WinSub))]),
        ...group('PC', [
          menuRow('cpu', 'green', 'System & Leistung', 'CPU, RAM, Grafikkarte, Laufwerke', () => push(SysSub)),
          menuRow('power', 'red', 'Energie', 'Sperren, Monitor aus, Herunterfahren mit Timer', () => push(PowerSub)),
          menuRow('clipboard', 'orange', 'Zwischenablage & Befehle', 'Text hin und her, Konsolenbefehle', () => push(ToolsSub))]),
        ...group('PC Remote', [
          menuRow('settings', 'slate', 'Einstellungen', 'Addons, Spotify, Deck, Vibration, Abmelden', () => push(SettingsView)),
          menuRow('puzzle', 'violet', 'Addons verwalten', 'Welche Apps Extra-Funktionen bekommen', addonManager)]));
    }
  };

  const ConnectView = {
    title: 'Handy verbinden',
    render(root) {
      const top = el('div');
      root.append(top, heading('Verbundene Geräte'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Einmal verbunden, verbinden sich diese Geräte von selbst wieder. Neue Geräte können auch ohne QR-Code „Am PC bestätigen“ wählen – dann fragt PC Remote hier nach.'),
        devicesPanel());
      renderConnect(top);
    }
  };

  // ---------- phone as monitor ----------

  // fps/br/w = H.264 video; q + fps (max 20) also drive the picture stream fallback
  const DQ = {
    smooth: { fps: 60, br: 8000000, w: 1920, q: 50, label: 'Flüssig (60 fps)' },
    mid: { fps: 30, br: 6000000, w: 1920, q: 62, label: 'Ausgewogen' },
    sharp: { fps: 30, br: 14000000, w: 2560, q: 80, label: 'Scharf' }
  };

  // One open line to the PC for touch/mouse input: every move arrives at once and in order.
  const Live = {
    ws: null, ok: false, users: 0, retry: null,
    use() {
      this.users++;
      this.open();
      let done = false;
      return () => { if (done) return; done = true; if (--this.users <= 0) this.shut(); };
    },
    open() {
      if (this.ws || !S.pin || typeof WebSocket === 'undefined') return;
      try {
        const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/ws?' + authQ());
        this.ws = ws;
        ws.onopen = () => { this.ok = true; };
        ws.onclose = () => {
          this.ok = false;
          this.ws = null;
          if (this.users > 0) this.retry = setTimeout(() => this.open(), 1500);
        };
      } catch (e) { this.ws = null; }
    },
    shut() {
      this.users = 0;
      clearTimeout(this.retry);
      if (this.ws) try { this.ws.close(); } catch (e) { }
      this.ws = null;
      this.ok = false;
    },
    // false = not connected, caller falls back to a normal request
    send(a) {
      if (!this.ok || !this.ws || this.ws.readyState !== 1) return false;
      if ((a.t === 'pointer' && a.op === 'move' || a.t === 'mouse' && !a.click && !a.down && !a.up) && this.ws.bufferedAmount > 64 * 1024) return true; // WLAN is busy: skip a move
      this.ws.send(JSON.stringify(a));
      return true;
    }
  };

  let jmuxerLoad = null;
  function loadJmuxer() {
    if (window.JMuxer) return Promise.resolve();
    if (!jmuxerLoad) jmuxerLoad = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = '/vendor/jmuxer.min.js';
      s.onload = () => window.JMuxer ? res() : rej(new Error('jmuxer'));
      s.onerror = () => { jmuxerLoad = null; rej(new Error('jmuxer')); };
      document.head.append(s);
    });
    return jmuxerLoad;
  }
  const canVideo = () => !!(window.MediaSource && window.ReadableStream && MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E"')) && LS.get('dvVideo', true);
  const DSIZES = [['big', 'Große Schrift'], ['mid', 'Normal'], ['sharp', 'Viel Platz']];
  const SIDES = [['left', '← Links'], ['right', 'Rechts →'], ['above', '↑ Oben'], ['below', '↓ Unten']];
  const SIDE_NAMES = { left: 'links neben', right: 'rechts neben', above: 'über', below: 'unter' };
  const alignOpts = side => side === 'left' || side === 'right'
    ? [['start', 'Oben bündig'], ['center', 'Mittig'], ['end', 'Unten bündig']]
    : [['start', 'Links bündig'], ['center', 'Mittig'], ['end', 'Rechts bündig']];

  // Desktop size for the extra monitor, shaped like this phone held sideways.
  function phoneSize(size) {
    const a = Math.max(screen.width, screen.height) / Math.min(screen.width, screen.height) || 16 / 9;
    const h = { big: 576, mid: 720, sharp: 1080 }[size] || 720;
    return [Math.round(h * Math.min(Math.max(a, 1.3), 2.4) / 8) * 8, h];
  }

  // Where and how the extra monitor appears; remembered on this phone.
  function dispLayout() {
    return Object.assign({ size: LS.get('dispSize', 'mid'), portrait: false, of: 1, side: 'below', align: 'center' }, LS.get('dispLayout', {}));
  }
  function saveDispLayout(patch) { LS.set('dispLayout', Object.assign(dispLayout(), patch)); }
  function layoutParams(st) {
    const L = dispLayout();
    const [w, h] = phoneSize(L.size);
    const real = ((st && st.monitors) || []).filter(m => !m.virtual);
    const target = real[L.of - 1] || real[0];
    return { w, h, portrait: !!L.portrait, of: target ? target.dev : null, side: L.side, align: L.align };
  }

  // Same rule as the PC uses: touching the chosen monitor on that side, aligned start/center/end.
  function spotRect(t, w, h, side, align) {
    const vert = side === 'left' || side === 'right';
    const along = (start, len) => align === 'center' ? start + Math.trunc((len - (vert ? h : w)) / 2) : align === 'end' ? start + len - (vert ? h : w) : start;
    if (side === 'left') return { x: t.x - w, y: along(t.y, t.h), w, h };
    if (side === 'right') return { x: t.x + t.w, y: along(t.y, t.h), w, h };
    if (side === 'above') return { x: along(t.x, t.w), y: t.y - h, w, h };
    return { x: along(t.x, t.w), y: t.y + t.h, w, h };
  }
  const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

  async function startExtend() {
    const st = await api('/api/display').catch(() => null);
    if (!st) return;
    if (!st.installed) { toast('Einmal einrichten, dann klappt es per Knopf', 'err'); return openDisplayPage(); }
    if (st.active.length) return openViewer(st.active[0], { virtual: true, portrait: dispLayout().portrait });
    toast('Bildschirm wird angelegt …');
    const r = await act(Object.assign({ t: 'display', cmd: 'add' }, layoutParams(st)), { quiet: 1 });
    if (r && r.warn) toast(r.warn, 'err');
    if (r && r.dev) openViewer(r.dev, { virtual: true, portrait: dispLayout().portrait });
  }

  async function applyArrange(st) {
    if (!st || !st.active || !st.active.length) return;
    const r = await act(Object.assign({ t: 'display', cmd: 'arrange' }, layoutParams(st)), { quiet: 1 });
    if (r) toast('Bildschirm neu angeordnet');
  }

  // Mini version of the Windows display settings: your monitors + where the phone screen goes. Drag the phone to move it.
  function arrangeMap(st, onPick) {
    const real = st.monitors.filter(m => !m.virtual);
    const ours = st.monitors.find(m => st.active.includes(m.dev));
    const L = dispLayout(), p = layoutParams(st);
    const pw = ours ? ours.w : (p.portrait ? p.h : p.w), ph = ours ? ours.h : (p.portrait ? p.w : p.h);
    const target = real[L.of - 1] || real[0];
    if (!target) return el('div', { class: 'hint' }, 'Keine Bildschirme gefunden.');
    const cur = ours ? { x: ours.x, y: ours.y, w: ours.w, h: ours.h } : spotRect(target, pw, ph, L.side, L.align);
    const rects = real.map(m => ({ x: m.x, y: m.y, w: m.w, h: m.h })).concat([cur]);
    const pad = Math.max(...rects.map(r => Math.max(r.w, r.h))) * 0.12;
    const minX = Math.min(...rects.map(r => r.x)) - pad, minY = Math.min(...rects.map(r => r.y)) - pad;
    const BW = Math.max(...rects.map(r => r.x + r.w)) + pad - minX, BH = Math.max(...rects.map(r => r.y + r.h)) + pad - minY;
    const pos = (r, n) => { n.style.left = (r.x - minX) / BW * 100 + '%'; n.style.top = (r.y - minY) / BH * 100 + '%'; n.style.width = r.w / BW * 100 + '%'; n.style.height = r.h / BH * 100 + '%'; return n; };
    const map = el('div', { class: 'arr-map', style: 'aspect-ratio:' + BW.toFixed(0) + '/' + BH.toFixed(0) });
    real.forEach(m => map.append(pos(m, el('div', { class: 'arr-mon' + (m === target ? ' target' : '') }, el('b', null, m.nr), el('small', null, m.w + '×' + m.h + (m.primary ? ' · Haupt' : ''))))));
    const bad = !ours && real.some(m => m !== target && overlap(m, cur));
    const phone = pos(cur, el('div', { class: 'arr-phone' + (bad ? ' bad' : '') + (ours ? ' live' : '') }, ic('devices'), el('b', null, 'Handy'), el('small', null, pw + '×' + ph)));
    map.append(phone);

    // drag & snap to the nearest free spot
    let drag = null;
    phone.addEventListener('pointerdown', e => {
      e.preventDefault();
      try { phone.setPointerCapture(e.pointerId); } catch (x) { }
      drag = { cx: e.clientX, cy: e.clientY, l: phone.offsetLeft, t: phone.offsetTop };
      phone.classList.add('dragging');
    });
    phone.addEventListener('pointermove', e => {
      if (!drag) return;
      phone.style.left = drag.l + e.clientX - drag.cx + 'px';
      phone.style.top = drag.t + e.clientY - drag.cy + 'px';
    });
    const drop = e => {
      if (!drag) return;
      const moved = Math.hypot(e.clientX - drag.cx, e.clientY - drag.cy);
      drag = null;
      phone.classList.remove('dragging');
      if (moved < 6) return onPick(null);
      const mr = map.getBoundingClientRect();
      const cx = minX + (phone.offsetLeft + phone.offsetWidth / 2) / mr.width * BW, cy = minY + (phone.offsetTop + phone.offsetHeight / 2) / mr.height * BH;
      let best = null;
      real.forEach((m, i) => SIDES.forEach(([side]) => ['start', 'center', 'end'].forEach(align => {
        const r = spotRect(m, pw, ph, side, align);
        if (real.some(o => o !== m && overlap(o, r))) return;
        const d = Math.hypot(r.x + r.w / 2 - cx, r.y + r.h / 2 - cy);
        if (!best || d < best.d) best = { d, of: i + 1, side, align };
      })));
      onPick(best ? { of: best.of, side: best.side, align: best.align } : null);
    };
    phone.addEventListener('pointerup', drop);
    phone.addEventListener('pointercancel', drop);
    return el('div', null, map, bad ? el('p', { class: 'hint warn-text' }, 'Dort ist schon ein Bildschirm – wähle eine andere Seite oder zieh das Handy woanders hin.') : null);
  }

  async function quickDisplay(mode) {
    if (PC) return show('display');
    if (mode === 'extend') return startExtend();
    const st = await api('/api/display').catch(() => null);
    if (!st) return;
    const nr = +String(mode).slice(-1);
    const m = st.monitors.filter(x => !x.virtual)[nr - 1] || st.monitors[0];
    if (m) openViewer(m.dev, {});
  }

  function openDisplayPage() {
    if (PC) return show('display');
    if (current !== DisplayView) { show('more'); push(DisplayView); }
  }

  const DisplayView = {
    title: 'Handy als Bildschirm',
    poll: () => ({ path: '/api/display', ms: 2000 }),
    render(root) {
      this.key = null;
      this.box = el('div', null, el('div', { class: 'empty' }, 'Lade …'));
      root.append(this.box);
    },
    update(d) {
      this.st = d;
      const key = JSON.stringify([d.installed, d.installing, d.installMsg, d.active, d.custom, d.monitors.map(m => [m.dev, m.x, m.y, m.w, m.h])]);
      if (key === this.key) return;
      this.key = key;
      this.draw(d);
    },
    change(patch) {
      saveDispLayout(patch);
      this.draw(this.st);
      applyArrange(this.st);
    },
    // The driver only offers some sizes; offer to add ones shaped exactly like this phone.
    modesHint(d) {
      if (PC) return null;
      const [w, h] = phoneSize('sharp'), a = w / h;
      const fits = (d.custom || []).some(m => Math.abs(Math.max(m.w, m.h) / Math.min(m.w, m.h) - a) < 0.06);
      if (fits) return null;
      return el('div', { class: 'modes-hint' },
        el('p', { class: 'hint', style: 'margin:0' }, 'Die Auflösungen des Treibers passen noch nicht genau zu deinem Handy (' + (Math.round(a * 9 * 10) / 10) + ':9) – deshalb gibt es schwarze Ränder. Einmal einrichten, dann füllt das Bild den ganzen Handy-Bildschirm.'),
        el('button', { class: 'btn small', onclick: async () => {
          if (!await confirmSheet('Handy-Auflösungen einrichten?', 'Am PC fragt Windows einmal nach Erlaubnis. Ein aktiver Handy-Bildschirm wird dabei kurz entfernt.', 'Einrichten')) return;
          const r = await act({ t: 'display', cmd: 'modes', w, h });
          if (r) { this.key = null; pollSoon(); }
        } }, ic('settings'), 'Auflösungen fürs Handy einrichten'));
    },
    draw(d) {
      const box = this.box;
      box.innerHTML = '';
      const real = d.monitors.filter(m => !m.virtual);
      const ours = d.monitors.find(m => d.active.includes(m.dev));
      const nr = real.length + 1;
      const L = dispLayout();
      const target = real[L.of - 1] || real[0];

      // 1) extra monitor
      const card = el('div', { class: 'card disp-card' });
      card.append(el('div', { class: 'row' }, tic('devices', 'cyan'),
        el('div', { class: 'grow' }, el('b', null, 'Als ' + nr + '. Bildschirm'), el('small', null, ours
          ? 'Aktiv · ' + ours.w + ' × ' + ours.h + ' · ' + (SIDE_NAMES[L.side] || '') + ' Bildschirm ' + (target ? target.nr : 1)
          : 'Das Handy wird ein echter zusätzlicher Monitor – Fenster einfach rüberziehen.'))));
      if (d.installing) {
        card.append(el('div', { class: 'disp-wait' }, el('span', { class: 'spinner' }), d.installMsg || 'Wird eingerichtet …'));
      } else if (!d.installed) {
        const [w, h] = PC ? [2400, 1080] : phoneSize('sharp');
        card.append(...[
          el('ol', { class: 'steps small' },
            el('li', null, el('span', null, 'Einmalig wird der kostenlose Bildschirm-Treiber von Parsec installiert (signiert, ca. 0,5 MB). Ohne ihn kennt Windows keinen weiteren Bildschirm.')),
            el('li', null, el('span', null, 'Am PC fragt Windows einmal nach Erlaubnis – mit „Ja“ bestätigen.')),
            el('li', null, el('span', null, 'Danach reicht ein Knopf: Bildschirm an, Bildschirm aus.'))),
          d.installMsg ? el('p', { class: 'hint' }, d.installMsg) : null,
          el('button', { class: 'btn primary block', onclick: async () => {
            const r = await act({ t: 'display', cmd: 'install', w, h });
            if (r) { this.key = null; pollSoon(); }
          } }, ic('download'), 'Einmalig einrichten')].filter(Boolean));
      } else if (d.active.length) {
        card.append(el('div', { class: 'disp-on' }, el('i', { class: 'dot' }), 'Bildschirm ' + d.monitors.length + ' ist aktiv'),
          el('div', { class: 'row wrap' },
            PC ? el('p', { class: 'hint grow' }, 'Öffne ihn am Handy unter Mehr → Handy als Bildschirm.') :
              el('button', { class: 'btn primary grow', onclick: () => openViewer(d.active[0], { virtual: true, portrait: L.portrait }) }, ic('fullscreen'), 'Anzeigen'),
            el('button', { class: 'btn danger', onclick: () => act({ t: 'display', cmd: 'remove' }) }, ic('x'), 'Entfernen')));
      } else {
        card.append(PC ? el('p', { class: 'hint' }, 'Starte es am Handy: Mehr → Handy als Bildschirm (oder per Deck-Knopf).') :
          el('button', { class: 'btn primary block', onclick: startExtend }, ic('devices'), 'Jetzt als ' + nr + '. Bildschirm starten'));
      }
      box.append(card);

      if (d.installed && real.length) {
        // 2) arrangement: map + side / alignment, applied live while the screen is on
        const sideRow = segTabs(SIDES, L.side, k => this.change({ side: k }));
        box.append(heading('Anordnung', el('small', { class: 'hint' }, ours ? 'wird sofort übernommen' : 'gilt beim Start')),
          el('div', { class: 'card form' },
            arrangeMap(d, pick => pick ? this.change(pick) : null),
            real.length > 1 ? field('Neben welchem Bildschirm?', segTabs(real.map(m => [String(m.nr), 'Bildschirm ' + m.nr + (m.primary ? ' (Haupt)' : '')]), String(L.of), k => this.change({ of: +k }))) : null,
            field('Seite', sideRow),
            field('Ausrichtung', segTabs(alignOpts(L.side), L.align, k => this.change({ align: k }))),
            el('p', { class: 'hint', style: 'margin:0' }, 'Tipp: Das Handy-Feld in der Karte kannst du auch einfach an die gewünschte Stelle ziehen. Die Maus wechselt dann genau an dieser Kante auf das Handy.')),
          heading('Größe & Format'),
          el('div', { class: 'card form' },
            field('Größe', segTabs(DSIZES, L.size, k => { LS.set('dispSize', k); this.change({ size: k }); }), '„Große Schrift“ ist am Handy am besten lesbar, „Viel Platz“ zeigt mehr auf einmal.'),
            field('Format', segTabs([['land', 'Quer'], ['port', 'Hochkant']], L.portrait ? 'port' : 'land', k => this.change({ portrait: k === 'port' })), 'Hochkant = Handy aufrecht halten – praktisch für Discord, Chats oder Spotify.'),
            this.modesHint(d)));
      }

      // 3) mirror an existing monitor
      box.append(heading('Bildschirm spiegeln'),
        el('p', { class: 'hint', style: 'margin:-4px 2px 10px' }, 'Zeigt einen vorhandenen Bildschirm auf dem Handy – ohne Treiber. Tippen klickt dort.'),
        el('div', { class: 'pick-list' }, real.map(m => el('button', { class: 'pick-item', disabled: PC ? true : null, onclick: () => openViewer(m.dev, {}) },
          tic('monitor', m.primary ? 'violet' : 'slate'), el('div', null, el('b', null, 'Bildschirm ' + m.nr + (m.primary ? ' (Hauptbildschirm)' : '')), el('small', null, m.w + ' × ' + m.h + ' · ' + m.hz + ' Hz')),
          PC ? null : ic('right', 'chev')))));

      // 3) picture settings
      box.append(heading('Bild'),
        el('div', { class: 'card form' },
          field('Übertragung', segTabs(Object.keys(DQ).map(k => [k, DQ[k].label]), LS.get('dispQ', 'smooth'), k => LS.set('dispQ', k)), 'Das Bild kommt als Video (H.264) – „Flüssig“ mit 60 Bildern pro Sekunde, „Scharf“ mit mehr Details für Text. Am besten im 5-GHz-WLAN.'),
          el('label', { class: 'check' }, el('span', null, 'Video verwenden', el('small', { class: 'hint', style: 'display:block' }, 'Nur ausschalten, wenn das Bild am Handy schwarz bleibt – dann kommen Einzelbilder.')),
            sw(LS.get('dvVideo', true), v => LS.set('dvVideo', v))),
          el('p', { class: 'hint', style: 'margin:0' }, 'Bedienung: Tippen = Klick · Ziehen = Maus gedrückt halten (Fenster verschieben) · lange drücken = Rechtsklick · 2 Finger = scrollen · 2 Finger auseinander = zoomen. Oben rechts: Touchpad-Modus für genaues Zielen. Tipp: Bildschirm-Timeout am Handy hochsetzen, sonst endet die Übertragung, wenn das Handy ausgeht.')));
    }
  };

  let viewer = null, skipPop = false;

  function openViewer(dev, opts) {
    if (viewer) viewer.close(true);
    opts = opts || {};
    const q = DQ[LS.get('dispQ', 'smooth')] || DQ.smooth;
    const maxW = Math.min(2560, Math.round(Math.max(screen.width, screen.height) * (window.devicePixelRatio || 1)));
    const img = el('img', { class: 'dv-img', alt: '', draggable: 'false' });
    const video = el('video', { class: 'dv-img', playsinline: true, autoplay: true, muted: true, disablepictureinpicture: true });
    video.muted = true;
    let media = canVideo() ? video : img; // H.264 video when the phone can play it, otherwise single pictures
    const waitText = el('span', null, 'Verbinde …');
    const wait = el('div', { class: 'dv-wait' }, el('span', { class: 'spinner' }), waitText);
    const stage = el('div', { class: 'dv-stage' }, media, wait);
    const releaseLive = Live.use();
    const kb = el('input', { class: 'dv-kb', autocomplete: 'off', autocorrect: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'send' });
    let mode = LS.get('dvMode', 'direct'), rightNext = false, zoom = 1, tx = 0, ty = 0;
    const btnMode = el('button', { 'aria-label': 'Touchpad-Modus', onclick: () => {
      mode = mode === 'direct' ? 'pad' : 'direct';
      LS.set('dvMode', mode);
      paintBar();
      toast(mode === 'pad' ? 'Touchpad: wischen bewegt die Maus, tippen klickt, lange drücken zieht' : 'Direkt: tippen klickt genau dort');
    } }, ic('mouse'));
    const btnRight = el('button', { 'aria-label': 'Nächster Tipp = Rechtsklick', onclick: () => { rightNext = !rightNext; paintBar(); } }, el('span', { class: 'dv-r' }, 'R'));
    const btnZoom = el('button', { 'aria-label': 'Zoom zurücksetzen', onclick: () => setZoom(1, 0, 0) }, ic('zoomout'));
    const bar = el('div', { class: 'dv-bar' }, btnMode, btnRight,
      el('button', { 'aria-label': 'Tastatur', onclick: () => { kb.focus(); } }, ic('keyboard')),
      btnZoom,
      el('button', { 'aria-label': 'Vollbild', onclick: () => fullscreen(true) }, ic('fullscreen')),
      el('button', { 'aria-label': 'Schließen', onclick: () => closeAsk() }, ic('x')));
    const paintBar = () => {
      btnMode.classList.toggle('on', mode === 'pad');
      btnRight.classList.toggle('on', rightNext);
      btnZoom.style.display = zoom > 1.01 ? '' : 'none';
    };
    // the toolbar fades out so it does not cover the picture
    let dimT = null;
    const wake = () => { bar.classList.remove('dim'); clearTimeout(dimT); dimT = setTimeout(() => bar.classList.add('dim'), 3500); };
    bar.addEventListener('pointerdown', wake);
    const node = el('div', { class: 'dv' }, stage, bar, kb);
    document.body.append(node);
    document.body.classList.add('dv-open');

    let retry = null, frames = false, jm = null, abort = null, everVideo = false, started = 0;
    const frameMs = Math.round(1000 / q.fps);
    const lost = () => {
      if (!viewer) return;
      frames = false;
      wait.style.display = '';
      waitText.textContent = 'Verbindung unterbrochen – verbinde neu …';
      clearTimeout(retry);
      retry = setTimeout(connect, 1200);
    };

    // picture stream (fallback)
    const imgSrc = () => '/api/stream?' + authQ() + '&dev=' + enc(dev) + '&w=' + Math.min(maxW, 1600) + '&q=' + q.q + '&fps=' + Math.min(20, q.fps) + '&t=' + Date.now();
    img.onerror = lost;

    // H.264 video: [4 bytes length][2 bytes duration ms][frame] … fed into the phone's video player
    function stopVideo() {
      if (abort) { try { abort.abort(); } catch (e) { } abort = null; }
      if (jm) { try { jm.destroy(); } catch (e) { } jm = null; }
    }
    async function startVideo() {
      stopVideo();
      await loadJmuxer();
      jm = new window.JMuxer({ node: video, mode: 'video', flushingTime: 0, fps: q.fps, debug: false, onError: () => { } });
      const ctl = abort = new AbortController();
      const res = await fetch('/api/video?' + authQ() + '&dev=' + enc(dev) + '&w=' + Math.min(maxW, q.w) + '&fps=' + q.fps + '&br=' + q.br + '&t=' + Date.now(), { signal: ctl.signal, cache: 'no-store' });
      if (!res.ok || !res.body) throw new Error('stream');
      const reader = res.body.getReader();
      let buf = new Uint8Array(0);
      (async () => {
        try {
          while (true) {
            const { value, done } = await reader.read();
            if (done || ctl.signal.aborted) break;
            const nb = new Uint8Array(buf.length + value.length);
            nb.set(buf); nb.set(value, buf.length);
            buf = nb;
            let off = 0;
            while (buf.length - off >= 6) {
              const len = ((buf[off] << 24) >>> 0) + (buf[off + 1] << 16) + (buf[off + 2] << 8) + buf[off + 3];
              if (buf.length - off - 6 < len) break;
              // A short access-unit delimiter after every frame: jMuxer holds back the last NAL unit of each chunk,
              // so without it the last slice of a frame would only arrive with the next one (broken picture).
              const fr = new Uint8Array(len + 6);
              fr.set(buf.subarray(off + 6, off + 6 + len));
              fr.set([0, 0, 0, 1, 9, 240], len);
              // fixed frame time: on a still screen the player simply waits for the next frame instead of lagging behind later
              if (jm) jm.feed({ video: fr, duration: frameMs });
              off += 6 + len;
            }
            if (off) buf = buf.slice(off);
          }
        } catch (e) { }
        if (abort === ctl) lost();
      })();
    }

    function connect() {
      clearTimeout(retry);
      started = Date.now();
      if (media === video) startVideo().catch(() => { if (!everVideo) useImages('Video ging nicht – zeige Einzelbilder'); else lost(); });
      else img.src = imgSrc();
    }
    function useImages(why) {
      stopVideo();
      media = img;
      video.replaceWith(img);
      img.style.transform = video.style.transform;
      if (why) toast(why, 'err');
      connect();
    }
    connect();

    const shown = setInterval(() => {
      const ready = media === video ? video.readyState >= 2 && video.videoWidth > 0 : img.naturalWidth > 0;
      if (ready) {
        if (!frames) { wait.style.display = 'none'; frames = true; if (media === video) everVideo = true; }
      } else if (media === video && !everVideo && Date.now() - started > 7000) useImages('Video startet nicht – zeige Einzelbilder');
      if (media === video && video.buffered.length) {
        // live, not "smooth but late": jump to the newest picture when the player falls behind
        const end = video.buffered.end(video.buffered.length - 1);
        if (end - video.currentTime > 0.25) video.currentTime = Math.max(0, end - 0.03);
        if (video.paused) video.play().catch(() => { });
      }
    }, 200);
    // the extra screen can also be removed elsewhere (timeout, PC, other phone)
    const alive = setInterval(async () => {
      const st = await api('/api/display').catch(() => null);
      if (!st || !viewer) return;
      if (!st.monitors.some(m => m.dev === dev)) { wait.style.display = ''; waitText.textContent = 'Dieser Bildschirm ist nicht mehr da – schließe die Ansicht und starte ihn neu.'; }
    }, 4000);
    history.pushState({ viewer: 1 }, '');

    function setZoom(z, x, y) {
      const r = stage.getBoundingClientRect();
      zoom = Math.max(1, Math.min(5, z));
      tx = zoom === 1 ? 0 : Math.min(0, Math.max(r.width - r.width * zoom, x));
      ty = zoom === 1 ? 0 : Math.min(0, Math.max(r.height - r.height * zoom, y));
      media.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + zoom + ')';
      paintBar();
    }

    function fullscreen(on) {
      try {
        if (on && !document.fullscreenElement && node.requestFullscreen) node.requestFullscreen().then(() => {
          if (screen.orientation && screen.orientation.lock) screen.orientation.lock(opts.portrait ? 'portrait' : 'landscape').catch(() => { });
        }).catch(() => { });
        if (!on && document.fullscreenElement) document.exitFullscreen().catch(() => { });
      } catch (e) { }
    }
    fullscreen(true);
    wake();
    paintBar();

    // ---- touch → mouse on that monitor ----
    // One ordered queue; moves are merged and sent once per screen refresh over the open line
    // (or, without it, one web request at a time).
    const P = { busy: false, pos: null, dx: 0, dy: 0, q: [], raf: 0 };
    const pump = () => {
      P.raf = 0;
      if (!Live.ok) return flushP();
      while (P.q.length) if (!Live.send(P.q[0])) return flushP(); else P.q.shift();
      if (P.pos) { Live.send({ t: 'pointer', dev, op: 'move', x: P.pos.x, y: P.pos.y }); P.pos = null; }
      const dx = Math.trunc(P.dx), dy = Math.trunc(P.dy);
      if (dx || dy) { P.dx -= dx; P.dy -= dy; Live.send({ t: 'mouse', dx, dy }); }
    };
    const schedule = () => { if (!P.raf) P.raf = requestAnimationFrame(pump); };
    const flushP = () => {
      if (P.busy) return;
      let a = P.q.shift();
      if (!a && P.pos) { a = { t: 'pointer', dev, op: 'move', x: P.pos.x, y: P.pos.y }; P.pos = null; }
      if (!a && (Math.trunc(P.dx) || Math.trunc(P.dy))) {
        const dx = Math.trunc(P.dx), dy = Math.trunc(P.dy);
        P.dx -= dx; P.dy -= dy;
        a = { t: 'mouse', dx, dy };
      }
      if (!a) return;
      P.busy = true;
      api('/api/action', a).catch(() => { }).then(() => { P.busy = false; flushP(); });
    };
    const send = a => { P.pos = null; P.q.push(a); schedule(); };
    const ptr = (op, pos) => send(Object.assign({ t: 'pointer', dev, op }, pos || {}));
    const rel = p => {
      const r = media.getBoundingClientRect();
      const nw = media === video ? video.videoWidth || 16 : img.naturalWidth || 16, nh = media === video ? video.videoHeight || 9 : img.naturalHeight || 9;
      const sc = Math.min(r.width / nw, r.height / nh), dw = nw * sc, dh = nh * sc;
      return { x: (p.clientX - r.left - (r.width - dw) / 2) / dw, y: (p.clientY - r.top - (r.height - dh) / 2) / dh };
    };
    const click = (right, pos) => {
      buzz();
      if (mode === 'pad') send({ t: 'mouse', click: right ? 'right' : 'left' });
      else ptr(right ? 'right' : 'click', pos);
      if (rightNext) { rightNext = false; paintBar(); }
    };
    const pts = new Map();
    let start = null, dragging = false, consumed = false, longT = null, two = null;
    const mid = () => {
      const v = [...pts.values()];
      return { x: (v[0].x + v[1].x) / 2, y: (v[0].y + v[1].y) / 2, d: Math.hypot(v[0].x - v[1].x, v[0].y - v[1].y) || 1 };
    };
    stage.addEventListener('pointerdown', e => {
      e.preventDefault();
      wake();
      if (!frames) { connect(); return; }
      try { stage.setPointerCapture(e.pointerId); } catch (x) { }
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 1) {
        start = { cx: e.clientX, cy: e.clientY, lx: e.clientX, ly: e.clientY, pos: rel(e), moved: false };
        dragging = false; consumed = false; two = null;
        clearTimeout(longT);
        longT = setTimeout(() => {
          if (!start || start.moved || two) return;
          consumed = true;
          buzz(25);
          if (mode === 'pad') { dragging = true; send({ t: 'mouse', down: 'left' }); } // hold = grab, then move
          else ptr('right', start.pos);
        }, 550);
      } else if (pts.size === 2) {
        clearTimeout(longT);
        consumed = true;
        if (dragging) { mode === 'pad' ? send({ t: 'mouse', up: 'left' }) : ptr('up', start && start.pos); dragging = false; }
        const m = mid();
        two = { d0: m.d, m0: m, z0: zoom, tx0: tx, ty0: ty, kind: null, lx: m.x, ly: m.y, t: performance.now() };
      }
    });
    stage.addEventListener('pointermove', e => {
      const p = pts.get(e.pointerId);
      if (!p) return;
      p.x = e.clientX; p.y = e.clientY;
      if (two && pts.size >= 2) {
        const m = mid(), r = stage.getBoundingClientRect();
        if (!two.kind) {
          if (Math.abs(m.d / two.d0 - 1) > 0.12) two.kind = 'zoom';
          else if (Math.hypot(m.x - two.m0.x, m.y - two.m0.y) > 12) two.kind = zoom > 1.01 ? 'pan' : 'scroll';
        }
        if (two.kind === 'zoom') {
          // keep the spot between the fingers where it is while zooming
          const z = Math.max(1, Math.min(5, two.z0 * m.d / two.d0));
          const px = (two.m0.x - r.left - two.tx0) / two.z0, py = (two.m0.y - r.top - two.ty0) / two.z0;
          setZoom(z, m.x - r.left - px * z, m.y - r.top - py * z);
        } else if (two.kind === 'pan') {
          setZoom(zoom, two.tx0 + m.x - two.m0.x, two.ty0 + m.y - two.m0.y);
        } else if (two.kind === 'scroll') {
          const dy = m.y - two.ly, dx = m.x - two.lx;
          if (Math.abs(dy) < 6 && Math.abs(dx) < 6) return;
          ptr('scroll', { sy: Math.round(dy * 5), sx: Math.round(-dx * 5) });
        }
        two.lx = m.x; two.ly = m.y;
        return;
      }
      if (!start) return;
      if (!start.moved && Math.hypot(e.clientX - start.cx, e.clientY - start.cy) > 10) {
        start.moved = true;
        if (!consumed) clearTimeout(longT);
      }
      if (mode === 'pad') {
        const dx = e.clientX - start.lx, dy = e.clientY - start.ly;
        start.lx = e.clientX; start.ly = e.clientY;
        if (!start.moved && !dragging) return;
        const acc = 1 + Math.min(2, Math.hypot(dx, dy) / 12);
        P.dx += dx * 1.6 * acc / zoom;
        P.dy += dy * 1.6 * acc / zoom;
        schedule();
        return;
      }
      if (consumed) return;
      if (!dragging && start.moved) { dragging = true; ptr('down', start.pos); }
      if (dragging) { P.pos = rel(e); schedule(); }
    });
    const up = e => {
      if (!pts.has(e.pointerId)) return;
      pts.delete(e.pointerId);
      if (two) {
        // quick two-finger tap = right click
        if (!pts.size) {
          if (!two.kind && performance.now() - two.t < 320) click(true, rel({ clientX: two.m0.x, clientY: two.m0.y }));
          two = null;
          start = null;
        }
        return;
      }
      if (pts.size) return;
      clearTimeout(longT);
      if (dragging) mode === 'pad' ? send({ t: 'mouse', up: 'left' }) : ptr('up', rel(e));
      else if (!consumed && start && !start.moved) click(rightNext, start.pos);
      start = null;
      dragging = false;
    };
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
    stage.addEventListener('contextmenu', e => e.preventDefault());

    // ---- keyboard: typed text goes straight to the PC ----
    let last = '';
    kb.addEventListener('input', () => {
      const v = kb.value;
      let i = 0;
      while (i < last.length && i < v.length && last[i] === v[i]) i++;
      for (let k = 0; k < last.length - i; k++) act({ t: 'key', keys: 'backspace' }, { quiet: 1 });
      if (v.slice(i)) act({ t: 'text', text: v.slice(i) }, { quiet: 1 });
      last = v;
      if (v.length > 60) { kb.value = ''; last = ''; }
    });
    kb.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); act({ t: 'key', keys: 'enter' }, { quiet: 1 }); kb.value = ''; last = ''; } });

    async function closeAsk() {
      if (!opts.virtual) return close(false);
      const choice = await new Promise(res => {
        const c = sheet('Ansicht schließen', pickList([
          { icon: tic('x', 'red'), title: 'Bildschirm entfernen', sub: 'Fenster darauf wandern zurück auf deine anderen Bildschirme', onclick: () => { c(); res('remove'); } },
          { icon: tic('monitor', 'slate'), title: 'Nur Ansicht schließen', sub: 'Der Bildschirm bleibt noch 90 Sekunden bestehen', onclick: () => { c(); res('keep'); } }
        ]), { onClose: () => res(null) });
      });
      if (choice === 'remove') { close(false); act({ t: 'display', cmd: 'remove' }); }
      else if (choice === 'keep') close(false);
    }

    function close(fromHistory) {
      if (!viewer) return;
      viewer = null;
      clearInterval(shown);
      clearInterval(alive);
      clearTimeout(retry);
      clearTimeout(dimT);
      if (P.raf) cancelAnimationFrame(P.raf);
      stopVideo();
      releaseLive();
      img.onerror = null;
      img.src = '';
      fullscreen(false);
      try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) { }
      node.remove();
      document.body.classList.remove('dv-open');
      if (!fromHistory) { skipPop = true; history.back(); }
      pollSoon();
    }

    viewer = { close };
  }

  // ---------- tile / button editor ----------

  function addTileSheet() {
    const make = (tile, edit) => () => {
      close();
      if (edit) editTile(Object.assign({ id: uid() }, tile), true);
      else addTile(tile);
    };
    const A = (t, extra) => ({ type: 'action', a: Object.assign({ t }, extra || {}) });
    const close = sheet('Kachel hinzufügen', el('div', null,
      heading('Ton & Medien'),
      pickList([
        { icon: tic('sliders', 'cyan'), title: 'Lautstärkeregler', sub: 'Statt Lauter/Leiser: ein Regler so groß wie 1–2 Buttons – Gesamt, Mikro, Spotify, eine App …', onclick: make({ type: 'slider', bind: 'master' }, true) },
        { icon: tic('sliders', 'violet'), title: 'Lautstärkeleiste (breit)', sub: 'Waagerechter Regler über die ganze Zeile', onclick: make({ type: 'slider', bind: 'master', wide: true }, true) },
        { icon: tic('micoff', 'red'), title: 'Stummschalter', sub: 'Mikrofon, Ton, Discord, App oder Voicemeeter – mit Live-Status', onclick: make({ type: 'toggle', bind: 'mic', w: 1 }, true) },
        { icon: tic('music', 'green'), title: 'Wiedergabe', sub: 'Aktueller Titel mit Cover und Play/Pause', onclick: make({ type: 'np' }) },
        { icon: tic('play', 'green'), title: 'Medientaste', sub: 'Play/Pause, Weiter, Zurück – auch nur für Spotify', onclick: make(A('media', { k: 'playpause' }), true) },
        { icon: tic('headphones', 'cyan'), title: 'Audiogerät wechseln', sub: 'z. B. Headset ↔ Lautsprecher', onclick: make(A('device'), true) }
      ]),
      heading('Apps & Addons'),
      pickList([
        { icon: tic('gamepad', 'violet'), title: 'App oder Spiel', sub: 'Starten oder nach vorne holen', onclick: () => { close(); appPicker(); } },
        { icon: tic('music', 'green'), title: 'Spotify-Befehl', sub: 'Liken, lauter/leiser in Spotify, Shuffle …', onclick: make(A('spotify', { cmd: 'like' }), true) },
        { icon: tic('message', 'violet'), title: 'Discord-Befehl', sub: 'Stumm, Ton aus, Auflegen, Kamera …', onclick: make(A('discord', { cmd: 'mute' }), true) },
        { icon: tic('keyboard', 'cyan'), title: 'Taste an eine App senden', sub: 'z. B. Strg+T an Chrome, F8 an ein Spiel', onclick: make(A('appkey', { keys: '' }), true) },
        { icon: tic('devices', 'cyan'), title: 'Handy als Bildschirm', sub: 'Ein Knopf: Handy wird zusätzlicher Bildschirm oder spiegelt einen', onclick: make(Object.assign(A('display', { mode: 'extend' }), { icon: 'devices', color: 'cyan' }), true) },
        { icon: tic('scissors', 'red'), title: 'Clip speichern', sub: 'Die letzten Sekunden als Video sichern', onclick: make(Object.assign(A('clipsave'), { color: 'red' })) },
        { icon: tic('puzzle', 'violet'), title: 'Aus einem Addon', sub: 'In „Apps“ jeden Button lange drücken → „Aufs Deck legen“', onclick: () => { close(); setEditing(false); show('apps'); } }
      ]),
      heading('Aktionen'),
      pickList([
        { icon: tic('keyboard', 'violet'), title: 'Tastenkürzel', sub: 'z. B. Strg + Shift + M', onclick: make(A('key', { keys: '' }), true) },
        { icon: tic('type', 'violet'), title: 'Text tippen', sub: 'Fester Text, z. B. „gg“', onclick: make(A('text', { text: '' }), true) },
        { icon: tic('globe', 'cyan'), title: 'Webseite / Link öffnen', onclick: make(A('url', { url: 'https://' }), true) },
        { icon: tic('folder', 'orange'), title: 'Programm / Datei öffnen', onclick: make(A('launch', { target: '' }), true) },
        { icon: tic('zap', 'yellow'), title: 'Makro', sub: 'Mehrere Schritte nacheinander', onclick: make(A('macro', { script: '' }), true) },
        { icon: tic('terminal', 'slate'), title: 'Konsolenbefehl', onclick: make(A('cmd', { cmd: '' }), true) },
        { icon: tic('x', 'red'), title: 'Programm beenden', onclick: make(A('kill', { procs: '' }), true) },
        { icon: tic('power', 'red'), title: 'Energie', sub: 'Sperren, Herunterfahren, Monitor aus …', onclick: make(A('power', { cmd: 'lock' }), true) },
        { icon: tic('gamepad', 'red'), title: 'Riot-Spiel starten', sub: 'VALORANT oder League of Legends', onclick: make(A('riot', { product: 'valorant' }), true) },
        { icon: tic('sliders', 'cyan'), title: 'Voicemeeter-Befehl', onclick: make(A('vm', { cmd: 'show' }), true) }
      ]),
      heading('Anzeige'),
      pickList([{ icon: tic('cpu', 'violet'), title: 'Systemwerte', sub: 'CPU, RAM und Grafikkarte', onclick: make({ type: 'stats' }) }])));
  }

  function appPicker() {
    const list = el('div', { class: 'pick-list' });
    const q = el('input', { class: 'in', type: 'search', placeholder: 'Suchen …' });
    const draw = () => {
      list.innerHTML = '';
      const s = q.value.trim().toLowerCase();
      const apps = S.apps.filter(a => !s || a.name.toLowerCase().includes(s));
      if (!apps.length) list.append(el('div', { class: 'empty' }, S.apps.length ? 'Nichts gefunden.' : 'Noch keine Apps gefunden – unter „Apps“ neu scannen.'));
      for (const a of apps) list.append(el('button', { class: 'pick-item', onclick: () => { close(); addTile({ type: 'app', app: a.id, name: a.name }); } },
        appIcon({ id: a.id }, a.name), el('div', null, el('b', null, a.name), el('small', null, ({ game: 'Spiel', app: 'App', launcher: 'Launcher' })[a.kind] || ''))));
    };
    q.addEventListener('input', draw);
    draw();
    const close = sheet('App oder Spiel wählen', el('div', null, el('div', { class: 'search', style: 'margin-bottom:12px' }, ic('search'), q), list));
  }

  function field(label, input, hint) {
    return el('div', { class: 'field' }, label ? el('span', { class: 'field-label' }, label) : null, input, hint ? el('small', { class: 'field-hint', style: 'white-space:pre-line' }, hint) : null);
  }
  function textIn(obj, key, ph, type) {
    const i = el(type === 'area' ? 'textarea' : 'input', { class: 'in', placeholder: ph || '', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
    if (type === 'number') { i.type = 'number'; i.inputMode = 'numeric'; }
    i.value = obj[key] == null ? '' : obj[key];
    i.addEventListener('input', () => { obj[key] = type === 'number' ? (+i.value || 0) : i.value; });
    return i;
  }
  function selectIn(obj, key, options, onchange) {
    const s = el('select', { class: 'in' });
    const add = (parent, [v, l]) => parent.append(el('option', { value: v }, l));
    for (const o of options) {
      if (o.group) { const g = el('optgroup', { label: o.group }); o.items.forEach(x => add(g, x)); s.append(g); }
      else add(s, o);
    }
    s.value = obj[key] == null ? '' : obj[key];
    if (s.selectedIndex < 0 && s.options.length) { s.selectedIndex = 0; obj[key] = s.value; }
    s.addEventListener('change', () => { obj[key] = s.value; if (onchange) onchange(s); });
    return s;
  }
  function segIn(obj, key, options) {
    return segTabs(options.map(([v, l]) => [String(v), l]), String(obj[key]), k => { obj[key] = isNaN(+k) ? k : +k; });
  }

  async function bindOptions(forToggle, current) {
    const opts = [['master', 'Lautsprecher (Gesamt)'], ['mic', 'Mikrofon']];
    if (!forToggle) opts.push(['spotify', 'Spotify (Lautstärke in Spotify)']);
    else opts.push({ group: 'Discord', items: [['discord:mute', 'Discord – Mikro stumm'], ['discord:deaf', 'Discord – Ton aus']] });
    let mx = null;
    try { mx = await api('/api/mixer?vm=1'); } catch (e) { }
    const seen = new Set(['master', 'mic', 'spotify', 'discord:mute', 'discord:deaf']);
    const playing = [];
    for (const s of (mx && mx.sessions) || []) {
      if (s.key === 'system') continue;
      playing.push(['app:' + s.key, s.name + ' (Windows-Lautstärke)']);
      seen.add('app:' + s.key);
    }
    if (playing.length) opts.push({ group: 'Apps, die gerade Ton abspielen', items: playing });
    const known = [];
    for (const a of S.apps) {
      const p = a.procs[0];
      if (!p || seen.has('app:' + p)) continue;
      seen.add('app:' + p);
      known.push(['app:' + p, a.name]);
    }
    if (known.length) opts.push({ group: 'Weitere Apps', items: known });
    const vm = mx && mx.vm;
    if (vm && vm.ok) {
      S.vm = vm;
      const items = [];
      for (const s of vm.strips) {
        const b = 'vm:Strip[' + s.i + ']';
        if (forToggle) {
          items.push([b + '.Mute', s.label + ' – Stumm']);
          vm.buses.forEach(x => items.push([b + '.' + x.name, s.label + ' → ' + x.name]));
        } else items.push([b + '.Gain', s.label + ' – Gain']);
      }
      for (const x of vm.buses) items.push(['vm:Bus[' + x.i + '].' + (forToggle ? 'Mute' : 'Gain'), 'Bus ' + x.name + (forToggle ? ' – Stumm' : ' – Gain')]);
      opts.push({ group: 'Voicemeeter', items });
    }
    if (current && !seen.has(current) && !(vm && vm.ok && current.startsWith('vm:'))) opts.push([current, current.replace(/^app:/, '') + ' (aktuell)']);
    return opts;
  }

  // Lauter/Leiser buttons → which volume they change (null = not a volume button)
  const volBind = a => !a ? null : a.t === 'media' && (a.k === 'volup' || a.k === 'voldown') ? 'master'
    : a.t === 'spotify' && (a.cmd === 'volup' || a.cmd === 'voldown') ? 'spotify' : null;

  // Replace a volume button (and its Lauter/Leiser partner right next to it) by one slider in the same spot.
  function volumeToSlider(id, close) {
    const loc = findTile(id);
    if (!loc) return;
    const page = loc.page, tile = page.tiles[loc.i], bind = volBind(tile.a), dir = tile.a.k || tile.a.cmd;
    remember();
    const p = tile.pos;
    const partner = page.tiles.find(o => o !== tile && o.type === 'action' && volBind(o.a) === bind && (o.a.k || o.a.cmd) !== dir &&
      o.pos.w === 1 && o.pos.h === 1 && p.w === 1 && p.h === 1 &&
      ((o.pos.y === p.y && Math.abs(o.pos.x - p.x) === 1) || (o.pos.x === p.x && Math.abs(o.pos.y - p.y) === 1)));
    let r = { x: p.x, y: p.y, w: p.w, h: p.h };
    if (partner) {
      r = partner.pos.y === p.y ? { x: Math.min(p.x, partner.pos.x), y: p.y, w: 2, h: 1 } : { x: p.x, y: Math.min(p.y, partner.pos.y), w: 1, h: 2 };
      page.tiles.splice(page.tiles.indexOf(partner), 1);
    }
    page.tiles[page.tiles.indexOf(tile)] = { id: tile.id, type: 'slider', bind, pos: r };
    saveLayout();
    close();
    if (current === Deck) Deck.draw();
    toast(partner ? 'Lauter und Leiser sind jetzt ein Regler' : 'Jetzt ein Regler – zum Einstellen hoch/runter wischen');
  }

  // target: undefined = deck tile; otherwise { title, save(t) } for addon custom buttons
  function editTile(orig, isNew, target) {
    const t = clone(orig);
    const kind = TILES[t.type];
    const custom = !!target;
    const body = el('div', { class: 'form' });
    const loc = custom ? null : findTile(t.id);
    const where = { p: String(loc ? S.layout.pages.indexOf(loc.page) : curPageIdx()) };
    const wantAt = isNew ? addAt : null; // tapped empty cell
    if (isNew) addAt = null;

    const draw = () => {
      body.innerHTML = '';
      const def = t.type === 'action' ? actLabel(t.a) : t.type === 'app' ? ((appById(t.app) || {}).name || t.name) :
        t.type === 'slider' ? bindInfo(t.bind).label : t.type === 'toggle' ? toggleInfo(t.bind).label : kind.name;

      if (t.type === 'slider' || t.type === 'toggle') {
        const holder = el('div', null, el('div', { class: 'hint' }, 'Lade Ziele …'));
        body.append(field(t.type === 'slider' ? 'Was soll der Regler steuern?' : 'Was soll geschaltet werden?', holder));
        bindOptions(t.type === 'toggle', t.bind).then(opts => { holder.innerHTML = ''; holder.append(selectIn(t, 'bind', opts, draw)); });
      }

      if (t.type === 'app') {
        body.append(field('App oder Spiel', selectIn(t, 'app', S.apps.map(a => [a.id, a.name]).concat(appById(t.app) ? [] : [[t.app, t.name || t.app]]), s => { t.name = s.options[s.selectedIndex].text; })));
        body.append(field('Beim Tippen', selectIn(t, 'op', [['smart', 'Starten – oder nach vorne holen, wenn es läuft'], ['launch', 'Immer neu starten'], ['focus', 'Nur nach vorne holen'], ['kill', 'Beenden']])));
      }

      if (t.type === 'action') {
        const types = Object.keys(ACTS).filter(k => !HIDDEN_ACTS[k]);
        if (!ACTS[t.a.t]) types.unshift(t.a.t);
        body.append(field('Was soll passieren?', selectIn(t.a, 't', types.map(k => [k, ACTS[k] ? ACTS[k].name : 'Addon-Aktion']), () => { t.a = { t: t.a.t }; delete t.icon; draw(); })));
        const d = ACTS[t.a.t];
        for (const [key, label, type, extra] of d ? d.fields : []) {
          if (type === 'select') body.append(field(label, selectIn(t.a, key, extra, draw)));
          else if (type === 'check') body.append(el('label', { class: 'check' }, label, sw(t.a[key], v => { t.a[key] = v; })));
          else if (type === 'keys') {
            const inp = textIn(t.a, key, 'z. B. ctrl+shift+m');
            const chips = el('div', { class: 'chips', style: 'margin-top:8px' }, ['ctrl', 'shift', 'alt', 'win', 'tab', 'enter', 'esc', 'space', 'f1', 'up', 'down'].map(k =>
              el('button', { class: 'chip', type: 'button', onclick: () => { inp.value = inp.value ? inp.value.replace(/\+?$/, '+') + k : k; inp.dispatchEvent(new Event('input')); } }, k)));
            body.append(field(label, el('div', null, inp, chips), 'Tasten mit + verbinden, mehrere Schritte mit Leerzeichen (z. B. „ctrl+k s“). Buchstaben, Zahlen, f1–f24, ctrl, shift, alt, win, enter, esc, tab, space, up/down/left/right, delete, home, end, printscreen …'));
          } else if (type === 'appsel') {
            const opts = S.apps.map(a => [a.id, a.name]);
            if (t.a.procs && !t.a.id) opts.unshift(['', 'Diese App (' + t.a.procs + ')']);
            body.append(field(label, selectIn(t.a, key, opts, () => { if (t.a.id) delete t.a.procs; })));
          } else if (type === 'device') {
            const holder = el('div', null, el('div', { class: 'hint' }, 'Lade Geräte …'));
            body.append(field(label, holder));
            api('/api/mixer').then(mx => {
              const opts = [];
              if (mx.outputs && mx.outputs.length) opts.push({ group: 'Ausgabe', items: mx.outputs.map(x => [x.id, x.name]) });
              if (mx.inputs && mx.inputs.length) opts.push({ group: 'Eingabe', items: mx.inputs.map(x => [x.id, x.name]) });
              holder.innerHTML = '';
              const sync = s => { t.a.devName = s.options[s.selectedIndex] ? s.options[s.selectedIndex].text : ''; };
              const s = selectIn(t.a, key, opts, sync);
              sync(s);
              holder.append(s);
            }).catch(e => { holder.textContent = e.message; });
          } else body.append(field(label, textIn(t.a, key, extra, type)));
        }
        if (d && d.hint) body.append(el('small', { class: 'field-hint', style: 'white-space:pre-line' }, d.hint));
        if (!custom && !isNew && volBind(t.a))
          body.append(el('div', { class: 'convert-box' }, tic('sliders', 'cyan'),
            el('div', { class: 'grow' }, el('b', null, 'Lieber ein Regler?'), el('small', null, 'Ersetzt diesen Button – und den passenden Lauter/Leiser-Button daneben – durch einen Lautstärkeregler.')),
            el('button', { class: 'btn small primary', type: 'button', onclick: () => volumeToSlider(t.id, close) }, 'Umwandeln')));
      }

      if (t.type !== 'np' && t.type !== 'stats')
        body.append(field('Beschriftung', textIn(t, 'label', def)));

      if (t.type === 'action') {
        const pick = el('div', { class: 'icon-pick' });
        const curIcon = t.icon || actIcon(t.a);
        for (const n of PICK_ICONS)
          pick.append(el('button', { type: 'button', class: n === curIcon ? 'on' : '', 'aria-label': n, onclick: e => { t.icon = n; [...pick.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); } }, ic(n)));
        body.append(field('Symbol', pick));
      }

      if (t.type === 'action' || t.type === 'toggle') {
        const sws = el('div', { class: 'swatches' });
        for (const c of COLORS)
          sws.append(el('button', { type: 'button', class: 'c-' + c + ((t.color || 'violet') === c ? ' on' : ''), 'aria-label': c, onclick: e => { t.color = c; [...sws.children].forEach(x => x.classList.remove('on')); e.currentTarget.classList.add('on'); } }));
        body.append(field('Farbe', sws));
      }

      if (t.type === 'action')
        body.append(el('label', { class: 'check' }, 'Vor dem Ausführen nachfragen', sw(t.confirm, v => { t.confirm = v; })));

      if (!custom) {
        // size and spot on the grid (dragging in edit mode does the same, this is for exact control)
        const pg = S.layout.pages[+where.p] || curPage(), cols = pageCols(pg);
        if (!t.pos) {
          // a new volume slider starts upright (1×2) like a mixer channel, unless the wide one was picked
          const s = t.type === 'slider' && !t.wide ? { w: 1, h: 2 } : defSize(t, cols), want = wantAt || { x: 0, y: Math.max(0, pageRows(pg) - 1) };
          t.pos = { x: Math.min(want.x, cols - s.w), y: want.y, w: s.w, h: s.h };
        }
        delete t.wide;
        t.pos.w = Math.max(MIN_W[t.type] || 1, Math.min(t.pos.w, cols));
        if (t.type === 'slider') {
          const shape = t.pos.w >= 2 * t.pos.h ? 'wide' : t.pos.w === 1 && t.pos.h === 1 ? 'small' : 'tall';
          body.append(field('Form', segTabs([['tall', 'Hochkant'], ['small', 'Klein (1 Feld)'], ['wide', 'Breit']], shape, k => {
            if (k === 'wide') { t.pos.w = Math.min(cols, 4); t.pos.h = 1; }
            else { t.pos.w = 1; t.pos.h = k === 'tall' ? 2 : 1; }
            t.pos.x = Math.min(t.pos.x, cols - t.pos.w);
            draw();
          }), 'Hochkant und Klein: zum Einstellen auf dem Regler nach oben oder unten wischen (am PC auch Mausrad). Das Symbol schaltet stumm.'));
        }
        const widths = [];
        for (let w = MIN_W[t.type] || 1; w <= cols; w++) widths.push([w, w === cols ? 'Ganze Zeile' : String(w)]);
        body.append(el('div', { class: 'size-row' },
          field('Breite', segIn(t.pos, 'w', widths)),
          field('Höhe', segIn(t.pos, 'h', [[1, '1'], [2, '2'], [3, '3'], [4, '4']]))));
        if (!isNew) {
          const posLabel = el('span', { class: 'pos-label' });
          const paintPos = () => { posLabel.textContent = 'Spalte ' + (t.pos.x + 1) + ' · Zeile ' + (t.pos.y + 1); };
          const nudge = (dx, dy) => {
            t.pos.x = Math.max(0, Math.min(cols - t.pos.w, t.pos.x + dx));
            t.pos.y = Math.max(0, t.pos.y + dy);
            paintPos();
          };
          const nb = (icon, dx, dy, label) => el('button', { class: 'icon-btn', type: 'button', 'aria-label': label, onclick: () => nudge(dx, dy) }, ic(icon));
          paintPos();
          body.append(field('Position', el('div', { class: 'pos-pad' }, nb('left', -1, 0, 'Links'), nb('up', 0, -1, 'Hoch'), posLabel, nb('down', 0, 1, 'Runter'), nb('right', 1, 0, 'Rechts')),
            'Wird beim Speichern übernommen – eine Kachel am Ziel rückt zur Seite. Schneller geht es im Bearbeiten-Modus per Ziehen.'));
        }
        if (S.layout.pages.length > 1)
          body.append(field('Deck-Seite', selectIn(where, 'p', S.layout.pages.map((p, i) => [String(i), p.name]))));
      }

      body.append(el('div', { class: 'sheet-actions' },
        isNew || custom ? null : el('button', { class: 'btn danger', type: 'button', onclick: async () => {
          if (!await confirmSheet('Kachel löschen?', null, 'Löschen', true)) return;
          remember();
          const cur = findTile(t.id);
          if (cur) cur.page.tiles.splice(cur.i, 1);
          saveLayout();
          close();
          Deck.draw();
        } }, ic('trash')),
        el('button', { class: 'btn primary', type: 'button', onclick: save }, ic('check'), isNew ? 'Hinzufügen' : 'Speichern')));
    };

    const save = () => {
      if (t.type === 'action') {
        const need = { key: 'keys', appkey: 'keys', text: 'text', url: 'url', launch: 'target', cmd: 'cmd', macro: 'script', kill: 'procs', device: 'id' }[t.a.t];
        if (need && !String(t.a[need] || '').trim().replace(/^https:\/\/$/, '')) return toast('Bitte erst ausfüllen, was passieren soll', 'err');
        if (t.a.t === 'appkey' && !t.a.id && !t.a.procs) return toast('Bitte eine App wählen', 'err');
      }
      if (!t.label) delete t.label;
      close();
      if (target) return target.save(t);
      remember();
      const dest = S.layout.pages[+where.p] || curPage();
      const cur = findTile(t.id);
      if (cur) cur.page.tiles.splice(cur.i, 1);
      const cols = pageCols(dest);
      const w = Math.max(MIN_W[t.type] || 1, Math.min(cols, t.pos ? t.pos.w : defSize(t, cols).w)), h = t.pos ? t.pos.h : 1;
      const keep = cur && cur.page === dest ? { x: Math.min(t.pos.x, cols - w), y: t.pos.y, w, h } : null;
      const draft = t.pos;
      t.pos = null;
      dest.tiles.push(t);
      if (keep) placeAt(dest, t, keep); // same page: the spot from the editor, others make room
      else {
        const want = isNew && draft ? draft : { x: 0, y: Math.max(0, pageRows(dest) - 1) };
        const r = { x: Math.min(want.x, cols - w), y: want.y, w, h };
        t.pos = fits(dest, r, t) ? r : freeSpot(dest, w, h, r.x, r.y, t);
      }
      saveLayout();
      if (current === Deck) Deck.draw();
    };

    draw();
    const close = sheet(target ? target.title : isNew ? (t.type === 'action' ? ACTS[t.a.t].name : kind.name) + ' hinzufügen' : 'Kachel bearbeiten', body);
  }

  // ---------- navigation: tabs, each holding a stack of pages ----------

  const TABS = PC
    ? [['deck', 'Deck', 'grid', Deck, 'Steuern'], ['media', 'Medien', 'music', MediaView, 'Steuern'], ['clips', 'Clips', 'video', ClipsView, 'Steuern'], ['apps', 'Apps & Addons', 'puzzle', AppsView, 'Steuern'],
       ['mixer', 'Mixer', 'sliders', Mixer, 'Steuern'], ['display', 'Handy als Bildschirm', 'devices', DisplayView, 'Steuern'], ['system', 'System', 'cpu', SysSub, 'PC'], ['power', 'Energie', 'power', PowerSub, 'PC'],
       ['windows', 'Fenster', 'window', WinSub, 'PC'], ['tools', 'Werkzeuge', 'clipboard', ToolsSub, 'PC'],
       ['connect', 'Handy verbinden', 'qr', ConnectView, ''], ['settings', 'Einstellungen', 'settings', SettingsView, '']]
    : [['deck', 'Deck', 'grid', Deck], ['media', 'Medien', 'music', MediaView], ['clips', 'Clips', 'video', ClipsView], ['apps', 'Apps', 'puzzle', AppsView], ['mixer', 'Mixer', 'sliders', Mixer],
       ['more', 'Mehr', 'more', More]];

  const NAV = { tab: null, stack: [] };

  function mount() {
    const view = NAV.stack[NAV.stack.length - 1];
    [...$('#view').children].forEach(c => { c.style.display = c === view.el ? '' : 'none'; });
    current = view;
    const back = $('#backBtn');
    if (back) back.style.display = NAV.stack.length > 1 ? '' : 'none';
    const t = $('#viewTitle');
    if (t) t.textContent = view.title || '';
    document.querySelectorAll('.edit-btn').forEach(b => { b.style.display = view === Deck ? '' : 'none'; });
    paintUndo();
    startPoll();
  }

  function enter(view) {
    view.el = el('div', { class: 'page' });
    $('#view').append(view.el);
    view.render(view.el);
  }

  function show(tab) {
    const def = TABS.find(t => t[0] === tab) || TABS[0];
    stopPoll();
    if (S.editing) setEditing(false);
    NAV.stack.forEach(v => { if (v.destroy) v.destroy(); });
    NAV.stack = [];
    $('#view').innerHTML = '';
    NAV.tab = def[0];
    if (def[0] !== 'connect') LS.set('tab', def[0]);
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b.dataset.tab === def[0]));
    $('#view').className = 'view-' + def[0];
    NAV.stack.push(def[3]);
    enter(def[3]);
    window.scrollTo(0, 0);
    mount();
  }

  function push(view) {
    stopPoll();
    NAV.stack[NAV.stack.length - 1].scrollY = window.scrollY;
    NAV.stack.push(view);
    enter(view);
    history.pushState({ depth: NAV.stack.length }, '');
    window.scrollTo(0, 0);
    mount();
  }

  function pop() {
    if (NAV.stack.length < 2) return;
    stopPoll();
    const top = NAV.stack.pop();
    if (top.destroy) top.destroy();
    top.el.remove();
    mount();
    window.scrollTo(0, NAV.stack[NAV.stack.length - 1].scrollY || 0);
  }

  function goBack() { if (NAV.stack.length > 1) history.back(); }

  window.addEventListener('popstate', () => {
    if (skipPop) { skipPop = false; return; }
    if (viewer) { viewer.close(true); return; }
    if (sheets.length) { sheets[sheets.length - 1](); if (NAV.stack.length > 1) history.pushState({ depth: NAV.stack.length }, ''); return; }
    pop();
  });
  window.pcGo = v => { if (S.pin && $('#view')) show(v); };

  async function startApp() {
    const app = $('#app');
    app.innerHTML = '';
    document.body.classList.toggle('pc', PC);
    const editBtn = () => el('button', { class: 'btn small edit-btn', 'aria-label': 'Bearbeiten', onclick: () => setEditing(!S.editing) }, ic('edit'), el('span', null, 'Bearbeiten'));
    const status = () => el('small', { class: 'status' }, el('i', { class: 'dot' }), el('span', { class: 'status-text' }, 'Verbunden'), PC ? null : el('span', null, '· ' + (S.name || 'PC')));
    const tabBtn = ([k, l, i]) => el('button', { class: 'tab', 'data-tab': k, onclick: () => { buzz(); show(k); } }, ic(i), el('span', null, l));
    const topBar = () => el('header', { class: 'top' },
      el('button', { id: 'backBtn', class: 'icon-btn back-btn', 'aria-label': 'Zurück', onclick: goBack, style: 'display:none' }, ic('back')),
      el('div', { class: 'top-title' }, el('h1', { id: 'viewTitle' }, ''), PC ? null : status()),
      el('div', { class: 'top-actions' },
        el('button', { class: 'icon-btn undo-btn', 'aria-label': 'Rückgängig', title: 'Rückgängig', style: 'display:none', onclick: undoLast }, ic('undo')),
        editBtn()));

    if (PC) {
      const groups = [];
      for (const t of TABS) {
        let g = groups.find(x => x.name === t[4]);
        if (!g) groups.push(g = { name: t[4], items: [] });
        g.items.push(t);
      }
      app.append(el('div', { class: 'pc-shell' },
        el('aside', { class: 'side' },
          el('div', { class: 'brand' }, el('img', { src: '/logo-64.png', alt: '' }), el('div', null, el('b', null, 'PC Remote'), status())),
          groups.map(g => el('nav', { class: 'side-nav' + (g.name ? '' : ' bottom') }, g.name ? el('div', { class: 'side-label' }, g.name) : null, g.items.map(tabBtn))),
          el('div', { class: 'side-foot hint' }, S.name)),
        el('div', { class: 'pc-main' }, topBar(), el('main', { id: 'view' }, el('div', { class: 'empty' }, 'Lade …')))));
    } else {
      app.append(topBar(),
        el('main', { id: 'view' }, el('div', { class: 'empty' }, 'Lade …')),
        el('nav', { class: 'tabs' }, el('div', { class: 'tabs-in' }, TABS.map(tabBtn))));
    }
    S.online = true;
    document.title = PC ? 'PC Remote' : (S.name ? S.name + ' · ' : '') + 'PC Remote';
    if (PC) watchPairing();

    await Promise.all([loadApps(), loadAddons()]);
    await loadLayout();
    api('/api/spotify?what=status').then(s => { S.sp = s; }).catch(() => { });
    const hash = location.hash.slice(1);
    show(hash && TABS.some(t => t[0] === hash) ? hash : LS.get('tab', 'deck'));
    if (hash) history.replaceState(null, '', location.pathname + location.search);

    // The PC scans apps in the background at startup; pick them up once ready.
    for (let i = 0; i < 6 && !S.apps.length; i++) {
      await new Promise(r => setTimeout(r, 2500));
      await loadApps();
      if (S.apps.length) {
        if (!S.layout.custom) S.layout = defaultLayout();
        show(NAV.tab);
      }
    }
  }

  function logout(msg) {
    stopPoll();
    NAV.stack.forEach(v => { if (v.destroy) v.destroy(); });
    NAV.stack = [];
    current = null;
    S.pin = null;
    S.token = null;
    S.deviceId = null;
    LS.del('pin');
    LS.del('token');
    clearInterval(pairWatch);
    sheets.slice().forEach(c => c());
    renderLogin(msg);
  }

  let loginPoll = null;
  function renderLogin(msg) {
    const app = $('#app');
    app.innerHTML = '';
    clearInterval(loginPoll);
    const sub = el('p', null, 'Mit deinem PC verbinden');
    const err = el('div', { class: 'err-text' }, msg || '');
    const askBox = el('div', { class: 'ask-box' });
    const failMsg = x => x.message === 'Failed to fetch' ? 'PC nicht erreichbar – läuft PC Remote?' : x.message;

    // 1) no PIN, no scanning: the PC asks "allow this device?"
    const askBtn = el('button', { class: 'btn primary block', type: 'button', onclick: async () => {
      err.textContent = '';
      askBtn.disabled = true;
      try {
        const r = await fetch('/api/pair/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: deviceName() }), cache: 'no-store' });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'Fehler ' + r.status);
        askBtn.style.display = 'none';
        askBox.innerHTML = '';
        askBox.append(el('div', { class: 'hint' }, 'Code'), el('div', { class: 'ask-code' }, d.code),
          el('p', { class: 'hint' }, 'Am PC erscheint jetzt „Gerät verbinden?“. Prüfe, dass dort derselbe Code steht, und klicke „Erlauben“.'),
          el('div', { class: 'disp-wait', style: 'justify-content:center' }, el('span', { class: 'spinner' }), 'Warte auf den PC …'));
        const t0 = Date.now();
        loginPoll = setInterval(async () => {
          try {
            const s = await fetch('/api/pair/status?req=' + enc(d.req) + '&secret=' + enc(d.secret), { cache: 'no-store' }).then(x => x.json());
            if (s.state === 'ok') { clearInterval(loginPoll); saveToken(s.token); verify(); return; }
            if (s.state === 'no' || s.state === 'gone' || Date.now() - t0 > 180000) {
              clearInterval(loginPoll);
              askBox.innerHTML = '';
              askBtn.style.display = '';
              askBtn.disabled = false;
              err.textContent = s.state === 'no' ? 'Am PC abgelehnt.' : 'Keine Antwort vom PC – bitte nochmal versuchen.';
            }
          } catch (e) { }
        }, 1500);
      } catch (x) { err.textContent = failMsg(x); askBtn.disabled = false; }
    } }, ic('phone'), 'Am PC bestätigen');

    // 2) or with the PIN
    const pin = el('input', { class: 'in pin-in', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: '8', placeholder: 'PIN', 'aria-label': 'PIN' });
    const btn = el('button', { class: 'btn block', type: 'submit' }, 'Mit PIN verbinden');
    const form = el('form', { class: 'login', onsubmit: async e => {
      e.preventDefault();
      const v = pin.value.trim();
      if (!v) return pin.focus();
      btn.disabled = true;
      err.textContent = '';
      try {
        if (isLocal()) {
          // a browser on the PC itself is not stored as a device
          const r = await fetch('/api/auth', { headers: { 'X-Pin': v }, cache: 'no-store' });
          const d = await r.json().catch(() => ({}));
          if (!r.ok) throw new Error(d.error || 'Fehler ' + r.status);
          S.pin = v;
          LS.set('pin', v);
        } else await pairWithPin(v);
        verify();
      } catch (x) {
        err.textContent = failMsg(x);
        pin.select();
      }
      btn.disabled = false;
    } },
      el('img', { class: 'logo', src: '/logo-192.png', alt: '' }),
      el('h1', null, 'PC Remote'), sub,
      askBtn, askBox, err,
      el('div', { class: 'or-line' }, el('span', null, 'oder mit PIN')),
      pin, btn,
      el('p', { class: 'hint' }, 'Einmal verbinden reicht – danach öffnet sich PC Remote auf diesem Gerät von selbst. Die PIN steht am PC unter „Handy verbinden“.'));
    app.append(el('div', { class: 'center' }, form));
    fetch('/api/ping', { cache: 'no-store' }).then(r => r.json()).then(d => { sub.textContent = 'Mit „' + d.name + '“ verbinden'; }).catch(() => { });
  }

  async function verify() {
    try {
      const d = await api('/api/auth');
      S.name = d.name;
      S.local = !!d.local;
      S.deviceId = d.device || null;
      startApp();
    } catch (e) {
      if (e.status === 401) return;
      const app = $('#app');
      app.innerHTML = '';
      app.append(el('div', { class: 'center' }, el('div', { class: 'login' },
        el('img', { class: 'logo', src: '/logo-192.png', alt: '' }),
        el('h1', null, 'Keine Verbindung'),
        el('p', null, e.status === 429 ? e.message : 'Der PC ist gerade nicht erreichbar. Ist er an und läuft PC Remote?'),
        el('button', { class: 'btn primary block', onclick: verify }, ic('refresh'), 'Erneut versuchen'))));
    }
  }

  // ---------- connect page (shown on the PC itself) ----------

  function loadQr() {
    return new Promise((res, rej) => {
      if (window.qrcode) return res(window.qrcode);
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js';
      s.onload = () => window.qrcode ? res(window.qrcode) : rej(new Error('qr'));
      s.onerror = rej;
      document.head.append(s);
    });
  }

  function qrSvg(qrcode, text) {
    const q = qrcode(0, 'M');
    q.addData(text);
    q.make();
    const n = q.getModuleCount();
    let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + c + ' ' + r + 'h1v1h-1z';
    return '<svg viewBox="-1 -1 ' + (n + 2) + ' ' + (n + 2) + '" shape-rendering="crispEdges"><path fill="#0b0c10" d="' + d + '"/></svg>';
  }

  // Without a target it renders the full-screen page (browser on the PC), with one it fills that element (PC app).
  async function renderConnect(target) {
    const host = target || $('#app');
    host.innerHTML = '';
    let d;
    try {
      const r = await fetch('/api/connect', { cache: 'no-store' });
      d = await r.json();
      if (!r.ok) throw new Error(d.error);
    } catch (e) {
      host.append(el('div', { class: 'center' }, el('div', { class: 'login' },
        el('h1', null, 'Nur am PC'), el('p', null, 'Diese Seite funktioniert nur direkt am PC.'),
        el('a', { class: 'btn primary block', href: '/' }, 'Zur Fernbedienung'))));
      return;
    }
    let url = d.urls[0];
    const qrBox = el('div', { class: 'qr-box' }, el('div', { class: 'qr-fallback' }, 'QR-Code wird erstellt …'));
    const urlText = el('div', { class: 'url' }, url);
    const drawQr = () => {
      urlText.textContent = url;
      loadQr().then(qr => { qrBox.innerHTML = qrSvg(qr, url + '/#pin=' + d.pin); })
        .catch(() => { qrBox.innerHTML = ''; qrBox.append(el('div', { class: 'qr-fallback' }, 'Für den QR-Code braucht der PC Internet. Gib stattdessen die Adresse am Handy ein.')); });
    };
    const urlChips = d.urls.length > 1 ? el('div', { class: 'chips', style: 'margin-top:10px' }, d.urls.map(u =>
      el('button', { class: 'chip' + (u === url ? ' on' : ''), onclick: e => { url = u; [...e.currentTarget.parentNode.children].forEach(c => c.classList.remove('on')); e.currentTarget.classList.add('on'); drawQr(); } }, u.replace('http://', '')))) : null;

    const content = el('div', { class: 'connect' },
      el('div', null, qrBox, urlChips),
      el('div', null,
        target ? null : el('div', { class: 'brand' }, el('img', { src: '/logo-64.png', alt: '' }), el('div', null, el('b', null, 'PC Remote'), el('small', null, d.name))),
        target ? null : el('h1', null, 'Handy verbinden'),
        el('p', { class: 'lead' }, 'Steuere Lautstärke, Musik, Apps, Spiele und Maus vom Handy aus.'),
        el('ol', { class: 'steps' },
          el('li', null, 'Handy ins selbe WLAN wie diesen PC.'),
          el('li', null, 'QR-Code mit der Handy-Kamera scannen – die Fernbedienung öffnet sich und verbindet sich automatisch.'),
          el('li', null, 'Im Browser-Menü „Zum Startbildschirm hinzufügen“ – dann startet sie wie eine App.')),
        el('div', { class: 'card manual' },
          el('div', null, el('div', { class: 'hint' }, 'Oder am Handy eintippen'), urlText),
          el('div', { style: 'text-align:right' }, el('div', { class: 'hint' }, 'PIN'), el('div', { class: 'pin' }, d.pin))),
        el('p', { class: 'hint' }, 'Klappt es nicht? Fragt Windows beim ersten Start nach der Firewall, „Private Netzwerke“ erlauben. Und das Handy darf nicht im Gäste-WLAN sein.'),
        target ? null : el('button', { class: 'btn', style: 'margin-top:8px', onclick: () => { S.pin = d.pin; LS.set('pin', d.pin); history.replaceState(null, '', '/'); verify(); } }, ic('grid'), 'Fernbedienung hier am PC öffnen')));
    host.append(target ? content : el('div', { class: 'center' }, content));
    drawQr();
  }

  // ---------- boot ----------

  async function boot() {
    if (PC) document.body.classList.add('pc');
    const m = /pin=(\d+)/.exec(location.hash);
    if (m) {
      S.pin = m[1];
      history.replaceState(null, '', location.pathname + location.search);
    }
    if (location.hash === '#connect' && !PC) return renderConnect();
    if (PC || isLocal()) {
      // on the PC itself: PIN straight from the PC, no device key
      S.token = null;
      if (PC || !S.pin) {
        try {
          const r = await fetch('/api/connect', { cache: 'no-store' });
          if (r.ok) { S.pin = (await r.json()).pin; LS.set('pin', S.pin); }
        } catch (e) { }
      }
    } else {
      // a QR code was scanned although this device is already paired: keep the old key if it still works
      if (m && S.token) {
        const ok = await fetch('/api/auth', { headers: { 'X-Token': S.token }, cache: 'no-store' }).then(r => r.ok).catch(() => false);
        if (!ok) { S.token = null; LS.del('token'); }
      }
      // PIN from the QR code, typed earlier or kept by an older version: pair this device once
      if (!S.token && S.pin) {
        try { await pairWithPin(S.pin); }
        catch (e) {
          S.pin = null;
          LS.del('pin');
          return renderLogin(e.status === 401 ? 'Die PIN stimmt nicht mehr – bitte neu verbinden.' : e.status === 0 || e.message === 'Failed to fetch' ? 'PC nicht erreichbar – läuft PC Remote?' : e.message);
        }
      }
    }
    if (!S.token && !S.pin) return renderLogin();
    verify();
  }

  window.addEventListener('hashchange', () => {
    const h = location.hash.slice(1);
    if (!h) return;
    if (PC && S.pin && $('#view') && TABS.some(t => t[0] === h)) { show(h); history.replaceState(null, '', location.pathname + location.search); }
    else if (h === 'connect' && !PC) renderConnect();
  });
  boot();
})();
